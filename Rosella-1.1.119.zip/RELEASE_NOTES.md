## Rosella 1.1.119

- Feed cards: larger white title, aligned to the right for Arabic (RTL) text.
- Dreams without an image now use a compact card with a gradient based on the mood.
- New action row on every card: favorite, interpretation, private/public, share.
