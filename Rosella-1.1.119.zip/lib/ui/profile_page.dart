import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../core/strings.dart';
import '../core/symbols.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'dream_detail.dart';
import 'settings_page.dart';
import 'share_card.dart';
import 'social_pages.dart';
import 'widgets.dart';

/// The 4th tab: an Instagram-style profile. Everything is stored on this device only.
class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _tab = 0; // 0 posts, 1 private
  bool _privOk = false;

  Future<void> _selectTab(AppState app, int i) async {
    if (i == 1 && !_privOk) {
      final ok = await app.external(() => app.authenticate());
      if (!ok || !mounted) return;
      _privOk = true;
    }
    if (i != 1) _privOk = false;
    Haptics.selection();
    setState(() => _tab = i);
  }

  void _open(Dream d) => Navigator.of(context)
      .push(CupertinoPageRoute<void>(builder: (_) => DreamDetailPage(id: d.id)));

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final name = app.profileName.trim().isNotEmpty
        ? app.profileName.trim()
        : (app.userName ?? context.t('prof_default_name'));
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    final hasPhoto = avatar != null && File(avatar).existsSync();
    final pub = app.dreams.where((d) => !d.priv).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final priv = app.dreams.where((d) => d.priv).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    Widget stat(String n, String label, VoidCallback? onTap) => Expanded(
          child: Pressable(
            scale: 0.95,
            onTap: onTap,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(n,
                    style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.dim, fontSize: 12.5)),
              ],
            ),
          ),
        );
    final tabIcons = [Icons.view_agenda_outlined, Icons.lock_outline_rounded];
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text(context.t('prof_title'),
                      style: TextStyle(
                          color: c.text,
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.8)),
                ),
              ),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  RoundIconButton(
                    icon: Icons.settings_rounded,
                    onTap: () => Navigator.of(context).push(
                        CupertinoPageRoute<void>(builder: (_) => const AppSettingsRoute())),
                  ),
                  if (app.updateAvailable)
                    Positioned(
                      right: 2,
                      top: 2,
                      child: Container(
                        width: 11,
                        height: 11,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF3B30),
                          shape: BoxShape.circle,
                          border: Border.all(color: c.bg, width: 1.5),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),
          FadeSlide(
            child: Row(
              children: [
                Pressable(
                  scale: 0.95,
                  onTap: hasPhoto
                      ? () => Navigator.of(context).push(PageRouteBuilder<void>(
                            opaque: false,
                            transitionDuration: const Duration(milliseconds: 220),
                            pageBuilder: (_, a, __) => FadeTransition(
                                opacity: a,
                                child: PhotoViewerPage(path: avatar, tag: 'profile_photo')),
                          ))
                      : null,
                  child: Hero(
                      tag: 'profile_photo',
                      child: ProfileAvatar(path: avatar, name: name, size: 88)),
                ),
                const SizedBox(width: 12),
                if (app.profileShowCount) stat('${pub.length}', context.t('prof_stat_dreams'), null),
                if (app.profileShowStreak) stat('${app.streakDays}', context.t('prof_stat_streak'), null),
                if (app.profileShowLucid)
                  stat('${app.dreams.where((d) => d.lucid).length}', context.t('prof_stat_lucid'), null),
                if (app.profileShowRecurring)
                  stat('${recurringSymbols(pub, max: 50).length}', context.t('prof_stat_recurring'), null),
              ],
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 30,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  if (app.profileBio.trim().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(app.profileBio.trim(),
                          textDirection: textDirOf(app.profileBio, Directionality.of(context)),
                          style: TextStyle(color: c.text, fontSize: 14.5, height: 1.5)),
                    ),
                  if (app.unlocked.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final a in kAchievements)
                            if (app.unlocked.contains(a.id))
                              Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: c.border),
                                  color: al(c.a, 0.14),
                                ),
                                child: Icon(a.icon, size: 20, color: c.text),
                              ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 60,
            child: Row(
              children: [
                Expanded(
                  child: GradientButton(
                    label: context.t('prof_edit'),
                    onTap: () => Navigator.of(context).push(
                        CupertinoPageRoute<void>(builder: (_) => const ProfileEditPage())),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              for (var i = 0; i < 2; i++)
                Expanded(
                  child: Pressable(
                    scale: 0.96,
                    onTap: () => _selectTab(app, i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                              color: _tab == i ? c.text : c.border, width: _tab == i ? 2 : 1),
                        ),
                      ),
                      child: Icon(tabIcons[i], color: _tab == i ? c.text : c.dim, size: 24),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: KeyedSubtree(
              key: ValueKey(_tab),
              child: _postsList(context, app, name, hasPhoto ? avatar : null,
                  _tab == 1 ? priv : pub),
            ),
          ),
        ],
      ),
    );
  }

  Widget _grid(BuildContext context, AppState app, List<Dream> list) {
    final c = context.colors;
    if (list.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Text(context.t('prof_no_dreams'), style: TextStyle(color: c.dim, fontSize: 14)),
        ),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: list.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 0.95),
      itemBuilder: (_, i) {
        final d = list[i];
        final img = app.abs(d.image);
        final has = img != null && File(img).existsSync();
        final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
        return Pressable(
          scale: 0.97,
          onTap: () => _open(d),
          child: Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: c.border),
              color: c.surface,
              gradient: has ? null : LinearGradient(colors: [al(c.a, 0.28), al(c.b, 0.22)]),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (has) Image.file(File(img), fit: BoxFit.cover, cacheWidth: 500),
                if (has)
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0x00000000), Color(0xCC000000)],
                      ),
                    ),
                  ),
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(color: Color(0x66000000), shape: BoxShape.circle),
                    child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 15)),
                  ),
                ),
                if (d.friends && !d.priv)
                  const Positioned(
                      top: 12, right: 12, child: Icon(Icons.group_rounded, size: 17, color: Colors.white)),
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 10,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(t,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textDirection: textDirOf(t, Directionality.of(context)),
                          style: TextStyle(
                              color: has ? Colors.white : c.text,
                              fontSize: 15,
                              fontWeight: FontWeight.w800)),
                      Text(fmtDate(d.createdAt, app.lang),
                          style: TextStyle(
                              color: has ? Colors.white70 : c.dim, fontSize: 11.5)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _postsList(
      BuildContext context, AppState app, String name, String? avatar, List<Dream> list) {
    final c = context.colors;
    if (list.isEmpty) return _grid(context, app, list);
    return Column(
      children: [
        for (final d in list)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: PostCard(
              dream: d,
              name: name,
              avatar: avatar,
              onTap: () => _open(d),
              color: c,
            ),
          ),
      ],
    );
  }
}

class PostCard extends StatelessWidget {
  final Dream dream;
  final String name;
  final String? avatar;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool selected;
  final AppColors color;
  const PostCard(
      {super.key,
      required this.dream,
      required this.name,
      required this.avatar,
      required this.onTap,
      this.onLongPress,
      this.selected = false,
      required this.color});

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final c = color;
    final d = dream;
    final img = app.abs(d.image);
    final has = img != null && File(img).existsSync();
    final dir = Directionality.of(context);
    final title = d.title.trim();
    final body = d.content.replaceAll(RegExp(r'\s+'), ' ').trim();
    final tdir = textDirOf('$title $body', dir);
    return Pressable(
      scale: 0.985,
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: selected ? c.a : c.border, width: selected ? 2 : 1),
          color: al(c.surface, 0.6),
          gradient: has
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [al(moodColor(d.mood), 0.30), al(c.surface, 0.7)],
                ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
              child: Row(
                children: [
                  ProfileAvatar(path: avatar, name: name, size: 38),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontSize: 14.5, fontWeight: FontWeight.w800)),
                        Text(fmtDate(d.createdAt, app.lang),
                            style: TextStyle(color: c.dim, fontSize: 12)),
                      ],
                    ),
                  ),
                  if (d.pin) Icon(Icons.push_pin_rounded, size: 18, color: c.dim),
                  if (d.fav)
                    const Padding(
                      padding: EdgeInsetsDirectional.only(start: 6),
                      child: Icon(Icons.star_rounded, size: 19, color: Color(0xFFFFC94D)),
                    ),
                  if (selected)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(start: 6),
                      child: Icon(Icons.check_circle_rounded, size: 22, color: c.a),
                    ),
                ],
              ),
            ),
            if (has)
              Image.file(File(img), height: 280, width: double.infinity, fit: BoxFit.cover, cacheWidth: 1000),
            Directionality(
              textDirection: tdir,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title.isNotEmpty)
                      SizedBox(
                        width: double.infinity,
                        child: Text(title,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 21,
                                height: 1.3,
                                fontWeight: FontWeight.w800)),
                      ),
                    if (body.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: SizedBox(
                          width: double.infinity,
                          child: Text(body,
                              maxLines: has ? 3 : 6,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: al(Colors.white, 0.72), fontSize: 14.5, height: 1.5)),
                        ),
                      ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        _chip(c, moodEmoji(d.mood)),
                        if (d.lucid) _chip(c, '#${context.t('lucid_tag')}'),
                        for (final t in d.tags.take(3)) _chip(c, '#$t'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Divider(height: 1, indent: 14, endIndent: 14, color: al(Colors.white, 0.08)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _act(c, d.fav ? Icons.star_rounded : Icons.star_border_rounded,
                      d.fav ? const Color(0xFFFFC94D) : null, () {
                    Haptics.selection();
                    app.updateDream(d.copyWith(fav: !d.fav));
                  }),
                  _act(
                      c,
                      d.interpretation != null
                          ? Icons.auto_awesome_rounded
                          : Icons.auto_awesome_outlined,
                      d.interpretation != null ? c.a : null,
                      onTap),
                  _act(c, d.priv ? Icons.lock_rounded : Icons.lock_open_rounded, null, () async {
                    if (d.priv) {
                      final ok = await app.external(() => app.authenticate());
                      if (!ok || !context.mounted) return;
                    }
                    app.updateDream(d.copyWith(priv: !d.priv));
                    if (context.mounted) toast(context, app.tr(d.priv ? 'priv_off' : 'priv_on'));
                  }),
                  _act(c, Icons.ios_share_rounded, null, () {
                    if (d.priv) {
                      toast(context, app.tr('priv_no_share'));
                      return;
                    }
                    Navigator.of(context).push(
                        CupertinoPageRoute<void>(builder: (_) => ShareCardPage(id: d.id)));
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _act(AppColors c, IconData icon, Color? tint, VoidCallback onTap) => Pressable(
        scale: 0.85,
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          child: Icon(icon, size: 24, color: tint ?? c.dim),
        ),
      );

  Widget _chip(AppColors c, String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14), border: Border.all(color: c.border)),
        child: Text(t, style: TextStyle(color: c.text, fontSize: 12.5)),
      );
}

/// The app settings (the old 4th tab), opened from the gear on the profile page.
class AppSettingsRoute extends StatelessWidget {
  const AppSettingsRoute({super.key});

  @override
  Widget build(BuildContext context) => PageScaffold(
        child: Column(
          children: const [
            TopBar(),
            Expanded(child: SettingsPage()),
          ],
        ),
      );
}

class ProfileAvatar extends StatelessWidget {
  final String? path;
  final String name;
  final double size;
  const ProfileAvatar({required this.path, required this.name, required this.size});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final letter = name.trim().isEmpty ? 'R' : name.trim().characters.first.toUpperCase();
    final has = path != null && File(path!).existsSync();
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: al(c.text, 0.55), width: 2),
      ),
      child: ClipOval(
        child: has
            ? Image.file(File(path!),
                fit: BoxFit.cover, cacheWidth: (size * 3).toInt())
            : Container(
                color: c.surface,
                alignment: Alignment.center,
                child: Text(letter,
                    style: TextStyle(
                        color: c.text, fontSize: size * 0.42, fontWeight: FontWeight.w800)),
              ),
      ),
    );
  }
}

class _FeaturedCard extends StatelessWidget {
  final Dream dream;
  const _FeaturedCard({required this.dream});

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final c = context.colors;
    final img = app.abs(dream.image);
    final title = dream.title.trim().isEmpty ? fmtDate(dream.createdAt, app.lang) : dream.title;
    final body = dream.content.replaceAll(RegExp(r'\s+'), ' ').trim();
    return Pressable(
      scale: 0.98,
      onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: dream.id))),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: c.border),
          color: c.surface,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (img != null && File(img).existsSync())
              Image.file(File(img),
                  height: 180, width: double.infinity, fit: BoxFit.cover, cacheWidth: 900)
            else
              Container(
                height: 110,
                alignment: Alignment.center,
                decoration: BoxDecoration(gradient: LinearGradient(colors: [al(c.a, 0.4), al(c.b, 0.4)])),
                child: Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 44)),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Color(0xFFFFC94D), size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textDirection: textDirOf(title, Directionality.of(context)),
                            style: TextStyle(
                                color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                  if (body.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(body,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        textDirection: textDirOf(body, Directionality.of(context)),
                        style: TextStyle(color: c.dim, fontSize: 14, height: 1.45)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to choose the dream shown on the profile (private dreams are never offered).
Future<void> pickFeaturedDream(BuildContext context) async {
  final app = context.read<AppState>();
  final list = app.dreams.where((d) => !d.priv).toList();
  final c = context.colors;
  if (list.isEmpty) {
    toast(context, context.t('prof_no_dreams'));
    return;
  }
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: c.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.7),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(context.t('prof_featured_pick'),
                        style: TextStyle(
                            color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                  if (app.featuredId != null)
                    TextButton(
                      onPressed: () {
                        app.updateProfile(clearFeatured: true);
                        Navigator.of(ctx).pop();
                      },
                      child: Text(context.t('prof_featured_none')),
                    ),
                ],
              ),
            ),
            Flexible(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final d = list[i];
                  final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
                  return ListTile(
                    leading: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
                    title: Text(t,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                    subtitle: Text(fmtDate(d.createdAt, app.lang),
                        style: TextStyle(color: c.dim)),
                    trailing: app.featuredId == d.id
                        ? Icon(Icons.check_rounded, color: c.text)
                        : null,
                    onTap: () {
                      Haptics.selection();
                      app.updateProfile(featured: d.id);
                      Navigator.of(ctx).pop();
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Edit the profile: photo, name, bio and what is shown.
class ProfileEditPage extends StatefulWidget {
  const ProfileEditPage({super.key});

  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  late final TextEditingController _name;
  late final TextEditingController _bio;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _name = TextEditingController(text: app.profileName);
    _bio = TextEditingController(text: app.profileBio);
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final app = context.read<AppState>();
    try {
      final x = await app.external(() => ImagePicker().pickImage(
            source: ImageSource.gallery,
            maxWidth: 800,
            imageQuality: 85,
          ));
      if (x == null) return;
      final rel = app.newFileRel('images', 'jpg');
      await File(x.path).copy(app.abs(rel)!);
      app.updateProfile(avatar: rel);
    } catch (_) {}
  }

  Widget _switch(BuildContext context, String label, bool v, ValueChanged<bool> on) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(color: c.text, fontSize: 15, fontWeight: FontWeight.w600)),
          ),
          Switch(value: v, onChanged: (x) {
            Haptics.selection();
            on(x);
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    InputDecoration deco(String hint) => InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: c.dim),
          filled: true,
          fillColor: al(c.surface, 0.8),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        );
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('prof_edit')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: [
                Center(
                  child: Pressable(
                    onTap: _pickPhoto,
                    child: Stack(
                      children: [
                        ProfileAvatar(
                            path: avatar,
                            name: app.profileName.isEmpty ? (app.userName ?? '') : app.profileName,
                            size: 104),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(color: c.surfaceHi, shape: BoxShape.circle),
                            child: Icon(Icons.photo_camera_rounded, size: 18, color: c.text),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (app.profileAvatar != null)
                  Center(
                    child: TextButton(
                      onPressed: () => app.updateProfile(clearAvatar: true),
                      child: Text(context.t('prof_photo_remove')),
                    ),
                  ),
                const SizedBox(height: 14),
                TextField(
                  controller: _name,
                  maxLength: 40,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_name')),
                  onChanged: (v) => app.updateProfile(name: v),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _bio,
                  maxLength: 160,
                  maxLines: 3,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_bio')),
                  onChanged: (v) => app.updateProfile(bio: v),
                ),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    children: [
                      _switch(context, context.t('prof_show_count'), app.profileShowCount,
                          (v) => app.updateProfile(showCount: v)),
                      _switch(context, context.t('prof_show_streak'), app.profileShowStreak,
                          (v) => app.updateProfile(showStreak: v)),
                      _switch(context, context.t('prof_show_lucid'), app.profileShowLucid,
                          (v) => app.updateProfile(showLucid: v)),
                      _switch(context, context.t('prof_show_recurring'), app.profileShowRecurring,
                          (v) => app.updateProfile(showRecurring: v)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
