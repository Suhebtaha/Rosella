import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'chats_page.dart';
import 'widgets.dart';

class _Msg {
  final bool user;
  final String text;
  final bool error;
  const _Msg(this.user, this.text, {this.error = false});
}

/// Opens the general AI chat (asks for fingerprint / PIN first when the lock is on).
Future<void> openGeneralChat(BuildContext context, {String? gid}) async {
  final app = context.read<AppState>();
  if (app.lockChats) {
    final ok = await app.external(() => app.authenticate());
    if (!ok || !context.mounted) return;
  }
  Navigator.of(context)
      .push(CupertinoPageRoute<void>(builder: (_) => DreamChatPage(gid: gid)));
}

/// Follow-up conversation with the AI about one dream (saved with the dream).
class DreamChatPage extends StatefulWidget {
  /// null = the open "general chat" that has nothing to do with dreams
  final String? id;

  /// general mode only: an existing conversation to continue (null = a new one)
  final String? gid;
  const DreamChatPage({super.key, this.id, this.gid});

  @override
  State<DreamChatPage> createState() => _DreamChatPageState();
}

class _DreamChatPageState extends State<DreamChatPage> {
  final TextEditingController _ctrl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<_Msg> _msgs = [];
  bool _busy = false;
  String _partial = '';
  String? _gid;
  final AudioRecorder _rec = AudioRecorder();
  bool _recording = false;
  bool _transcribing = false;
  int _token = 0;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _gid = widget.gid;
    final List? chat = widget.id == null
        ? (_gid == null ? null : app.generalById(_gid!)?['msgs'] as List?)
        : app.byId(widget.id!)?.chat;
    for (final m in chat ?? const []) {
      _msgs.add(_Msg(m['u'] == true, (m['t'] ?? '').toString()));
    }
  }

  void _openHistory() {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'chats',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 280),
      pageBuilder: (ctx, _, __) => _HistoryDrawer(
        currentId: _gid,
        onPick: (id) {
          Navigator.of(ctx).pop();
          if (id == _gid) return;
          _switchTo(id);
        },
        onNew: () {
          Navigator.of(ctx).pop();
          _switchTo(null);
        },
        onDreams: () {
          Navigator.of(ctx).pop();
          Navigator.of(context).push(
              CupertinoPageRoute<void>(builder: (_) => const ChatsPage()));
        },
      ),
      transitionBuilder: (ctx, anim, _, child) => SlideTransition(
        position: Tween<Offset>(begin: Offset(rtl ? 1 : -1, 0), end: Offset.zero)
            .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: child,
      ),
    );
  }

  void _switchTo(String? id) {
    if (id == null && _msgs.isEmpty) return; // already a fresh chat
    Navigator.of(context).pushReplacement(PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (_, __, ___) => DreamChatPage(gid: id),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  /// Stops the recording and returns the transcribed text ('' when nothing was heard).
  Future<String?> _finishRecording() async {
    final app = context.read<AppState>();
    String? path;
    try {
      path = await _rec.stop();
    } catch (_) {}
    if (!mounted) return null;
    setState(() {
      _recording = false;
      _transcribing = path != null;
    });
    if (path == null) return null;
    String? text;
    try {
      text = await AiService.transcribe(path, app.sttLang, appLang: app.lang);
    } catch (_) {}
    try {
      File(path).deleteSync();
    } catch (_) {}
    if (!mounted) return null;
    setState(() => _transcribing = false);
    if (text == null) {
      toast(context, '${app.tr('transcribe_failed')}\n${AiService.lastError}');
      return null;
    }
    if (text.trim().isEmpty) {
      toast(context, app.tr('no_speech'));
      return null;
    }
    return text.trim();
  }

  Future<void> _startRecording() async {
    final app = context.read<AppState>();
    if (_transcribing || _recording) return;
    var ok = false;
    try {
      ok = await app.external(() => _rec.hasPermission());
    } catch (_) {}
    if (!mounted) return;
    if (!ok) {
      toast(context, app.tr('mic_unavailable'));
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      await _rec.start(
        const RecordConfig(
            encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 16000, numChannels: 1),
        path: '${dir.path}/chat-voice.m4a',
      );
      if (mounted) setState(() => _recording = true);
    } catch (_) {
      if (mounted) toast(context, app.tr('mic_unavailable'));
    }
  }

  /// Mic button: tap (or long-press) to record, tap again to stop. The speech becomes text in the box.
  Future<void> _toggleMic() async {
    if (_transcribing) return;
    if (_recording) {
      final text = await _finishRecording();
      if (text == null || !mounted) return;
      final old = _ctrl.text.trim();
      _ctrl.text = old.isEmpty ? text : '$old $text';
      _ctrl.selection = TextSelection.collapsed(offset: _ctrl.text.length);
      return;
    }
    await _startRecording();
  }

  /// Send button: while recording it stops, transcribes and sends by itself.
  Future<void> _onSend() async {
    if (_busy) {
      _stopReply();
      return;
    }
    if (_transcribing) return;
    if (_recording) {
      final text = await _finishRecording();
      if (text == null || !mounted) return;
      final old = _ctrl.text.trim();
      await _send(old.isEmpty ? text : '$old $text');
      return;
    }
    await _send(_ctrl.text);
  }

  /// Cancels the AI reply that is being written.
  void _stopReply() {
    _token++;
    final part = _partial.trim();
    setState(() {
      if (part.isNotEmpty) _msgs.add(_Msg(false, part));
      _busy = false;
      _partial = '';
    });
    _persist();
  }

  Future<void> _persist() async {
    final app = context.read<AppState>();
    final list = <Map<String, dynamic>>[
      for (final m in _msgs.where((m) => !m.error)) {'u': m.user, 't': m.text}
    ];
    if (widget.id == null) {
      if (list.isNotEmpty) _gid = app.saveGeneral(_gid, list);
      return;
    }
    final d = app.byId(widget.id!);
    if (d == null) return;
    await app.updateDream(d.copyWith(chat: list));
  }

  Future<void> _clear() async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('chat_clear'),
      message: app.tr('chat_clear_confirm'),
      confirm: app.tr('delete'),
    );
    if (!ok || !mounted) return;
    if (widget.id == null) {
      if (_gid != null) app.deleteGeneral(_gid!);
      if (mounted) Navigator.of(context).pop();
      return;
    }
    setState(_msgs.clear);
    await _persist();
  }

  @override
  void dispose() {
    _rec.dispose();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic);
      }
    });
  }

  Future<void> _send(String text) async {
    final q = text.trim();
    final app = context.read<AppState>();
    final general = widget.id == null;
    final d = general ? null : app.byId(widget.id!);
    if (q.isEmpty || _busy || (!general && d == null)) return;
    final history = [
      for (final m in _msgs.where((m) => !m.error))
        {'role': m.user ? 'user' : 'assistant', 'content': m.text}
    ];
    final my = ++_token;
    setState(() {
      _msgs.add(_Msg(true, q));
      _busy = true;
      _partial = '';
      _ctrl.clear();
    });
    _toEnd();
    void partial(String t) {
      if (!mounted || my != _token) return;
      setState(() => _partial = t);
      _toEnd();
    }

    final res = general
        ? await AiService.general(
            lang: app.lang, history: history, question: q, onPartial: partial)
        : await AiService.ask(
            title: d!.title,
            content: d.content,
            mood: d.mood,
            interpretation: d.interpretation,
            lang: app.lang,
            history: history,
            question: q,
            onPartial: partial,
          );
    if (!mounted || my != _token) return;
    setState(() {
      _msgs.add(res == null ? _Msg(false, '${app.tr('chat_failed')}\n${AiService.trace}', error: true) : _Msg(false, res));
      _busy = false;
      _partial = '';
    });
    if (res != null) app.bumpAi();
    _persist();
    _toEnd();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final general = widget.id == null;
    final d = general ? null : app.byId(widget.id!);
    final c = context.colors;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            title: context.t(general ? 'gen_title' : 'chat_title'),
            actions: [
              if (general) ...[
                RoundIconButton(icon: Icons.add_comment_outlined, onTap: () => _switchTo(null)),
                const SizedBox(width: 8),
                RoundIconButton(icon: Icons.menu_rounded, onTap: _openHistory),
              ],
              if (_msgs.isNotEmpty && !_busy) ...[
                if (general) const SizedBox(width: 8),
                RoundIconButton(icon: Icons.delete_outline_rounded, onTap: _clear),
              ],
            ],
          ),
          Expanded(
            child: ListView(
              controller: _scroll,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              children: [
                if (d != null)
                  Panel(
                    radius: 20,
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Icon(Icons.nights_stay_rounded, color: c.a),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontWeight: FontWeight.w800, fontSize: 15),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 14),
                if (_msgs.isEmpty) ...[
                  Text(context.t(general ? 'gen_intro' : 'chat_intro'),
                      style: TextStyle(color: c.dim, fontSize: 14, height: 1.5)),
                  const SizedBox(height: 14),
                  for (final k in general
                      ? const ['gen_s1', 'gen_s2', 'gen_s3']
                      : const ['chat_s1', 'chat_s2', 'chat_s3'])
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Pressable(
                        onTap: () => _send(app.tr(k)),
                        child: Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            color: al(c.a, 0.12),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: al(c.a, 0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: c.a, size: 18),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(context.t(k),
                                    style: TextStyle(
                                        color: c.text,
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
                for (final m in _msgs) _Bubble(msg: m),
                if (_busy && _partial.isNotEmpty) _Bubble(msg: _Msg(false, _partial)),
                if (_busy && _partial.isEmpty)
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: SizedBox(
                        width: 26,
                        height: 26,
                        child: CircularProgressIndicator(strokeWidth: 2.6, color: c.a),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 14 + (bottom > 0 ? 0 : 0)),
            child: Panel(
              padding: const EdgeInsetsDirectional.fromSTEB(16, 4, 6, 4),
              radius: 26,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: _send,
                      style: TextStyle(color: c.text, fontSize: 15.5),
                      decoration: bareInput(context, context.t('chat_hint')),
                    ),
                  ),
                  if (general)
                    Pressable(
                      onTap: _toggleMic,
                      onLongPress: () {
                        HapticFeedback.mediumImpact();
                        _startRecording();
                      },
                      scale: 0.9,
                      child: Container(
                        width: 42,
                        height: 42,
                        margin: const EdgeInsetsDirectional.only(end: 6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _recording
                              ? const Color(0xFFFF3B30)
                              : al(c.text, 0.08),
                        ),
                        child: _transcribing
                            ? Padding(
                                padding: const EdgeInsets.all(11),
                                child: CircularProgressIndicator(
                                    strokeWidth: 2.4, color: c.a),
                              )
                            : Icon(
                                _recording ? Icons.stop_rounded : Icons.mic_rounded,
                                color: _recording ? Colors.white : c.text,
                                size: 21),
                      ),
                    ),
                  Pressable(
                    onTap: _onSend,
                    scale: 0.9,
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration:
                          BoxDecoration(shape: BoxShape.circle, gradient: c.gradient),
                      child: Icon(_busy ? Icons.stop_rounded : Icons.arrow_upward_rounded,
                          color: onAccent(c.a, c.b), size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final _Msg msg;
  const _Bubble({required this.msg});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final user = msg.user;
    final fg = user ? onAccent(c.a, c.b) : (msg.error ? const Color(0xFFFF5470) : c.text);
    return Align(
      alignment: user ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: FadeSlide(
        dy: 10,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          constraints:
              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: user ? c.gradient : null,
            color: user ? null : al(c.surface, c.isDark ? 0.85 : 0.95),
            borderRadius: BorderRadius.circular(20),
            border: user ? null : Border.all(color: c.border),
          ),
          child: SelectableText(msg.text,
              style: TextStyle(color: fg, fontSize: 15, height: 1.55)),
        ),
      ),
    );
  }
}


/// Side panel with the saved general chats (search, open, long-press to delete, new chat).
class _HistoryDrawer extends StatefulWidget {
  final String? currentId;
  final ValueChanged<String> onPick;
  final VoidCallback onNew;
  final VoidCallback onDreams;
  const _HistoryDrawer(
      {required this.currentId,
      required this.onPick,
      required this.onNew,
      required this.onDreams});

  @override
  State<_HistoryDrawer> createState() => _HistoryDrawerState();
}

class _HistoryDrawerState extends State<_HistoryDrawer> {
  final TextEditingController _q = TextEditingController();
  bool _search = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final w = MediaQuery.of(context).size.width;
    final q = _q.text.trim().toLowerCase();
    final list = [
      for (final g in app.generalChats)
        if (q.isEmpty ||
            (g['title'] ?? '').toString().toLowerCase().contains(q) ||
            [for (final m in (g['msgs'] as List)) (m['t'] ?? '').toString().toLowerCase()]
                .any((t) => t.contains(q)))
          g
    ];
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Material(
        color: c.isDark ? const Color(0xFF1C1C1E) : c.bg,
        child: SizedBox(
          width: w * 0.82,
          height: double.infinity,
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
                  child: Row(children: [
                    Expanded(
                      child: Text(context.t('chats_title'),
                          style: TextStyle(
                              color: c.text, fontSize: 26, fontWeight: FontWeight.w800)),
                    ),
                    RoundIconButton(
                      icon: _search ? Icons.close_rounded : Icons.search_rounded,
                      onTap: () => setState(() {
                        _search = !_search;
                        if (!_search) _q.clear();
                      }),
                    ),
                  ]),
                ),
                if (_search)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: Panel(
                      padding: const EdgeInsetsDirectional.fromSTEB(14, 2, 14, 2),
                      radius: 20,
                      child: TextField(
                        controller: _q,
                        autofocus: true,
                        onChanged: (_) => setState(() {}),
                        style: TextStyle(color: c.text, fontSize: 15.5),
                        decoration: bareInput(context, context.t('gen_search')),
                      ),
                    ),
                  ),
                Expanded(
                  child: list.isEmpty
                      ? Center(
                          child: Text(context.t('gen_none'),
                              style: TextStyle(color: c.dim, fontSize: 14.5)))
                      : ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          padding: const EdgeInsets.fromLTRB(8, 4, 8, 12),
                          itemCount: list.length,
                          itemBuilder: (_, i) {
                            final g = list[i];
                            final id = g['id'] as String;
                            final cur = id == widget.currentId;
                            return GestureDetector(
                              onTap: () => widget.onPick(id),
                              onLongPress: () async {
                                final ok = await confirmDialog(
                                  context,
                                  title: app.tr('chat_clear'),
                                  message: app.tr('chat_clear_confirm'),
                                  confirm: app.tr('delete'),
                                );
                                if (!ok) return;
                                app.deleteGeneral(id);
                                if (cur && context.mounted) widget.onNew();
                              },
                              child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 2),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 14),
                                decoration: BoxDecoration(
                                  color: cur ? al(c.a, 0.14) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  (g['title'] ?? '').toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: c.text,
                                      fontSize: 16,
                                      fontWeight: cur ? FontWeight.w800 : FontWeight.w500),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                  child: Pressable(
                    onTap: widget.onDreams,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        color: al(c.text, 0.07),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.nights_stay_rounded, color: c.a, size: 18),
                          const SizedBox(width: 8),
                          Text(context.t('gen_dream_chats'),
                              style: TextStyle(
                                  color: c.text,
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  child: GradientButton(
                    label: context.t('gen_new'),
                    icon: Icons.edit_outlined,
                    onTap: widget.onNew,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
