import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../services/update_check.dart';
import 'widgets.dart';

/// In-app update: downloads the APK from the GitHub release and opens the system installer.
/// The download belongs to [UpdateJob], so it keeps going when the dialog is hidden.
Future<void> showUpdateDialog(BuildContext context, UpdateInfo info) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _UpdateDialog(info: info),
  );
}

enum _St { idle, perm, error }

class _UpdateDialog extends StatefulWidget {
  final UpdateInfo info;
  const _UpdateDialog({required this.info});

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> with WidgetsBindingObserver {
  final UpdateJob _job = UpdateJob.I;
  _St _st = _St.idle;
  String _err = '';
  String? _ready; // downloaded APK, so the user never has to download twice
  bool _installing = false;

  bool get _mine => _job.tag == widget.info.tag;
  bool get _busy => _job.downloading && _mine;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _job.dialogOpen = true;
    _job.acknowledge();
    _job.addListener(_onJob);
    if (_job.readyPath != null && _mine) _ready = _job.readyPath;
    UpdateCheck.readyPath(widget.info.tag).then((p) {
      if (mounted && p != null) setState(() => _ready = p);
    });
  }

  @override
  void dispose() {
    _job.dialogOpen = false;
    _job.removeListener(_onJob);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onJob() {
    if (!mounted) return;
    if (!_job.downloading && _mine) {
      if (_job.readyPath != null && _ready == null) {
        _ready = _job.readyPath;
        _installNow();
        return;
      }
      if (_job.error.isNotEmpty) {
        _st = _St.error;
        _err = _job.error;
      }
    }
    setState(() {});
  }

  /// Back from the "allow installs" screen: install right away, no new download.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _st == _St.perm && _ready != null) {
      _installNow();
    }
  }

  Future<void> _installNow() async {
    final path = _ready;
    if (path == null) return _go();
    if (_installing) return;
    _installing = true;
    final r = await UpdateCheck.install(path);
    _installing = false;
    if (!mounted) return;
    if (r == 'ok') {
      Navigator.of(context).pop();
    } else if (r == 'perm') {
      setState(() => _st = _St.perm);
    } else {
      setState(() {
        _st = _St.error;
        _err = 'install';
      });
    }
  }

  Future<void> _go() async {
    if (_ready != null) return _installNow();
    final apk = widget.info.apkUrl;
    if (apk.isEmpty) {
      await _github();
      return;
    }
    setState(() => _st = _St.idle);
    _job.start(
      widget.info,
      title: '${context.t('downloading')} ${widget.info.tag}',
      doneTitle: context.t('update_downloaded'),
      doneBody: context.t('update_downloaded_sub'),
    );
  }

  Future<void> _github() async {
    final url = widget.info.url.isEmpty ? kReleasesPage : widget.info.url;
    final ok = await UpdateCheck.open(url);
    if (!ok) {
      await Clipboard.setData(ClipboardData(text: url));
      if (mounted) toast(context, context.t('copied'));
    }
  }

  void _close() {
    if (_busy) _job.cancel();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final busy = _busy;
    final p = _job.progress;
    String msg;
    if (busy) {
      msg = '${context.t('downloading')} ${(100 * p).round()}%';
    } else {
      switch (_st) {
        case _St.idle:
          msg = context.t(_ready != null ? 'update_ready' : 'update_choose');
          break;
        case _St.perm:
          msg = context.t('update_perm');
          break;
        case _St.error:
          msg = '${context.t('update_error')}\n$_err';
          break;
      }
    }
    return PopScope(
      canPop: !busy,
      child: AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(26),
          side: BorderSide(color: c.border),
        ),
        titlePadding: const EdgeInsetsDirectional.fromSTEB(24, 14, 10, 0),
        title: Row(
          children: [
            Expanded(
              child: Text('${context.t('update_available')} ${widget.info.tag}',
                  style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
            ),
            IconButton(
              onPressed: _close,
              icon: Icon(Icons.close_rounded, color: c.dim),
              tooltip: context.t('cancel'),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(msg, style: TextStyle(color: c.dim, height: 1.5)),
            if (busy) ...[
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: p > 0 ? p : null,
                  minHeight: 8,
                  color: c.a,
                  backgroundColor: c.surfaceHi,
                ),
              ),
            ],
          ],
        ),
        actions: busy
            ? [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(context.t('update_hide'), style: TextStyle(color: c.a, fontWeight: FontWeight.w800)),
                ),
              ]
            : [
                TextButton(
                  onPressed: _github,
                  child: Text(context.t('update_manual'), style: TextStyle(color: c.dim)),
                ),
                TextButton(
                  onPressed: _go,
                  child: Text(
                    _ready != null
                        ? context.t('install_now')
                        : _st == _St.idle
                            ? context.t('update_inapp')
                            : context.t('try_again'),
                    style: TextStyle(color: c.a, fontWeight: FontWeight.w800),
                  ),
                ),
              ],
      ),
    );
  }
}
