import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../services/haptics.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'audio_clip.dart';
import 'dream_chat.dart';
import 'dream_editor.dart';
import 'share_card.dart';
import 'widgets.dart';

class DreamDetailPage extends StatefulWidget {
  final String id;
  final bool autoInterpret;
  const DreamDetailPage({super.key, required this.id, this.autoInterpret = false});

  @override
  State<DreamDetailPage> createState() => _DreamDetailPageState();
}

class _DreamDetailPageState extends State<DreamDetailPage> {
  bool _deleting = false;
  bool _interpreting = false;
  bool _genImage = false;
  String _partial = '';
  String _info = '';

  @override
  void initState() {
    super.initState();
    if (widget.autoInterpret) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final d = context.read<AppState>().byId(widget.id);
        if (mounted && d != null) _interpret(d);
      });
    }
  }

  Future<void> _interpret(Dream d) async {
    final app = context.read<AppState>();
    if (d.content.trim().isEmpty && d.title.trim().isEmpty) {
      toast(context, app.tr('interpret_need_text'));
      return;
    }
    setState(() {
      _interpreting = true;
      _partial = '';
    });
    final res = await AiService.interpret(
      title: d.title,
      content: d.content,
      lang: app.lang,
      mood: d.mood,
      onPartial: (t) {
        if (mounted) setState(() => _partial = t);
      },
    );
    if (!mounted) return;
    final cur = app.byId(d.id) ?? d;
    if (!res.fromAi && !AiService.localHasMatch(d.title, d.content)) {
      // nothing relevant to say offline: don't store a generic, unrelated text
      setState(() {
        _interpreting = false;
        _partial = '';
      });
      toast(context, '${app.tr('ai_failed')}\n${AiService.trace}');
      return;
    }
    await app.updateDream(cur.copyWith(interpretation: res.text));
    if (res.fromAi) app.bumpAi();
    if (!mounted) return;
    setState(() {
      _interpreting = false;
      _partial = '';
      _info = res.fromAi ? AiService.lastInfo : '';
    });
    if (!res.fromAi) toast(context, '${app.tr('offline_note')}\n${res.error}');
  }

  Future<void> _deleteImage(Dream d) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('del_image_title'),
      message: app.tr('del_image_confirm'),
      confirm: app.tr('delete'),
    );
    if (!ok || !mounted) return;
    final cur = app.byId(d.id) ?? d;
    await app.updateDream(cur.copyWith(image: null));
  }

  Future<void> _generate(Dream d) async {
    final app = context.read<AppState>();
    if (d.content.trim().isEmpty && d.title.trim().isEmpty) {
      toast(context, app.tr('interpret_need_text'));
      return;
    }
    setState(() => _genImage = true);
    final rel = app.newFileRel('images', 'jpg');
    final ok = await AiService.generateImage(
      title: d.title,
      content: d.content,
      savePath: app.abs(rel)!,
    );
    if (!mounted) return;
    if (ok) {
      final cur = app.byId(d.id) ?? d;
      await app.updateDream(cur.copyWith(image: rel));
      app.bumpImg();
    } else if (AiService.lastError.startsWith('Adult')) {
      toast(context, app.tr('image_unsafe'));
    } else {
      final c = context.colors;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: c.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(app.tr('image_failed'),
              style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 16)),
          content: SingleChildScrollView(
            child: SelectableText(
              AiService.trace.isEmpty ? AiService.lastError : AiService.trace,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: c.dim, fontSize: 13, height: 1.5),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(app.tr('done'),
                    style: TextStyle(color: c.a, fontWeight: FontWeight.w800))),
          ],
        ),
      );
    }
    if (mounted) setState(() => _genImage = false);
  }

  Future<void> _pickMood(Dream d) async {
    final app = context.read<AppState>();
    final c = context.colors;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 14),
                child: Text(app.tr('how_felt'),
                    style: TextStyle(
                        color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              MoodPicker(
                value: (app.byId(d.id) ?? d).mood,
                onChanged: (m) async {
                  final cur = app.byId(d.id) ?? d;
                  Navigator.of(ctx).pop();
                  await app.updateDream(cur.copyWith(mood: m));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _delete(Dream d) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_title'),
      message: app.tr('delete_confirm'),
      confirm: app.tr('delete'),
    );
    if (!ok) return;
    _deleting = true;
    await app.deleteDream(d.id);
    if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final d = app.byId(widget.id);
    if (d == null) {
      if (_deleting) return const SizedBox.shrink();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
      });
      return const SizedBox.shrink();
    }
    final c = context.colors;
    final imgPath = app.abs(d.image);
    final title = d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;

    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            actions: [
              RoundIconButton(
                icon: d.fav ? Icons.star_rounded : Icons.star_border_rounded,
                color: d.fav ? const Color(0xFFFFB020) : null,
                onTap: () {
                  Haptics.selection();
                  app.updateDream(d.copyWith(fav: !d.fav));
                },
              ),
              RoundIconButton(
                icon: d.priv ? Icons.lock_rounded : Icons.lock_open_rounded,
                onTap: () async {
                  Haptics.selection();
                  if (d.priv) {
                    // making a private dream public again needs fingerprint / PIN
                    final ok = await app.external(() => app.authenticate());
                    if (!ok || !context.mounted) return;
                  }
                  app.updateDream(d.copyWith(priv: !d.priv));
                  toast(context, app.tr(d.priv ? 'priv_off' : 'priv_on'));
                },
              ),
              RoundIconButton(
                icon: Icons.ios_share_rounded,
                onTap: () {
                  if (d.priv) {
                    toast(context, app.tr('priv_no_share'));
                    return;
                  }
                  Navigator.of(context).push(CupertinoPageRoute<void>(
                      builder: (_) => ShareCardPage(id: d.id)));
                },
              ),
              RoundIconButton(
                icon: Icons.edit_rounded,
                onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                    builder: (_) => DreamEditorPage(dream: d))),
              ),
              RoundIconButton(
                icon: Icons.delete_outline_rounded,
                color: const Color(0xFFFF5470),
                onTap: () => _delete(d),
              ),
            ],
          ),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                if (imgPath != null)
                  FadeSlide(
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).push(PageRouteBuilder<void>(
                            opaque: false,
                            barrierColor: null,
                            transitionDuration: const Duration(milliseconds: 380),
                            reverseTransitionDuration: const Duration(milliseconds: 320),
                            pageBuilder: (_, __, ___) =>
                                _ImageViewer(path: imgPath, tag: 'dreamimg_${d.id}'),
                            transitionsBuilder: (_, __, ___, child) => child,
                          )),
                      child: Hero(
                        tag: 'dreamimg_${d.id}',
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(26),
                          child: Image.file(
                            File(imgPath),
                            height: 250,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            cacheWidth: 1100,
                            errorBuilder: (_, __, ___) => Container(
                              height: 250,
                              color: c.surfaceHi,
                              child: Icon(Icons.broken_image_rounded, color: c.dim),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                if (imgPath != null) const SizedBox(height: 16),
                Text(title,
                    style: TextStyle(
                        color: c.text,
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Pressable(
                      onTap: () => _pickMood(d),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: al(moodColor(d.mood), 0.18),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: al(moodColor(d.mood), 0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 16)),
                            const SizedBox(width: 6),
                            Text(context.t('mood_${d.mood}'),
                                style: TextStyle(
                                    color: c.text,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13)),
                            const SizedBox(width: 4),
                            Icon(Icons.expand_more_rounded, size: 18, color: c.dim),
                          ],
                        ),
                      ),
                    ),
                    if (d.lucid) const LucidTag(),
                    Text('${fmtDate(d.createdAt, app.lang)} • ${fmtTime(d.createdAt)}',
                        style: TextStyle(color: c.dim, fontSize: 13)),
                  ],
                ),
                if (d.audio != null) ...[
                  const SizedBox(height: 16),
                  AudioClip(
                    key: ValueKey(d.audio),
                    path: app.abs(d.audio)!,
                    durationMs: d.audioMs,
                  ),
                ],
                if (d.content.trim().isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Panel(
                    padding: const EdgeInsets.all(18),
                    child: SelectableText(
                      d.content,
                      style: TextStyle(color: c.text, fontSize: 16.5, height: 1.65),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                GradientButton(
                  label: d.interpretation == null
                      ? context.t('interpret')
                      : context.t('reinterpret'),
                  icon: Icons.psychology_rounded,
                  loading: _interpreting,
                  expand: true,
                  onTap: () => _interpret(d),
                ),
                if (d.image != null) ...[
                  const SizedBox(height: 10),
                  _genImage
                      ? SubtleButton(
                          label: context.t('generating'),
                          icon: Icons.hourglass_top_rounded,
                        )
                      : SubtleButton(
                          label: context.t('regen_image'),
                          icon: Icons.refresh_rounded,
                          onTap: () => _generate(d),
                        ),
                  const SizedBox(height: 10),
                  SubtleButton(
                    label: context.t('del_image_title'),
                    icon: Icons.delete_outline_rounded,
                    onTap: () => _deleteImage(d),
                  ),
                ],
                if (d.image == null) ...[
                  const SizedBox(height: 10),
                  _genImage
                      ? SubtleButton(
                          label: context.t('generating'),
                          icon: Icons.hourglass_top_rounded,
                        )
                      : SubtleButton(
                          label: context.t('gen_image'),
                          icon: Icons.auto_awesome_rounded,
                          onTap: () => _generate(d),
                        ),
                ],
                const SizedBox(height: 10),
                SubtleButton(
                  label: context.t('chat_ask'),
                  icon: Icons.forum_rounded,
                  onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                      builder: (_) => DreamChatPage(id: d.id))),
                ),
                if (_interpreting && _partial.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Center(
                      child: Text(context.t('interpreting'),
                          style: TextStyle(color: c.dim, fontSize: 13)),
                    ),
                  ),
                if ((_interpreting && _partial.isNotEmpty) || d.interpretation != null) ...[
                  const SizedBox(height: 16),
                  FadeSlide(
                    child: Panel(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: c.a, size: 20),
                              const SizedBox(width: 8),
                              Text(context.t('interpretation'),
                                  style: TextStyle(
                                      color: c.text,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          SelectableText(
                            (_interpreting && _partial.isNotEmpty)
                                ? _partial
                                : d.interpretation!,
                            style: TextStyle(color: c.text, fontSize: 15.5, height: 1.7),
                          ),
                          const SizedBox(height: 12),
                          Text(
                              _info.isEmpty
                                  ? context.t('ai_note')
                                  : '${context.t('ai_note')} • $_info',
                              style: TextStyle(color: c.dim, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ImageViewer extends StatefulWidget {
  final String path;
  final String tag;
  const _ImageViewer({required this.path, required this.tag});

  @override
  State<_ImageViewer> createState() => _ImageViewerState();
}

class _ImageViewerState extends State<_ImageViewer> with SingleTickerProviderStateMixin {
  bool _busy = false;
  String? _note;
  Timer? _noteTimer;
  final TransformationController _tc = TransformationController();
  bool _zoomed = false;
  double _dy = 0; // vertical drag offset
  late final AnimationController _snap =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 220));
  double _snapFrom = 0;

  @override
  void initState() {
    super.initState();
    _tc.addListener(() {
      final z = _tc.value.getMaxScaleOnAxis() > 1.02;
      if (z != _zoomed) setState(() => _zoomed = z);
    });
    _snap.addListener(() {
      setState(() => _dy = _snapFrom * (1 - Curves.easeOutCubic.transform(_snap.value)));
    });
  }

  @override
  void dispose() {
    _snap.dispose();
    _noteTimer?.cancel();
    _tc.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    setState(() => _busy = true);
    final app = context.read<AppState>();
    String msg;
    try {
      if (!await Gal.hasAccess(toAlbum: true)) {
        await Gal.requestAccess(toAlbum: true);
      }
      await Gal.putImage(widget.path, album: 'Rosella');
      msg = app.tr('saved_gallery');
    } catch (_) {
      msg = app.tr('save_failed');
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _note = msg;
    });
    _noteTimer?.cancel();
    _noteTimer = Timer(const Duration(milliseconds: 2200), () {
      if (mounted) setState(() => _note = null);
    });
  }

  void _dragEnd(DragEndDetails d) {
    final v = d.primaryVelocity ?? 0;
    if (_dy.abs() > 110 || v.abs() > 800) {
      Navigator.of(context).pop(); // the Hero flies back from where the image is now
    } else {
      _snapFrom = _dy;
      _snap.forward(from: 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final route = ModalRoute.of(context)!;
    final h = MediaQuery.of(context).size.height;
    final drag = (_dy.abs() / (h * 0.45)).clamp(0.0, 1.0);
    final anim = route.animation ?? const AlwaysStoppedAnimation<double>(1);
    return Material(
      type: MaterialType.transparency,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // black backdrop: fades in with the route, fades out while dragging
          FadeTransition(
            opacity: anim,
            child: ColoredBox(color: al(Colors.black, 1 - drag)),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onVerticalDragStart: _zoomed ? null : (_) => _snap.stop(),
            onVerticalDragUpdate: _zoomed ? null : (d) => setState(() => _dy += d.delta.dy),
            onVerticalDragEnd: _zoomed ? null : _dragEnd,
            child: Transform.translate(
              offset: Offset(0, _dy),
              child: Transform.scale(
                scale: 1 - 0.25 * drag,
                child: InteractiveViewer(
                  transformationController: _tc,
                  maxScale: 5,
                  panEnabled: _zoomed,
                  child: SizedBox.expand(
                    child: Hero(
                      tag: widget.tag,
                      child: Image.file(
                        File(widget.path),
                        fit: BoxFit.contain,
                        alignment: Alignment.center,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: anim,
              child: Opacity(
                opacity: (1 - drag * 2).clamp(0.0, 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      RoundIconButton(
                        icon: Icons.close_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const Spacer(),
                      RoundIconButton(
                        icon: _busy ? Icons.hourglass_top_rounded : Icons.download_rounded,
                        onTap: _save,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 24,
            right: 24,
            bottom: 48 + MediaQuery.of(context).padding.bottom,
            child: IgnorePointer(
              child: AnimatedOpacity(
                opacity: _note == null ? 0 : 1,
                duration: const Duration(milliseconds: 200),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xE6202028),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0x33FFFFFF)),
                    ),
                    child: Text(_note ?? '',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            decoration: TextDecoration.none)),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
