import 'dart:async';
import 'dart:io';
import 'dart:ui' show ImageFilter, FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'audio_clip.dart';
import '../services/ai_service.dart';
import '../services/haptics.dart';
import 'widgets.dart';

Future<void> showQuickVoice(BuildContext context, {bool hold = false}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    enableDrag: false,
    builder: (_) => QuickVoiceSheet(hold: hold),
  );
}

enum _Phase { starting, recording, done, permission, error }

class QuickVoiceSheet extends StatefulWidget {
  /// opened by holding the mic: recording stops when the finger is lifted
  final bool hold;
  const QuickVoiceSheet({super.key, this.hold = false});

  /// bumped by the mic button when the finger is released
  static final ValueNotifier<int> release = ValueNotifier<int>(0);

  @override
  State<QuickVoiceSheet> createState() => _QuickVoiceSheetState();
}

class _QuickVoiceSheetState extends State<QuickVoiceSheet> {
  final AudioRecorder _rec = AudioRecorder();
  late final AppState _app;
  final TextEditingController _title = TextEditingController();
  final Stopwatch _sw = Stopwatch();
  Timer? _timer;
  _Phase _phase = _Phase.starting;
  int _ms = 0;
  double _level = 0;
  int _mood = 3;
  String? _rel;
  String? _abs;
  bool _saved = false;
  bool _busy = false;
  bool _released = false;
  bool _transcribing = false;
  int _txGen = 0;
  final TextEditingController _text = TextEditingController();

  @override
  void initState() {
    super.initState();
    _app = context.read<AppState>();
    if (widget.hold) QuickVoiceSheet.release.addListener(_onRelease);
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  void _onRelease() {
    if (_phase == _Phase.recording) {
      _stop();
    } else if (_phase == _Phase.starting) {
      _released = true;
    }
  }

  Future<void> _start() async {
    var ok = false;
    try {
      ok = await _app.external(() => _rec.hasPermission());
    } catch (_) {}
    if (!mounted) return;
    if (!ok) {
      setState(() => _phase = _Phase.permission);
      return;
    }
    _rel = _app.newFileRel('audio', 'm4a');
    _abs = _app.abs(_rel);
    try {
      await _rec.start(
        const RecordConfig(
            encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 16000, numChannels: 1),
        path: _abs!,
      );
    } catch (_) {
      if (mounted) setState(() => _phase = _Phase.error);
      return;
    }
    if (!mounted) return;
    Haptics.light();
    _sw.start();
    setState(() => _phase = _Phase.recording);
    if (_released) {
      _stop();
      return;
    }
    _timer = Timer.periodic(const Duration(milliseconds: 90), (_) async {
      double lvl = _level;
      try {
        final a = await _rec.getAmplitude();
        lvl = ((a.current + 45) / 45).clamp(0.0, 1.0);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _ms = _sw.elapsedMilliseconds;
        _level = lvl;
      });
    });
  }

  Future<void> _stop() async {
    if (_phase != _Phase.recording || _busy) return;
    _busy = true;
    _timer?.cancel();
    _sw.stop();
    try {
      await _rec.stop();
    } catch (_) {}
    _busy = false;
    if (!mounted) return;
    Haptics.medium();
    if (widget.hold && _sw.elapsedMilliseconds < 700) {
      _discard(); // accidental touch
      return;
    }
    setState(() {
      _ms = _sw.elapsedMilliseconds;
      _level = 0;
      _phase = _Phase.done;
    });
    _transcribe();
  }

  /// speech → text (Arabic / Kurdish / English); the audio stays either way
  Future<void> _transcribe() async {
    final path = _abs;
    if (path == null) return;
    final gen = ++_txGen;
    setState(() => _transcribing = true);
    String? text;
    try {
      text = await AiService.transcribe(path, _app.sttLang, appLang: _app.lang);
    } catch (_) {}
    if (!mounted || gen != _txGen) return;
    setState(() => _transcribing = false);
    if (text == null) {
      toast(context, '${_app.tr('transcribe_failed')}\n${AiService.lastError}');
    } else if (text.isEmpty) {
      toast(context, _app.tr('no_speech'));
    } else if (_text.text.trim().isEmpty) {
      _text.text = text;
    }
  }

  Future<void> _save() async {
    final title = _title.text.trim().isEmpty
        ? '${_app.tr('voice_default')} • ${fmtDate(DateTime.now(), _app.lang)}'
        : _title.text.trim();
    final d = Dream(
      id: _app.newId(),
      title: title,
      content: _text.text.trim(),
      createdAt: DateTime.now(),
      mood: _mood,
      audio: _rel,
      audioMs: _ms,
    );
    _saved = true;
    final msg = _app.tr('qv_saved');
    await _app.addDream(d);
    if (!mounted) return;
    Navigator.of(context).pop();
    toast(context, msg);
  }

  void _discard() => Navigator.of(context).pop();

  @override
  void dispose() {
    _txGen++;
    QuickVoiceSheet.release.removeListener(_onRelease);
    _timer?.cancel();
    _title.dispose();
    _text.dispose();
    final abs = _abs;
    final saved = _saved;
    () async {
      try {
        if (await _rec.isRecording()) await _rec.stop();
      } catch (_) {}
      try {
        await _rec.dispose();
      } catch (_) {}
      if (!saved && abs != null) {
        try {
          final f = File(abs);
          if (f.existsSync()) f.deleteSync();
        } catch (_) {}
      }
    }();
    super.dispose();
  }

  String _fmt(int ms) {
    final s = ms ~/ 1000;
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final ss = (s % 60).toString().padLeft(2, '0');
    final t = ((ms % 1000) ~/ 100).toString();
    return '$m:$ss.$t';
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final mq = MediaQuery.of(context);
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(34)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          width: double.infinity,
          color: al(c.isDark ? const Color(0xFF0B0B12) : Colors.white, 0.9),
          padding: EdgeInsets.fromLTRB(22, 12, 22, 22 + mq.padding.bottom + mq.viewInsets.bottom),
          child: SingleChildScrollView(
            child: AnimatedSize(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                        color: c.border, borderRadius: BorderRadius.circular(3)),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    context.t('quick_voice'),
                    style: TextStyle(
                        color: c.text, fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 6),
                  _body(c),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _body(AppColors c) {
    switch (_phase) {
      case _Phase.starting:
      case _Phase.recording:
        return Column(
          children: [
            Text(
              _phase == _Phase.recording
                  ? context.t('qv_recording')
                  : '…',
              style: TextStyle(color: c.dim, fontSize: 14),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: 230,
              height: 230,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 120),
                    width: 130 + 100 * _level,
                    height: 130 + 100 * _level,
                    decoration:
                        BoxDecoration(shape: BoxShape.circle, color: al(c.a, 0.10)),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 120),
                    width: 112 + 60 * _level,
                    height: 112 + 60 * _level,
                    decoration:
                        BoxDecoration(shape: BoxShape.circle, color: al(c.b, 0.16)),
                  ),
                  Pressable(
                    onTap: _stop,
                    scale: 0.93,
                    child: Container(
                      width: 104,
                      height: 104,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: c.gradient,
                        boxShadow: [
                          BoxShadow(color: al(c.a, 0.45), blurRadius: 28, spreadRadius: 1),
                        ],
                      ),
                      child: Icon(
                        _phase == _Phase.recording
                            ? Icons.stop_rounded
                            : Icons.mic_rounded,
                        color: Colors.white,
                        size: 46,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              _fmt(_ms),
              textDirection: TextDirection.ltr,
              style: TextStyle(
                color: c.text,
                fontSize: 44,
                fontWeight: FontWeight.w200,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
            const SizedBox(height: 6),
            Text(context.t(widget.hold ? 'qv_release' : 'qv_tap_stop'), style: TextStyle(color: c.dim, fontSize: 13)),
            const SizedBox(height: 14),
            TextButton(
              onPressed: _discard,
              child: Text(context.t('cancel'), style: TextStyle(color: c.dim)),
            ),
          ],
        );
      case _Phase.done:
        return Column(
          children: [
            const SizedBox(height: 10),
            Text(context.t('qv_done'), style: TextStyle(color: c.dim, fontSize: 14)),
            const SizedBox(height: 14),
            AudioClip(path: _abs!, durationMs: _ms),
            const SizedBox(height: 14),
            if (_transcribing)
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: c.dim),
                    ),
                    const SizedBox(width: 10),
                    Text(context.t('transcribing'),
                        style: TextStyle(color: c.dim, fontSize: 13.5)),
                  ],
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  radius: 18,
                  child: TextField(
                    controller: _text,
                    minLines: 2,
                    maxLines: 6,
                    style: TextStyle(color: c.text, fontSize: 15.5, height: 1.5),
                    decoration: bareInput(context, context.t('content_hint')),
                  ),
                ),
              ),
            Panel(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              radius: 18,
              child: TextField(
                controller: _title,
                style: TextStyle(color: c.text, fontSize: 16),
                decoration: bareInput(context, context.t('name_hint')),
              ),
            ),
            const SizedBox(height: 14),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8, left: 4, right: 4),
                child: Text(context.t('how_felt'),
                    style: TextStyle(
                        color: c.dim, fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
            MoodPicker(value: _mood, onChanged: (m) => setState(() => _mood = m)),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: SubtleButton(
                    label: context.t('discard'),
                    icon: Icons.delete_outline_rounded,
                    onTap: _discard,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GradientButton(
                    label: context.t('save'),
                    icon: Icons.check_rounded,
                    expand: true,
                    onTap: _save,
                  ),
                ),
              ],
            ),
          ],
        );
      case _Phase.permission:
      case _Phase.error:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(
            children: [
              Icon(Icons.mic_off_rounded, size: 48, color: c.dim),
              const SizedBox(height: 14),
              Text(
                _phase == _Phase.permission
                    ? context.t('mic_permission')
                    : context.t('qv_start_error'),
                textAlign: TextAlign.center,
                style: TextStyle(color: c.text, fontSize: 15, height: 1.5),
              ),
              const SizedBox(height: 18),
              SubtleButton(
                label: context.t('cancel'),
                icon: Icons.close_rounded,
                onTap: _discard,
              ),
            ],
          ),
        );
    }
  }
}
