import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import '../services/update_check.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import '../services/haptics.dart';
import 'update_dialog.dart';
import 'widgets.dart';

const String kSupportEmail = 'contact.somina@gmail.com';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  static const String kShareLink = 'https://github.com/Suhebtaha/Rosella/releases/latest';

  Future<void> _sheet(BuildContext context, String title,
      List<(IconData, String, VoidCallback)> options) async {
    final c = context.colors;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 14),
                child: Text(title,
                    style: TextStyle(
                        color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              for (final o in options)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Pressable(
                    onTap: () {
                      Navigator.of(ctx).pop();
                      o.$3();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      decoration: BoxDecoration(
                        color: c.surfaceHi,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(o.$1, color: c.a),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Text(o.$2,
                                style: TextStyle(
                                    color: c.text,
                                    fontSize: 15.5,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _update(BuildContext context) async {
    final app = context.read<AppState>();
    if (app.checkingUpdate) return;
    var r = UpdateInfo(
        available: app.updateAvailable,
        tag: app.updateTag,
        url: app.updateUrl,
        apkUrl: app.updateApk);
    if (!app.updateAvailable) {
      r = await app.checkForUpdate();
      if (!context.mounted) return;
      if (r.failed) {
        toast(context, context.t('update_failed'));
        return;
      }
      if (!r.available) {
        toast(context, context.t('up_to_date'));
        return;
      }
    }
    if (!context.mounted) return;
    await showUpdateDialog(context, r);
  }

  Future<void> _copy(BuildContext context, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (context.mounted) toast(context, context.t('copied'));
  }

  void _chooseShare(BuildContext context) {
    _sheet(context, context.t('share_app'), [
      (Icons.ios_share_rounded, context.t('share_now'), () => Share.share(context.t('share_text'))),
      (Icons.link_rounded, context.t('copy_link'), () => _copy(context, kShareLink)),
    ]);
  }

  void _chooseMail(BuildContext context) {
    _sheet(context, context.t('feedback'), [
      (Icons.mail_rounded, context.t('open_mail'), () => _mail(context)),
      (Icons.copy_rounded, context.t('copy_email'), () => _copy(context, kSupportEmail)),
    ]);
  }

  /// Writes every dream into one readable text file and shares it.
  Future<void> _exportText(BuildContext context, AppState app) async {
    final pub = app.dreams.where((d) => !d.priv).toList();
    if (pub.isEmpty) {
      toast(context, context.t('export_empty'));
      return;
    }
    final b = StringBuffer('Rosella\n${pub.length}\n\n');
    for (final d in pub) {
      final dt = d.createdAt;
      b.writeln('=== ${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}'
          '  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
          '${d.lucid ? '  *' : ''} ===');
      if (d.title.trim().isNotEmpty) b.writeln(d.title.trim());
      b.writeln(d.content.trim());
      if (d.interpretation != null && d.interpretation!.trim().isNotEmpty) {
        b.writeln('\n-- ${context.t('interpretation')} --');
        b.writeln(d.interpretation!.trim());
      }
      b.writeln('\n');
    }
    final bytes = Uint8List.fromList(utf8.encode(b.toString()));
    try {
      // system "save as" screen: the user picks the folder and the name
      final saved = await app.external(() => FilePicker.platform.saveFile(
            dialogTitle: context.t('export_txt'),
            fileName: 'Rosella-dreams.txt',
            bytes: bytes,
            type: FileType.custom,
            allowedExtensions: const ['txt'],
          ));
      if (saved != null && context.mounted) toast(context, context.t('export_saved'));
    } catch (_) {
      // fall back to the share sheet
      try {
        final dir = await getTemporaryDirectory();
        final f = File('${dir.path}/Rosella-dreams.txt');
        await f.writeAsBytes(bytes, flush: true);
        await app.external(() => Share.shareXFiles([XFile(f.path)], text: 'Rosella'));
      } catch (_) {
        if (context.mounted) toast(context, context.t('export_empty'));
      }
    }
  }

  /// Opens the mail app with the address filled in; copies it if no mail app answers.
  Future<void> _mail(BuildContext context) async {
    final subject = context.t('mail_subject');
    bool ok = false;
    try {
      ok = await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('mail', {'to': kSupportEmail, 'subject': subject}) ??
          false;
    } catch (_) {}
    if (!ok) {
      await Clipboard.setData(const ClipboardData(text: kSupportEmail));
      if (context.mounted) toast(context, context.t('email_copied'));
    }
  }

  Future<void> _toggleBio(BuildContext context, bool v) async {
    final app = context.read<AppState>();
    if (v) {
      final supported = await app.canAuth();
      if (!supported) {
        if (context.mounted) toast(context, app.tr('bio_unsupported'));
        return;
      }
      final ok = await app.authenticate();
      if (!ok) return;
    } else {
      // turning the lock OFF also needs fingerprint / PIN
      final ok = await app.external(() => app.authenticate());
      if (!ok) return;
    }
    app.setBio(v);
  }

  Future<void> _signIn(BuildContext context) async {
    final app = context.read<AppState>();
    final err = await app.googleSignIn();
    if (err != null && context.mounted) {
      toast(context, '${app.tr('signin_failed')}\n$err');
    }
  }

  Future<void> _editKey(BuildContext context) async {
    final app = context.read<AppState>();
    final c = context.colors;
    final ctrl = TextEditingController(text: app.geminiKey);
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(app.tr('gemini_key'),
            style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(app.tr('gemini_hint'),
                style: TextStyle(color: c.dim, fontSize: 13.5, height: 1.5)),
            const SizedBox(height: 14),
            TextField(
              controller: ctrl,
              autocorrect: false,
              enableSuggestions: false,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: c.text, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'AIza…',
                hintStyle: TextStyle(color: al(c.dim, 0.7)),
                filled: true,
                fillColor: c.surfaceHi,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(app.tr('cancel'), style: TextStyle(color: c.dim))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(app.tr('save'),
                  style: TextStyle(color: c.a, fontWeight: FontWeight.w800))),
        ],
      ),
    );
    if (res != null) {
      app.setGeminiKey(res);
      if (context.mounted) toast(context, app.tr('gemini_saved'));
    }
  }

  Future<void> _testAi(BuildContext context) async {
    final app = context.read<AppState>();
    final c = context.colors;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(app.tr('ai_test'),
            style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 18)),
        content: FutureBuilder<String>(
          future: AiService.selfTest(),
          builder: (_, snap) {
            if (!snap.hasData) {
              return SizedBox(
                height: 70,
                child: Center(child: CircularProgressIndicator(color: c.a)),
              );
            }
            return SingleChildScrollView(
              child: SelectableText(
                snap.data!,
                textDirection: TextDirection.ltr,
                style: TextStyle(color: c.text, fontSize: 13.5, height: 1.6),
              ),
            );
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(app.tr('done'),
                  style: TextStyle(color: c.a, fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }

  static String _syncMsg(AppState app, String err) =>
      err == 'api' ? app.tr('sync_api') : '${app.tr('sync_failed')}\n$err';

  static String _fmt(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String p(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${p(d.month)}-${p(d.day)} ${p(d.hour)}:${p(d.minute)}';
  }

  Future<void> _deleteAll(BuildContext context) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_all'),
      message: app.tr('delete_all_confirm'),
      confirm: app.tr('delete'),
    );
    if (ok) await app.deleteAll();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    const sky = Color(0xFF38A8FF);
    const amber = Color(0xFFFFA94D);
    const green = Color(0xFF34D399);
    const red = Color(0xFFFF5470);
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 0, 6, 18),
            child: Text(context.t('set_title'),
                style: TextStyle(
                    color: c.text,
                    fontSize: 34,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.8)),
          ),
          FadeSlide(child: _ProfileCard(onSignIn: () => _signIn(context))),
          if (app.userEmail != null) ...[
            const SizedBox(height: 22),
            _Label(context.t('backup')),
            FadeSlide(
              delay: 40,
              child: _Group(children: [
                _SwitchRow(
                  icon: Icons.cloud_sync_rounded,
                  tint: sky,
                  title: context.t('auto_backup'),
                  subtitle: context.t('auto_backup_sub'),
                  value: app.autoBackup,
                  onChanged: (v) {
                    Haptics.selection();
                    app.setAutoBackup(v);
                  },
                ),
                _Tile(
                  icon: Icons.cloud_upload_rounded,
                  tint: sky,
                  title: app.syncing ? context.t('syncing') : context.t('sync_now'),
                  subtitle: app.syncError != null
                      ? _syncMsg(app, app.syncError!)
                      : app.lastSync == 0
                          ? context.t('never_synced')
                          : '${context.t('last_sync')}: ${_fmt(app.lastSync)}',
                  subtitleColor: app.syncError != null ? red : null,
                  trailing: app.syncing
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2.4, color: c.a))
                      : Icon(Icons.chevron_right_rounded, color: c.dim),
                  onTap: () async {
                    if (app.syncing) return;
                    final err = await app.syncNow();
                    if (!context.mounted) return;
                    toast(context, err == null ? app.tr('sync_ok') : _syncMsg(app, err));
                  },
                ),
              ]),
            ),
          ],
          const SizedBox(height: 22),
          _Label(context.t('export_section')),
          FadeSlide(
            delay: 45,
            child: _Group(children: [
              _Tile(
                icon: Icons.file_download_rounded,
                tint: sky,
                title: context.t('export_txt'),
                subtitle: context.t('export_txt_sub'),
                onTap: () => _exportText(context, app),
              ),
            ]),
          ),
          const SizedBox(height: 22),
          _Label(context.t('ai_section')),
          FadeSlide(
            delay: 50,
            child: _Group(children: [
              _Tile(
                icon: Icons.auto_awesome_rounded,
                tint: const Color(0xFF8B7BFF),
                title: context.t('gemini_key'),
                subtitle: context.t('gemini_key_sub'),
                trailing: Text(
                    app.geminiKey.isEmpty && !AiService.hasBuiltIn
                        ? context.t('gemini_off')
                        : context.t('gemini_on'),
                    style: TextStyle(
                        color: app.geminiKey.isEmpty && !AiService.hasBuiltIn
                            ? c.dim
                            : const Color(0xFF34D399),
                        fontSize: 13,
                        fontWeight: FontWeight.w800)),
                onTap: () => _editKey(context),
              ),
              _Tile(
                icon: Icons.speed_rounded,
                tint: const Color(0xFF34D399),
                title: context.t('ai_test'),
                trailing: Icon(Icons.chevron_right_rounded, color: c.dim),
                onTap: () => _testAi(context),
              ),
            ]),
          ),
          const SizedBox(height: 22),
          _Label(context.t('reminders')),
          FadeSlide(
            delay: 60,
            child: _Group(children: [
              _SwitchRow(
                icon: Icons.notifications_active_rounded,
                tint: amber,
                title: context.t('morning_reminder'),
                subtitle: context.t('morning_reminder_sub'),
                value: app.reminder,
                onChanged: (v) async {
                  Haptics.selection();
                  final ok = await app.setReminder(v);
                  if (!ok && context.mounted) {
                    toast(context, app.tr('notif_denied'));
                  }
                },
              ),
              if (app.reminder)
                _Tile(
                  icon: Icons.schedule_rounded,
                  tint: amber,
                  title: context.t('reminder_time'),
                  trailing: Text(
                      '${app.reminderH.toString().padLeft(2, '0')}:${app.reminderM.toString().padLeft(2, '0')}',
                      style: TextStyle(
                          color: c.a, fontSize: 17, fontWeight: FontWeight.w800)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(hour: app.reminderH, minute: app.reminderM),
                    );
                    if (t != null) app.setReminderTime(t.hour, t.minute);
                  },
                ),
              _SwitchRow(
                icon: Icons.bedtime_rounded,
                tint: const Color(0xFF7C5CFF),
                title: context.t('bedtime_reminder'),
                subtitle: context.t('bedtime_reminder_sub'),
                value: app.bedtime,
                onChanged: (v) async {
                  Haptics.selection();
                  final ok = await app.setBedtime(v);
                  if (!ok && context.mounted) {
                    toast(context, app.tr('notif_denied'));
                  }
                },
              ),
              if (app.bedtime)
                _Tile(
                  icon: Icons.schedule_rounded,
                  tint: const Color(0xFF7C5CFF),
                  title: context.t('bedtime_time'),
                  trailing: Text(
                      '${app.bedH.toString().padLeft(2, '0')}:${app.bedM.toString().padLeft(2, '0')}',
                      style: TextStyle(
                          color: c.a, fontSize: 17, fontWeight: FontWeight.w800)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(hour: app.bedH, minute: app.bedM),
                    );
                    if (t != null) app.setBedtimeTime(t.hour, t.minute);
                  },
                ),
            ]),
          ),
          const SizedBox(height: 22),
          _Label(context.t('appearance')),
          FadeSlide(
            delay: 80,
            child: _Group(children: [
              _SwitchRow(
                icon: app.dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                tint: const Color(0xFF8B7BFF),
                title: context.t('dark_mode'),
                value: app.dark,
                onChanged: (v) {
                  Haptics.selection();
                  app.setDark(v);
                },
              ),
            ]),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 100,
            child: _Group(children: [
              _Tile(
                icon: Icons.vibration_rounded,
                tint: const Color(0xFFFFB84D),
                title: context.t('haptic_title'),
                subtitle: context.t('haptic_sub'),
                trailing: null,
                onTap: Haptics.test,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (var i = 0; i < 4; i++)
                      Pressable(
                        onTap: () {
                          app.setHapticLevel(i);
                          Haptics.test();
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                          decoration: BoxDecoration(
                            gradient: app.hapticLevel == i ? c.gradient : flatGradient(c.surfaceHi),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Text(
                            context.t(const ['haptic_off', 'haptic_light', 'haptic_medium', 'haptic_strong'][i]),
                            style: TextStyle(
                              color: app.hapticLevel == i ? onAccent(c.a, c.b) : c.text,
                              fontWeight: FontWeight.w700,
                              fontSize: 13.5,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              if (app.hapticLevel > 0)
                _SwitchRow(
                  icon: Icons.phone_android_rounded,
                  tint: const Color(0xFFFFB84D),
                  title: context.t('haptic_motor'),
                  subtitle: context.t('haptic_motor_sub'),
                  value: app.hapticMotor,
                  onChanged: (v) {
                    app.setHapticMotor(v);
                    Haptics.test();
                  },
                ),
            ]),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 10),
            child: Text(context.t('theme'),
                style: TextStyle(
                    color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          LayoutBuilder(builder: (context, cons) {
            const gap = 12.0;
            final w = (cons.maxWidth - gap) / 2;
            return Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                for (final p in kPalettes)
                  SizedBox(
                    width: w,
                    child: _ThemeCard(
                      palette: p,
                      selected: app.themeId == p.id,
                      label: Strings.get(app.lang, p.nameKey),
                      onTap: () {
                        Haptics.selection();
                        app.setTheme(p.id);
                      },
                    ),
                  ),
              ],
            );
          }),
          const SizedBox(height: 22),
          _Label(context.t('cards')),
          _ChoiceRow(
            value: app.cardStyle,
            onChanged: app.setCardStyle,
            options: [
              ('list', Icons.view_agenda_rounded, context.t('card_list')),
              ('grid', Icons.grid_view_rounded, context.t('card_grid')),
            ],
          ),
          const SizedBox(height: 22),
          _Label(context.t('home_filters')),
          _Group(children: [
            _SwitchRow(
              icon: Icons.star_border_rounded,
              tint: const Color(0xFFFFB020),
              title: context.t('hide_fav'),
              subtitle: context.t('hide_fav_sub'),
              value: app.hideFavFilter,
              onChanged: (v) {
                Haptics.selection();
                app.setHideFavFilter(v);
              },
            ),
            _SwitchRow(
              icon: Icons.lock_outline_rounded,
              tint: const Color(0xFF7C5CFF),
              title: context.t('hide_priv'),
              subtitle: context.t('hide_priv_sub'),
              value: app.hidePrivFilter,
              onChanged: (v) async {
                Haptics.selection();
                if (!v) {
                  final ok = await app.external(() => app.authenticate());
                  if (!ok) return;
                }
                app.setHidePrivFilter(v);
              },
            ),
          ]),
          const SizedBox(height: 22),
          _Label(context.t('mic_pos')),
          _ChoiceRow(
            value: app.micCenter ? 'center' : 'side',
            onChanged: (v) => app.setMicCenter(v == 'center'),
            options: [
              ('side', Icons.align_horizontal_right_rounded, context.t('mic_side')),
              ('center', Icons.adjust_rounded, context.t('mic_center')),
            ],
          ),
          const SizedBox(height: 22),
          _Label(context.t('language')),
          FadeSlide(
            delay: 100,
            child: Panel(
              padding: const EdgeInsets.all(8),
              radius: 24,
              child: _LangSegment(
                current: app.lang,
                onChanged: (v) {
                  Haptics.selection();
                  app.setLang(v);
                },
              ),
            ),
          ),
          const SizedBox(height: 22),
          _Label(context.t('speech_lang')),
          FadeSlide(
            delay: 110,
            child: Panel(
              padding: const EdgeInsets.all(8),
              radius: 24,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 4, 4, 6),
                  child: Row(children: [
                    Expanded(
                      child: Text(context.t('speech_auto'),
                          style: TextStyle(
                              color: context.colors.text,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                    ),
                    Switch.adaptive(
                      value: app.speechLang.isEmpty,
                      onChanged: (v) {
                        Haptics.selection();
                        app.setSpeechLang(v ? '' : app.lang);
                      },
                    ),
                  ]),
                ),
                IgnorePointer(
                  ignoring: app.speechLang.isEmpty,
                  child: AnimatedOpacity(
                    opacity: app.speechLang.isEmpty ? 0.35 : 1,
                    duration: const Duration(milliseconds: 200),
                    child: _LangSegment(
                      current: app.speechLang.isEmpty ? app.lang : app.speechLang,
                      onChanged: (v) {
                        Haptics.selection();
                        app.setSpeechLang(v);
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                  child: Text(context.t('speech_lang_sub'),
                      style: TextStyle(color: context.colors.dim, fontSize: 12.5, height: 1.4)),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 22),
          _Label(context.t('security')),
          FadeSlide(
            delay: 120,
            child: _Group(children: [
              _SwitchRow(
                icon: Icons.fingerprint_rounded,
                tint: green,
                title: context.t('bio_lock'),
                subtitle: context.t('bio_sub'),
                value: app.bioLock,
                onChanged: (v) => _toggleBio(context, v),
              ),
              _SwitchRow(
                icon: Icons.forum_rounded,
                tint: green,
                title: context.t('lock_chats'),
                subtitle: context.t('lock_chats_sub'),
                value: app.lockChats,
                onChanged: (v) async {
                  final ok = await app.external(() => app.authenticate());
                  if (!ok) return;
                  app.setLockChats(v);
                },
              ),
            ]),
          ),
          const SizedBox(height: 22),
          _Label(context.t('data')),
          FadeSlide(
            delay: 140,
            child: _Group(children: [
              _Tile(
                icon: Icons.delete_sweep_rounded,
                tint: red,
                title: context.t('delete_all'),
                titleColor: red,
                onTap: () => _deleteAll(context),
              ),
            ]),
          ),
          const SizedBox(height: 22),
          FadeSlide(
            delay: 160,
            child: _Group(children: [
              ListenableBuilder(
                listenable: UpdateJob.I,
                builder: (context, _) => _Tile(
                icon: Icons.system_update_rounded,
                badge: app.updateAvailable,
                tint: const Color(0xFFFF6B6B),
                title: app.updateAvailable
                    ? '${context.t('update_available')} ${app.updateTag}'
                    : context.t('check_update'),
                subtitle: UpdateJob.I.downloading
                    ? '${context.t('downloading')} ${(100 * UpdateJob.I.progress).round()}%'
                    : UpdateJob.I.readyPath != null && app.updateAvailable
                        ? context.t('update_downloaded_sub')
                        : app.checkingUpdate
                    ? context.t('checking')
                    : (app.updateAvailable
                        ? context.t('update_tap')
                        : '${context.t('version')} $kAppVersion'),
                onTap: () => _update(context),
              ),
              ),
              _Tile(
                icon: Icons.ios_share_rounded,
                tint: const Color(0xFF38BDF8),
                title: context.t('share_app'),
                subtitle: context.t('share_app_sub'),
                onTap: () => _chooseShare(context),
              ),
              _Tile(
                icon: Icons.mail_rounded,
                tint: const Color(0xFF34D399),
                title: context.t('feedback'),
                subtitle: kSupportEmail,
                onTap: () => _chooseMail(context),
              ),
            ]),
          ),
          const SizedBox(height: 34),
          Center(
            child: Column(
              children: [
                Text('Rosella • $kAppVersion', style: TextStyle(color: c.dim, fontSize: 12)),
                const SizedBox(height: 14),
                Text(
                  'Developed by',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(
                      color: al(c.dim, 0.9), fontSize: 13, letterSpacing: 1.2),
                ),
                const SizedBox(height: 2),
                const Directionality(
                  textDirection: TextDirection.ltr,
                  child: DynamicText('Suhaib',
                      fontSize: 46, letterSpacing: 1.5, weight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ pieces
class _ProfileCard extends StatelessWidget {
  final VoidCallback onSignIn;
  const _ProfileCard({required this.onSignIn});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final signed = app.userEmail != null;
    final light = onAccent(c.a, c.b) != Colors.white;
    Color deep(Color x) => light ? Color.lerp(x, Colors.black, 0.55)! : x;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [al(deep(c.a), 0.95), al(deep(c.b), 0.9)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(color: al(c.a, 0.35), blurRadius: 28, offset: const Offset(0, 12)),
        ],
      ),
      child: signed
          ? Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: al(Colors.white, 0.35)),
                  child: CircleAvatar(
                    radius: 28,
                    backgroundColor: al(Colors.black, 0.25),
                    backgroundImage:
                        app.userPhoto != null ? NetworkImage(app.userPhoto!) : null,
                    onBackgroundImageError: app.userPhoto != null ? (_, __) {} : null,
                    child: app.userPhoto == null
                        ? Text((app.userName ?? '?').characters.first.toUpperCase(),
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 22))
                        : null,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(app.userName ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(app.userEmail ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: al(Colors.white, 0.8), fontSize: 13)),
                    ],
                  ),
                ),
                Pressable(
                  onTap: () => app.googleSignOut(),
                  scale: 0.9,
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: al(Colors.white, 0.22)),
                    child: const Icon(Icons.logout_rounded, color: Colors.white, size: 20),
                  ),
                ),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: al(Colors.white, 0.22)),
                      child: const Icon(Icons.person_rounded, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(context.t('account'),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Pressable(
                  onTap: onSignIn,
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.login_rounded, color: c.a, size: 20),
                        const SizedBox(width: 8),
                        Text(context.t('sign_google'),
                            style: TextStyle(
                                color: c.a, fontSize: 15.5, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        child: Text(text,
            style: TextStyle(
                color: context.colors.dim,
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.3)),
      );
}

/// Rounded group of rows separated by thin dividers (iOS style).
class _Group extends StatelessWidget {
  final List<Widget> children;
  const _Group({required this.children});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Panel(
      padding: EdgeInsets.zero,
      radius: 24,
      child: Column(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0)
              Divider(
                  color: c.border, height: 1, indent: 70, endIndent: 16, thickness: 1),
            children[i],
          ],
        ],
      ),
    );
  }
}

class _IconBox extends StatelessWidget {
  final IconData icon;
  final Color tint;
  const _IconBox(this.icon, this.tint);

  @override
  Widget build(BuildContext context) => Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [tint, Color.lerp(tint, Colors.black, 0.28)!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(13),
          boxShadow: [
            BoxShadow(color: al(tint, 0.35), blurRadius: 10, offset: const Offset(0, 4)),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 21),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final Color tint;
  final String title;
  final Color? titleColor;
  final String? subtitle;
  final Color? subtitleColor;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool badge;
  const _Tile({
    this.badge = false,
    required this.icon,
    required this.tint,
    required this.title,
    this.titleColor,
    this.subtitle,
    this.subtitleColor,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final row = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          _IconBox(icon, tint),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(title,
                          style: TextStyle(
                              color: titleColor ?? c.text,
                              fontSize: 15.5,
                              fontWeight: FontWeight.w700)),
                    ),
                    if (badge) ...[
                      const SizedBox(width: 8),
                      Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                            color: Color(0xFFFF3B30), shape: BoxShape.circle),
                      ),
                    ],
                  ],
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(subtitle!,
                        style: TextStyle(
                            color: subtitleColor ?? c.dim, fontSize: 12.5, height: 1.35)),
                  ),
              ],
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 10), trailing!],
        ],
      ),
    );
    if (onTap == null) return row;
    return Pressable(onTap: onTap, scale: 0.985, child: row);
  }
}

class _SwitchRow extends StatelessWidget {
  final IconData icon;
  final Color? tint;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({
    required this.icon,
    this.tint,
    required this.title,
    this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return _Tile(
      icon: icon,
      tint: tint ?? c.a,
      title: title,
      subtitle: subtitle,
      onTap: () {
        Haptics.selection();
        onChanged(!value);
      },
      trailing: Switch(
        value: value,
        onChanged: (v) {
          Haptics.selection();
          onChanged(v);
        },
        activeTrackColor: c.a,
        inactiveTrackColor: c.surfaceHi,
        thumbColor: const WidgetStatePropertyAll<Color>(Colors.white),
        trackOutlineColor: const WidgetStatePropertyAll<Color>(Colors.transparent),
      ),
    );
  }
}

/// Two big selectable cards (used for card shape and mic position).
class _ChoiceRow extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final List<(String, IconData, String)> options;
  const _ChoiceRow(
      {required this.value, required this.onChanged, required this.options});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Row(
      children: [
        for (var i = 0; i < options.length; i++) ...[
          if (i > 0) const SizedBox(width: 12),
          Expanded(
            child: Pressable(
              scale: 0.96,
              onTap: () {
                Haptics.selection();
                onChanged(options[i].$1);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                height: 92,
                decoration: BoxDecoration(
                  gradient: value == options[i].$1
                      ? c.gradient
                      : flatGradient(al(c.surface, c.isDark ? 0.75 : 0.95)),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: value == options[i].$1 ? Colors.transparent : c.border),
                  boxShadow: value == options[i].$1
                      ? [BoxShadow(color: al(c.a, 0.4), blurRadius: 18, offset: const Offset(0, 8))]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(options[i].$2,
                        size: 28,
                        color: value == options[i].$1 ? onAccent(c.a, c.b) : c.dim),
                    const SizedBox(height: 8),
                    Text(options[i].$3,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: value == options[i].$1 ? onAccent(c.a, c.b) : c.text)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

/// A theme preview card: miniature app mock on the theme's gradient.
class _ThemeCard extends StatelessWidget {
  final AppPalette palette;
  final bool selected;
  final String label;
  final VoidCallback onTap;
  const _ThemeCard(
      {required this.palette,
      required this.selected,
      required this.label,
      required this.onTap});

  static const List<Color> _dyn = [
    Color(0xFF12C2D6),
    Color(0xFF2F6BFF),
    Color(0xFF5B3DF5),
    Color(0xFFB23CFF),
    Color(0xFFE23DA8),
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final isDyn = palette.id == 'dynamic';
    final fg = isDyn ? Colors.white : onAccent(palette.a, palette.b);
    final grad = isDyn
        ? const LinearGradient(
            colors: _dyn, begin: Alignment.topLeft, end: Alignment.bottomRight)
        : LinearGradient(
            colors: [palette.a, palette.b],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight);
    return Pressable(
      onTap: onTap,
      scale: 0.96,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        height: 118,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: grad,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
              color: selected ? al(fg, 0.95) : al(fg, 0.0), width: 2.5),
          boxShadow: [
            BoxShadow(
              color: al(palette.a, selected ? 0.55 : 0.22),
              blurRadius: selected ? 22 : 12,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            // mini app mock
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      width: 46,
                      height: 7,
                      decoration: BoxDecoration(
                          color: al(fg, 0.85),
                          borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 8),
                  Container(
                      height: 22,
                      decoration: BoxDecoration(
                          color: al(Colors.black, 0.22),
                          borderRadius: BorderRadius.circular(9))),
                ],
              ),
            ),
            PositionedDirectional(
              start: 0,
              bottom: 0,
              end: 30,
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: fg, fontSize: 14.5, fontWeight: FontWeight.w800)),
            ),
            PositionedDirectional(
              end: 0,
              bottom: 0,
              child: AnimatedScale(
                scale: selected ? 1 : 0,
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutBack,
                child: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: fg),
                  child: Icon(Icons.check_rounded,
                      size: 16, color: isDyn ? palette.a : palette.b),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LangSegment extends StatelessWidget {
  final String current;
  final ValueChanged<String> onChanged;
  const _LangSegment({required this.current, required this.onChanged});

  static const List<List<String>> _opts = [
    ['ar', 'العربية'],
    ['ckb', 'کوردی'],
      ['es', 'Español'],
      ['ko', '한국어'],
    ['en', 'English'],
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final n = _opts.length;
    final idx = _opts.indexWhere((o) => o[0] == current).clamp(0, n - 1);
    return SizedBox(
      height: 46,
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 320),
            curve: Curves.easeOutCubic,
            alignment: AlignmentDirectional(-1.0 + 2.0 * idx / (n - 1), 0),
            child: FractionallySizedBox(
              widthFactor: 1 / n,
              heightFactor: 1,
              child: Container(
                decoration: BoxDecoration(
                  gradient: c.gradient,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                        color: al(c.a, 0.3), blurRadius: 12, offset: const Offset(0, 4)),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              for (final o in _opts)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onChanged(o[0]),
                    child: Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 250),
                        style: TextStyle(
                          color: current == o[0] ? Colors.white : c.text,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                        ),
                        child: FittedBox(fit: BoxFit.scaleDown, child: Text(o[1])),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
