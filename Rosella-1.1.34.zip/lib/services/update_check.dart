import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

import 'notifier.dart';

/// Installed version. Publish GitHub releases with a tag like v1.1.1 (higher than this).
const String kAppVersion = '1.1.34';
const String kReleasesPage = 'https://github.com/Suhebtaha/Rosella/releases/latest';

class UpdateInfo {
  final bool available;
  final String tag;
  final String url;
  final bool failed;
  final String apkUrl;
  const UpdateInfo(
      {this.available = false,
      this.tag = '',
      this.url = kReleasesPage,
      this.failed = false,
      this.apkUrl = ''});
}

class UpdateCheck {
  static List<int> _parts(String v) {
    final m = RegExp(r'\d+').allMatches(v).map((e) => int.parse(e.group(0)!)).toList();
    while (m.length < 3) {
      m.add(0);
    }
    return m;
  }

  static bool _newer(String a, String b) {
    final x = _parts(a), y = _parts(b);
    for (var i = 0; i < 3; i++) {
      if (x[i] != y[i]) return x[i] > y[i];
    }
    return false;
  }

  static Future<UpdateInfo> check() async {
    try {
      final res = await http
          .get(
            Uri.parse('https://api.github.com/repos/Suhebtaha/Rosella/releases/latest'),
            headers: {'Accept': 'application/vnd.github+json'},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 404) return const UpdateInfo(); // no release yet
      if (res.statusCode != 200) return const UpdateInfo(failed: true);
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final tag = (j['tag_name'] ?? '').toString();
      final url = (j['html_url'] ?? kReleasesPage).toString();
      if (tag.isEmpty) return const UpdateInfo();
      var apk = '';
      for (final a in (j['assets'] as List? ?? const [])) {
        final m = a as Map;
        final n = (m['name'] ?? '').toString().toLowerCase();
        if (n.endsWith('.apk')) {
          apk = (m['browser_download_url'] ?? '').toString();
          break;
        }
      }
      return UpdateInfo(available: _newer(tag, kAppVersion), tag: tag, url: url, apkUrl: apk);
    } catch (_) {
      return const UpdateInfo(failed: true);
    }
  }

  /// Opens the link in the browser / GitHub app. Returns false if nothing could open it.
  static Future<bool> open(String url) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('open', {'url': url}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Downloads the APK to the cache folder; [onProgress] gets 0..1. Returns the file path.
  static Future<String> download(String url, void Function(double) onProgress,
      {void Function(http.Client)? onClient, bool Function()? isCancelled}) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/rosella-update.apk');
    if (file.existsSync()) file.deleteSync();
    final client = http.Client();
    onClient?.call(client);
    try {
      final resp = await client.send(http.Request('GET', Uri.parse(url)))
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) throw Exception('HTTP ${resp.statusCode}');
      final total = resp.contentLength ?? 0;
      var got = 0;
      final sink = file.openWrite();
      await for (final chunk in resp.stream) {
        if (isCancelled?.call() == true) {
          await sink.close();
          throw Exception('cancelled');
        }
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) onProgress((got / total).clamp(0.0, 1.0));
      }
      await sink.flush();
      await sink.close();
      if (got < 1000000) throw Exception('file too small');
      return file.path;
    } finally {
      client.close();
    }
  }

  /// Remember which release the cached APK belongs to (the app may be restarted
  /// by Android while the user grants the install permission).
  static Future<void> markDownloaded(String tag) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('apk_tag', tag);
    } catch (_) {}
  }

  /// Path of an already downloaded APK for [tag], or null.
  static Future<String?> readyPath(String tag) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (p.getString('apk_tag') != tag) return null;
      final ext = await getExternalStorageDirectory();
      final dirs = [if (ext != null) ext.path, (await getTemporaryDirectory()).path];
      for (final d in dirs) {
        final f = File('$d/rosella-update.apk');
        if (f.existsSync() && f.lengthSync() > 1000000) return f.path;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  static const MethodChannel _ch = MethodChannel('rosella/haptic');

  /// Starts a system DownloadManager download (keeps going when the app is closed).
  /// Returns its id, or null when this phone / build cannot do it.
  static Future<String?> dlStart(String url, String title) async {
    try {
      final r = await _ch.invokeMethod<String>('dlStart', {'url': url, 'title': title});
      return (r == null || r.isEmpty) ? null : r;
    } catch (_) {
      return null;
    }
  }

  /// {status, done, total, path} or an empty map when the id is unknown (cancelled).
  static Future<Map<String, dynamic>> dlStatus(String id) async {
    try {
      final r = await _ch.invokeMethod<Map>('dlStatus', {'id': id});
      return {for (final e in (r ?? const {}).entries) e.key.toString(): e.value};
    } catch (_) {
      return {'status': -1};
    }
  }

  static Future<void> dlCancel(String id) async {
    try {
      await _ch.invokeMethod('dlCancel', {'id': id});
    } catch (_) {}
  }

  static Future<void> saveJob(String? id, String tag) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (id == null) {
        await p.remove('dl_id');
        await p.remove('dl_tag');
      } else {
        await p.setString('dl_id', id);
        await p.setString('dl_tag', tag);
      }
    } catch (_) {}
  }

  /// 'ok' (system install screen opened), 'perm' (user must allow installs from this app), 'fail'.
  static Future<String> install(String path) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<String>('install', {'path': path}) ??
          'fail';
    } catch (_) {
      return 'fail';
    }
  }
}

/// One update download for the whole app: keeps running when the dialog is hidden,
/// shows a progress notification and lets Settings display / cancel it.
class UpdateJob extends ChangeNotifier {
  static final UpdateJob I = UpdateJob._();
  UpdateJob._();

  bool downloading = false;
  double progress = 0;
  String tag = '';
  String? readyPath;
  String error = '';
  bool cancelled = false;
  /// set when a download finished while nobody was looking at the dialog
  bool finishedQuietly = false;
  bool dialogOpen = false;
  http.Client? _client;
  int _lastPct = -1;

  String? _dlId;

  Future<void> start(UpdateInfo info,
      {required String title, required String doneTitle, required String doneBody}) async {
    if (downloading) return;
    downloading = true;
    cancelled = false;
    error = '';
    progress = 0;
    tag = info.tag;
    finishedQuietly = false;
    _lastPct = -1;
    notifyListeners();
    try {
      // preferred: the system DownloadManager (survives leaving / closing the app)
      final id = await UpdateCheck.dlStart(info.apkUrl, title);
      if (id != null) {
        _dlId = id;
        await UpdateCheck.saveJob(id, info.tag);
        await _poll(id, info.tag, doneTitle, doneBody);
      } else {
        await _httpDownload(info, title, doneTitle, doneBody);
      }
    } catch (e) {
      downloading = false;
      await Notifier.updateClear();
      if (!cancelled) {
        final m = e.toString().replaceAll('Exception: ', '');
        error = m.length > 70 ? m.substring(0, 70) : m;
      }
    }
    _client = null;
    notifyListeners();
  }

  /// After the app was closed and opened again: pick up a download that kept running.
  Future<void> resume() async {
    if (downloading) return;
    try {
      final p = await SharedPreferences.getInstance();
      final id = p.getString('dl_id');
      final t = p.getString('dl_tag');
      if (id == null || t == null) return;
      downloading = true;
      cancelled = false;
      error = '';
      tag = t;
      _dlId = id;
      notifyListeners();
      try {
        await _poll(id, t, '', '');
      } catch (e) {
        downloading = false;
        final m = e.toString().replaceAll('Exception: ', '');
        if (!cancelled && m != 'gone') error = m.length > 70 ? m.substring(0, 70) : m;
      }
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _poll(String id, String t, String doneTitle, String doneBody) async {
    while (true) {
      if (cancelled) {
        await UpdateCheck.dlCancel(id);
        await UpdateCheck.saveJob(null, '');
        downloading = false;
        throw Exception('cancelled');
      }
      final st = await UpdateCheck.dlStatus(id);
      final status = (st['status'] as num?)?.toInt() ?? -1;
      if (status == 8) {
        final path = (st['path'] ?? '').toString();
        await UpdateCheck.saveJob(null, '');
        if (path.isEmpty || !File(path).existsSync() || File(path).lengthSync() < 1000000) {
          throw Exception('file too small');
        }
        await UpdateCheck.markDownloaded(t);
        readyPath = path;
        progress = 1;
        downloading = false;
        if (!dialogOpen) {
          finishedQuietly = true;
          if (doneTitle.isNotEmpty) await Notifier.updateDone(doneTitle, doneBody);
        }
        return;
      }
      if (status == 16) {
        await UpdateCheck.saveJob(null, '');
        throw Exception('download failed (${st['reason'] ?? ''})');
      }
      if (status == -1 || st.isEmpty) {
        // removed by the user from the system notification
        await UpdateCheck.saveJob(null, '');
        downloading = false;
        throw Exception('gone');
      }
      final total = (st['total'] as num?)?.toDouble() ?? 0;
      final done = (st['done'] as num?)?.toDouble() ?? 0;
      if (total > 0) {
        progress = (done / total).clamp(0.0, 1.0);
        notifyListeners();
      }
      await Future<void>.delayed(const Duration(milliseconds: 700));
    }
  }

  Future<void> _httpDownload(
      UpdateInfo info, String title, String doneTitle, String doneBody) async {
    final path = await UpdateCheck.download(info.apkUrl, (v) {
      progress = v;
      final pct = (v * 100).round();
      if (pct != _lastPct) {
        _lastPct = pct;
        if (pct % 2 == 0) Notifier.updateProgress(pct, title);
        notifyListeners();
      }
    }, onClient: (c) => _client = c, isCancelled: () => cancelled);
    await UpdateCheck.markDownloaded(info.tag);
    readyPath = path;
    downloading = false;
    if (!dialogOpen) {
      finishedQuietly = true;
      await Notifier.updateDone(doneTitle, doneBody);
    } else {
      await Notifier.updateClear();
    }
  }

  void cancel() {
    if (!downloading) return;
    cancelled = true;
    try {
      _client?.close();
    } catch (_) {}
  }

  void acknowledge() {
    finishedQuietly = false;
    notifyListeners();
  }
}
