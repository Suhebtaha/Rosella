## Rosella 1.1.117

- Social features removed: no followers/following, friends, notifications or public/friends visibility. Rosella stays a private dream journal.
- Profile keeps your photo, name, bio, dream stats (dreams, day streak, lucid, recurring), unlocked achievements, and your dreams as a feed. The email is no longer shown.
