import 'models.dart';

class SymbolCount {
  final String word;
  final int dreams;
  const SymbolCount(this.word, this.dreams);
}

const Set<String> _stop = {
  // Arabic
  'في','من','على','الي','عن','مع','كان','كانت','كنت','ثم','هذا','هذه','ذلك','تلك','التي','الذي','انا','لكن','حتي','كل','بعد','قبل','عند','هو','هي','هم','او','ان','انه','انها','لم','لا','ما','ماذا','قد','كانوا','يكون','وكان','وكانت','فقط','جدا','هناك','هنا','حيث','بين','اني','لقد','اذا','ايضا','الا','له','لها','بها','به','منه','منها','فيه','فيها','عليه','عليها','حلمت','رايت','حلم','شفت','وانا','واني','لكني','وكنت','ثم','بعدها','فجاه','كأن','كان','يعني','شي','شيء','اللي','هاي','هذي','بس','مو','وين','شلون','ليش','كلها','كله','نفس','احد','شخص','اشخاص','اني','وبعدين',
  // English
  'the','and','was','were','that','this','with','for','you','had','have','has','but','not','are','from','they','them','his','her','she','him','then','there','their','what','when','where','who','into','out','about','just','like','very','been','being','would','could','dream','dreamed','dreamt','saw','one','all','got','get','went','came','some','also','still','even','while','after','before','over','back','around','through','than','too','can','did','does','its','our','your','mine','myself','because','were','which','will','much','more','many','made','make',
  // Kurdish (Sorani)
  'ئەو','ئەم','لە','بە','کە','من','لەگەڵ','بۆ','دا','هەبوو','بوو','بووم','ئەوە','ئەمە','یان','هەر','تەنها','زۆر','کاتێک','دواتر','پاشان','خەون','خەونم','بینیم','دەمبینی','لەناو','ئێمە','ئەوان','ئەویش','هیچ','هەموو','وەک','ڕۆیشتم','دوای','پێش','نێوان','چوومە','بووین','دەکرد','کرد','دەبوو','ئەگەر','بەڵام','چونکە','هێشتا','یەکێک','کەسێک','شتێک','لێ','پێ','تێ','ئەوەی','ئەوەش',
};

String _norm(String s) {
  var t = s.toLowerCase();
  t = t.replaceAll(RegExp('[ً-ْـ]'), '');
  t = t
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ک', 'ك')
      .replaceAll('ی', 'ي');
  return t;
}

final RegExp _split = RegExp(r'[^\p{L}\p{N}]+', unicode: true);
final Set<String> _stopN = _stop.map(_norm).toSet();

Set<String> _tokens(Dream d) {
  final out = <String>{};
  for (var w in _norm('${d.title} ${d.content}').split(_split)) {
    if (w.length > 4 && w.startsWith('ال')) w = w.substring(2);
    if (w.length < 3 || _stopN.contains(w)) continue;
    if (RegExp(r'^\d+$').hasMatch(w)) continue;
    out.add(w);
  }
  return out;
}

/// Words that show up in at least two different dreams, most frequent first.
List<SymbolCount> recurringSymbols(List<Dream> dreams, {int max = 10}) {
  final counts = <String, int>{};
  for (final d in dreams) {
    for (final w in _tokens(d)) {
      counts[w] = (counts[w] ?? 0) + 1;
    }
  }
  final list = counts.entries
      .where((e) => e.value >= 2)
      .map((e) => SymbolCount(e.key, e.value))
      .toList()
    ..sort((a, b) {
      final c = b.dreams.compareTo(a.dreams);
      return c != 0 ? c : a.word.compareTo(b.word);
    });
  return list.take(max).toList();
}
