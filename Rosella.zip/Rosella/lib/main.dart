import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/nav_bus.dart';
import 'core/theme.dart';
import 'services/sound_session.dart';
import 'services/widget_sync.dart';
import 'services/sounds.dart';
import 'ui/lock_screen.dart';
import 'ui/now_playing.dart';
import 'ui/root.dart';
import 'ui/widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  final state = AppState();
  await state.init();
  state.addListener(() => WidgetSync.schedule(state));
  WidgetSync.schedule(state);
  SoundAudioHandler? handler;
  try {
    handler = await AudioService.init(
      builder: () => SoundAudioHandler(),
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'com.suhaib.rosella.sounds',
        androidNotificationChannelName: 'Rosella sounds',
        androidNotificationIcon: 'drawable/ic_stat_rosella',
        androidNotificationOngoing: true,
      ),
    ).timeout(const Duration(seconds: 6));
    SoundAudioHandler.status = 'ok';
  } catch (e) {
    handler = null; // the app still works, just without the media notification
    SoundAudioHandler.status = 'init failed: $e';
  }
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: state),
        ChangeNotifierProvider<SoundController>(
            create: (_) => SoundController(handler: handler, langOf: () => state.lang)),
      ],
      child: const DreamsApp(),
    ),
  );
}

class DreamsApp extends StatelessWidget {
  const DreamsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = context.select<AppState, String>((s) => s.lang);
    final themeId = context.select<AppState, String>((s) => s.themeId);
    final dark = context.select<AppState, bool>((s) => s.dark);
    return MaterialApp(
      title: 'Rosella',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: rootMessengerKey,
      navigatorKey: rootNavKey,
      theme: buildTheme(themeId, dark),
      locale: lang == 'en' ? const Locale('en') : const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final locked = context.select<AppState, bool>((s) => s.locked);
        final icons = (dark || themeId == 'onyx') ? Brightness.light : Brightness.dark;
        return LifecycleGate(
          child: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness: icons,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarIconBrightness: icons,
            ),
            child: Stack(
              children: [
                Positioned.fill(child: child ?? const SizedBox.shrink()),
                const _Wordmark(),
                const NowPlayingIsland(),
                Positioned.fill(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: locked
                        ? const LockScreen(key: ValueKey('lock'))
                        : const SizedBox.shrink(key: ValueKey('open')),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      home: const RootGate(),
    );
  }
}

/// "Rosella" shown small at the top of every page.
class _Wordmark extends StatelessWidget {
  const _Wordmark();

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return ValueListenableBuilder<bool>(
      valueListenable: splashShowing,
      builder: (context, splash, _) {
        final locked = context.select<AppState, bool>((s) => s.locked);
        final show = !splash && !locked;
        final c = context.colors;
        return PositionedDirectional(
          top: top > 6 ? top - 5 : 2,
          start: 20,
          child: IgnorePointer(
            child: AnimatedOpacity(
              opacity: show ? 1 : 0,
              duration: const Duration(milliseconds: 500),
              child: ShaderMask(
                shaderCallback: (r) => c.gradient.createShader(r),
                child: const Text(
                  'Rosella',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.6,
                    decoration: TextDecoration.none,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
