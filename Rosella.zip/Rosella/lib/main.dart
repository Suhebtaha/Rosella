import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/theme.dart';
import 'services/sounds.dart';
import 'ui/lock_screen.dart';
import 'ui/now_playing.dart';
import 'ui/root.dart';
import 'ui/widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  final state = AppState();
  await state.init();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: state),
        ChangeNotifierProvider<SoundController>(create: (_) => SoundController()),
      ],
      child: const DreamsApp(),
    ),
  );
}

class DreamsApp extends StatelessWidget {
  const DreamsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = context.select<AppState, String>((s) => s.lang);
    final themeId = context.select<AppState, String>((s) => s.themeId);
    final dark = context.select<AppState, bool>((s) => s.dark);
    return MaterialApp(
      title: 'Rosella',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: rootMessengerKey,
      theme: buildTheme(themeId, dark),
      locale: lang == 'en' ? const Locale('en') : const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final locked = context.select<AppState, bool>((s) => s.locked);
        final icons = dark ? Brightness.light : Brightness.dark;
        return LifecycleGate(
          child: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness: icons,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarIconBrightness: icons,
            ),
            child: Stack(
              children: [
                Positioned.fill(child: child ?? const SizedBox.shrink()),
                const NowPlayingIsland(),
                Positioned.fill(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: locked
                        ? const LockScreen(key: ValueKey('lock'))
                        : const SizedBox.shrink(key: ValueKey('open')),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      home: const RootGate(),
    );
  }
}
