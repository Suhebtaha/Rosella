import 'dart:math' as math;

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/symbols.dart';
import '../core/theme.dart';
import 'lucid_page.dart';
import 'widgets.dart';

class InsightsPage extends StatelessWidget {
  const InsightsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final st = app.stats;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final days = <DateTime>[
      for (var i = 6; i >= 0; i--) DateTime(today.year, today.month, today.day - i)
    ];
    double avgFor(DateTime day) {
      final ds = app.dreams.where((d) =>
          d.createdAt.year == day.year &&
          d.createdAt.month == day.month &&
          d.createdAt.day == day.day);
      if (ds.isEmpty) return 0;
      return ds.map((d) => d.mood).reduce((a, b) => a + b) / ds.length;
    }

    final counts = List<int>.generate(
        5, (i) => app.dreams.where((d) => d.mood == i + 1).length);
    final maxCount = math.max(1, counts.reduce(math.max));
    final symbols = recurringSymbols(app.dreams);

    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
            child: Text(context.t('ins_title'),
                style: TextStyle(
                    color: c.text,
                    fontSize: 32,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5)),
          ),
          Row(
            children: [
              Expanded(
                  child: _StatTile(
                      icon: Icons.nights_stay_rounded,
                      value: st.total,
                      label: context.t('ins_total'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _StatTile(
                      icon: Icons.local_fire_department_rounded,
                      value: st.streak,
                      label: context.t('ins_streak'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _StatTile(
                      icon: Icons.mic_rounded,
                      value: st.voice,
                      label: context.t('ins_voice'))),
            ],
          ),
          const SizedBox(height: 14),
          Panel(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('ins_week'),
                    style: TextStyle(
                        color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                SizedBox(
                  height: 168,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (final day in days)
                        Expanded(
                            child: _DayBar(day: day, avg: avgFor(day), lang: app.lang)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('ins_dist'),
                    style: TextStyle(
                        color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                for (var m = 5; m >= 1; m--)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      children: [
                        Text(moodEmoji(m), style: const TextStyle(fontSize: 20)),
                        const SizedBox(width: 10),
                        SizedBox(
                          width: 64,
                          child: Text(context.t('mood_$m'),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: c.dim, fontSize: 12.5)),
                        ),
                        Expanded(
                          child: TweenAnimationBuilder<double>(
                            tween: Tween(begin: 0, end: counts[m - 1] / maxCount),
                            duration: const Duration(milliseconds: 700),
                            curve: Curves.easeOutCubic,
                            builder: (_, v, __) => ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: Stack(
                                children: [
                                  Container(height: 10, color: c.surfaceHi),
                                  FractionallySizedBox(
                                    widthFactor: v.clamp(0.0, 1.0),
                                    child: Container(height: 10, color: moodColor(m)),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 32,
                          child: Text('${counts[m - 1]}',
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                  color: c.text,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13)),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('sym_title'),
                    style: TextStyle(
                        color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(context.t('sym_sub'),
                    style: TextStyle(color: c.dim, fontSize: 12.5)),
                const SizedBox(height: 12),
                if (symbols.isEmpty)
                  Text(context.t('sym_none'),
                      style: TextStyle(color: c.dim, fontSize: 13.5))
                else
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final s in symbols)
                        Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: al(c.a, 0.14),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: al(c.a, 0.35)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(s.word,
                                  style: TextStyle(
                                      color: c.text,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700)),
                              const SizedBox(width: 6),
                              Text('×${s.dreams}',
                                  style: TextStyle(
                                      color: c.a,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                    ],
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Panel(
            onTap: () => Navigator.of(context)
                .push(CupertinoPageRoute<void>(builder: (_) => const LucidPage())),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    gradient: c.gradient,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.visibility_rounded, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(context.t('lucid_title'),
                          style: TextStyle(
                              color: c.text,
                              fontSize: 16,
                              fontWeight: FontWeight.w800)),
                      Text(context.t('lucid_entry'),
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: c.dim),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
            child: Text(context.t('ins_ach'),
                style: TextStyle(
                    color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
          ),
          for (var i = 0; i < kAchievements.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _AchievementRow(
                def: kAchievements[i],
                value: kAchievements[i].value(st),
                unlocked: app.unlocked.contains(kAchievements[i].id),
                lang: app.lang,
              ),
            ),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final IconData icon;
  final int value;
  final String label;
  const _StatTile({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Panel(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
      child: Column(
        children: [
          Icon(icon, color: c.a, size: 24),
          const SizedBox(height: 8),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: value.toDouble()),
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) => Text('${v.round()}',
                style: TextStyle(
                    color: c.text, fontSize: 26, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 2),
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: c.dim, fontSize: 12)),
        ],
      ),
    );
  }
}

class _DayBar extends StatelessWidget {
  final DateTime day;
  final double avg;
  final String lang;
  const _DayBar({required this.day, required this.avg, required this.lang});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final has = avg > 0;
    final mood = avg.round().clamp(1, 5);
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        SizedBox(
          height: 24,
          child: has
              ? Text(moodEmoji(mood), style: const TextStyle(fontSize: 18))
              : Text('·', style: TextStyle(color: c.dim, fontSize: 18)),
        ),
        const SizedBox(height: 4),
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: has ? 14 + (avg / 5) * 90 : 8),
          duration: const Duration(milliseconds: 700),
          curve: Curves.easeOutCubic,
          builder: (_, h, __) => Container(
            width: 20,
            height: h,
            decoration: BoxDecoration(
              color: has ? moodColor(mood) : c.surfaceHi,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(Strings.get(lang, 'd${day.weekday}'),
            maxLines: 1,
            style: TextStyle(color: c.dim, fontSize: 11, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _AchievementRow extends StatelessWidget {
  final AchievementDef def;
  final int value;
  final bool unlocked;
  final String lang;
  const _AchievementRow(
      {required this.def,
      required this.value,
      required this.unlocked,
      required this.lang});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final p = (value / def.target).clamp(0.0, 1.0);
    return Opacity(
      opacity: unlocked ? 1 : 0.7,
      child: Panel(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: unlocked ? c.gradient : null,
                color: unlocked ? null : c.surfaceHi,
              ),
              child: Icon(def.icon, color: unlocked ? Colors.white : c.dim, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(Strings.get(lang, def.titleKey),
                      style: TextStyle(
                          color: c.text, fontSize: 15.5, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(Strings.get(lang, def.descKey),
                      style: TextStyle(color: c.dim, fontSize: 12.5)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TweenAnimationBuilder<double>(
                          tween: Tween(begin: 0, end: unlocked ? 1.0 : p),
                          duration: const Duration(milliseconds: 700),
                          curve: Curves.easeOutCubic,
                          builder: (_, v, __) => ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: v,
                              minHeight: 6,
                              backgroundColor: c.surfaceHi,
                              valueColor: AlwaysStoppedAnimation<Color>(c.a),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        unlocked ? '✓' : '${math.min(value, def.target)}/${def.target}',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                            color: unlocked ? c.a : c.dim,
                            fontSize: 12,
                            fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
