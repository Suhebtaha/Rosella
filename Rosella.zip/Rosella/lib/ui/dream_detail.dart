import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'audio_clip.dart';
import 'dream_editor.dart';
import 'share_card.dart';
import 'widgets.dart';

class DreamDetailPage extends StatefulWidget {
  final String id;
  const DreamDetailPage({super.key, required this.id});

  @override
  State<DreamDetailPage> createState() => _DreamDetailPageState();
}

class _DreamDetailPageState extends State<DreamDetailPage> {
  bool _interpreting = false;
  bool _genImage = false;

  Future<void> _interpret(Dream d) async {
    final app = context.read<AppState>();
    if (d.content.trim().isEmpty && d.title.trim().isEmpty) {
      toast(context, app.tr('interpret_need_text'));
      return;
    }
    setState(() => _interpreting = true);
    final res = await AiService.interpret(
      title: d.title,
      content: d.content,
      lang: app.lang,
      mood: d.mood,
    );
    if (!mounted) return;
    final cur = app.byId(d.id) ?? d;
    await app.updateDream(cur.copyWith(interpretation: res.text));
    if (res.fromAi) app.bumpAi();
    if (!mounted) return;
    setState(() => _interpreting = false);
    if (!res.fromAi) toast(context, app.tr('offline_note'));
  }

  Future<void> _generate(Dream d) async {
    final app = context.read<AppState>();
    if (d.content.trim().isEmpty && d.title.trim().isEmpty) {
      toast(context, app.tr('interpret_need_text'));
      return;
    }
    setState(() => _genImage = true);
    final rel = app.newFileRel('images', 'jpg');
    final ok = await AiService.generateImage(
      title: d.title,
      content: d.content,
      savePath: app.abs(rel)!,
    );
    if (!mounted) return;
    if (ok) {
      final cur = app.byId(d.id) ?? d;
      await app.updateDream(cur.copyWith(image: rel));
      app.bumpImg();
    } else {
      toast(context, app.tr('image_failed'));
    }
    if (mounted) setState(() => _genImage = false);
  }

  Future<void> _delete(Dream d) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_title'),
      message: app.tr('delete_confirm'),
      confirm: app.tr('delete'),
    );
    if (!ok) return;
    await app.deleteDream(d.id);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final d = app.byId(widget.id);
    if (d == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
      });
      return const SizedBox.shrink();
    }
    final c = context.colors;
    final imgPath = app.abs(d.image);
    final title = d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;

    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            actions: [
              RoundIconButton(
                icon: Icons.ios_share_rounded,
                onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                    builder: (_) => ShareCardPage(id: d.id))),
              ),
              RoundIconButton(
                icon: Icons.edit_rounded,
                onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                    builder: (_) => DreamEditorPage(dream: d))),
              ),
              RoundIconButton(
                icon: Icons.delete_outline_rounded,
                color: const Color(0xFFFF5470),
                onTap: () => _delete(d),
              ),
            ],
          ),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                if (imgPath != null)
                  FadeSlide(
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                          builder: (_) => _ImageViewer(path: imgPath))),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(26),
                        child: Image.file(
                          File(imgPath),
                          height: 250,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          cacheWidth: 1100,
                          errorBuilder: (_, __, ___) => Container(
                            height: 250,
                            color: c.surfaceHi,
                            child: Icon(Icons.broken_image_rounded, color: c.dim),
                          ),
                        ),
                      ),
                    ),
                  ),
                if (imgPath != null) const SizedBox(height: 16),
                Text(title,
                    style: TextStyle(
                        color: c.text,
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: al(moodColor(d.mood), 0.18),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 6),
                          Text(context.t('mood_${d.mood}'),
                              style: TextStyle(
                                  color: c.text, fontWeight: FontWeight.w700, fontSize: 13)),
                        ],
                      ),
                    ),
                    Text('${fmtDate(d.createdAt, app.lang)} • ${fmtTime(d.createdAt)}',
                        style: TextStyle(color: c.dim, fontSize: 13)),
                  ],
                ),
                if (d.audio != null) ...[
                  const SizedBox(height: 16),
                  AudioClip(
                    key: ValueKey(d.audio),
                    path: app.abs(d.audio)!,
                    durationMs: d.audioMs,
                  ),
                ],
                if (d.content.trim().isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Panel(
                    padding: const EdgeInsets.all(18),
                    child: SelectableText(
                      d.content,
                      style: TextStyle(color: c.text, fontSize: 16.5, height: 1.65),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GradientButton(
                        label: d.interpretation == null
                            ? context.t('interpret')
                            : context.t('reinterpret'),
                        icon: Icons.psychology_rounded,
                        loading: _interpreting,
                        expand: true,
                        onTap: () => _interpret(d),
                      ),
                    ),
                    if (d.image == null) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: _genImage
                            ? SubtleButton(
                                label: context.t('generating'),
                                icon: Icons.hourglass_top_rounded,
                              )
                            : SubtleButton(
                                label: context.t('gen_image'),
                                icon: Icons.auto_awesome_rounded,
                                onTap: () => _generate(d),
                              ),
                      ),
                    ],
                  ],
                ),
                if (_interpreting)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Center(
                      child: Text(context.t('interpreting'),
                          style: TextStyle(color: c.dim, fontSize: 13)),
                    ),
                  ),
                if (d.interpretation != null) ...[
                  const SizedBox(height: 16),
                  FadeSlide(
                    child: Panel(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: c.a, size: 20),
                              const SizedBox(width: 8),
                              Text(context.t('interpretation'),
                                  style: TextStyle(
                                      color: c.text,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          SelectableText(
                            d.interpretation!,
                            style: TextStyle(color: c.text, fontSize: 15.5, height: 1.7),
                          ),
                          const SizedBox(height: 12),
                          Text(context.t('ai_note'),
                              style: TextStyle(color: c.dim, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ImageViewer extends StatelessWidget {
  final String path;
  const _ImageViewer({required this.path});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Center(
            child: InteractiveViewer(
              maxScale: 5,
              child: Image.file(File(path)),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: RoundIconButton(
                icon: Icons.close_rounded,
                onTap: () => Navigator.of(context).pop(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
