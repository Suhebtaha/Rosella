import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'dream_detail.dart';
import 'widgets.dart';

/// Month calendar: days with dreams are coloured by the average mood.
class DreamCalendar extends StatefulWidget {
  const DreamCalendar({super.key});

  @override
  State<DreamCalendar> createState() => _DreamCalendarState();
}

class _DreamCalendarState extends State<DreamCalendar> {
  late DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);

  static const _wdAr = ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']; // Sat..Fri
  static const _wdEn = ['S', 'M', 'T', 'W', 'T', 'F', 'S']; // Sun..Sat

  void _shift(int d) => setState(() => _month = DateTime(_month.year, _month.month + d));

  void _openDay(BuildContext context, List<Dream> ds) {
    if (ds.length == 1) {
      Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: ds.first.id)));
      return;
    }
    final c = context.colors;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(16),
          children: [
            for (final d in ds)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Panel(
                  onTap: () {
                    Navigator.of(ctx).pop();
                    Navigator.of(context).push(CupertinoPageRoute<void>(
                        builder: (_) => DreamDetailPage(id: d.id)));
                  },
                  child: Row(
                    children: [
                      Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          d.title.isEmpty ? fmtTime(d.createdAt) : d.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: c.text, fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                      ),
                      Text(fmtTime(d.createdAt),
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final rtl = app.lang != 'en';
    final first = DateTime(_month.year, _month.month, 1);
    final daysIn = DateTime(_month.year, _month.month + 1, 0).day;
    // Arabic/Kurdish weeks start on Saturday, English on Sunday
    final offset = rtl ? (first.weekday + 1) % 7 : first.weekday % 7;
    final wd = rtl ? _wdAr : _wdEn;
    final now = DateTime.now();

    final byDay = <int, List<Dream>>{};
    for (final d in app.dreams) {
      if (d.createdAt.year == _month.year && d.createdAt.month == _month.month) {
        byDay.putIfAbsent(d.createdAt.day, () => []).add(d);
      }
    }

    return Panel(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
      child: Column(
        children: [
          Row(
            children: [
              RoundIconButton(
                  icon: rtl ? Icons.chevron_right_rounded : Icons.chevron_left_rounded,
                  onTap: () => _shift(-1)),
              Expanded(
                child: Center(
                  child: Text('${context.t('m${_month.month}')} ${_month.year}',
                      style: TextStyle(
                          color: c.text, fontSize: 16.5, fontWeight: FontWeight.w800)),
                ),
              ),
              RoundIconButton(
                  icon: rtl ? Icons.chevron_left_rounded : Icons.chevron_right_rounded,
                  onTap: () => _shift(1)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              for (final w in wd)
                Expanded(
                  child: Center(
                    child: Text(w,
                        style: TextStyle(
                            color: c.dim, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          for (var row = 0; row < 6; row++)
            if (row * 7 - offset < daysIn)
              Row(
                children: [
                  for (var col = 0; col < 7; col++)
                    Expanded(child: _cell(context, c, row * 7 + col - offset + 1, daysIn, byDay, now)),
                ],
              ),
        ],
      ),
    );
  }

  Widget _cell(BuildContext context, AppColors c, int day, int daysIn,
      Map<int, List<Dream>> byDay, DateTime now) {
    if (day < 1 || day > daysIn) return const SizedBox(height: 42);
    final ds = byDay[day];
    final isToday =
        now.year == _month.year && now.month == _month.month && now.day == day;
    Color? fill;
    if (ds != null) {
      final avg = ds.map((d) => d.mood).reduce((a, b) => a + b) / ds.length;
      fill = moodColor(avg.round());
    }
    return Padding(
      padding: const EdgeInsets.all(3),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: ds == null ? null : () => _openDay(context, ds),
        child: Container(
          height: 36,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: fill == null ? null : al(fill, 0.85),
            border: isToday ? Border.all(color: c.a, width: 2) : null,
          ),
          child: Text('$day',
              style: TextStyle(
                  color: fill != null ? Colors.white : c.text,
                  fontSize: 13.5,
                  fontWeight: fill != null ? FontWeight.w800 : FontWeight.w500)),
        ),
      ),
    );
  }
}
