import 'dart:async';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart' show SpringDescription, SpringSimulation;
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'home_page.dart';
import 'insights_page.dart';
import 'quick_voice.dart';
import 'settings_page.dart';
import 'sounds_page.dart';
import 'widgets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  int _prev = 0;
  StreamSubscription<AchievementDef>? _sub;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _sub = app.unlockStream.listen((a) => _onUnlock(app, a));
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _onUnlock(AppState app, AchievementDef a) {
    HapticFeedback.mediumImpact();
    final pal = AppColors.from(paletteById(app.themeId), app.dark);
    rootMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 120),
        duration: const Duration(seconds: 4),
        content: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: pal.gradient,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [BoxShadow(color: al(pal.a, 0.4), blurRadius: 24)],
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: al(Colors.white, 0.25)),
                child: Icon(a.icon, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(Strings.get(app.lang, 'ach_unlocked'),
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w600)),
                    Text(Strings.get(app.lang, a.titleKey),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ));
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const HomePage();
      case 1:
        return const InsightsPage();
      case 2:
        return const SoundsPage();
      default:
        return const SettingsPage();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final keyboard = MediaQuery.of(context).viewInsets.bottom > 0;
    return Scaffold(
      backgroundColor: c.bg,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Positioned.fill(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 340),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, anim) {
                final rtl = Directionality.of(context) == TextDirection.rtl;
                final dir = (_tab >= _prev ? 1.0 : -1.0) * (rtl ? -1.0 : 1.0);
                final isNew = child.key == ValueKey(_tab);
                final begin = Offset((isNew ? 0.10 : -0.10) * dir, 0);
                return FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(begin: begin, end: Offset.zero).animate(anim),
                    child: child,
                  ),
                );
              },
              child: KeyedSubtree(key: ValueKey(_tab), child: _page(_tab)),
            ),
          ),
          if (!keyboard)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: GlassNavBar(
                index: _tab,
                onTap: (i) => setState(() {
                  _prev = _tab;
                  _tab = i;
                }),
                onMic: () {
                  HapticFeedback.mediumImpact();
                  showQuickVoice(context);
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String key;
  const _NavItem(this.icon, this.key);
}

class GlassNavBar extends StatefulWidget {
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onMic;
  const GlassNavBar(
      {super.key, required this.index, required this.onTap, required this.onMic});

  static const List<_NavItem> items = [
    _NavItem(Icons.nights_stay_rounded, 'tab_dreams'),
    _NavItem(Icons.insights_rounded, 'tab_insights'),
    _NavItem(Icons.headphones_rounded, 'tab_sounds'),
    _NavItem(Icons.tune_rounded, 'tab_settings'),
  ];

  @override
  State<GlassNavBar> createState() => _GlassNavBarState();
}

class _GlassNavBarState extends State<GlassNavBar> with SingleTickerProviderStateMixin {
  // the lens position in "tab units": 0.0 = first tab … 3.0 = last tab
  late final AnimationController _c =
      AnimationController.unbounded(vsync: this, value: widget.index.toDouble());
  static const double _pad = 6;
  static const SpringDescription _spring =
      SpringDescription(mass: 1, stiffness: 300, damping: 21);

  bool _dragging = false;
  bool _pressed = false;
  bool _rtl = false;
  double _w = 240;
  int _lastTick = 0;

  double _gap = 0; // empty space in the middle of the bar when the mic sits there

  double get _tabW => (_w - _pad * 2 - _gap) / 4;

  double _slot(int i) => _pad + i * _tabW + (i >= 2 ? _gap : 0);

  /// left edge of the lens for a (fractional) tab position
  double _startFor(double p) {
    final i = p.floor().clamp(0, 2);
    final f = p - i;
    return _slot(i) + f * (_slot(i + 1) - _slot(i));
  }

  @override
  void didUpdateWidget(covariant GlassNavBar old) {
    super.didUpdateWidget(old);
    if (old.index != widget.index && !_dragging) _animateTo(widget.index);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _animateTo(int i, {double velocity = 0}) {
    _c.animateWith(SpringSimulation(_spring, _c.value, i.toDouble(), velocity));
  }

  double _posFromX(double x) {
    if (_rtl) x = _w - x;
    final half = _tabW / 2;
    if (x <= _slot(0) + half) return 0;
    if (x >= _slot(3) + half) return 3;
    for (var i = 0; i < 3; i++) {
      final a = _slot(i) + half;
      final b = _slot(i + 1) + half;
      if (x <= b) return i + (x - a) / (b - a);
    }
    return 3;
  }

  void _grab(double x) {
    if (!_dragging) {
      HapticFeedback.lightImpact();
      setState(() {
        _dragging = true;
        _pressed = true;
      });
    }
    _c.stop();
    _c.value = _posFromX(x);
    final r = _c.value.round();
    if (r != _lastTick) {
      _lastTick = r;
      HapticFeedback.selectionClick();
    }
  }

  void _release() {
    final t = _c.value.round().clamp(0, 3);
    setState(() {
      _dragging = false;
      _pressed = false;
    });
    _animateTo(t);
    if (t != widget.index) widget.onTap(t);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final bottom = MediaQuery.of(context).padding.bottom;
    _rtl = Directionality.of(context) == TextDirection.rtl;
    final center = context.select<AppState, bool>((s) => s.micCenter);
    _gap = center ? 74 : 0;
    if (center) {
      return Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 10 + bottom),
        child: SizedBox(
          height: 94,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(left: 0, right: 0, bottom: 0, height: 68, child: _bar(c)),
              Positioned(
                  left: 0, right: 0, top: 0, child: Center(child: _MicButton(onTap: widget.onMic))),
            ],
          ),
        ),
      );
    }
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 10 + bottom),
      child: SizedBox(
        height: 68,
        child: Row(
          children: [
            Expanded(child: _bar(c)),
            const SizedBox(width: 12),
            _MicButton(onTap: widget.onMic),
          ],
        ),
      ),
    );
  }

  Widget _bar(AppColors c) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(34),
        boxShadow: [
          BoxShadow(
              color: al(Colors.black, c.isDark ? 0.5 : 0.12),
              blurRadius: 28,
              offset: const Offset(0, 10)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: c.isDark
                    ? [al(const Color(0xFF2A2A38), 0.55), al(const Color(0xFF101018), 0.7)]
                    : [al(Colors.white, 0.8), al(Colors.white, 0.6)],
              ),
              borderRadius: BorderRadius.circular(34),
              border: Border.all(
                  color: c.isDark ? al(Colors.white, 0.16) : al(Colors.black, 0.06)),
            ),
            child: LayoutBuilder(builder: (ctx, cons) {
              _w = cons.maxWidth;
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapDown: (_) => setState(() => _pressed = true),
                onTapCancel: () => setState(() => _pressed = false),
                onTapUp: (d) {
                  final t = _posFromX(d.localPosition.dx).round().clamp(0, 3);
                  setState(() => _pressed = false);
                  if (t != widget.index) HapticFeedback.selectionClick();
                  _animateTo(t);
                  widget.onTap(t);
                },
                onLongPressStart: (d) => _grab(d.localPosition.dx),
                onLongPressMoveUpdate: (d) => _grab(d.localPosition.dx),
                onLongPressEnd: (_) => _release(),
                onHorizontalDragStart: (d) => _grab(d.localPosition.dx),
                onHorizontalDragUpdate: (d) => _grab(d.localPosition.dx),
                onHorizontalDragEnd: (_) => _release(),
                onHorizontalDragCancel: () {
                  if (_dragging) _release();
                },
                child: AnimatedBuilder(
                  animation: _c,
                  builder: (_, __) {
                    final pos = _c.value;
                    final target = pos.round().clamp(0, 3);
                    final remain = (target - pos).abs().clamp(0.0, 1.0);
                    final stretch = 1 + 0.16 * remain;
                    return Stack(
                      children: [
                        PositionedDirectional(
                          start: _startFor(pos),
                          top: 7,
                          bottom: 7,
                          width: _tabW,
                          child: TweenAnimationBuilder<double>(
                            tween: Tween(
                                end: _dragging ? 1.16 : (_pressed ? 1.06 : 1.0)),
                            duration: const Duration(milliseconds: 260),
                            curve: Curves.easeOutBack,
                            builder: (_, sc, child) => Transform(
                              alignment: Alignment.center,
                              transform: Matrix4.diagonal3Values(sc * stretch, sc, 1),
                              child: child,
                            ),
                            child: _Lens(dragging: _dragging),
                          ),
                        ),
                        for (var i = 0; i < 4; i++)
                          PositionedDirectional(
                            start: _slot(i),
                            top: 0,
                            bottom: 0,
                            width: _tabW,
                            child: _NavButton(
                              item: GlassNavBar.items[i],
                              t: (1 - (pos - i).abs()).clamp(0.0, 1.0),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

/// The sliding "liquid glass" lens behind the active tab.
class _Lens extends StatelessWidget {
  final bool dragging;
  const _Lens({required this.dragging});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            al(c.a, dragging ? 0.50 : 0.36),
            al(c.b, dragging ? 0.34 : 0.22),
          ],
        ),
        border: Border.all(
            color: c.isDark ? al(Colors.white, 0.34) : al(c.a, 0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
              color: al(c.a, dragging ? 0.55 : 0.3),
              blurRadius: dragging ? 24 : 14,
              offset: const Offset(0, 4)),
        ],
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final double t; // 0 = inactive … 1 = under the lens
  const _NavButton({required this.item, required this.t});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final color = Color.lerp(c.dim, c.text, t)!;
    return IgnorePointer(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Transform.scale(
            scale: 1 + 0.12 * t,
            child: Icon(item.icon, size: 24, color: color),
          ),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(context.t(item.key),
                maxLines: 1,
                style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: t > 0.5 ? FontWeight.w800 : FontWeight.w500,
                  color: color,
                )),
          ),
        ],
      ),
    );
  }
}

class _MicButton extends StatefulWidget {
  final VoidCallback onTap;
  const _MicButton({required this.onTap});

  @override
  State<_MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<_MicButton> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2400))
    ..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) {
          final v = Curves.easeInOut.transform(_ctrl.value);
          return Pressable(
            onTap: widget.onTap,
            scale: 0.9,
            child: Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: c.gradient,
                border: Border.all(color: al(Colors.white, 0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: al(c.a, 0.35 + 0.25 * v),
                    blurRadius: 16 + 12 * v,
                    spreadRadius: 0.5 + 2.5 * v,
                  ),
                ],
              ),
              child: Icon(Icons.mic_rounded, color: onAccent(c.a, c.b), size: 30),
            ),
          );
        },
      ),
    );
  }
}
