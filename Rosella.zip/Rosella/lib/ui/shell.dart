import 'dart:async';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'home_page.dart';
import 'insights_page.dart';
import 'quick_voice.dart';
import 'settings_page.dart';
import 'sounds_page.dart';
import 'widgets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  StreamSubscription<AchievementDef>? _sub;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _sub = app.unlockStream.listen((a) => _onUnlock(app, a));
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _onUnlock(AppState app, AchievementDef a) {
    HapticFeedback.mediumImpact();
    final pal = AppColors.from(paletteById(app.themeId), app.dark);
    rootMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 120),
        duration: const Duration(seconds: 4),
        content: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: pal.gradient,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [BoxShadow(color: al(pal.a, 0.4), blurRadius: 24)],
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: al(Colors.white, 0.25)),
                child: Icon(a.icon, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(Strings.get(app.lang, 'ach_unlocked'),
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w600)),
                    Text(Strings.get(app.lang, a.titleKey),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ));
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const HomePage();
      case 1:
        return const InsightsPage();
      case 2:
        return const SoundsPage();
      default:
        return const SettingsPage();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final keyboard = MediaQuery.of(context).viewInsets.bottom > 0;
    return Scaffold(
      backgroundColor: c.bg,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Positioned.fill(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                          begin: const Offset(0, 0.015), end: Offset.zero)
                      .animate(anim),
                  child: child,
                ),
              ),
              child: KeyedSubtree(key: ValueKey(_tab), child: _page(_tab)),
            ),
          ),
          if (!keyboard)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: GlassNavBar(
                index: _tab,
                onTap: (i) => setState(() => _tab = i),
                onMic: () {
                  HapticFeedback.mediumImpact();
                  showQuickVoice(context);
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String key;
  const _NavItem(this.icon, this.key);
}

class GlassNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onMic;
  const GlassNavBar(
      {super.key, required this.index, required this.onTap, required this.onMic});

  static const List<_NavItem> _items = [
    _NavItem(Icons.nights_stay_rounded, 'tab_dreams'),
    _NavItem(Icons.insights_rounded, 'tab_insights'),
    _NavItem(Icons.headphones_rounded, 'tab_sounds'),
    _NavItem(Icons.tune_rounded, 'tab_settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final bottom = MediaQuery.of(context).padding.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 0, 18, 12 + bottom),
      child: SizedBox(
        height: 92,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 70,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  boxShadow: [
                    BoxShadow(
                        color: al(Colors.black, c.isDark ? 0.55 : 0.14),
                        blurRadius: 30,
                        offset: const Offset(0, 12)),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(35),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 36, sigmaY: 36),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: c.isDark
                              ? [al(const Color(0xFF23232F), 0.62), al(const Color(0xFF0E0E16), 0.72)]
                              : [al(Colors.white, 0.82), al(Colors.white, 0.64)],
                        ),
                        borderRadius: BorderRadius.circular(35),
                        border: Border.all(
                            color: c.isDark
                                ? al(Colors.white, 0.14)
                                : al(Colors.black, 0.06),
                            width: 1),
                      ),
                      child: LayoutBuilder(builder: (ctx, cons) {
                        const pad = 8.0;
                        const gap = 84.0;
                        final itemW = (cons.maxWidth - pad * 2 - gap) / 4;
                        double slot(int i) =>
                            pad + (i < 2 ? i * itemW : i * itemW + gap);
                        return Stack(
                          children: [
                            AnimatedPositionedDirectional(
                              duration: const Duration(milliseconds: 420),
                              curve: Curves.easeOutBack,
                              start: slot(index),
                              top: 9,
                              bottom: 9,
                              width: itemW,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: c.gradient,
                                  borderRadius: BorderRadius.circular(26),
                                  boxShadow: [
                                    BoxShadow(
                                        color: al(c.a, 0.45),
                                        blurRadius: 16,
                                        offset: const Offset(0, 5)),
                                  ],
                                ),
                              ),
                            ),
                            for (var i = 0; i < 4; i++)
                              PositionedDirectional(
                                start: slot(i),
                                top: 0,
                                bottom: 0,
                                width: itemW,
                                child: _NavButton(
                                  item: _items[i],
                                  selected: index == i,
                                  onTap: () {
                                    if (index != i) HapticFeedback.selectionClick();
                                    onTap(i);
                                  },
                                ),
                              ),
                          ],
                        );
                      }),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              child: Center(child: _MicButton(onTap: onMic)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final bool selected;
  final VoidCallback onTap;
  const _NavButton({required this.item, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final color = selected ? onAccent(c.a, c.b) : c.dim;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedScale(
            scale: selected ? 1.1 : 1,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutBack,
            child: TweenAnimationBuilder<Color?>(
              tween: ColorTween(end: color),
              duration: const Duration(milliseconds: 250),
              builder: (_, col, __) => Icon(item.icon, size: 24, color: col),
            ),
          ),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 250),
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                color: color,
              ),
              child: Text(context.t(item.key), maxLines: 1),
            ),
          ),
        ],
      ),
    );
  }
}

class _MicButton extends StatefulWidget {
  final VoidCallback onTap;
  const _MicButton({required this.onTap});

  @override
  State<_MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<_MicButton> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2200))
    ..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) {
          final v = Curves.easeInOut.transform(_ctrl.value);
          return Pressable(
            onTap: widget.onTap,
            scale: 0.92,
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: c.gradient,
                border: Border.all(color: al(Colors.white, 0.35), width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: al(c.a, 0.35 + 0.25 * v),
                    blurRadius: 18 + 14 * v,
                    spreadRadius: 1 + 3 * v,
                  ),
                ],
              ),
              child: const Icon(Icons.mic_rounded, color: Colors.white, size: 30),
            ),
          );
        },
      ),
    );
  }
}
