import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'shell.dart';
import 'widgets.dart';

/// Splash (short, never blocks) → first-run onboarding → main shell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splash = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 1300), () {
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final onboarded = context.select<AppState, bool>((s) => s.onboarded);
    return Stack(
      children: [
        Positioned.fill(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: onboarded
                ? const Shell(key: ValueKey('shell'))
                : const OnboardingPage(key: ValueKey('onb')),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            ignoring: !_splash,
            child: AnimatedOpacity(
              opacity: _splash ? 1 : 0,
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOut,
              child: const _Splash(),
            ),
          ),
        ),
      ],
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      color: c.bg,
      child: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Center(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutBack,
              builder: (_, v, child) => Opacity(
                opacity: v.clamp(0.0, 1.0),
                child: Transform.scale(scale: 0.7 + 0.3 * v, child: child),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 104,
                    height: 104,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: c.gradient,
                      boxShadow: [
                        BoxShadow(
                            color: al(c.a, 0.55), blurRadius: 40, spreadRadius: 4),
                      ],
                    ),
                    child: Icon(Icons.nights_stay_rounded,
                        size: 54, color: onAccent(c.a, c.b)),
                  ),
                  const SizedBox(height: 22),
                  ShaderMask(
                    shaderCallback: (r) => c.gradient.createShader(r),
                    child: const Text('Rosella',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pc = PageController();
  int _i = 0;

  static const _icons = [
    Icons.mic_rounded,
    Icons.psychology_rounded,
    Icons.headphones_rounded,
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _next() {
    if (_i >= 2) {
      context.read<AppState>().completeOnboarding();
    } else {
      _pc.nextPage(
          duration: const Duration(milliseconds: 380), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Scaffold(
      backgroundColor: c.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          SafeArea(
            child: Column(
              children: [
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    child: AnimatedOpacity(
                      opacity: _i < 2 ? 1 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: TextButton(
                        onPressed: _i < 2
                            ? () => context.read<AppState>().completeOnboarding()
                            : null,
                        child: Text(context.t('skip'),
                            style: TextStyle(
                                color: c.dim,
                                fontSize: 15,
                                fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    itemCount: 3,
                    onPageChanged: (v) => setState(() => _i = v),
                    itemBuilder: (_, i) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 132,
                            height: 132,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: c.gradient,
                              boxShadow: [
                                BoxShadow(
                                    color: al(c.a, 0.5), blurRadius: 40, spreadRadius: 2),
                              ],
                            ),
                            child: Icon(_icons[i],
                                size: 62, color: onAccent(c.a, c.b)),
                          ),
                          const SizedBox(height: 40),
                          Text(context.t('ob${i + 1}_t'),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: c.text,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.4)),
                          const SizedBox(height: 14),
                          Text(context.t('ob${i + 1}_d'),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: c.dim, fontSize: 16, height: 1.6)),
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < 3; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _i == i ? 26 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: _i == i ? c.a : al(c.dim, 0.4),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 24, 24, 28),
                  child: GradientButton(
                    label: context.t(_i == 2 ? 'start' : 'next'),
                    icon: _i == 2 ? Icons.check_rounded : Icons.arrow_forward_rounded,
                    expand: true,
                    onTap: _next,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
