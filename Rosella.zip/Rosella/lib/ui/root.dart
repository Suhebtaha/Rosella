import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/nav_bus.dart';
import '../core/theme.dart';
import 'shell.dart';
import 'widgets.dart';

/// Splash (short, never blocks) → first-run onboarding → main shell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splash = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    splashShowing.value = true;
    _t = Timer(const Duration(milliseconds: 3000), () {
      splashShowing.value = false;
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final onboarded = context.select<AppState, bool>((s) => s.onboarded);
    return Stack(
      children: [
        Positioned.fill(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: onboarded
                ? const Shell(key: ValueKey('shell'))
                : const OnboardingPage(key: ValueKey('onb')),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            ignoring: !_splash,
            child: AnimatedOpacity(
              opacity: _splash ? 1 : 0,
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOut,
              child: const _Splash(),
            ),
          ),
        ),
      ],
    );
  }
}

/// Cinematic opening: stars fade in, the crescent-and-rose mark draws itself,
/// then ROSELLA appears letter by letter and "by Suhaib" fades in underneath.
class _Splash extends StatefulWidget {
  const _Splash();

  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2800))
        ..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static double _seg(double t, double a, double b) =>
      ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  @override
  Widget build(BuildContext context) {
    const word = 'ROSELLA';
    return Container(
      color: Colors.black,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final stars = Curves.easeOut.transform(_seg(t, 0.0, 0.3));
          final draw = Curves.easeInOutCubic.transform(_seg(t, 0.08, 0.55));
          final glow = Curves.easeOut.transform(_seg(t, 0.2, 0.7));
          final by = Curves.easeOut.transform(_seg(t, 0.82, 1.0));
          return Stack(
            children: [
              Positioned.fill(
                child: Opacity(
                  opacity: stars,
                  child: const CustomPaint(painter: _SplashStars()),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 150,
                      height: 150,
                      child: CustomPaint(painter: _RoseMoonPainter(draw, glow)),
                    ),
                    const SizedBox(height: 26),
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var i = 0; i < word.length; i++)
                            Builder(builder: (context) {
                              final p = Curves.easeOut
                                  .transform(_seg(t, 0.45 + i * 0.045, 0.62 + i * 0.045));
                              return Opacity(
                                opacity: p,
                                child: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 2.0 + 4.0 * p),
                                  child: Text(
                                    word[i],
                                    style: TextStyle(
                                      fontFamily: 'serif',
                                      color: Color.lerp(const Color(0xFF6E86A8),
                                          const Color(0xFFE8E8EC), p),
                                      fontSize: 34,
                                      fontWeight: FontWeight.w500,
                                      shadows: [
                                        Shadow(
                                            color: al(const Color(0xFF9DB7E0), 0.55 * (1 - p)),
                                            blurRadius: 14),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Opacity(
                      opacity: by,
                      child: Text('by Suhaib',
                          style: TextStyle(
                            fontFamily: 'serif',
                            color: al(const Color(0xFFD9D9DE), 0.8),
                            fontSize: 16,
                            letterSpacing: 1.4,
                          )),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SplashStars extends CustomPainter {
  const _SplashStars();

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(7);
    final p = Paint();
    for (var i = 0; i < 140; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final rad = 0.4 + r.nextDouble() * 0.9;
      p.color = Colors.white.withAlpha(30 + r.nextInt(120));
      canvas.drawCircle(Offset(x, y), rad, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Line-art crescent moon holding a rose, drawn progressively.
class _RoseMoonPainter extends CustomPainter {
  final double progress;
  final double glow;
  const _RoseMoonPainter(this.progress, this.glow);

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 150;
    canvas.save();
    canvas.scale(s);

    // soft warm halo behind the mark
    final halo = Paint()
      ..shader = RadialGradient(colors: [
        al(const Color(0xFFE9D6B0), 0.30 * glow),
        al(const Color(0xFFE9D6B0), 0),
      ]).createShader(Rect.fromCircle(center: const Offset(75, 75), radius: 95));
    canvas.drawRect(const Rect.fromLTWH(-40, -40, 230, 230), halo);

    // crescent = big circle minus a shifted circle
    final outer = Path()..addOval(Rect.fromCircle(center: const Offset(70, 76), radius: 56));
    final inner = Path()..addOval(Rect.fromCircle(center: const Offset(92, 66), radius: 50));
    final crescent = Path.combine(PathOperation.difference, outer, inner);

    // rose
    final rose = Path();
    final c = const Offset(82, 56);
    // spiral bud
    var first = true;
    for (var a = 0.0; a <= 6.2 * 1.7; a += 0.12) {
      final rr = 1.5 + a * 1.15;
      final pt = Offset(c.dx + rr * math.cos(a), c.dy + rr * math.sin(a) * 0.9);
      if (first) {
        rose.moveTo(pt.dx, pt.dy);
        first = false;
      } else {
        rose.lineTo(pt.dx, pt.dy);
      }
    }
    // outer petals (cup shape)
    rose.moveTo(c.dx - 19, c.dy - 6);
    rose.cubicTo(c.dx - 24, c.dy + 16, c.dx - 8, c.dy + 26, c.dx, c.dy + 25);
    rose.cubicTo(c.dx + 8, c.dy + 26, c.dx + 24, c.dy + 16, c.dx + 19, c.dy - 6);
    rose.moveTo(c.dx - 13, c.dy - 17);
    rose.cubicTo(c.dx - 6, c.dy - 24, c.dx + 6, c.dy - 24, c.dx + 13, c.dy - 17);
    // stem and leaves
    rose.moveTo(c.dx, c.dy + 25);
    rose.cubicTo(c.dx - 2, c.dy + 45, c.dx + 2, c.dy + 62, c.dx, c.dy + 78);
    rose.moveTo(c.dx - 1, c.dy + 58);
    rose.cubicTo(c.dx - 18, c.dy + 54, c.dx - 28, c.dy + 62, c.dx - 30, c.dy + 72);
    rose.cubicTo(c.dx - 16, c.dy + 76, c.dx - 4, c.dy + 70, c.dx - 1, c.dy + 58);
    rose.moveTo(c.dx + 1, c.dy + 66);
    rose.cubicTo(c.dx + 14, c.dy + 60, c.dx + 24, c.dy + 64, c.dx + 28, c.dy + 72);
    rose.cubicTo(c.dx + 14, c.dy + 76, c.dx + 4, c.dy + 74, c.dx + 1, c.dy + 66);

    Path trim(Path p, double f) {
      final out = Path();
      for (final m in p.computeMetrics()) {
        out.addPath(m.extractPath(0, m.length * f), Offset.zero);
      }
      return out;
    }

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = 2.2
      ..color = const Color(0xFFE6E6EA);
    final soft = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 5
      ..color = al(const Color(0xFFF3E3C2), 0.35 * glow)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
    final cp = trim(crescent, progress);
    final rp = trim(rose, progress);
    canvas.drawPath(cp, soft);
    canvas.drawPath(rp, soft);
    canvas.drawPath(cp, line);
    canvas.drawPath(rp, line);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _RoseMoonPainter old) =>
      old.progress != progress || old.glow != glow;
}

/// "Developed by Suhaib" with the flowing dynamic colours.
class _Credit extends StatelessWidget {
  final double size;
  const _Credit({required this.size});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: DynamicText('Developed by Suhaib',
          fontSize: size, letterSpacing: 0.8, weight: FontWeight.w800),
    );
  }
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pc = PageController();
  int _i = 0;

  static const _icons = [
    Icons.mic_rounded,
    Icons.psychology_rounded,
    Icons.headphones_rounded,
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _next() {
    if (_i >= 2) {
      context.read<AppState>().completeOnboarding();
    } else {
      _pc.nextPage(
          duration: const Duration(milliseconds: 380), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Scaffold(
      backgroundColor: c.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          SafeArea(
            child: Column(
              children: [
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    child: AnimatedOpacity(
                      opacity: _i < 2 ? 1 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: TextButton(
                        onPressed: _i < 2
                            ? () => context.read<AppState>().completeOnboarding()
                            : null,
                        child: Text(context.t('skip'),
                            style: TextStyle(
                                color: c.dim,
                                fontSize: 15,
                                fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),
                Column(
                  children: [
                    ShaderMask(
                      shaderCallback: (r) => c.gradient.createShader(r),
                      child: const Text('Rosella',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 40,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.4)),
                    ),
                    const SizedBox(height: 6),
                    const _Credit(size: 26),
                  ],
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    itemCount: 3,
                    onPageChanged: (v) => setState(() => _i = v),
                    itemBuilder: (_, i) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 132,
                            height: 132,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: c.gradient,
                              boxShadow: [
                                BoxShadow(
                                    color: al(c.a, 0.5), blurRadius: 40, spreadRadius: 2),
                              ],
                            ),
                            child: Icon(_icons[i],
                                size: 62, color: onAccent(c.a, c.b)),
                          ),
                          const SizedBox(height: 40),
                          Text(context.t('ob${i + 1}_t'),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: c.text,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.4)),
                          const SizedBox(height: 14),
                          Text(context.t('ob${i + 1}_d'),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: c.dim, fontSize: 16, height: 1.6)),
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < 3; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _i == i ? 26 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: _i == i ? c.a : al(c.dim, 0.4),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 24, 24, 28),
                  child: GradientButton(
                    label: context.t(_i == 2 ? 'start' : 'next'),
                    icon: _i == 2 ? Icons.check_rounded : Icons.arrow_forward_rounded,
                    expand: true,
                    onTap: _next,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
