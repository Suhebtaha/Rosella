import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// Dream rate over a week / month / year, with a small bar chart.
class FrequencyPanel extends StatefulWidget {
  const FrequencyPanel({super.key});

  @override
  State<FrequencyPanel> createState() => _FrequencyPanelState();
}

class _FrequencyPanelState extends State<FrequencyPanel> {
  int _mode = 0; // 0 week, 1 month, 2 year

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    int countBetween(DateTime from, DateTime to) => app.dreams.where((d) {
          final x = DateTime(d.createdAt.year, d.createdAt.month, d.createdAt.day);
          return !x.isBefore(from) && x.isBefore(to);
        }).length;

    final labels = <String>[];
    final values = <int>[];
    double avg;
    String avgKey;
    int total;

    if (_mode == 0) {
      // last 7 days, one bar per day
      for (var i = 6; i >= 0; i--) {
        final d0 = DateTime(today.year, today.month, today.day - i);
        final d1 = DateTime(today.year, today.month, today.day - i + 1);
        labels.add('${d0.day}');
        values.add(countBetween(d0, d1));
      }
      total = values.fold(0, (a, b) => a + b);
      avg = total / 7;
      avgKey = 'freq_avg_day';
    } else if (_mode == 1) {
      // last 5 weeks, one bar per week
      for (var i = 4; i >= 0; i--) {
        final d0 = DateTime(today.year, today.month, today.day - i * 7 - 6);
        final d1 = DateTime(today.year, today.month, today.day - i * 7 + 1);
        labels.add('${d0.day}/${d0.month}');
        values.add(countBetween(d0, d1));
      }
      total = values.fold(0, (a, b) => a + b);
      avg = total / 5;
      avgKey = 'freq_avg_week';
    } else {
      // last 12 months, one bar per month
      for (var i = 11; i >= 0; i--) {
        final d0 = DateTime(today.year, today.month - i, 1);
        final d1 = DateTime(today.year, today.month - i + 1, 1);
        labels.add('${d0.month}');
        values.add(countBetween(d0, d1));
      }
      total = values.fold(0, (a, b) => a + b);
      avg = total / 12;
      avgKey = 'freq_avg_month';
    }
    final maxV = values.fold<int>(1, (a, b) => b > a ? b : a);

    Widget seg(int i, String key) {
      final sel = _mode == i;
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Haptics.selection();
            setState(() => _mode = i);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(vertical: 9),
            decoration: BoxDecoration(
              gradient: sel ? c.gradient : null,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(context.t(key),
                  style: TextStyle(
                      color: sel ? onAccent(c.a, c.b) : c.dim,
                      fontWeight: FontWeight.w800,
                      fontSize: 13.5)),
            ),
          ),
        ),
      );
    }

    return Panel(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(context.t('freq_title'),
              style: TextStyle(color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: c.surfaceHi,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                seg(0, 'freq_week'),
                seg(1, 'freq_month'),
                seg(2, 'freq_year'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(avg.toStringAsFixed(1),
                  style: TextStyle(
                      color: c.text,
                      fontSize: 38,
                      fontWeight: FontWeight.w800,
                      height: 1.0)),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(context.t(avgKey),
                    style: TextStyle(color: c.dim, fontSize: 13.5)),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('$total ${context.t('freq_dreams')}',
                    style: TextStyle(
                        color: c.a, fontSize: 13.5, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 110,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var i = 0; i < values.length; i++)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (values[i] > 0)
                          Text('${values[i]}',
                              style: TextStyle(
                                  color: c.dim, fontSize: 10.5, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 3),
                        TweenAnimationBuilder<double>(
                          key: ValueKey('$_mode-$i'),
                          tween: Tween(begin: 0, end: values[i] / maxV),
                          duration: Duration(milliseconds: 500 + i * 30),
                          curve: Curves.easeOutCubic,
                          builder: (_, v, __) => Container(
                            width: _mode == 2 ? 10 : 18,
                            height: 4 + 64 * v,
                            decoration: BoxDecoration(
                              gradient: values[i] > 0 ? c.gradient : null,
                              color: values[i] > 0 ? null : c.surfaceHi,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(labels[i],
                            maxLines: 1,
                            style: TextStyle(color: c.dim, fontSize: 10.5)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
