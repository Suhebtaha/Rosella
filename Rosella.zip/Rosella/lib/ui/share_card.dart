import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'widgets.dart';

/// Preview of a shareable dream card + a button that shares it as a PNG image.
class ShareCardPage extends StatefulWidget {
  final String id;
  const ShareCardPage({super.key, required this.id});

  @override
  State<ShareCardPage> createState() => _ShareCardPageState();
}

class _ShareCardPageState extends State<ShareCardPage> {
  final GlobalKey _key = GlobalKey();
  bool _busy = false;

  Future<void> _saveToGallery(Dream d) async {
    final app = context.read<AppState>();
    setState(() => _busy = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('png');
      if (!await Gal.hasAccess(toAlbum: true)) {
        await Gal.requestAccess(toAlbum: true);
      }
      await Gal.putImageBytes(data.buffer.asUint8List(), album: 'Rosella');
      if (mounted) toast(context, app.tr('saved_gallery'));
    } catch (_) {
      if (mounted) toast(context, app.tr('save_failed'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _share(Dream d) async {
    final app = context.read<AppState>();
    setState(() => _busy = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('png');
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/rosella_${d.id}.png');
      await f.writeAsBytes(data.buffer.asUint8List(), flush: true);
      await app.external(() => Share.shareXFiles([XFile(f.path)], text: 'Rosella'));
    } catch (_) {
      if (mounted) toast(context, app.tr('share_failed'));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final d = app.byId(widget.id);
    if (d == null) return const SizedBox.shrink();
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('share_title')),
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 10),
                child: FittedBox(
                  fit: BoxFit.contain,
                  child: RepaintBoundary(
                    key: _key,
                    child: _Card(dream: d, app: app),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 18),
            child: Column(
              children: [
                GradientButton(
                  label: context.t('share'),
                  icon: Icons.ios_share_rounded,
                  expand: true,
                  loading: _busy,
                  onTap: () => _share(d),
                ),
                const SizedBox(height: 10),
                SubtleButton(
                  label: context.t('save_gallery'),
                  icon: Icons.download_rounded,
                  onTap: _busy ? null : () => _saveToGallery(d),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Dream dream;
  final AppState app;
  const _Card({required this.dream, required this.app});

  String _excerpt() {
    final src = (dream.interpretation ?? '').trim().isNotEmpty
        ? dream.interpretation!.trim()
        : dream.content.trim();
    final flat = src.replaceAll(RegExp(r'[\*#>_`]+'), '').replaceAll(RegExp(r'\s+'), ' ');
    return flat.length > 230 ? '${flat.substring(0, 227)}…' : flat;
  }

  @override
  Widget build(BuildContext context) {
    final p = paletteById(app.themeId);
    final a = p.a;
    final b = p.b;
    final img = app.abs(dream.image);
    final title = dream.title.isEmpty ? fmtDate(dream.createdAt, app.lang) : dream.title;
    const w = 360.0;
    return Container(
      width: w,
      height: 450,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: const Color(0xFF05050B),
      ),
      child: Stack(
        children: [
          Positioned(
            top: -90,
            left: -70,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [al(a, 0.55), al(a, 0)]),
              ),
            ),
          ),
          Positioned(
            bottom: -110,
            right: -80,
            child: Container(
              width: 320,
              height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [al(b, 0.5), al(b, 0)]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (img != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.file(
                      File(img),
                      height: 190,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      cacheWidth: 900,
                      errorBuilder: (_, __, ___) => const SizedBox(height: 190),
                    ),
                  )
                else
                  Container(
                    height: 120,
                    width: double.infinity,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(colors: [al(a, 0.35), al(b, 0.35)]),
                    ),
                    child: Text(moodEmoji(dream.mood),
                        style: const TextStyle(fontSize: 52)),
                  ),
                const SizedBox(height: 16),
                Text(title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        height: 1.25)),
                const SizedBox(height: 8),
                Expanded(
                  child: Text(_excerpt(),
                      overflow: TextOverflow.fade,
                      style: TextStyle(
                          color: al(Colors.white, 0.78), fontSize: 14.5, height: 1.5)),
                ),
                Row(
                  children: [
                    Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(fmtDate(dream.createdAt, app.lang),
                        style: TextStyle(color: al(Colors.white, 0.6), fontSize: 12.5)),
                    const Spacer(),
                    ShaderMask(
                      shaderCallback: (r) =>
                          LinearGradient(colors: [a, b]).createShader(r),
                      child: const Text('Rosella',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
