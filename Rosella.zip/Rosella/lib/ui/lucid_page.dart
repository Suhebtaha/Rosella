import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'widgets.dart';

class LucidPage extends StatelessWidget {
  const LucidPage({super.key});

  static const _items = [
    (Icons.help_outline_rounded, 'lt1'),
    (Icons.psychology_alt_rounded, 'lt2'),
    (Icons.alarm_rounded, 'lt3'),
    (Icons.menu_book_rounded, 'lt4'),
  ];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final n = app.dreams.where((d) => d.lucid).length;
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('lucid_title')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                FadeSlide(
                  child: Panel(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Icon(Icons.visibility_rounded, color: c.a, size: 34),
                        const SizedBox(height: 10),
                        TweenAnimationBuilder<double>(
                          tween: Tween(begin: 0, end: n.toDouble()),
                          duration: const Duration(milliseconds: 700),
                          curve: Curves.easeOutCubic,
                          builder: (_, v, __) => Text('${v.round()}',
                              style: TextStyle(
                                  color: c.text,
                                  fontSize: 44,
                                  fontWeight: FontWeight.w800)),
                        ),
                        Text(context.t('lucid_count'),
                            style: TextStyle(color: c.dim, fontSize: 14)),
                        const SizedBox(height: 10),
                        Text(context.t('lucid_sub'),
                            textAlign: TextAlign.center,
                            style: TextStyle(color: c.dim, fontSize: 13.5, height: 1.5)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                FadeSlide(
                  delay: 60,
                  child: Panel(
                    child: Row(
                      children: [
                        Icon(Icons.notifications_active_rounded, color: c.a, size: 24),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(context.t('lucid_mode'),
                                  style: TextStyle(
                                      color: c.text,
                                      fontSize: 15.5,
                                      fontWeight: FontWeight.w700)),
                              Text(context.t('lucid_mode_sub'),
                                  style: TextStyle(color: c.dim, fontSize: 12.5)),
                            ],
                          ),
                        ),
                        Switch(
                          value: app.lucidMode,
                          onChanged: (v) async {
                            final ok = await app.setLucidMode(v);
                            if (!ok && context.mounted) {
                              toast(context, app.tr('notif_denied'));
                            }
                          },
                          activeTrackColor: c.a,
                          inactiveTrackColor: c.surfaceHi,
                          thumbColor: const WidgetStatePropertyAll<Color>(Colors.white),
                          trackOutlineColor:
                              const WidgetStatePropertyAll<Color>(Colors.transparent),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
                  child: Text(context.t('lucid_tech'),
                      style: TextStyle(
                          color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
                ),
                for (var i = 0; i < _items.length; i++)
                  FadeSlide(
                    delay: 100 + i * 50,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Panel(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: c.gradient,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Icon(_items[i].$1, color: Colors.white),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(context.t(_items[i].$2),
                                      style: TextStyle(
                                          color: c.text,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800)),
                                  const SizedBox(height: 4),
                                  Text(context.t('${_items[i].$2}_d'),
                                      style: TextStyle(
                                          color: c.dim, fontSize: 13.5, height: 1.5)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
