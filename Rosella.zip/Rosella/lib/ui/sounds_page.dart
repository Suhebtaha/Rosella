import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../services/sound_session.dart';
import '../services/sounds.dart';
import 'widgets.dart';

class SoundsPage extends StatelessWidget {
  const SoundsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final sc = context.watch<SoundController>();
    final running = sc.isPlaying && sc.timerTotal > 0;
    final mm = (sc.remaining ~/ 60).toString().padLeft(2, '0');
    final ss = (sc.remaining % 60).toString().padLeft(2, '0');
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('snd_title'),
                    style: TextStyle(
                        color: c.text,
                        fontSize: 32,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.5)),
                const SizedBox(height: 2),
                Text(context.t('snd_sub'), style: TextStyle(color: c.dim, fontSize: 14)),
                const SizedBox(height: 2),
                Text(context.t('mix_hint'), style: TextStyle(color: c.dim, fontSize: 12.5)),
                if (SoundAudioHandler.status != 'ok')
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: SelectableText('notification: ${SoundAudioHandler.status}',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(color: c.dim, fontSize: 11)),
                  ),
              ],
            ),
          ),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.0,
            children: [
              for (var i = 0; i < kSounds.length; i++)
                FadeSlide(delay: i * 60, child: _SoundCard(def: kSounds[i])),
            ],
          ),
          if (sc.active.length > 1) ...[
            const SizedBox(height: 16),
            Panel(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final id in sc.active)
                    Row(
                      children: [
                        Icon(soundDef(id).icon, color: soundDef(id).colors.first, size: 22),
                        const SizedBox(width: 10),
                        SizedBox(
                          width: 64,
                          child: Text(context.t(soundDef(id).nameKey),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: c.text, fontSize: 14, fontWeight: FontWeight.w700)),
                        ),
                        Expanded(
                          child: SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              trackHeight: 5,
                              activeTrackColor: soundDef(id).colors.first,
                              inactiveTrackColor: c.surfaceHi,
                              thumbColor: Colors.white,
                              overlayShape: SliderComponentShape.noOverlay,
                              thumbShape:
                                  const RoundSliderThumbShape(enabledThumbRadius: 9),
                            ),
                            child: Slider(
                              value: sc.levelOf(id),
                              onChanged: (v) => sc.setLevel(id, v),
                            ),
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
          Panel(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('volume'),
                    style: TextStyle(
                        color: c.text, fontSize: 15, fontWeight: FontWeight.w700)),
                Row(
                  children: [
                    Icon(Icons.volume_down_rounded, color: c.dim),
                    Expanded(
                      child: SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 6,
                          activeTrackColor: c.a,
                          inactiveTrackColor: c.surfaceHi,
                          thumbColor: Colors.white,
                          overlayShape: SliderComponentShape.noOverlay,
                          thumbShape:
                              const RoundSliderThumbShape(enabledThumbRadius: 10),
                        ),
                        child: Slider(
                          value: sc.volume,
                          onChanged: (v) => sc.setVolume(v),
                        ),
                      ),
                    ),
                    Icon(Icons.volume_up_rounded, color: c.dim),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.bedtime_rounded, color: c.a, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(context.t('sleep_timer'),
                          style: TextStyle(
                              color: c.text, fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                    if (running)
                      Text(
                        '$mm:$ss ${context.t('remaining')}',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                            color: c.a, fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final m in const [0, 15, 30, 60, 90])
                      _TimerChip(
                        label: m == 0 ? context.t('off') : '$m ${context.t('min')}',
                        selected: sc.timerTotal == m,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          sc.setTimer(m);
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TimerChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _TimerChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: selected ? c.gradient : null,
          color: selected ? null : c.surfaceHi,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(label,
            style: TextStyle(
              color: selected ? Colors.white : c.text,
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
            )),
      ),
    );
  }
}

class _SoundCard extends StatelessWidget {
  final SoundDef def;
  const _SoundCard({required this.def});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final sc = context.watch<SoundController>();
    final active = sc.isActive(def.id);
    final loading = sc.loadingId == def.id;
    return Pressable(
      onTap: () {
        HapticFeedback.lightImpact();
        sc.toggle(def.id);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: active
              ? LinearGradient(
                  colors: def.colors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight)
              : null,
          color: active ? null : al(c.surface, c.isDark ? 0.72 : 0.92),
          border: Border.all(color: active ? al(Colors.white, 0.25) : c.border),
          boxShadow: active
              ? [
                  BoxShadow(
                      color: al(def.colors.first, 0.4),
                      blurRadius: 28,
                      offset: const Offset(0, 10)),
                ]
              : const [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: active ? al(Colors.white, 0.22) : al(def.colors.first, 0.16),
                  ),
                  child: Icon(def.icon,
                      size: 28, color: active ? Colors.white : def.colors.first),
                ),
                if (loading)
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                  )
                else
                  EqBars(active: active, color: Colors.white),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t(def.nameKey),
                    style: TextStyle(
                        color: active ? Colors.white : c.text,
                        fontSize: 22,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(
                  active ? context.t('playing') : context.t('tap_play'),
                  style: TextStyle(
                      color: active ? al(Colors.white, 0.8) : c.dim, fontSize: 12.5),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class EqBars extends StatefulWidget {
  final bool active;
  final Color color;
  const EqBars({super.key, required this.active, required this.color});

  @override
  State<EqBars> createState() => _EqBarsState();
}

class _EqBarsState extends State<EqBars> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));

  @override
  void initState() {
    super.initState();
    if (widget.active) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant EqBars old) {
    super.didUpdateWidget(old);
    if (widget.active && !_ctrl.isAnimating) {
      _ctrl.repeat();
    } else if (!widget.active && _ctrl.isAnimating) {
      _ctrl.stop();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.active) return const SizedBox(width: 28, height: 22);
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => SizedBox(
        width: 28,
        height: 22,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < 4; i++)
              Container(
                width: 4,
                height: 6 +
                    16 * (0.5 + 0.5 * math.sin(_ctrl.value * 2 * math.pi + i * 1.3)),
                margin: const EdgeInsets.symmetric(horizontal: 1.5),
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
