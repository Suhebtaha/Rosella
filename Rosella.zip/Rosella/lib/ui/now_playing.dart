import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../services/sounds.dart';
import 'widgets.dart';

/// A small "dynamic island" pill that floats at the top of every screen while
/// sleep sounds are playing. Tap it to expand: per-sound volume, stop buttons.
class NowPlayingIsland extends StatefulWidget {
  const NowPlayingIsland({super.key});

  @override
  State<NowPlayingIsland> createState() => _NowPlayingIslandState();
}

class _NowPlayingIslandState extends State<NowPlayingIsland>
    with SingleTickerProviderStateMixin {
  bool _open = false;
  late final AnimationController _eq =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));

  @override
  void dispose() {
    _eq.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sc = context.watch<SoundController>();
    final playing = sc.isPlaying;
    if (playing && !_eq.isAnimating) _eq.repeat();
    if (!playing && _eq.isAnimating) _eq.stop();
    if (!playing && _open) _open = false;
    final top = MediaQuery.of(context).padding.top;
    final c = context.colors;
    final w = MediaQuery.of(context).size.width;

    return Positioned(
      top: top + 2,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !playing,
        child: Align(
          alignment: Alignment.topCenter,
          child: AnimatedSlide(
            offset: playing ? Offset.zero : const Offset(0, -2.2),
            duration: const Duration(milliseconds: 520),
            curve: playing ? Curves.easeOutBack : Curves.easeInCubic,
            child: AnimatedOpacity(
              opacity: playing ? 1 : 0,
              duration: const Duration(milliseconds: 250),
              child: Material(
                type: MaterialType.transparency,
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.selectionClick();
                    setState(() => _open = !_open);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 380),
                    curve: Curves.easeOutCubic,
                    width: _open ? w - 32 : null,
                    constraints: BoxConstraints(maxWidth: w - 32),
                    padding: EdgeInsets.symmetric(
                        horizontal: _open ? 16 : 12, vertical: _open ? 14 : 7),
                    decoration: BoxDecoration(
                      color: const Color(0xF2050509),
                      borderRadius: BorderRadius.circular(_open ? 28 : 22),
                      border: Border.all(color: al(Colors.white, 0.10)),
                      boxShadow: [
                        BoxShadow(
                            color: al(c.a, 0.30), blurRadius: 22, offset: const Offset(0, 6)),
                      ],
                    ),
                    child: AnimatedSize(
                      duration: const Duration(milliseconds: 380),
                      curve: Curves.easeOutCubic,
                      alignment: Alignment.topCenter,
                      child: _open ? _expanded(context, sc) : _collapsed(sc),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _time(SoundController sc) {
    final m = (sc.remaining ~/ 60).toString().padLeft(2, '0');
    final s = (sc.remaining % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _collapsed(SoundController sc) {
    final ids = sc.active.take(3).toList();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 22.0 + (ids.length - 1).clamp(0, 2) * 14,
          height: 24,
          child: Stack(
            children: [
              for (var i = 0; i < ids.length; i++)
                Positioned(
                  left: i * 14.0,
                  child: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: soundDef(ids[i]).colors),
                      border: Border.all(color: const Color(0xFF050509), width: 1.6),
                    ),
                    child: Icon(soundDef(ids[i]).icon, size: 13, color: Colors.white),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        _Eq(ctrl: _eq),
        if (sc.timerTotal > 0) ...[
          const SizedBox(width: 10),
          Text(_time(sc),
              textDirection: TextDirection.ltr,
              style: const TextStyle(
                  color: Colors.white70, fontSize: 12.5, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }

  Widget _expanded(BuildContext context, SoundController sc) {
    final c = context.colors;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final id in sc.active)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: soundDef(id).colors),
                  ),
                  child: Icon(soundDef(id).icon, size: 18, color: Colors.white),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 60,
                  child: Text(context.t(soundDef(id).nameKey),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                ),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 4,
                      activeTrackColor: soundDef(id).colors.first,
                      inactiveTrackColor: al(Colors.white, 0.14),
                      thumbColor: Colors.white,
                      overlayShape: SliderComponentShape.noOverlay,
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                    ),
                    child: Slider(
                      value: sc.levelOf(id),
                      onChanged: (v) => sc.setLevel(id, v),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => sc.toggle(id),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Icon(Icons.close_rounded, size: 20, color: al(Colors.white, 0.7)),
                  ),
                ),
              ],
            ),
          ),
        const SizedBox(height: 2),
        Row(
          children: [
            if (sc.timerTotal > 0) ...[
              Icon(Icons.bedtime_rounded, size: 16, color: c.a),
              const SizedBox(width: 6),
              Text(_time(sc),
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                      color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w700)),
            ],
            const Spacer(),
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                sc.stop();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: al(Colors.white, 0.12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.stop_rounded, size: 18, color: Colors.white),
                    const SizedBox(width: 4),
                    Text(context.t('stop_all'),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _Eq extends StatelessWidget {
  final AnimationController ctrl;
  const _Eq({required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ctrl,
      builder: (_, __) => SizedBox(
        width: 22,
        height: 16,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < 4; i++)
              Container(
                width: 3,
                height: 4 + 12 * (0.5 + 0.5 * math.sin(ctrl.value * 2 * math.pi + i * 1.4)),
                margin: const EdgeInsets.symmetric(horizontal: 1.2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
