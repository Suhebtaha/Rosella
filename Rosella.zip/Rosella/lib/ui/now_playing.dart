import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/nav_bus.dart';
import '../core/theme.dart';
import '../services/sounds.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// A small "dynamic island" pill that floats at the top of every screen while
/// sleep sounds are playing. Tap it to expand: per-sound volume, stop buttons.
class NowPlayingIsland extends StatefulWidget {
  const NowPlayingIsland({super.key});

  @override
  State<NowPlayingIsland> createState() => _NowPlayingIslandState();
}

class _NowPlayingIslandState extends State<NowPlayingIsland>
    with TickerProviderStateMixin {
  bool _open = false;
  late final AnimationController _eq =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));

  // same flowing colours as the Dynamic theme
  late final AnimationController _flow =
      AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();

  static const List<Color> _cycle = [
    Color(0xFF12C2D6),
    Color(0xFF2F6BFF),
    Color(0xFF5B3DF5),
    Color(0xFFB23CFF),
    Color(0xFFE23DA8),
    Color(0xFF2F6BFF),
  ];

  static Color _at(double p) {
    final n = _cycle.length;
    final x = (p % 1.0) * n;
    final i = x.floor() % n;
    final f = x - x.floor();
    return Color.lerp(_cycle[i], _cycle[(i + 1) % n], Curves.easeInOut.transform(f))!;
  }

  // morph animation: 0 = pill, 1 = open panel (spring, like the system island)
  late final AnimationController _mc = AnimationController.unbounded(vsync: this, value: 0);
  final GlobalKey _cKey = GlobalKey();
  final GlobalKey _eKey = GlobalKey();
  double _cw = 112; // measured size of the folded pill
  double _ch = 38;
  double _eh = 220; // measured height of the open panel
  bool _measureQueued = false;

  static double _lerp(double a, double b, double t) => a + (b - a) * t;

  void _setOpen(bool v, {bool snap = false}) {
    if (_open == v && !snap) return;
    _open = v;
    if (snap) {
      _mc.stop();
      _mc.value = v ? 1 : 0;
    } else {
      final sim = SpringSimulation(
        const SpringDescription(mass: 1, stiffness: 300, damping: 25),
        _mc.value,
        v ? 1.0 : 0.0,
        _mc.velocity,
      );
      _mc.animateWith(sim);
    }
    if (mounted) setState(() {});
  }

  void _scheduleMeasure() {
    if (_measureQueued) return;
    _measureQueued = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _measureQueued = false;
      if (!mounted) return;
      var changed = false;
      final cs = _cKey.currentContext?.size;
      if (cs != null && _mc.value < 0.5) {
        final nw = cs.width + 26, nh = math.max(36.0, cs.height + 14);
        if ((nw - _cw).abs() > 0.5 || (nh - _ch).abs() > 0.5) {
          _cw = nw;
          _ch = nh;
          changed = true;
        }
      }
      final es = _eKey.currentContext?.size;
      if (es != null && es.height > 40 && (es.height - _eh).abs() > 0.5) {
        _eh = es.height;
        changed = true;
      }
      if (changed) setState(() {});
    });
  }

  @override
  void dispose() {
    _mc.dispose();
    _eq.dispose();
    _flow.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sc = context.watch<SoundController>();
    final playing = sc.isPlaying;
    if (playing && !_eq.isAnimating) _eq.repeat();
    if (!playing && _eq.isAnimating) _eq.stop();
    final top = MediaQuery.of(context).padding.top;
    final w = MediaQuery.of(context).size.width;

    if (!playing && _open) {
      _open = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _mc.stop();
          _mc.value = 0;
        }
      });
    }
    final ew = w - 32.0; // expanded width
    final island = Positioned(
      top: top + 2,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !playing,
        child: Align(
          alignment: Alignment.topCenter,
          child: AnimatedSlide(
            offset: playing ? Offset.zero : const Offset(0, -2.2),
            duration: const Duration(milliseconds: 560),
            curve: playing ? Curves.easeOutBack : Curves.easeInCubic,
            child: AnimatedOpacity(
              opacity: playing ? 1 : 0,
              duration: const Duration(milliseconds: 250),
              child: Material(
                type: MaterialType.transparency,
                child: GestureDetector(
                  onTap: () {
                    Haptics.selection();
                    _setOpen(!_open);
                  },
                  child: AnimatedBuilder(
                    animation: Listenable.merge([_mc, _flow]),
                    builder: (context, _) {
                      _scheduleMeasure();
                      final o = _mc.value.clamp(0.0, 1.06);
                      final oc = _mc.value.clamp(0.0, 1.0);
                      final t = _flow.value;
                      final c1 = _at(t);
                      final c2 = _at(t + 0.33);
                      const dark = Color(0xFF050509);
                      final width = _lerp(_cw, ew, o);
                      final height = _lerp(_ch, _eh, o);
                      // content: the folded pill fades out first, the panel fades in later
                      final foldedOp = (1 - oc * 3.2).clamp(0.0, 1.0);
                      final openOp = ((oc - 0.28) / 0.55).clamp(0.0, 1.0);
                      return Container(
                        width: width,
                        height: height,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment(math.cos(2 * math.pi * t), math.sin(2 * math.pi * t)),
                            end: Alignment(-math.cos(2 * math.pi * t), -math.sin(2 * math.pi * t)),
                            colors: [
                              Color.alphaBlend(al(c1, 0.55), dark),
                              Color.alphaBlend(al(c2, 0.55), dark),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(_lerp(21, 32, oc)),
                          border: Border.all(color: al(c1, 0.55)),
                          boxShadow: [
                            BoxShadow(
                                color: al(c2, 0.35),
                                blurRadius: 22 + 10 * oc,
                                offset: const Offset(0, 6)),
                          ],
                        ),
                        child: Stack(
                          children: [
                            if (foldedOp > 0)
                              Positioned.fill(
                                child: Opacity(
                                  opacity: foldedOp,
                                  child: Center(
                                    child: OverflowBox(
                                      minWidth: 0,
                                      maxWidth: double.infinity,
                                      child: KeyedSubtree(
                                          key: _cKey, child: _collapsed(sc)),
                                    ),
                                  ),
                                ),
                              ),
                            if (openOp > 0 || _open)
                              Positioned(
                                top: 0,
                                left: 0,
                                right: 0,
                                child: Opacity(
                                  opacity: openOp,
                                  child: OverflowBox(
                                    minHeight: 0,
                                    maxHeight: double.infinity,
                                    alignment: Alignment.topCenter,
                                    child: Padding(
                                      key: _eKey,
                                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                                      child: SizedBox(
                                          width: ew - 32, child: _expanded(context, sc)),
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    return Positioned.fill(
      child: Stack(
        children: [
          // a tap anywhere else folds the island back (the tap still reaches the app)
          if (_open && playing)
            Positioned.fill(
              child: Listener(
                behavior: HitTestBehavior.translucent,
                onPointerDown: (_) => _setOpen(false),
              ),
            ),
          island,
        ],
      ),
    );
  }

  String _time(SoundController sc) {
    final m = (sc.remaining ~/ 60).toString().padLeft(2, '0');
    final s = (sc.remaining % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _collapsed(SoundController sc) {
    final ids = sc.active.take(3).toList();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 22.0 + (ids.length - 1).clamp(0, 2) * 14,
          height: 24,
          child: Stack(
            children: [
              for (var i = 0; i < ids.length; i++)
                Positioned(
                  left: i * 14.0,
                  child: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: soundDef(ids[i]).colors),
                      border: Border.all(color: const Color(0xFF050509), width: 1.6),
                    ),
                    child: Icon(soundDef(ids[i]).icon, size: 13, color: Colors.white),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        _Eq(ctrl: _eq),
        if (sc.timerTotal > 0) ...[
          const SizedBox(width: 10),
          Text(_time(sc),
              textDirection: TextDirection.ltr,
              style: const TextStyle(
                  color: Colors.white70, fontSize: 12.5, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }

  Widget _expanded(BuildContext context, SoundController sc) {
    final c = context.colors;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final id in sc.active)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    Haptics.selection();
                    _setOpen(false);
                    openTab(2);
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: soundDef(id).colors),
                        ),
                        child: Icon(soundDef(id).icon, size: 18, color: Colors.white),
                      ),
                      const SizedBox(width: 10),
                      SizedBox(
                        width: 60,
                        child: Text(context.t(soundDef(id).nameKey),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _MiniSlider(
                    value: sc.levelOf(id),
                    color: soundDef(id).colors.first,
                    onChanged: (v) => sc.setLevel(id, v),
                  ),
                ),
                GestureDetector(
                  onTap: () => sc.toggle(id),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Icon(Icons.close_rounded, size: 20, color: al(Colors.white, 0.7)),
                  ),
                ),
              ],
            ),
          ),
        if (sc.active.length < kSounds.length) ...[
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final d in kSounds)
                if (!sc.isActive(d.id))
                  GestureDetector(
                    onTap: () {
                      Haptics.selection();
                      sc.toggle(d.id);
                    },
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: al(Colors.white, 0.12),
                        border: Border.all(color: al(Colors.white, 0.22)),
                      ),
                      child: sc.loadingId == d.id
                          ? const Padding(
                              padding: EdgeInsets.all(9),
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : Icon(d.icon, size: 18, color: Colors.white),
                    ),
                  ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        const SizedBox(height: 2),
        Row(
          children: [
            if (sc.timerTotal > 0) ...[
              Icon(Icons.bedtime_rounded, size: 16, color: c.a),
              const SizedBox(width: 6),
              Text(_time(sc),
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                      color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w700)),
            ],
            const Spacer(),
            GestureDetector(
              onTap: () {
                Haptics.light();
                sc.stop();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: al(Colors.white, 0.12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.stop_rounded, size: 18, color: Colors.white),
                    const SizedBox(width: 4),
                    Text(context.t('stop_all'),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _Eq extends StatelessWidget {
  final AnimationController ctrl;
  const _Eq({required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ctrl,
      builder: (_, __) => SizedBox(
        width: 22,
        height: 16,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < 4; i++)
              Container(
                width: 3,
                height: 4 + 12 * (0.5 + 0.5 * math.sin(ctrl.value * 2 * math.pi + i * 1.4)),
                margin: const EdgeInsets.symmetric(horizontal: 1.2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// A tiny slider that needs no Overlay/Material (the island lives above the Navigator).
class _MiniSlider extends StatelessWidget {
  final double value;
  final Color color;
  final ValueChanged<double> onChanged;
  const _MiniSlider({required this.value, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth;
      final rtl = Directionality.of(context) == TextDirection.rtl;
      void set(double dx) {
        var f = (dx / w).clamp(0.0, 1.0);
        if (rtl) f = 1 - f;
        onChanged(f);
      }

      final v = value.clamp(0.0, 1.0);
      final pos = (rtl ? 1 - v : v) * w;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (d) => set(d.localPosition.dx),
        onHorizontalDragUpdate: (d) => set(d.localPosition.dx),
        child: SizedBox(
          height: 30,
          child: Stack(
            alignment: Alignment.centerLeft,
            children: [
              Container(
                height: 4,
                decoration: BoxDecoration(
                  color: al(Colors.white, 0.16),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Positioned(
                left: rtl ? pos : 0,
                width: rtl ? w - pos : pos,
                child: Container(
                  height: 4,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Positioned(
                left: (pos - 8).clamp(0.0, w - 16),
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
