import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'widgets.dart';

class DreamEditorPage extends StatefulWidget {
  final Dream? dream;
  const DreamEditorPage({super.key, this.dream});

  @override
  State<DreamEditorPage> createState() => _DreamEditorPageState();
}

class _DreamEditorPageState extends State<DreamEditorPage> {
  late final AppState _app;
  late final TextEditingController _title;
  late final TextEditingController _content;
  late int _mood;
  bool _lucid = false;
  late DateTime _date;
  String? _image;

  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _sttReady = false;
  bool _listening = false;
  bool _generating = false;
  bool _saved = false;
  String _base = '';

  @override
  void initState() {
    super.initState();
    _app = context.read<AppState>();
    final d = widget.dream;
    _title = TextEditingController(text: d?.title ?? '');
    _content = TextEditingController(text: d?.content ?? '');
    _mood = d?.mood ?? 3;
    _lucid = d?.lucid ?? false;
    _date = d?.createdAt ?? DateTime.now();
    _image = d?.image;
  }

  @override
  void dispose() {
    try {
      _speech.cancel();
    } catch (_) {}
    if (!_saved && _image != null && _image != widget.dream?.image) {
      try {
        final f = File(_app.abs(_image)!);
        if (f.existsSync()) f.deleteSync();
      } catch (_) {}
    }
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  Future<String?> _pickLocale(String lang) async {
    try {
      final locs = await _speech.locales();
      final prefixes = lang == 'ar'
          ? ['ar_iq', 'ar']
          : lang == 'ckb'
              ? ['ckb', 'ku']
              : ['en_us', 'en'];
      for (final p in prefixes) {
        for (final l in locs) {
          final id = l.localeId.toLowerCase().replaceAll('-', '_');
          if (id.startsWith(p)) return l.localeId;
        }
      }
    } catch (_) {}
    return null;
  }

  Future<void> _toggleListen() async {
    if (_listening) {
      try {
        await _speech.stop();
      } catch (_) {}
      if (mounted) setState(() => _listening = false);
      return;
    }
    if (!_sttReady) {
      try {
        _sttReady = await _app.external(() => _speech.initialize(
              onStatus: (st) {
                if ((st == 'done' || st == 'notListening') && mounted) {
                  setState(() => _listening = false);
                }
              },
              onError: (e) {
                if (mounted) setState(() => _listening = false);
              },
            ));
      } catch (_) {
        _sttReady = false;
      }
    }
    if (!mounted) return;
    if (!_sttReady) {
      toast(context, _app.tr('mic_unavailable'));
      return;
    }
    final locale = await _pickLocale(_app.lang);
    if (!mounted) return;
    _base = _content.text.trimRight();
    setState(() => _listening = true);
    try {
      await _speech.listen(
        onResult: (r) {
          final txt = r.recognizedWords;
          final full = _base.isEmpty ? txt : '$_base $txt';
          if (!mounted) return;
          setState(() {
            _content.text = full;
            _content.selection = TextSelection.collapsed(offset: full.length);
          });
        },
        localeId: locale,
        listenFor: const Duration(minutes: 2),
        pauseFor: const Duration(seconds: 8),
      );
    } catch (_) {
      if (mounted) setState(() => _listening = false);
    }
  }

  Future<void> _pickImage() async {
    try {
      final x = await _app.external(() => ImagePicker().pickImage(
            source: ImageSource.gallery,
            maxWidth: 1600,
            imageQuality: 85,
          ));
      if (x == null) return;
      final rel = _app.newFileRel('images', 'jpg');
      await File(x.path).copy(_app.abs(rel)!);
      if (!mounted) return;
      _dropPendingImage();
      setState(() => _image = rel);
    } catch (_) {}
  }

  void _dropPendingImage() {
    if (_image != null && _image != widget.dream?.image) {
      try {
        final f = File(_app.abs(_image)!);
        if (f.existsSync()) f.deleteSync();
      } catch (_) {}
    }
  }

  Future<void> _generate() async {
    if (_generating) return;
    if (_content.text.trim().isEmpty && _title.text.trim().isEmpty) {
      toast(context, _app.tr('write_first'));
      return;
    }
    setState(() => _generating = true);
    final rel = _app.newFileRel('images', 'jpg');
    final ok = await AiService.generateImage(
      title: _title.text.trim(),
      content: _content.text.trim(),
      savePath: _app.abs(rel)!,
    );
    if (!mounted) return;
    if (ok) {
      _dropPendingImage();
      _app.bumpImg();
      setState(() {
        _image = rel;
        _generating = false;
      });
    } else {
      setState(() => _generating = false);
      toast(context, _app.tr('image_failed'));
    }
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (p != null && mounted) {
      setState(() => _date = DateTime(p.year, p.month, p.day, _date.hour, _date.minute));
    }
  }

  Future<void> _save() async {
    final old = widget.dream;
    if (_content.text.trim().isEmpty &&
        _title.text.trim().isEmpty &&
        old?.audio == null) {
      toast(context, _app.tr('write_first'));
      return;
    }
    try {
      await _speech.stop();
    } catch (_) {}
    final d = Dream(
      id: old?.id ?? _app.newId(),
      title: _title.text.trim(),
      content: _content.text.trim(),
      createdAt: _date,
      mood: _mood,
      audio: old?.audio,
      audioMs: old?.audioMs ?? 0,
      image: _image,
      interpretation: old?.interpretation,
      lucid: _lucid,
    );
    _saved = true;
    if (old == null) {
      await _app.addDream(d);
    } else {
      await _app.updateDream(d);
    }
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final lang = context.select<AppState, String>((s) => s.lang);
    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            title: widget.dream == null ? context.t('new_dream') : context.t('edit_dream'),
          ),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
              children: [
                Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  radius: 20,
                  child: TextField(
                    controller: _title,
                    textInputAction: TextInputAction.next,
                    style: TextStyle(color: c.text, fontSize: 18, fontWeight: FontWeight.w700),
                    decoration: bareInput(context, context.t('title_hint')),
                  ),
                ),
                const SizedBox(height: 12),
                Panel(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  radius: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: _content,
                        minLines: 8,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        style: TextStyle(color: c.text, fontSize: 16, height: 1.55),
                        decoration: bareInput(context, context.t('content_hint')),
                      ),
                      const SizedBox(height: 4),
                      Pressable(
                        onTap: _toggleListen,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          height: 40,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          decoration: BoxDecoration(
                            gradient: _listening ? c.gradient : null,
                            color: _listening ? null : c.surfaceHi,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _listening ? Icons.graphic_eq_rounded : Icons.mic_none_rounded,
                                size: 19,
                                color: _listening ? Colors.white : c.text,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _listening ? context.t('listening') : context.t('dictate'),
                                style: TextStyle(
                                  color: _listening ? Colors.white : c.text,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 4, right: 4),
                  child: Text(context.t('how_felt'),
                      style: TextStyle(
                          color: c.dim, fontSize: 13, fontWeight: FontWeight.w600)),
                ),
                MoodPicker(value: _mood, onChanged: (m) => setState(() => _mood = m)),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  radius: 18,
                  child: Row(
                    children: [
                      Icon(Icons.visibility_rounded, color: c.a),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(context.t('lucid_dream'),
                            style: TextStyle(
                                color: c.text,
                                fontSize: 15,
                                fontWeight: FontWeight.w600)),
                      ),
                      Switch(
                        value: _lucid,
                        onChanged: (v) => setState(() => _lucid = v),
                        activeTrackColor: c.a,
                        inactiveTrackColor: c.surfaceHi,
                        thumbColor: const WidgetStatePropertyAll<Color>(Colors.white),
                        trackOutlineColor:
                            const WidgetStatePropertyAll<Color>(Colors.transparent),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Panel(
                  onTap: _pickDate,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  radius: 18,
                  child: Row(
                    children: [
                      Icon(Icons.calendar_month_rounded, color: c.a),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          '${context.t('date')}: ${fmtDate(_date, lang)}',
                          style: TextStyle(
                              color: c.text, fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ),
                      Icon(Icons.edit_calendar_rounded, color: c.dim, size: 20),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _imageSection(c),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    label: context.t('save'),
                    icon: Icons.check_rounded,
                    expand: true,
                    onTap: _save,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _imageSection(AppColors c) {
    if (_generating) {
      return Panel(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Column(
          children: [
            SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 3, color: c.a),
            ),
            const SizedBox(height: 12),
            Text(context.t('generating'), style: TextStyle(color: c.dim)),
          ],
        ),
      );
    }
    if (_image != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            Image.file(
              File(_app.abs(_image)!),
              height: 220,
              width: double.infinity,
              fit: BoxFit.cover,
              cacheWidth: 1000,
              errorBuilder: (_, __, ___) => Container(
                height: 220,
                color: c.surfaceHi,
                child: Icon(Icons.broken_image_rounded, color: c.dim),
              ),
            ),
            PositionedDirectional(
              top: 10,
              end: 10,
              child: RoundIconButton(
                icon: Icons.close_rounded,
                onTap: () {
                  _dropPendingImage();
                  setState(() => _image = null);
                },
              ),
            ),
          ],
        ),
      );
    }
    return Row(
      children: [
        Expanded(
          child: SubtleButton(
            label: context.t('gallery'),
            icon: Icons.photo_library_rounded,
            onTap: _pickImage,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: GradientButton(
            label: context.t('gen_image'),
            icon: Icons.auto_awesome_rounded,
            expand: true,
            onTap: _generate,
          ),
        ),
      ],
    );
  }
}
