import 'dart:async';

import 'package:home_widget/home_widget.dart';

import '../core/app_state.dart';

/// Pushes a few numbers to the home-screen widget (dream count, streak).
class WidgetSync {
  static Timer? _t;

  /// Call whenever the state changes; the actual update is debounced.
  static void schedule(AppState app) {
    _t?.cancel();
    _t = Timer(const Duration(seconds: 2), () => push(app));
  }

  static Future<void> push(AppState app) async {
    try {
      final st = app.stats;
      await HomeWidget.saveWidgetData<String>(
          'wd_stats', '${st.total} ${app.tr('freq_dreams')}  ·  🔥 ${st.streak}');
      await HomeWidget.saveWidgetData<String>('wd_cta', '+ ${app.tr('wd_cta')}');
      await HomeWidget.updateWidget(
        name: 'RosellaWidget',
        androidName: 'RosellaWidget',
        qualifiedAndroidName: 'com.suhaib.rosella.RosellaWidget',
      );
    } catch (_) {
      // no widget on the home screen, or the plugin is unavailable: ignore
    }
  }
}
