import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import 'sound_synth.dart';

class SoundDef {
  final String id;
  final String nameKey;
  final IconData icon;
  final List<Color> colors;
  const SoundDef(this.id, this.nameKey, this.icon, this.colors);
}

const List<SoundDef> kSounds = [
  SoundDef('wind', 'snd_wind', Icons.air_rounded,
      [Color(0xFF5B8DEF), Color(0xFF38BDF8)]),
  SoundDef('birds', 'snd_birds', Icons.emoji_nature_rounded,
      [Color(0xFF34D399), Color(0xFFA3E635)]),
  SoundDef('fire', 'snd_fire', Icons.local_fire_department_rounded,
      [Color(0xFFFF8A4C), Color(0xFFFF4F7B)]),
  SoundDef('rain', 'snd_rain', Icons.water_drop_rounded,
      [Color(0xFF7C5CFF), Color(0xFF3DD6F5)]),
];

class SoundController extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();

  String? current;
  String? loadingId;
  double volume = 0.7;
  int timerTotal = 0; // minutes, 0 = off
  int remaining = 0; // seconds
  Timer? _timer;
  bool _disposed = false;

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<String> _file(String id) async {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/dt_$id.v3.wav');
    if (!await f.exists() || await f.length() < 1000) {
      final bytes = await compute(synthesizeWav, id);
      await f.writeAsBytes(bytes, flush: true);
    }
    return f.path;
  }

  Future<void> toggle(String id) async {
    if (loadingId != null) return;
    if (current == id) {
      await stop();
      return;
    }
    loadingId = id;
    _notify();
    try {
      final path = await _file(id);
      await _player.stop();
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.setVolume(volume);
      await _player.play(DeviceFileSource(path));
      current = id;
      if (timerTotal > 0) _startTicking(timerTotal * 60);
    } catch (_) {
      current = null;
    }
    loadingId = null;
    _notify();
  }

  Future<void> stop() async {
    _cancelTimer();
    try {
      await _player.stop();
    } catch (_) {}
    current = null;
    if (timerTotal > 0) remaining = timerTotal * 60;
    _notify();
  }

  Future<void> setVolume(double v) async {
    volume = v;
    try {
      await _player.setVolume(v);
    } catch (_) {}
    _notify();
  }

  void setTimer(int minutes) {
    _cancelTimer();
    timerTotal = minutes;
    remaining = minutes * 60;
    if (minutes > 0 && current != null) _startTicking(minutes * 60);
    _notify();
  }

  void _startTicking(int seconds) {
    _cancelTimer();
    remaining = seconds;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      remaining--;
      if (remaining <= 0) {
        _fadeAndStop();
      } else {
        _notify();
      }
    });
  }

  void _cancelTimer() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _fadeAndStop() async {
    _cancelTimer();
    for (var i = 9; i >= 0; i--) {
      try {
        await _player.setVolume(volume * i / 10);
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 180));
    }
    try {
      await _player.stop();
      await _player.setVolume(volume);
    } catch (_) {}
    current = null;
    remaining = timerTotal * 60;
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _player.dispose();
    super.dispose();
  }
}
