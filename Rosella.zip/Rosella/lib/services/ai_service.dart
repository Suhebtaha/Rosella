import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:http/http.dart' as http;

class AiResult {
  final String text;
  final bool fromAi;
  const AiResult(this.text, this.fromAi);
}

// ------------------------------------------------------------------ offline
class _Sym {
  final List<String> keys;
  final Map<String, String> text;
  const _Sym(this.keys, this.text);
}

const List<_Sym> _syms = [
  _Sym([
    'zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'الموتي الاحياء', 'زۆمبي'
  ], {
    'en':
        'Zombies usually point to exhaustion, burnout, or a feeling that something in your daily life is relentless and draining. Being chased by them suggests you are avoiding a pressure instead of facing it.',
    'ar':
        'الزومبي يرمز غالباً إلى الإرهاق والاحتراق النفسي، أو إلى شعورك بأن أمراً في حياتك اليومية يلاحقك باستمرار ويستنزفك. والهرب منهم يوحي بأنك تتجنب ضغطاً بدل مواجهته.',
    'ckb':
        'زۆمبی زۆرجار هێمای ماندووبوون و سووتانی دەروونییە، یان هەستکردنە بەوەی شتێک لە ژیانی ڕۆژانەتدا بەردەوام دەتگرێت و وزەت دەبات. ڕاکردن لێیان ئاماژەیە بۆ دوورکەوتنەوە لە فشارێک لەجیاتی ڕووبەڕووبوونەوەی.',
  }),
  _Sym([
    'monster', 'ghost', 'demon', 'وحش', 'شبح', 'عفريت', 'دێو', 'تارمايي'
  ], {
    'en':
        'Monsters and ghosts often represent a fear or worry you have not named yet; it tends to shrink once you look at it directly.',
    'ar':
        'الوحوش والأشباح تمثل غالباً خوفاً أو قلقاً لم تسمّه بعد، وغالباً يصغر حجمه حين تنظر إليه بوضوح.',
    'ckb':
        'دێو و تارمایی زۆرجار هێمای ترس یان نیگەرانییەکن کە هێشتا ناویان نەناوە، و کاتێک ڕاستەوخۆ سەیریان دەکەیت بچووک دەبنەوە.',
  }),
  _Sym([
    'water', 'sea', 'ocean', 'river', 'swim', 'drown', 'wave', 'flood',
    'ماء', 'بحر', 'نهر', 'غرق', 'موج', 'سباح', 'فيضان',
    'ئاو', 'دەريا', 'ڕووبار'
  ], {
    'en':
        'Water usually mirrors your emotions. Calm water suggests inner peace, while rough or deep water points to feelings you are still processing.',
    'ar':
        'الماء يعكس عادةً مشاعرك؛ صفاؤه يدل على سكينة داخلية، واضطرابه أو عمقه يشير إلى مشاعر ما زلت تعالجها.',
    'ckb':
        'ئاو زۆرجار ڕەنگدانەوەی هەستەکانتە؛ ئاوی ئارام ئاشتی ناوەوە دەگەیەنێت و ئاوی شەپۆلدار یان قووڵ هەستی تەواونەکراو.',
  }),
  _Sym([
    'fly', 'flying', 'soar', 'plane', 'اطير', 'تحليق', 'طاير', 'فڕين'
  ], {
    'en':
        'Flying often stands for freedom, ambition, or a wish to rise above a problem.',
    'ar':
        'الطيران يرمز غالباً إلى الحرية والطموح أو الرغبة في التسامي فوق مشكلة ما.',
    'ckb':
        'فڕین زۆرجار هێمای ئازادی و ئامانجە یان ئارەزووی بەرزبوونەوە بەسەر کێشەیەکدا.',
  }),
  _Sym([
    'fall', 'falling', 'سقط', 'سقوط', 'وقعت', 'كەوتن', 'كەوتم'
  ], {
    'en':
        'Falling is commonly linked to feeling a loss of control or worry about something slipping away.',
    'ar':
        'السقوط يرتبط عادةً بالشعور بفقدان السيطرة أو القلق من أن شيئاً ما يفلت منك.',
    'ckb':
        'کەوتن زۆرجار بە هەستکردن بە لەدەستدانی کۆنترۆڵ یان نیگەرانی لە ڕۆیشتنی شتێکەوە دەبەسترێتەوە.',
  }),
  _Sym([
    'chase', 'chased', 'run away', 'escape', 'flee', 'هرب', 'يطارد', 'مطارد',
    'لاحق', 'هەڵات', 'ڕاو'
  ], {
    'en':
        'Being chased often means you are avoiding a situation or emotion that needs to be faced.',
    'ar':
        'أن يُطاردك أحد يعني غالباً أنك تتجنب موقفاً أو شعوراً يحتاج إلى مواجهة.',
    'ckb':
        'ڕاوەدوونران زۆرجار مانای دووركەوتنەوەیە لە دۆخ یان هەستێک کە پێویستی بە ڕووبەڕووبوونەوە هەیە.',
  }),
  _Sym(['teeth', 'tooth', 'اسنان', 'سن ', 'ددان'], {
    'en':
        'Teeth dreams tend to connect with stress, self-image, or fear of embarrassment.',
    'ar': 'أحلام الأسنان ترتبط عادةً بالتوتر وصورة الذات والخوف من الإحراج.',
    'ckb':
        'خەونی ددان زۆرجار پەیوەندی بە فشار و وێنەی خود و ترسی شەرمەزاری هەیە.',
  }),
  _Sym(['snake', 'serpent', 'ثعبان', 'افعي', 'حيه', 'مار'], {
    'en':
        "A snake can symbolize a hidden fear, a change, or something you sense but haven't fully noticed yet.",
    'ar':
        'قد ترمز الأفعى إلى خوف مخفي أو تغيير قادم أو أمر تشعر به دون أن تدركه تماماً.',
    'ckb':
        'مار دەکرێت هێمای ترسێکی شاراوە یان گۆڕانکاری یان شتێک بێت کە هەستی پێدەکەیت بەڵام تەواو تێینەگەیشتووی.',
  }),
  _Sym([
    'death', 'dead', 'die', 'funeral', 'موت', 'ميت', 'جنازه', 'مات', 'مردن'
  ], {
    'en':
        'Death in dreams rarely means literal loss — it more often signals an ending and a new beginning.',
    'ar':
        'الموت في الأحلام نادراً ما يعني فقداناً حرفياً، بل يشير غالباً إلى نهاية مرحلة وبداية جديدة.',
    'ckb':
        'مردن لە خەوندا بە ڕێژەیەکی کەم مردنی ڕاستەقینە دەگەیەنێت؛ زیاتر کۆتایی قۆناغێک و دەستپێکێکی نوێیە.',
  }),
  _Sym([
    'exam', 'test', 'late', 'school', 'امتحان', 'اختبار', 'تاخر', 'تاقيكردنەوە'
  ], {
    'en':
        'Exams or being late reflect pressure to perform and fear of being judged or unprepared.',
    'ar':
        'الامتحان أو التأخر يعكس ضغط الأداء والخوف من التقييم أو عدم الاستعداد.',
    'ckb':
        'تاقیکردنەوە یان دواکەوتن فشاری ئەنجامدان و ترسی هەڵسەنگاندن یان ئامادەنەبوون ڕەنگدەداتەوە.',
  }),
  _Sym(['house', 'room', 'بيت', 'منزل', 'غرفه', 'ماڵ', 'ژوور'], {
    'en':
        'A house usually mirrors your inner self; different rooms stand for different parts of your life, and hidden or unfamiliar rooms suggest unexplored parts of you.',
    'ar':
        'البيت يعكس غالباً ذاتك الداخلية؛ فالغرف المختلفة تمثل جوانب من حياتك، والغرف الغريبة أو المخفية تشير إلى جوانب لم تستكشفها بعد.',
    'ckb':
        'ماڵ زۆرجار ڕەنگدانەوەی ناخی خۆتە؛ ژوورە جیاوازەکان بەشەکانی ژیانت دەنوێنن، و ژووری نەناسراو یان شاراوە ئاماژەیە بۆ لایەنێکی نەدۆزراوەی خۆت.',
  }),
  _Sym(['baby', 'pregnan', 'طفل', 'رضيع', 'حامل', 'منداڵ', 'مناڵ'], {
    'en':
        'Babies and pregnancy often symbolize new beginnings, a new idea, or something fragile you want to protect and grow.',
    'ar':
        'الأطفال والحمل يرمزان غالباً إلى بدايات جديدة أو فكرة جديدة أو شيء هش تريد حمايته ورعايته.',
    'ckb':
        'منداڵ و سکپڕی زۆرجار هێمای دەستپێکێکی نوێ یان بیرۆکەیەکی نوێ یان شتێکی ناسکن کە دەتەوێت بیپارێزیت و گەشەی پێبدەیت.',
  }),
  _Sym(['money', 'gold', 'rich', 'فلوس', 'نقود', 'ذهب', 'پارە', 'زێڕ'], {
    'en':
        'Money or gold in dreams usually relates to self-worth, security, or how valued you feel.',
    'ar':
        'المال أو الذهب في الأحلام يرتبط غالباً بقيمة الذات والأمان وبمدى شعورك بالتقدير.',
    'ckb':
        'پارە یان زێڕ لە خەوندا زۆرجار پەیوەندی بە بەهای خود و ئاسایش و ئەو هەستەوە هەیە کە چەند بەهادار دەزانیت خۆت.',
  }),
  _Sym(['car', 'driving', 'train', 'سياره', 'قطار', 'سفر', 'ئۆتۆمبێل', 'گەشت'], {
    'en':
        'Vehicles and journeys reflect the direction of your life and how much control you feel you have over it.',
    'ar': 'المركبات والرحلات تعكس اتجاه حياتك ومقدار تحكمك فيها.',
    'ckb':
        'ئۆتۆمبێل و گەشت ڕەنگدانەوەی ئاراستەی ژیانتن و ئەوەی چەند کۆنترۆڵت بەسەریدا هەیە.',
  }),
  _Sym(['fire', 'burn', 'نار', 'حريق', 'ئاگر'], {
    'en':
        'Fire can mean strong passion or anger, or a need for deep change and cleansing.',
    'ar': 'النار قد تعني شغفاً أو غضباً قوياً، أو حاجة إلى تغيير عميق وتطهير.',
    'ckb':
        'ئاگر دەکرێت مانای خولیا یان توڕەیی بەهێز بێت، یان پێویستی بە گۆڕانکاری قووڵ و پاکبوونەوە.',
  }),
  _Sym(['war', 'gun', 'shoot', 'weapon', 'حرب', 'سلاح', 'رصاص', 'جەنگ', 'چەک'], {
    'en':
        'War or weapons usually reflect an inner conflict or a feeling of being under pressure or attack.',
    'ar': 'الحرب أو السلاح تعكس غالباً صراعاً داخلياً أو شعوراً بالضغط أو التهديد.',
    'ckb':
        'جەنگ یان چەک زۆرجار ڕەنگدانەوەی ململانێی ناوەوە یان هەستکردنە بە فشار و مەترسی.',
  }),
  _Sym(['dog', 'cat', 'كلب', 'قطه', 'سەگ', 'پشيلە'], {
    'en':
        'Animals often stand for instincts; dogs relate to loyalty and friendship, cats to independence and intuition.',
    'ar':
        'الحيوانات ترمز غالباً إلى الغرائز؛ فالكلب يرتبط بالوفاء والصداقة والقطة بالاستقلال والحدس.',
    'ckb':
        'ئاژەڵ زۆرجار هێمای غەریزەیە؛ سەگ پەیوەندی بە دڵسۆزی و دۆستایەتییەوە هەیە و پشیلە بە سەربەخۆیی و هەستی ناوەکی.',
  }),
  _Sym(['lost', 'maze', 'تهت', 'ضعت', 'ضايع', 'تايه'], {
    'en':
        'Feeling lost suggests uncertainty about a direction or decision in your waking life.',
    'ar': 'الشعور بالضياع يوحي بحيرة تجاه اتجاه أو قرار في حياتك اليقظة.',
    'ckb':
        'هەستکردن بە ون بوون ئاماژەیە بۆ دوودڵی لەبارەی ئاراستە یان بڕیارێک لە ژیانی ڕۆژانەتدا.',
  }),
];

const Map<String, String> _intro = {
  'en': "Here's a gentle reflection on your dream:",
  'ar': 'هذه قراءة هادئة لحلمك:',
  'ckb': 'ئەمە خوێندنەوەیەکی ئارامە بۆ خەونەکەت:',
};

const Map<String, String> _generic = {
  'en':
      "Dreams often blend the day's thoughts, memories and feelings. Notice which feeling stood out most — it is usually the real message of the dream.",
  'ar':
      'الأحلام غالباً تمزج أفكار اليوم وذكرياته ومشاعره. انتبه إلى الشعور الأبرز فيها، فهو عادةً الرسالة الحقيقية للحلم.',
  'ckb':
      'خەونەکان زۆرجار بیرکردنەوە و بیرەوەری و هەستی ڕۆژ تێکەڵ دەکەن. سەرنج بدە کام هەست زیاتر دیار بوو؛ ئەوە زۆرجار پەیامی ڕاستەقینەی خەونەکەیە.',
};

const Map<String, List<String>> _moodNote = {
  'en': [
    'You woke up with heavy feelings, so be kind to yourself today — talking it through with someone you trust can lighten it.',
    'A calm mood suggests this dream was more about processing the day than sending a strong message.',
    'You woke up feeling good — the dream likely carries encouraging energy you can take into your day.',
  ],
  'ar': [
    'استيقظت بمشاعر ثقيلة، فكن لطيفاً مع نفسك اليوم، والحديث مع شخص تثق به قد يخفف عنك.',
    'المزاج الهادئ يوحي بأن الحلم كان لمعالجة أحداث اليوم أكثر منه رسالة قوية.',
    'استيقظت بشعور جيد، وغالباً يحمل الحلم طاقة مشجعة يمكنك أخذها معك في يومك.',
  ],
  'ckb': [
    'بە هەستی قورس هەستایت، ئەمڕۆ میهرەبان بە لەگەڵ خۆت؛ قسەکردن لەگەڵ کەسێکی متمانەپێکراو دەتوانێت سووکی بکات.',
    'دۆخی ئارام ئاماژەیە بۆ ئەوەی خەونەکە زیاتر بۆ پڕۆسێسکردنی ڕۆژ بووە نەک پەیامێکی بەهێز.',
    'بە هەستێکی باش هەستایت؛ خەونەکە ئەگەر وزەیەکی هاندەر هەڵگرتبێت دەتوانیت لە ڕۆژەکەتدا بەکاری بهێنیت.',
  ],
};

// -------------------------------------------------- offline image vocabulary
class _Vis {
  final List<String> keys;
  final String en;
  const _Vis(this.keys, this.en);
}

const List<_Vis> _vis = [
  _Vis(['zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'زۆمبي'],
      'a horde of zombies'),
  _Vis(['monster', 'وحش', 'دێو'], 'a giant monster'),
  _Vis(['ghost', 'شبح', 'تارمايي'], 'a pale ghost'),
  _Vis(['demon', 'عفريت', 'شيطان'], 'a dark demon'),
  _Vis(['snake', 'ثعبان', 'افعي', 'حيه', 'مار'], 'a large snake'),
  _Vis(['dog', 'كلب', 'سەگ'], 'a dog'),
  _Vis(['cat', 'قطه', 'پشيلە'], 'a cat'),
  _Vis(['bird', 'طير', 'طيور', 'باڵندە'], 'birds'),
  _Vis(['horse', 'حصان', 'ئەسپ'], 'a horse'),
  _Vis(['lion', 'اسد', 'شير', 'شێر'], 'a lion'),
  _Vis(['wolf', 'ذئب', 'گورگ'], 'a wolf'),
  _Vis(['spider', 'عنكبوت', 'جالەجاڵ'], 'a giant spider'),
  _Vis(['fish', 'سمك', 'ماسي'], 'fish'),
  _Vis(['sea', 'ocean', 'بحر', 'دەريا'], 'a vast sea'),
  _Vis(['river', 'نهر', 'ڕووبار'], 'a river'),
  _Vis(['rain', 'مطر', 'باران'], 'heavy rain'),
  _Vis(['flood', 'فيضان', 'لافاو'], 'a flood'),
  _Vis(['mountain', 'جبل', 'چيا'], 'tall mountains'),
  _Vis(['forest', 'غابه', 'دارستان'], 'a dark forest'),
  _Vis(['tree', 'شجره', 'شجر', 'دار '], 'a big tree'),
  _Vis(['desert', 'صحراء', 'بيابان'], 'a desert'),
  _Vis(['city', 'مدينه', 'شار'], 'a city'),
  _Vis(['house', 'بيت', 'منزل', 'ماڵ'], 'an old house'),
  _Vis(['school', 'مدرسه', 'قوتابخانە'], 'a school'),
  _Vis(['car', 'سياره', 'ئۆتۆمبێل'], 'a car'),
  _Vis(['train', 'قطار', 'شەمەندەفەر'], 'a train'),
  _Vis(['plane', 'airplane', 'طايره', 'طائره', 'فڕۆکە'], 'an airplane'),
  _Vis(['fly', 'flying', 'اطير', 'تحليق', 'فڕين'], 'a person flying in the sky'),
  _Vis(['moon', 'قمر', 'هلال', 'مانگ'], 'the moon'),
  _Vis(['star', 'نجوم', 'نجمه', 'ئەستێرە'], 'a sky full of stars'),
  _Vis(['sun', 'شمس', 'خۆر'], 'the sun'),
  _Vis(['fire', 'نار', 'حريق', 'ئاگر'], 'fire and flames'),
  _Vis(['snow', 'ثلج', 'بەفر'], 'snow'),
  _Vis(['war', 'حرب', 'جەنگ'], 'a battlefield'),
  _Vis(['gun', 'سلاح', 'چەک'], 'a gun'),
  _Vis(['baby', 'طفل', 'رضيع', 'منداڵ'], 'a baby'),
  _Vis(['mother', 'امي', 'والده', 'دايك'], 'a mother'),
  _Vis(['father', 'ابي', 'والدي', 'باوک'], 'a father'),
  _Vis(['wedding', 'عرس', 'زفاف', 'زەماوەند'], 'a wedding'),
  _Vis(['king', 'ملك', 'پاشا'], 'a king'),
  _Vis(['flower', 'ورد', 'زهور', 'گوڵ'], 'flowers'),
  _Vis(['bridge', 'جسر', 'پردێک', 'پرد'], 'a long bridge'),
  _Vis(['door', 'باب', 'دەرگا'], 'a mysterious door'),
  _Vis(['mirror', 'مرايه', 'ئاوێنە'], 'a mirror'),
  _Vis(['cave', 'كهف', 'ئەشکەوت'], 'a cave'),
  _Vis(['storm', 'عاصفه', 'ڕەشەبا'], 'a storm'),
  _Vis(['school', 'teacher', 'معلم', 'مامۆستا'], 'a classroom'),
  _Vis(['dead', 'death', 'ميت', 'موت', 'مردن'], 'a graveyard at night'),
];

// ------------------------------------------------------------------ service
class AiService {
  static const String _textUrl = 'https://text.pollinations.ai/';
  static const String _imgUrl = 'https://image.pollinations.ai/prompt/';

  /// tried in order: stronger model first, then the default one
  static const List<String> _models = ['openai-large', 'openai'];

  static const List<String> _moodNames = [
    '', 'nightmare', 'sad', 'neutral', 'good', 'amazing'
  ];

  static String _langName(String lang) => lang == 'ar'
      ? 'clear, natural Modern Standard Arabic'
      : lang == 'ckb'
          ? 'Central Kurdish (Sorani) in Kurdish Arabic script'
          : 'English';

  // ---------- text helpers
  static String _norm(String s) {
    var t = s.toLowerCase();
    t = t.replaceAll(RegExp(r'[ً-ٰٟـ]'), '');
    t = t
        .replaceAll(RegExp('[أإآٱ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ی', 'ي')
        .replaceAll('ة', 'ه')
        .replaceAll('ک', 'ك');
    return t;
  }

  static int _find(String text, String key) {
    if (key.isEmpty) return -1;
    if (RegExp(r'^[a-z0-9 ]+$').hasMatch(key)) {
      final m = RegExp(r'\b' + RegExp.escape(key.trim())).firstMatch(text);
      return m?.start ?? -1;
    }
    return text.indexOf(key);
  }

  static String _clean(String s) {
    var t = s.trim();
    t = t.replaceAll(
        RegExp(r'\n*-{3,}\s*\n.*pollinations.*$',
            dotAll: true, caseSensitive: false),
        '');
    t = t
        .split('\n')
        .where((l) => !l.toLowerCase().contains('pollinations'))
        .join('\n');
    t = t.replaceAll('**', '').replaceAll('__', '');
    t = t.replaceAll(RegExp(r'^#+\s*', multiLine: true), '');
    t = t.replaceAll(RegExp(r'^\s*[-*•]\s+', multiLine: true), '');
    t = t.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return t.trim();
  }

  static bool _validText(String t, String lang) {
    if (t.trim().length < 40) return false;
    final letters = RegExp(r'\p{L}', unicode: true).allMatches(t).length;
    if (letters == 0) return false;
    final arabic = RegExp(r'[؀-ۿݐ-ݿ]').allMatches(t).length;
    final latin = RegExp(r'[A-Za-z]').allMatches(t).length;
    if (lang == 'en') return latin / letters > 0.8;
    if (arabic / letters < 0.75) return false;
    if (lang == 'ckb') {
      return RegExp(r'[ەێۆڕڵڤ]').allMatches(t).length >= 4;
    }
    return true;
  }

  // ---------- network
  static Future<String> _chat(String system, String user,
      {required String model, int seconds = 35}) async {
    final res = await http
        .post(
          Uri.parse(_textUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'model': model,
            'private': true,
            'seed': math.Random().nextInt(1 << 30),
            'messages': [
              {'role': 'system', 'content': system},
              {'role': 'user', 'content': user},
            ],
          }),
        )
        .timeout(Duration(seconds: seconds));
    if (res.statusCode != 200) throw Exception('http ${res.statusCode}');
    final body = utf8.decode(res.bodyBytes).trim();
    if (body.isEmpty) throw Exception('empty');
    if (body.startsWith('{') && body.contains('"error"')) {
      throw Exception('api error');
    }
    return _clean(body);
  }

  static Future<String> _chatMsgs(List<Map<String, String>> messages,
      {required String model, int seconds = 35}) async {
    final res = await http
        .post(
          Uri.parse(_textUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'model': model,
            'private': true,
            'seed': math.Random().nextInt(1 << 30),
            'messages': messages,
          }),
        )
        .timeout(Duration(seconds: seconds));
    if (res.statusCode != 200) throw Exception('http ${res.statusCode}');
    final body = utf8.decode(res.bodyBytes).trim();
    if (body.isEmpty) throw Exception('empty');
    if (body.startsWith('{') && body.contains('"error"')) {
      throw Exception('api error');
    }
    return _clean(body);
  }

  static String _askSystem(String langName, String title, String content, int mood,
          String? interpretation) =>
      'You are a warm, insightful dream-interpretation assistant inside a dream journal app. '
      'The user is asking follow-up questions about THIS dream only.\n'
      'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
      'Dream: $content\n'
      '${interpretation == null ? '' : 'Interpretation already given: $interpretation\n'}'
      'Rules: answer the question directly in 40 to 110 words, plain text only (no markdown, '
      'no lists, no emojis). Use psychology and gentle symbolism. Never predict the future, '
      'never give medical or religious rulings, never be frightening, do not invent details '
      'that are not in the dream. Write the whole answer in $langName.';

  /// Follow-up question about a dream. [history] = alternating {role, content}.
  /// Returns null if the AI could not answer.
  static Future<String?> ask({
    required String title,
    required String content,
    required int mood,
    required String? interpretation,
    required String lang,
    required List<Map<String, String>> history,
    required String question,
  }) async {
    final past = history.length > 8 ? history.sublist(history.length - 8) : history;
    for (final model in _models) {
      try {
        final sysLang = lang == 'ckb' ? 'English' : _langName(lang);
        final out = await _chatMsgs([
          {
            'role': 'system',
            'content': _askSystem(sysLang, title, content, mood, interpretation)
          },
          ...past,
          {'role': 'user', 'content': question},
        ], model: model);
        if (lang == 'ckb') {
          if (!_validText(out, 'en')) throw Exception('bad en');
          final ku = await _chat(_soraniSystem, out, model: model, seconds: 45);
          if (_validText(ku, 'ckb')) return ku;
        } else if (_validText(out, lang)) {
          return out;
        }
      } catch (_) {}
    }
    return null;
  }

  // ---------- interpretation
  static String _interpretSystem(String langName) =>
      'You are a thoughtful dream interpreter who combines psychology (emotions, stress, '
      'daily-life themes, Jungian and Freudian ideas) with gentle cultural symbolism.\n'
      'Interpret THIS specific dream. First name the real elements of the dream '
      '(creatures, people, places, actions, feelings) and explain what each most plausibly '
      'symbolizes. Example: zombies usually represent exhaustion, burnout, or something '
      'relentless and draining in daily life; being chased by them suggests avoiding a pressure. '
      'Then connect the dream to the mood the person woke up with. End with one practical, kind '
      'suggestion.\n'
      'Rules: 130 to 200 words. Plain text only: no markdown, no bullet points, no headings, '
      'no emojis. Never predict the future, never give medical or religious rulings, never be '
      'frightening. Do not invent details that are not in the dream. If the dream is very short, '
      'interpret what is there.\n'
      'Write the whole answer in $langName.';

  static const String _soraniSystem =
      'You are a professional translator into Central Kurdish (Sorani), written in the Kurdish '
      'Arabic script (for example: ئەم، ئەو، دەکات، خەون، ڕێگا، هەست). Translate the user\'s text '
      'faithfully into natural, fluent Sorani. Use Sorani-specific letters such as ە ێ ۆ ڕ ڵ ڤ. '
      'Never answer in Arabic, Persian or Kurmanji. Output only the translation, nothing else.';

  static Future<AiResult> interpret({
    required String title,
    required String content,
    required String lang,
    required int mood,
  }) async {
    final user =
        'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
        'Dream (may be written in Arabic, Kurdish or English):\n$content';

    for (final model in _models) {
      try {
        String out;
        if (lang == 'ckb') {
          // write the interpretation in English, then translate to Sorani:
          // models are much more reliable at translating than at writing Sorani
          final en = await _chat(_interpretSystem('English'), user, model: model);
          if (!_validText(en, 'en')) throw Exception('bad en');
          out = await _chat(_soraniSystem, en, model: model, seconds: 45);
        } else {
          out = await _chat(_interpretSystem(_langName(lang)), user, model: model);
        }
        if (_validText(out, lang)) return AiResult(out, true);
      } catch (_) {}
    }
    return AiResult(_local(title, content, lang, mood), false);
  }

  static String _local(String title, String content, String lang, int mood) {
    final l = _intro.containsKey(lang) ? lang : 'en';
    final text = _norm('$title $content');
    final hits = <MapEntry<int, String>>[];
    for (final s in _syms) {
      var best = -1;
      for (final k in s.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0) hits.add(MapEntry(best, s.text[l]!));
    }
    hits.sort((a, b) => a.key.compareTo(b.key));
    final matched = hits.take(3).map((e) => e.value).toList();
    final notes = _moodNote[l]!;
    final note = mood <= 2 ? notes[0] : (mood == 3 ? notes[1] : notes[2]);
    final body = matched.isEmpty ? _generic[l]! : matched.join('\n\n');
    return '${_intro[l]}\n\n$body\n\n$note';
  }

  // ---------- image
  static const String _style =
      'surreal dreamlike digital painting, cinematic lighting, highly detailed';

  static String? _visualFromDictionary(String title, String content) {
    final text = _norm('$title $content');
    final found = <MapEntry<int, String>>[];
    final seen = <String>{};
    for (final v in _vis) {
      var best = -1;
      for (final k in v.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0 && seen.add(v.en)) found.add(MapEntry(best, v.en));
    }
    if (found.isEmpty) return null;
    found.sort((a, b) => a.key.compareTo(b.key));
    return found.take(4).map((e) => e.value).join(', ');
  }

  static Future<String> _imagePrompt(String title, String content) async {
    final src = '$title. $content'.trim();
    const system =
        'You turn dream descriptions (written in Arabic, Kurdish or English) into an English '
        'image-generation prompt. Output ONE line, at most 40 words. Start with the main '
        'subjects exactly as described in the dream, translated faithfully (for example '
        'زومبي = zombies, بحر = sea), then the setting, mood and lighting. Never add subjects or '
        'objects that are not in the dream. No quotes, no explanation.';
    for (final model in _models) {
      try {
        final p = await _chat(system, 'Dream: $src', model: model, seconds: 25);
        final firstLine = p.split('\n').first.trim();
        final hasArabic = RegExp(r'[؀-ۿ]').hasMatch(firstLine);
        if (!hasArabic && firstLine.length >= 8 && firstLine.length <= 500) {
          return firstLine;
        }
      } catch (_) {}
    }
    final fromDict = _visualFromDictionary(title, content);
    if (fromDict != null) return fromDict;
    final ascii = RegExp(r'^[\x00-\x7F]+$');
    final short = src.length > 200 ? src.substring(0, 200) : src;
    if (short.isNotEmpty && ascii.hasMatch(short)) return short;
    return 'a surreal dreamlike scene under a starry night sky';
  }

  static Future<bool> generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    var prompt = '${await _imagePrompt(title, content)}, $_style';
    if (prompt.length > 480) prompt = prompt.substring(0, 480);
    final encoded = Uri.encodeComponent(prompt);
    final models = ['flux', 'turbo'];
    for (var i = 0; i < models.length; i++) {
      final seed = math.Random().nextInt(1 << 30);
      final uri = Uri.parse(
          '$_imgUrl$encoded?width=768&height=768&nologo=true&model=${models[i]}&seed=$seed');
      try {
        final res = await http.get(uri).timeout(Duration(seconds: i == 0 ? 90 : 60));
        final ct = res.headers['content-type'] ?? '';
        if (res.statusCode == 200 &&
            ct.startsWith('image') &&
            res.bodyBytes.length > 2000) {
          await File(savePath).writeAsBytes(res.bodyBytes, flush: true);
          return true;
        }
      } catch (_) {}
    }
    return false;
  }
}
