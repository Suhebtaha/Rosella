import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:http/http.dart' as http;

class AiResult {
  final String text;
  final bool fromAi;
  final String error; // why the AI could not answer (empty when fromAi)
  const AiResult(this.text, this.fromAi, [this.error = '']);
}

// ------------------------------------------------------------------ offline
class _Sym {
  final List<String> keys;
  final Map<String, String> text;
  const _Sym(this.keys, this.text);
}

const List<_Sym> _syms = [
  _Sym([
    'zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'الموتي الاحياء', 'زۆمبي'
  ], {
    'en':
        'Zombies usually point to exhaustion, burnout, or a feeling that something in your daily life is relentless and draining. Being chased by them suggests you are avoiding a pressure instead of facing it.',
    'ar':
        'الزومبي يرمز غالباً إلى الإرهاق والاحتراق النفسي، أو إلى شعورك بأن أمراً في حياتك اليومية يلاحقك باستمرار ويستنزفك. والهرب منهم يوحي بأنك تتجنب ضغطاً بدل مواجهته.',
    'ckb':
        'زۆمبی زۆرجار هێمای ماندووبوون و سووتانی دەروونییە، یان هەستکردنە بەوەی شتێک لە ژیانی ڕۆژانەتدا بەردەوام دەتگرێت و وزەت دەبات. ڕاکردن لێیان ئاماژەیە بۆ دوورکەوتنەوە لە فشارێک لەجیاتی ڕووبەڕووبوونەوەی.',
  }),
  _Sym([
    'monster', 'ghost', 'demon', 'وحش', 'شبح', 'عفريت', 'دێو', 'تارمايي'
  ], {
    'en':
        'Monsters and ghosts often represent a fear or worry you have not named yet; it tends to shrink once you look at it directly.',
    'ar':
        'الوحوش والأشباح تمثل غالباً خوفاً أو قلقاً لم تسمّه بعد، وغالباً يصغر حجمه حين تنظر إليه بوضوح.',
    'ckb':
        'دێو و تارمایی زۆرجار هێمای ترس یان نیگەرانییەکن کە هێشتا ناویان نەناوە، و کاتێک ڕاستەوخۆ سەیریان دەکەیت بچووک دەبنەوە.',
  }),
  _Sym([
    'water', 'sea', 'ocean', 'river', 'swim', 'drown', 'wave', 'flood',
    'ماء', 'بحر', 'نهر', 'غرق', 'موج', 'سباح', 'فيضان',
    'ئاو', 'دەريا', 'ڕووبار'
  ], {
    'en':
        'Water usually mirrors your emotions. Calm water suggests inner peace, while rough or deep water points to feelings you are still processing.',
    'ar':
        'الماء يعكس عادةً مشاعرك؛ صفاؤه يدل على سكينة داخلية، واضطرابه أو عمقه يشير إلى مشاعر ما زلت تعالجها.',
    'ckb':
        'ئاو زۆرجار ڕەنگدانەوەی هەستەکانتە؛ ئاوی ئارام ئاشتی ناوەوە دەگەیەنێت و ئاوی شەپۆلدار یان قووڵ هەستی تەواونەکراو.',
  }),
  _Sym([
    'fly', 'flying', 'soar', 'plane', 'اطير', 'تحليق', 'طاير', 'فڕين'
  ], {
    'en':
        'Flying often stands for freedom, ambition, or a wish to rise above a problem.',
    'ar':
        'الطيران يرمز غالباً إلى الحرية والطموح أو الرغبة في التسامي فوق مشكلة ما.',
    'ckb':
        'فڕین زۆرجار هێمای ئازادی و ئامانجە یان ئارەزووی بەرزبوونەوە بەسەر کێشەیەکدا.',
  }),
  _Sym([
    'fall', 'falling', 'سقط', 'سقوط', 'وقعت', 'كەوتن', 'كەوتم'
  ], {
    'en':
        'Falling is commonly linked to feeling a loss of control or worry about something slipping away.',
    'ar':
        'السقوط يرتبط عادةً بالشعور بفقدان السيطرة أو القلق من أن شيئاً ما يفلت منك.',
    'ckb':
        'کەوتن زۆرجار بە هەستکردن بە لەدەستدانی کۆنترۆڵ یان نیگەرانی لە ڕۆیشتنی شتێکەوە دەبەسترێتەوە.',
  }),
  _Sym([
    'chase', 'chased', 'run away', 'escape', 'flee', 'هرب', 'يطارد', 'مطارد',
    'لاحق', 'هەڵات', 'ڕاو'
  ], {
    'en':
        'Being chased often means you are avoiding a situation or emotion that needs to be faced.',
    'ar':
        'أن يُطاردك أحد يعني غالباً أنك تتجنب موقفاً أو شعوراً يحتاج إلى مواجهة.',
    'ckb':
        'ڕاوەدوونران زۆرجار مانای دووركەوتنەوەیە لە دۆخ یان هەستێک کە پێویستی بە ڕووبەڕووبوونەوە هەیە.',
  }),
  _Sym(['teeth', 'tooth', 'اسنان', 'سن ', 'ددان'], {
    'en':
        'Teeth dreams tend to connect with stress, self-image, or fear of embarrassment.',
    'ar': 'أحلام الأسنان ترتبط عادةً بالتوتر وصورة الذات والخوف من الإحراج.',
    'ckb':
        'خەونی ددان زۆرجار پەیوەندی بە فشار و وێنەی خود و ترسی شەرمەزاری هەیە.',
  }),
  _Sym(['snake', 'serpent', 'ثعبان', 'افعي', 'حيه', 'مار'], {
    'en':
        "A snake can symbolize a hidden fear, a change, or something you sense but haven't fully noticed yet.",
    'ar':
        'قد ترمز الأفعى إلى خوف مخفي أو تغيير قادم أو أمر تشعر به دون أن تدركه تماماً.',
    'ckb':
        'مار دەکرێت هێمای ترسێکی شاراوە یان گۆڕانکاری یان شتێک بێت کە هەستی پێدەکەیت بەڵام تەواو تێینەگەیشتووی.',
  }),
  _Sym([
    'death', 'dead', 'die', 'funeral', 'موت', 'ميت', 'جنازه', 'مات', 'مردن'
  ], {
    'en':
        'Death in dreams rarely means literal loss — it more often signals an ending and a new beginning.',
    'ar':
        'الموت في الأحلام نادراً ما يعني فقداناً حرفياً، بل يشير غالباً إلى نهاية مرحلة وبداية جديدة.',
    'ckb':
        'مردن لە خەوندا بە ڕێژەیەکی کەم مردنی ڕاستەقینە دەگەیەنێت؛ زیاتر کۆتایی قۆناغێک و دەستپێکێکی نوێیە.',
  }),
  _Sym([
    'exam', 'test', 'late', 'school', 'امتحان', 'اختبار', 'تاخر', 'تاقيكردنەوە'
  ], {
    'en':
        'Exams or being late reflect pressure to perform and fear of being judged or unprepared.',
    'ar':
        'الامتحان أو التأخر يعكس ضغط الأداء والخوف من التقييم أو عدم الاستعداد.',
    'ckb':
        'تاقیکردنەوە یان دواکەوتن فشاری ئەنجامدان و ترسی هەڵسەنگاندن یان ئامادەنەبوون ڕەنگدەداتەوە.',
  }),
  _Sym(['house', 'room', 'بيت', 'منزل', 'غرفه', 'ماڵ', 'ژوور'], {
    'en':
        'A house usually mirrors your inner self; different rooms stand for different parts of your life, and hidden or unfamiliar rooms suggest unexplored parts of you.',
    'ar':
        'البيت يعكس غالباً ذاتك الداخلية؛ فالغرف المختلفة تمثل جوانب من حياتك، والغرف الغريبة أو المخفية تشير إلى جوانب لم تستكشفها بعد.',
    'ckb':
        'ماڵ زۆرجار ڕەنگدانەوەی ناخی خۆتە؛ ژوورە جیاوازەکان بەشەکانی ژیانت دەنوێنن، و ژووری نەناسراو یان شاراوە ئاماژەیە بۆ لایەنێکی نەدۆزراوەی خۆت.',
  }),
  _Sym(['baby', 'pregnan', 'طفل', 'رضيع', 'حامل', 'منداڵ', 'مناڵ'], {
    'en':
        'Babies and pregnancy often symbolize new beginnings, a new idea, or something fragile you want to protect and grow.',
    'ar':
        'الأطفال والحمل يرمزان غالباً إلى بدايات جديدة أو فكرة جديدة أو شيء هش تريد حمايته ورعايته.',
    'ckb':
        'منداڵ و سکپڕی زۆرجار هێمای دەستپێکێکی نوێ یان بیرۆکەیەکی نوێ یان شتێکی ناسکن کە دەتەوێت بیپارێزیت و گەشەی پێبدەیت.',
  }),
  _Sym(['money', 'gold', 'rich', 'فلوس', 'نقود', 'ذهب', 'پارە', 'زێڕ'], {
    'en':
        'Money or gold in dreams usually relates to self-worth, security, or how valued you feel.',
    'ar':
        'المال أو الذهب في الأحلام يرتبط غالباً بقيمة الذات والأمان وبمدى شعورك بالتقدير.',
    'ckb':
        'پارە یان زێڕ لە خەوندا زۆرجار پەیوەندی بە بەهای خود و ئاسایش و ئەو هەستەوە هەیە کە چەند بەهادار دەزانیت خۆت.',
  }),
  _Sym(['car', 'driving', 'train', 'سياره', 'قطار', 'سفر', 'ئۆتۆمبێل', 'گەشت'], {
    'en':
        'Vehicles and journeys reflect the direction of your life and how much control you feel you have over it.',
    'ar': 'المركبات والرحلات تعكس اتجاه حياتك ومقدار تحكمك فيها.',
    'ckb':
        'ئۆتۆمبێل و گەشت ڕەنگدانەوەی ئاراستەی ژیانتن و ئەوەی چەند کۆنترۆڵت بەسەریدا هەیە.',
  }),
  _Sym(['fire', 'burn', 'نار', 'حريق', 'ئاگر'], {
    'en':
        'Fire can mean strong passion or anger, or a need for deep change and cleansing.',
    'ar': 'النار قد تعني شغفاً أو غضباً قوياً، أو حاجة إلى تغيير عميق وتطهير.',
    'ckb':
        'ئاگر دەکرێت مانای خولیا یان توڕەیی بەهێز بێت، یان پێویستی بە گۆڕانکاری قووڵ و پاکبوونەوە.',
  }),
  _Sym(['war', 'gun', 'shoot', 'weapon', 'حرب', 'سلاح', 'رصاص', 'جەنگ', 'چەک'], {
    'en':
        'War or weapons usually reflect an inner conflict or a feeling of being under pressure or attack.',
    'ar': 'الحرب أو السلاح تعكس غالباً صراعاً داخلياً أو شعوراً بالضغط أو التهديد.',
    'ckb':
        'جەنگ یان چەک زۆرجار ڕەنگدانەوەی ململانێی ناوەوە یان هەستکردنە بە فشار و مەترسی.',
  }),
  _Sym(['dog', 'cat', 'كلب', 'قطه', 'سەگ', 'پشيلە'], {
    'en':
        'Animals often stand for instincts; dogs relate to loyalty and friendship, cats to independence and intuition.',
    'ar':
        'الحيوانات ترمز غالباً إلى الغرائز؛ فالكلب يرتبط بالوفاء والصداقة والقطة بالاستقلال والحدس.',
    'ckb':
        'ئاژەڵ زۆرجار هێمای غەریزەیە؛ سەگ پەیوەندی بە دڵسۆزی و دۆستایەتییەوە هەیە و پشیلە بە سەربەخۆیی و هەستی ناوەکی.',
  }),
  _Sym(['lost', 'maze', 'تهت', 'ضعت', 'ضايع', 'تايه'], {
    'en':
        'Feeling lost suggests uncertainty about a direction or decision in your waking life.',
    'ar': 'الشعور بالضياع يوحي بحيرة تجاه اتجاه أو قرار في حياتك اليقظة.',
    'ckb':
        'هەستکردن بە ون بوون ئاماژەیە بۆ دوودڵی لەبارەی ئاراستە یان بڕیارێک لە ژیانی ڕۆژانەتدا.',
  }),
];

const Map<String, String> _intro = {
  'en': "Here's a gentle reflection on your dream:",
  'ar': 'هذه قراءة هادئة لحلمك:',
  'ckb': 'ئەمە خوێندنەوەیەکی ئارامە بۆ خەونەکەت:',
};

const Map<String, String> _generic = {
  'en':
      "Dreams often blend the day's thoughts, memories and feelings. Notice which feeling stood out most — it is usually the real message of the dream.",
  'ar':
      'الأحلام غالباً تمزج أفكار اليوم وذكرياته ومشاعره. انتبه إلى الشعور الأبرز فيها، فهو عادةً الرسالة الحقيقية للحلم.',
  'ckb':
      'خەونەکان زۆرجار بیرکردنەوە و بیرەوەری و هەستی ڕۆژ تێکەڵ دەکەن. سەرنج بدە کام هەست زیاتر دیار بوو؛ ئەوە زۆرجار پەیامی ڕاستەقینەی خەونەکەیە.',
};

const Map<String, List<String>> _moodNote = {
  'en': [
    'You woke up with heavy feelings, so be kind to yourself today — talking it through with someone you trust can lighten it.',
    'A calm mood suggests this dream was more about processing the day than sending a strong message.',
    'You woke up feeling good — the dream likely carries encouraging energy you can take into your day.',
  ],
  'ar': [
    'استيقظت بمشاعر ثقيلة، فكن لطيفاً مع نفسك اليوم، والحديث مع شخص تثق به قد يخفف عنك.',
    'المزاج الهادئ يوحي بأن الحلم كان لمعالجة أحداث اليوم أكثر منه رسالة قوية.',
    'استيقظت بشعور جيد، وغالباً يحمل الحلم طاقة مشجعة يمكنك أخذها معك في يومك.',
  ],
  'ckb': [
    'بە هەستی قورس هەستایت، ئەمڕۆ میهرەبان بە لەگەڵ خۆت؛ قسەکردن لەگەڵ کەسێکی متمانەپێکراو دەتوانێت سووکی بکات.',
    'دۆخی ئارام ئاماژەیە بۆ ئەوەی خەونەکە زیاتر بۆ پڕۆسێسکردنی ڕۆژ بووە نەک پەیامێکی بەهێز.',
    'بە هەستێکی باش هەستایت؛ خەونەکە ئەگەر وزەیەکی هاندەر هەڵگرتبێت دەتوانیت لە ڕۆژەکەتدا بەکاری بهێنیت.',
  ],
};

// -------------------------------------------------- offline image vocabulary
class _Vis {
  final List<String> keys;
  final String en;
  const _Vis(this.keys, this.en);
}

const List<_Vis> _vis = [
  _Vis(['zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'زۆمبي'],
      'a horde of zombies'),
  _Vis(['monster', 'وحش', 'دێو'], 'a giant monster'),
  _Vis(['ghost', 'شبح', 'تارمايي'], 'a pale ghost'),
  _Vis(['demon', 'عفريت', 'شيطان'], 'a dark demon'),
  _Vis(['snake', 'ثعبان', 'افعي', 'حيه', 'مار'], 'a large snake'),
  _Vis(['dog', 'كلب', 'سەگ'], 'a dog'),
  _Vis(['cat', 'قطه', 'پشيلە'], 'a cat'),
  _Vis(['bird', 'طير', 'طيور', 'باڵندە'], 'birds'),
  _Vis(['horse', 'حصان', 'ئەسپ'], 'a horse'),
  _Vis(['lion', 'اسد', 'شير', 'شێر'], 'a lion'),
  _Vis(['wolf', 'ذئب', 'گورگ'], 'a wolf'),
  _Vis(['spider', 'عنكبوت', 'جالەجاڵ'], 'a giant spider'),
  _Vis(['fish', 'سمك', 'ماسي'], 'fish'),
  _Vis(['sea', 'ocean', 'بحر', 'دەريا'], 'a vast sea'),
  _Vis(['river', 'نهر', 'ڕووبار'], 'a river'),
  _Vis(['rain', 'مطر', 'باران'], 'heavy rain'),
  _Vis(['flood', 'فيضان', 'لافاو'], 'a flood'),
  _Vis(['mountain', 'جبل', 'چيا'], 'tall mountains'),
  _Vis(['forest', 'غابه', 'دارستان'], 'a dark forest'),
  _Vis(['tree', 'شجره', 'شجر', 'دار '], 'a big tree'),
  _Vis(['desert', 'صحراء', 'بيابان'], 'a desert'),
  _Vis(['city', 'مدينه', 'شار'], 'a city'),
  _Vis(['house', 'بيت', 'منزل', 'ماڵ'], 'an old house'),
  _Vis(['school', 'مدرسه', 'قوتابخانە'], 'a school'),
  _Vis(['car', 'سياره', 'ئۆتۆمبێل'], 'a car'),
  _Vis(['train', 'قطار', 'شەمەندەفەر'], 'a train'),
  _Vis(['plane', 'airplane', 'طايره', 'طائره', 'فڕۆکە'], 'an airplane'),
  _Vis(['fly', 'flying', 'اطير', 'تحليق', 'فڕين'], 'a person flying in the sky'),
  _Vis(['moon', 'قمر', 'هلال', 'مانگ'], 'the moon'),
  _Vis(['star', 'نجوم', 'نجمه', 'ئەستێرە'], 'a sky full of stars'),
  _Vis(['sun', 'شمس', 'خۆر'], 'the sun'),
  _Vis(['fire', 'نار', 'حريق', 'ئاگر'], 'fire and flames'),
  _Vis(['snow', 'ثلج', 'بەفر'], 'snow'),
  _Vis(['war', 'حرب', 'جەنگ'], 'a battlefield'),
  _Vis(['gun', 'سلاح', 'چەک'], 'a gun'),
  _Vis(['baby', 'طفل', 'رضيع', 'منداڵ'], 'a baby'),
  _Vis(['mother', 'امي', 'والده', 'دايك'], 'a mother'),
  _Vis(['father', 'ابي', 'والدي', 'باوک'], 'a father'),
  _Vis(['wedding', 'عرس', 'زفاف', 'زەماوەند'], 'a wedding'),
  _Vis(['king', 'ملك', 'پاشا'], 'a king'),
  _Vis(['flower', 'ورد', 'زهور', 'گوڵ'], 'flowers'),
  _Vis(['bridge', 'جسر', 'پردێک', 'پرد'], 'a long bridge'),
  _Vis(['door', 'باب', 'دەرگا'], 'a mysterious door'),
  _Vis(['mirror', 'مرايه', 'ئاوێنە'], 'a mirror'),
  _Vis(['cave', 'كهف', 'ئەشکەوت'], 'a cave'),
  _Vis(['storm', 'عاصفه', 'ڕەشەبا'], 'a storm'),
  _Vis(['school', 'teacher', 'معلم', 'مامۆستا'], 'a classroom'),
  _Vis(['dead', 'death', 'ميت', 'موت', 'مردن'], 'a graveyard at night'),
];

// ------------------------------------------------------------------ service
class AiService {
  static const String _textUrl = 'https://text.pollinations.ai/';
  static const String _imgUrl = 'https://image.pollinations.ai/prompt/';

  /// tried in order: stronger model first, then the default one
  static const List<String> _models = ['openai', 'openai-large', 'openai-fast', 'mistral'];

  static const List<String> _moodNames = [
    '', 'nightmare', 'sad', 'neutral', 'good', 'amazing'
  ];

  static String _langName(String lang) => lang == 'ar'
      ? 'clear, natural Modern Standard Arabic'
      : lang == 'ckb'
          ? 'Central Kurdish (Sorani) in Kurdish Arabic script'
          : 'English';

  // ---------- text helpers
  static String _norm(String s) {
    var t = s.toLowerCase();
    t = t.replaceAll(RegExp(r'[ً-ٰٟـ]'), '');
    t = t
        .replaceAll(RegExp('[أإآٱ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ی', 'ي')
        .replaceAll('ة', 'ه')
        .replaceAll('ک', 'ك');
    return t;
  }

  static int _find(String text, String key) {
    if (key.isEmpty) return -1;
    if (RegExp(r'^[a-z0-9 ]+$').hasMatch(key)) {
      final m = RegExp(r'\b' + RegExp.escape(key.trim())).firstMatch(text);
      return m?.start ?? -1;
    }
    return text.indexOf(key);
  }

  static String _clean(String s) {
    var t = s.trim();
    t = t.replaceAll(
        RegExp(r'\n*-{3,}\s*\n.*pollinations.*$',
            dotAll: true, caseSensitive: false),
        '');
    t = t
        .split('\n')
        .where((l) => !l.toLowerCase().contains('pollinations'))
        .join('\n');
    t = t.replaceAll('**', '').replaceAll('__', '');
    t = t.replaceAll(RegExp(r'^#+\s*', multiLine: true), '');
    t = t.replaceAll(RegExp(r'^\s*[-*•]\s+', multiLine: true), '');
    t = t.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return t.trim();
  }

  static bool _validText(String t, String lang) {
    if (t.trim().length < 40) return false;
    final letters = RegExp(r'\p{L}', unicode: true).allMatches(t).length;
    if (letters == 0) return false;
    final arabic = RegExp(r'[؀-ۿݐ-ݿ]').allMatches(t).length;
    final latin = RegExp(r'[A-Za-z]').allMatches(t).length;
    if (lang == 'en') return latin / letters > 0.8;
    if (arabic / letters < 0.75) return false;
    if (lang == 'ckb') {
      return RegExp(r'[ەێۆڕڵڤ]').allMatches(t).length >= 4;
    }
    return true;
  }

  // ---------- network
  /// Optional Google Gemini key (free from aistudio.google.com/apikey). When set it
  /// is tried first because it is far more reliable than the free anonymous endpoints.
  // one shared client => the TLS connection is reused (much faster after the first call)
  static final http.Client _client = http.Client();

  static final List<String> _trace = [];

  /// Per-attempt report (provider, result, seconds) for diagnosing slowness.
  static String get trace => _trace.join('\n');

  static String _secs(Stopwatch sw) => '${(sw.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';

  static String geminiKey = '';

  /// Key baked in at build time (--dart-define=GEMINI_KEY=...), used for everyone.
  static const String _builtInKey = String.fromEnvironment('GEMINI_KEY');
  static bool get hasBuiltIn => _builtInKey.isNotEmpty;

  // Identifies this app to Google so the key can be restricted to it.
  static const Map<String, String> _androidId = {
    'X-Android-Package': 'com.suhaib.rosella',
    'X-Android-Cert': 'C583A6CD590F56A454218ACE412EF433D00A0E04',
  };

  /// Last failure reason, shown to the user so problems can be diagnosed.
  static String lastError = '';

  static const List<String> _geminiModels = [
    'gemini-2.5-flash-lite', // fastest
    'gemini-flash-latest',
    'gemini-2.5-flash',
  ];

  // ---- model discovery: ask Google which models THIS key can use right now
  static final Map<String, List<List<String>>> _modelCache = {};

  static double _rank(String name, {bool image = false}) {
    final n = name.toLowerCase();
    var r = image
        ? (n.contains('pro') ? 1.0 : 0.0)
        : (n.contains('flash-lite') ? 0.0 : (n.contains('flash') ? 1.0 : 3.0));
    if (n.contains('preview')) r += 0.5;
    if (n.contains('latest')) r += 0.2;
    final v = RegExp(r'(\d+(?:\.\d+)?)').firstMatch(n);
    final ver = v == null ? 0.0 : (double.tryParse(v.group(1)!) ?? 0.0);
    return r - ver * 0.01; // newer first inside the same tier
  }

  /// [text models, image models], best first.
  static Future<List<List<String>>> _discover(String key, bool builtIn) async {
    final cached = _modelCache[key];
    if (cached != null) return cached;
    try {
      final res = await _client
          .get(
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=$key'),
            headers: {if (builtIn) ..._androidId},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) throw Exception('list ${res.statusCode}');
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final text = <String>[];
      final image = <String>[];
      for (final m in (j['models'] as List? ?? const [])) {
        final mm = m as Map;
        final name = (mm['name'] ?? '').toString().replaceFirst('models/', '');
        final methods =
            (mm['supportedGenerationMethods'] as List? ?? const []).map((e) => '$e').toList();
        if (!name.startsWith('gemini') || !methods.contains('generateContent')) continue;
        final n = name.toLowerCase();
        if (n.contains('image')) {
          image.add(name);
          continue;
        }
        const skip = ['tts', 'audio', 'live', 'embedding', 'robotics', 'computer', 'thinking', 'exp'];
        if (skip.any((w) => n.contains(w))) continue;
        text.add(name);
      }
      text.sort((a, b) => _rank(a).compareTo(_rank(b)));
      image.sort((a, b) => _rank(a, image: true).compareTo(_rank(b, image: true)));
      final out = [text.take(3).toList(), image.take(3).toList()];
      if (text.isNotEmpty) _modelCache[key] = out;
      if (text.isEmpty) throw Exception('no models');
      return out;
    } catch (_) {
      return [_geminiModels, const ['gemini-2.5-flash-image']];
    }
  }

  static bool get geminiAvailable => geminiKey.trim().isNotEmpty || _builtInKey.isNotEmpty;

  static String _apiMsg(String body) {
    try {
      final j = jsonDecode(body) as Map<String, dynamic>;
      final m = (j['error'] as Map)['message'] as String;
      return m.length > 80 ? m.substring(0, 80) : m;
    } catch (_) {
      return '';
    }
  }

  static String _cleanErr(Object e) {
    final m = e.toString().replaceAll('Exception: ', '').replaceAll('\n', ' ');
    return m.length > 90 ? m.substring(0, 90) : m;
  }

  static Future<String> _gemini(
      List<Map<String, String>> messages, int seconds, String key, bool builtIn) async {
    final system = messages
        .where((m) => m['role'] == 'system')
        .map((m) => m['content']!)
        .join('\n');
    final contents = [
      for (final m in messages.where((m) => m['role'] != 'system'))
        {
          'role': m['role'] == 'assistant' ? 'model' : 'user',
          'parts': [
            {'text': m['content']}
          ],
        }
    ];
    Object? last;
    final textModels = (await _discover(key, builtIn))[0];
    for (final model in textModels) {
      try {
        final res = await _client
            .post(
              Uri.parse(
                  'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key'),
              headers: {
                'Content-Type': 'application/json',
                if (builtIn) ..._androidId,
              },
              body: jsonEncode({
                if (system.isNotEmpty)
                  'systemInstruction': {
                    'parts': [
                      {'text': system}
                    ]
                  },
                'contents': contents,
                'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 800},
              }),
            )
            .timeout(Duration(seconds: seconds));
        if (res.statusCode != 200) {
          final msg = _apiMsg(utf8.decode(res.bodyBytes, allowMalformed: true));
          last = 'gemini $model ${res.statusCode} $msg';
          final keyBad = msg.contains('API key') || msg.contains('API_KEY');
          if (res.statusCode == 403 || keyBad) {
            // bad key / blocked by restrictions: other models will fail the same way
            throw Exception(last);
          }
          continue;
        }
        final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
        final parts = (((j['candidates'] as List).first as Map)['content']
            as Map)['parts'] as List;
        final text = parts.map((p) => (p as Map)['text'] ?? '').join();
        if (text.trim().isEmpty) throw Exception('gemini empty');
        lastInfo = '$model';
        return _clean(text);
      } on TimeoutException {
        last = 'gemini timeout';
      }
    }
    throw Exception('${last ?? 'gemini failed'}');
  }

  /// provider/model and time of the last successful call (shown to the user)
  static String lastInfo = '';

  static bool _pollDown = false; // free endpoint failed this session: skip it

  /// Gemini with server-sent events: text arrives word by word via [onPartial].
  static Future<String> _geminiStream(List<Map<String, String>> messages, int seconds,
      String key, bool builtIn, void Function(String) onPartial) async {
    final system = messages
        .where((m) => m['role'] == 'system')
        .map((m) => m['content']!)
        .join('\n');
    final contents = [
      for (final m in messages.where((m) => m['role'] != 'system'))
        {
          'role': m['role'] == 'assistant' ? 'model' : 'user',
          'parts': [
            {'text': m['content']}
          ],
        }
    ];
    Object? last;
    final textModels = (await _discover(key, builtIn))[0];
    for (final model in textModels) {
      final client = _client;
      final sw = Stopwatch()..start();
      var firstMs = -1;
      try {
        final req = http.Request(
            'POST',
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=$key'));
        req.headers['Content-Type'] = 'application/json';
        if (builtIn) req.headers.addAll(_androidId);
        req.body = jsonEncode({
          if (system.isNotEmpty)
            'systemInstruction': {
              'parts': [
                {'text': system}
              ]
            },
          'contents': contents,
          'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 800},
        });
        final resp = await client.send(req).timeout(Duration(seconds: seconds));
        if (resp.statusCode != 200) {
          final body = await resp.stream.bytesToString();
          final msg = _apiMsg(body);
          last = 'gemini $model ${resp.statusCode} $msg';
          final keyBad = msg.contains('API key') || msg.contains('API_KEY');
          if (resp.statusCode == 403 || keyBad) throw Exception(last);
          continue;
        }
        var acc = '';
        await for (final line in resp.stream
            .transform(utf8.decoder)
            .transform(const LineSplitter())
            .timeout(Duration(seconds: seconds))) {
          if (!line.startsWith('data:')) continue;
          final data = line.substring(5).trim();
          if (data.isEmpty) continue;
          try {
            final j = jsonDecode(data) as Map<String, dynamic>;
            final cands = j['candidates'] as List? ?? const [];
            if (cands.isEmpty) continue;
            final parts = ((cands.first as Map)['content'] as Map?)?['parts'] as List? ?? const [];
            for (final p in parts) {
              acc += ((p as Map)['text'] ?? '').toString();
            }
            if (firstMs < 0) firstMs = sw.elapsedMilliseconds;
            onPartial(_clean(acc));
          } catch (_) {}
        }
        if (acc.trim().isEmpty) {
          last = 'gemini empty';
          continue;
        }
        lastInfo =
            '$model • first ${(firstMs / 1000).toStringAsFixed(1)}s • total ${_secs(sw)}';
        return _clean(acc);
      } on TimeoutException {
        last = 'gemini timeout';
      }
    }
    throw Exception('${last ?? 'gemini failed'}');
  }

  static Future<String> _pollinations(
      List<Map<String, String>> messages, String model, int seconds) async {
    // 1) legacy plain-text endpoint
    try {
      final res = await _client
          .post(
            Uri.parse(_textUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'model': model,
              'private': true,
              'seed': math.Random().nextInt(1 << 30),
              'messages': messages,
            }),
          )
          .timeout(Duration(seconds: seconds));
      if (res.statusCode != 200) throw Exception('pollinations ${res.statusCode}');
      final body = utf8.decode(res.bodyBytes).trim();
      if (body.isEmpty) throw Exception('pollinations empty');
      if (body.startsWith('{')) {
        final j = jsonDecode(body);
        final ch = j is Map ? j['choices'] : null;
        if (ch is List && ch.isNotEmpty) {
          return _clean(((ch.first as Map)['message'] as Map)['content'] as String);
        }
        throw Exception('pollinations api error');
      }
      return _clean(body);
    } catch (e) {
      // 2) OpenAI-compatible endpoint of the same service
      final res = await _client
          .post(
            Uri.parse('https://text.pollinations.ai/openai'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'model': model, 'messages': messages}),
          )
          .timeout(Duration(seconds: seconds));
      if (res.statusCode != 200) {
        throw Exception('${_cleanErr(e)} / openai ${res.statusCode}');
      }
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final text = (((j['choices'] as List).first as Map)['message'] as Map)['content']
          as String;
      if (text.trim().isEmpty) throw Exception('pollinations empty');
      return _clean(text);
    }
  }

  /// One completion. Gemini first (if a key is set), then the free endpoints.
  static Future<String> _complete(List<Map<String, String>> messages,
      {int seconds = 30, void Function(String)? onPartial}) async {
    _trace.clear();
    final errors = <String>[];
    final own = geminiKey.trim();
    for (final k in [own, _builtInKey]) {
      if (k.isEmpty) continue;
      final builtIn = k == _builtInKey && own != k;
      final label = builtIn ? 'Gemini (built-in key)' : 'Gemini (your key)';
      final sw = Stopwatch()..start();
      try {
        final out = onPartial != null
            ? await _geminiStream(messages, seconds, k, builtIn, onPartial)
            : await _gemini(messages, seconds, k, builtIn);
        _trace.add('$label: OK ${_secs(sw)}');
        return out;
      } catch (e) {
        _trace.add('$label: FAILED ${_secs(sw)} - ${_cleanErr(e)}');
        errors.add(_cleanErr(e));
      }
    }
    final fallbackModels = geminiAvailable ? _models.take(1) : _models;
    for (final model in fallbackModels) {
      if (_pollDown) {
        _trace.add('Pollinations: skipped (failed earlier this session)');
        break;
      }
      final sw = Stopwatch()..start();
      try {
        final out = await _pollinations(messages, model, geminiAvailable ? 15 : seconds);
        lastInfo = 'pollinations/$model • ${_secs(sw)}';
        _trace.add('Pollinations/$model: OK ${_secs(sw)}');
        onPartial?.call(out);
        return out;
      } catch (e) {
        _trace.add('Pollinations/$model: FAILED ${_secs(sw)} - ${_cleanErr(e)}');
        errors.add(_cleanErr(e));
        if (e is TimeoutException) _pollDown = true;
      }
    }
    lastError = errors.isEmpty ? 'unknown' : errors.take(3).join(' | ');
    throw Exception(lastError);
  }

  /// Tiny request used by the "test AI" button: returns a readable report.
  static Future<String> selfTest() async {
    final sw = Stopwatch()..start();
    _pollDown = false;
    try {
      await _complete([
        {'role': 'user', 'content': 'Reply with exactly one word: ok'}
      ], seconds: 20, onPartial: (_) {});
      final k = geminiKey.trim().isNotEmpty ? geminiKey.trim() : _builtInKey;
      final d = k.isEmpty ? <List<String>>[[], []] : await _discover(k, k == _builtInKey && geminiKey.trim().isEmpty);
      return 'OK in ${_secs(sw)}\n$trace\n\nText models: ${d[0]}\nImage models: ${d[1]}';
    } catch (e) {
      return 'FAILED after ${_secs(sw)}\n$trace';
    }
  }

  static Future<String> _chat(String system, String user,
      {String? model, int seconds = 30, void Function(String)? onPartial}) {
    return _complete([
      {'role': 'system', 'content': system},
      {'role': 'user', 'content': user},
    ], seconds: seconds, onPartial: onPartial);
  }

  static String _askSystem(String langName, String title, String content, int mood,
          String? interpretation) =>
      'You are a warm, insightful dream-interpretation assistant inside a dream journal app. '
      'The user is asking follow-up questions about THIS dream only.\n'
      'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
      'Dream: $content\n'
      '${interpretation == null ? '' : 'Interpretation already given: $interpretation\n'}'
      'Rules: answer the question directly in 30 to 70 words, plain text only (no markdown, '
      'no lists, no emojis). Use psychology and gentle symbolism. Never predict the future, '
      'never give medical or religious rulings, never be frightening, do not invent details '
      'that are not in the dream. Write the whole answer in $langName.';

  /// Follow-up question about a dream. [history] = alternating {role, content}.
  /// Returns null if the AI could not answer.
  static Future<String?> ask({
    required String title,
    required String content,
    required int mood,
    required String? interpretation,
    required String lang,
    required List<Map<String, String>> history,
    required String question,
    void Function(String)? onPartial,
  }) async {
    final past = history.length > 8 ? history.sublist(history.length - 8) : history;
    final sysLang = lang == 'ckb' ? 'English' : _langName(lang);
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        if (lang == 'ckb' && geminiAvailable && attempt == 0) {
          final direct = await _complete([
            {
              'role': 'system',
              'content': _askSystem(_langName('ckb'), title, content, mood, interpretation)
            },
            ...past,
            {'role': 'user', 'content': question},
          ], onPartial: onPartial);
          if (_validText(direct, 'ckb')) return direct;
        }
        final out = await _complete([
          {
            'role': 'system',
            'content': _askSystem(sysLang, title, content, mood, interpretation)
          },
          ...past,
          {'role': 'user', 'content': question},
        ], onPartial: lang == 'ckb' ? null : onPartial);
        if (lang == 'ckb') {
          if (!_validText(out, 'en')) throw Exception('bad en');
          final ku = await _chat(_soraniSystem, out, seconds: 45);
          if (_validText(ku, 'ckb')) return ku;
          lastError = 'sorani check failed';
        } else if (_validText(out, lang)) {
          return out;
        } else {
          lastError = 'reply language check failed';
        }
      } catch (_) {}
    }
    return null;
  }

  // ---------- interpretation
  static String _interpretSystem(String langName) =>
      'You are a thoughtful dream interpreter who combines psychology (emotions, stress, '
      'daily-life themes, Jungian and Freudian ideas) with gentle cultural symbolism.\n'
      'Interpret THIS specific dream. First name the real elements of the dream '
      '(creatures, people, places, actions, feelings) and explain what each most plausibly '
      'symbolizes. Example: zombies usually represent exhaustion, burnout, or something '
      'relentless and draining in daily life; being chased by them suggests avoiding a pressure. '
      'Then connect the dream to the mood the person woke up with. End with one practical, kind '
      'suggestion.\n'
      'Rules: 90 to 130 words. Plain text only: no markdown, no bullet points, no headings, '
      'no emojis. Never predict the future, never give medical or religious rulings, never be '
      'frightening. Do not invent details that are not in the dream. If the dream is very short, '
      'interpret what is there.\n'
      'Write the whole answer in $langName.';

  static const String _soraniSystem =
      'You are a professional translator into Central Kurdish (Sorani), written in the Kurdish '
      'Arabic script (for example: ئەم، ئەو، دەکات، خەون، ڕێگا، هەست). Translate the user\'s text '
      'faithfully into natural, fluent Sorani. Use Sorani-specific letters such as ە ێ ۆ ڕ ڵ ڤ. '
      'Never answer in Arabic, Persian or Kurmanji. Output only the translation, nothing else.';

  static Future<AiResult> interpret({
    required String title,
    required String content,
    required String lang,
    required int mood,
    void Function(String)? onPartial,
  }) async {
    final user =
        'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
        'Dream (may be written in Arabic, Kurdish or English):\n$content';

    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        String out;
        if (lang == 'ckb' && geminiAvailable && attempt == 0) {
          // Gemini writes decent Sorani directly: one call instead of two (faster)
          final direct =
              await _chat(_interpretSystem(_langName('ckb')), user, onPartial: onPartial);
          if (_validText(direct, 'ckb')) return AiResult(direct, true);
          lastError = 'sorani direct check failed';
        }
        if (lang == 'ckb') {
          // write the interpretation in English, then translate to Sorani:
          // models are much more reliable at translating than at writing Sorani
          final en = await _chat(_interpretSystem('English'), user);
          if (!_validText(en, 'en')) throw Exception('bad en');
          out = await _chat(_soraniSystem, en, seconds: 45);
        } else {
          out = await _chat(_interpretSystem(_langName(lang)), user, onPartial: onPartial);
        }
        if (_validText(out, lang)) return AiResult(out, true);
        lastError = 'reply language check failed';
      } catch (_) {}
    }
    return AiResult(_local(title, content, lang, mood), false, lastError);
  }

  /// true when the offline dictionary recognised at least one symbol in the dream.
  static bool localHasMatch(String title, String content) {
    final text = _norm('$title $content');
    for (final s in _syms) {
      for (final k in s.keys) {
        if (_find(text, _norm(k)) >= 0) return true;
      }
    }
    return false;
  }

  static String _local(String title, String content, String lang, int mood) {
    final l = _intro.containsKey(lang) ? lang : 'en';
    final text = _norm('$title $content');
    final hits = <MapEntry<int, String>>[];
    for (final s in _syms) {
      var best = -1;
      for (final k in s.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0) hits.add(MapEntry(best, s.text[l]!));
    }
    hits.sort((a, b) => a.key.compareTo(b.key));
    final matched = hits.take(3).map((e) => e.value).toList();
    final notes = _moodNote[l]!;
    final note = mood <= 2 ? notes[0] : (mood == 3 ? notes[1] : notes[2]);
    final body = matched.isEmpty ? _generic[l]! : matched.join('\n\n');
    return '${_intro[l]}\n\n$body\n\n$note';
  }

  // ---------- image
  static const String _style =
      'surreal dreamlike digital painting, cinematic lighting, highly detailed';

  static String? _visualFromDictionary(String title, String content) {
    final text = _norm('$title $content');
    final found = <MapEntry<int, String>>[];
    final seen = <String>{};
    for (final v in _vis) {
      var best = -1;
      for (final k in v.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0 && seen.add(v.en)) found.add(MapEntry(best, v.en));
    }
    if (found.isEmpty) return null;
    found.sort((a, b) => a.key.compareTo(b.key));
    return found.take(4).map((e) => e.value).join(', ');
  }

  static Future<String?> _imagePrompt(String title, String content) async {
    final src = '$title. $content'.trim();
    const system =
        'You turn dream descriptions (written in Arabic, Kurdish or English) into an English '
        'image-generation prompt. Output ONE line, at most 40 words. Start with the main '
        'subjects exactly as described in the dream, translated faithfully (for example '
        'زومبي = zombies, بحر = sea), then the setting, mood and lighting. Never add subjects or '
        'objects that are not in the dream. No quotes, no explanation.';
    try {
      final p = await _chat(system, 'Dream: $src', seconds: 25);
      final firstLine = p.split('\n').first.trim();
      final hasArabic = RegExp(r'[؀-ۿ]').hasMatch(firstLine);
      if (!hasArabic && firstLine.length >= 8 && firstLine.length <= 500) {
        return firstLine;
      }
    } catch (_) {}
    final fromDict = _visualFromDictionary(title, content);
    if (fromDict != null) return fromDict;
    final ascii = RegExp(r'^[\x00-\x7F]+$');
    final short = src.length > 200 ? src.substring(0, 200) : src;
    if (short.isNotEmpty && ascii.hasMatch(short)) return short;
    return null; // never draw an unrelated generic scene
  }

  static bool _imgBlocked = false;

  static void _imgFail(String m) {
    lastError = m;
    _trace.add(m);
  }

  /// Image through Gemini (nano-banana). Returns true when a file was written.
  static Future<bool> _geminiImage(String prompt, String savePath) async {
    final keys = [geminiKey.trim(), _builtInKey].where((k) => k.isNotEmpty).toList();
    for (final k in keys) {
      final builtIn = k == _builtInKey && geminiKey.trim() != k;
      final models = (await _discover(k, builtIn))[1];
      if (models.isEmpty) {
        _imgFail('gemini-image: this key has no image model (models: ${(await _discover(k, builtIn))[1]})');
        continue;
      }
      for (final model in models) {
        try {
          final res = await _client
              .post(
                Uri.parse(
                    'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$k'),
                headers: {
                  'Content-Type': 'application/json',
                  if (builtIn) ..._androidId,
                },
                body: jsonEncode({
                  'contents': [
                    {
                      'parts': [
                        {'text': prompt}
                      ]
                    }
                  ],
                  'generationConfig': {
                    'responseModalities': ['IMAGE'],
                  },
                }),
              )
              .timeout(const Duration(seconds: 60));
          if (res.statusCode != 200) {
            _imgFail(
                'gemini-image $model ${res.statusCode} ${_apiMsg(utf8.decode(res.bodyBytes, allowMalformed: true))}');
            if (res.statusCode == 404) continue; // try the next model name
            break; // quota / key problem: next key
          }
          final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
          final cands = j['candidates'] as List? ?? const [];
          for (final cand in cands) {
            final parts = ((cand as Map)['content'] as Map?)?['parts'] as List? ?? const [];
            for (final part in parts) {
              final m = part as Map;
              final inline = (m['inlineData'] ?? m['inline_data']) as Map?;
              final b64 = inline?['data'] as String?;
              if (b64 != null && b64.isNotEmpty) {
                await File(savePath).writeAsBytes(base64Decode(b64), flush: true);
                return true;
              }
            }
          }
          final block = (j['promptFeedback'] as Map?)?['blockReason'];
          final finish = cands.isNotEmpty ? (cands.first as Map)['finishReason'] : null;
          _imgBlocked = true; // refused or text-only answer: retry with a softer prompt
          _imgFail('gemini-image $model: no image (${block ?? finish ?? 'declined'})');
        } catch (e) {
          _imgFail('gemini-image $model: ${_cleanErr(e)}');
        }
      }
    }
    return false;
  }

  static const String _cfAcc = String.fromEnvironment('CF_ACCOUNT');
  static const String _cfTok = String.fromEnvironment('CF_TOKEN');

  static Future<bool> _cfImage(String prompt, String savePath) async {
    final uri = Uri.parse('https://api.cloudflare.com/client/v4/accounts/$_cfAcc'
        '/ai/run/@cf/black-forest-labs/flux-1-schnell');
    for (var i = 0; i < 2; i++) {
      try {
        final res = await _client
            .post(uri,
                headers: {
                  'Authorization': 'Bearer $_cfTok',
                  'Content-Type': 'application/json',
                },
                body: jsonEncode({'prompt': prompt, 'steps': 6}))
            .timeout(const Duration(seconds: 60));
        if (res.statusCode == 200) {
          final j = jsonDecode(utf8.decode(res.bodyBytes));
          final b64 = (j['result'] as Map?)?['image'] as String?;
          if (b64 != null && b64.isNotEmpty) {
            final bytes = base64Decode(b64);
            if (bytes.length > 2000) {
              await File(savePath).writeAsBytes(bytes, flush: true);
              return true;
            }
          }
          _imgFail('cloudflare: empty image');
        } else {
          final b = utf8.decode(res.bodyBytes, allowMalformed: true);
          _imgFail('cloudflare ${res.statusCode} ${b.length > 160 ? b.substring(0, 160) : b}');
          if (res.statusCode == 401 || res.statusCode == 403 || res.statusCode == 429) return false;
        }
      } catch (e) {
        _imgFail('cloudflare ${_cleanErr(e)}');
      }
    }
    return false;
  }

  static Future<bool> generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    final ok = await _generateImage(title: title, content: content, savePath: savePath);
    if (!ok) {
      final head = 'build: cloudflare=${_cfAcc.isNotEmpty && _cfTok.isNotEmpty ? "ON" : "OFF (secrets missing in this build)"}'
          ' • gemini=${geminiAvailable ? "ON" : "OFF"}';
      if (_trace.isEmpty) _trace.add('no details were recorded');
      _trace.insert(0, head);
      lastError = _trace.join('\n');
    }
    return ok;
  }

  static Future<bool> _generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    lastError = '';
    _trace.clear();
    _imgBlocked = false;
    final sw0 = Stopwatch()..start();
    if (_cfAcc.isNotEmpty && _cfTok.isNotEmpty) {
      final en = await _imagePrompt(title, content);
      if (en != null) {
        var cp = '$en, $_style';
        if (cp.length > 1400) cp = cp.substring(0, 1400);
        if (await _cfImage(cp, savePath)) {
          lastInfo = 'cloudflare-flux • ${(sw0.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';
          return true;
        }
      } else {
        _imgFail('could not understand the dream text');
      }
    }
    if (_cfAcc.isEmpty && geminiAvailable) {
      // one call only: Gemini reads the (Arabic/Kurdish/English) dream and paints it
      final dream = '$title. $content';
      final prompts = [
        'A surreal dreamlike digital painting, cinematic lighting, highly detailed. '
            'Illustrate ONLY what is described in this dream (translate it faithfully, add '
            'nothing that is not mentioned). No text in the image.\nDream: $dream',
        // second try if the first was refused: same story, told tastefully and symbolically
        'A tasteful, wholesome, artistic dreamlike painting with soft cinematic light. '
            'Show the main people, creatures, places and objects of this dream faithfully, '
            'fully clothed and non-explicit, expressing any romance or violence only through '
            'gentle, symbolic, silhouette-style imagery. No text.\nDream: $dream',
      ];
      final sw = Stopwatch()..start();
      for (final pr in prompts) {
        _imgBlocked = false;
        if (await _geminiImage(pr.length > 1500 ? pr.substring(0, 1500) : pr, savePath)) {
          lastInfo = 'gemini-image • ${(sw.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';
          return true;
        }
        if (!_imgBlocked) break; // network/quota problem: retrying the prompt won't help
      }
    }
    final english = await _imagePrompt(title, content);
    if (english == null) {
      _imgFail('could not understand the dream text');
      return false;
    }
    var prompt = '$english, $_style';
    if (prompt.length > 480) prompt = prompt.substring(0, 480);
    final encoded = Uri.encodeComponent(prompt);
    final models = ['flux', 'turbo'];
    for (var i = 0; i < models.length; i++) {
      final seed = math.Random().nextInt(1 << 30);
      final uri = Uri.parse(
          '$_imgUrl$encoded?width=768&height=768&nologo=true&model=${models[i]}&seed=$seed');
      try {
        final res = await _client.get(uri).timeout(Duration(seconds: i == 0 ? 60 : 40));
        final ct = res.headers['content-type'] ?? '';
        if (res.statusCode == 200 &&
            ct.startsWith('image') &&
            res.bodyBytes.length > 2000) {
          await File(savePath).writeAsBytes(res.bodyBytes, flush: true);
          return true;
        }
        _imgFail('pollinations-image ${models[i]} ${res.statusCode}');
      } catch (e) {
        _imgFail('pollinations-image ${models[i]} ${_cleanErr(e)}');
      }
    }
    return false;
  }
}
