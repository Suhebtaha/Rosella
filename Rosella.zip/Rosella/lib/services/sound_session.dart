import 'package:audio_service/audio_service.dart';

/// Shows the sleep sounds in the phone's media notification (lock screen,
/// notification shade), like a music player. The audio itself is played by
/// [SoundController]; this only publishes state and receives the buttons.
class SoundAudioHandler extends BaseAudioHandler {
  /// 'ok' once the media session is ready, otherwise the reason it is not.
  static String status = 'not started';

  Future<void> Function()? onPlayReq;
  Future<void> Function()? onPauseReq;
  Future<void> Function()? onStopReq;

  @override
  Future<void> play() async => onPlayReq?.call();

  @override
  Future<void> pause() async => onPauseReq?.call();

  @override
  Future<void> stop() async => onStopReq?.call();

  void show(String title, bool playing) {
    mediaItem.add(MediaItem(
      id: 'rosella_sounds',
      title: title,
      artist: 'Rosella',
      album: 'Rosella',
    ));
    playbackState.add(PlaybackState(
      controls: [
        playing ? MediaControl.pause : MediaControl.play,
        MediaControl.stop,
      ],
      systemActions: const {MediaAction.play, MediaAction.pause, MediaAction.stop},
      androidCompactActionIndices: const [0, 1],
      processingState: AudioProcessingState.ready,
      playing: playing,
    ));
  }

  void hide() {
    playbackState.add(PlaybackState(
      processingState: AudioProcessingState.idle,
      playing: false,
    ));
  }
}
