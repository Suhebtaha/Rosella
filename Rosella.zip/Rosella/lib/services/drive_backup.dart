import 'dart:convert';

import 'package:http/http.dart' as http;

class DriveException implements Exception {
  final int status;
  final String body;
  const DriveException(this.status, this.body);

  bool get apiDisabled =>
      body.contains('accessNotConfigured') ||
      body.contains('SERVICE_DISABLED') ||
      body.contains('has not been used in project');

  bool get scopeProblem =>
      body.contains('insufficientPermissions') ||
      body.contains('ACCESS_TOKEN_SCOPE_INSUFFICIENT') ||
      body.contains('insufficient');

  String get message {
    try {
      final j = jsonDecode(body) as Map<String, dynamic>;
      final m = (j['error'] as Map<String, dynamic>)['message'];
      if (m is String && m.isNotEmpty) return '$status: $m';
    } catch (_) {}
    return 'HTTP $status';
  }

  @override
  String toString() => message;
}

/// Minimal Google Drive v3 client that only touches the hidden `appDataFolder`
/// (a private folder of this app inside the user's own Drive).
class DriveBackup {
  static const String scope = 'https://www.googleapis.com/auth/drive.appdata';
  static const String _api = 'https://www.googleapis.com/drive/v3';
  static const String _up = 'https://www.googleapis.com/upload/drive/v3';

  final String token;
  const DriveBackup(this.token);

  Map<String, String> get _h => {'Authorization': 'Bearer $token'};

  /// "audio/123.m4a" -> "audio__123.m4a" (Drive names are flat)
  static String flat(String rel) => rel.replaceFirst('/', '__');
  static String unflat(String name) => name.replaceFirst('__', '/');

  static String mimeFor(String name) {
    final n = name.toLowerCase();
    if (n.endsWith('.json')) return 'application/json';
    if (n.endsWith('.m4a')) return 'audio/mp4';
    if (n.endsWith('.jpg') || n.endsWith('.jpeg')) return 'image/jpeg';
    if (n.endsWith('.png')) return 'image/png';
    return 'application/octet-stream';
  }

  void _check(http.Response r) {
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw DriveException(r.statusCode, utf8.decode(r.bodyBytes, allowMalformed: true));
    }
  }

  /// name -> file id
  Future<Map<String, String>> list() async {
    final out = <String, String>{};
    String? page;
    do {
      final uri = Uri.parse('$_api/files').replace(queryParameters: {
        'spaces': 'appDataFolder',
        'fields': 'nextPageToken,files(id,name)',
        'pageSize': '1000',
        if (page != null) 'pageToken': page,
      });
      final r = await http.get(uri, headers: _h).timeout(const Duration(seconds: 30));
      _check(r);
      final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      for (final f in (j['files'] as List? ?? const [])) {
        final m = f as Map<String, dynamic>;
        out[m['name'] as String] = m['id'] as String;
      }
      page = j['nextPageToken'] as String?;
    } while (page != null);
    return out;
  }

  Future<void> upload(String name, List<int> bytes, String? existingId) async {
    final mime = mimeFor(name);
    if (existingId != null) {
      final r = await http
          .patch(
            Uri.parse('$_up/files/$existingId?uploadType=media'),
            headers: {..._h, 'Content-Type': mime},
            body: bytes,
          )
          .timeout(const Duration(seconds: 180));
      _check(r);
      return;
    }
    final boundary = 'rosella${DateTime.now().microsecondsSinceEpoch}';
    final meta = jsonEncode({
      'name': name,
      'parents': ['appDataFolder'],
    });
    final head = utf8.encode('--$boundary\r\n'
        'Content-Type: application/json; charset=UTF-8\r\n\r\n'
        '$meta\r\n'
        '--$boundary\r\n'
        'Content-Type: $mime\r\n\r\n');
    final tail = utf8.encode('\r\n--$boundary--');
    final r = await http
        .post(
          Uri.parse('$_up/files?uploadType=multipart'),
          headers: {..._h, 'Content-Type': 'multipart/related; boundary=$boundary'},
          body: <int>[...head, ...bytes, ...tail],
        )
        .timeout(const Duration(seconds: 180));
    _check(r);
  }

  Future<List<int>> download(String id) async {
    final r = await http
        .get(Uri.parse('$_api/files/$id?alt=media'), headers: _h)
        .timeout(const Duration(seconds: 180));
    _check(r);
    return r.bodyBytes;
  }

  Future<void> delete(String id) async {
    try {
      await http
          .delete(Uri.parse('$_api/files/$id'), headers: _h)
          .timeout(const Duration(seconds: 30));
    } catch (_) {}
  }
}
