import 'dart:math' as math;
import 'dart:typed_data';

const int _sr = 22050;

/// Length of every sound: 4 minutes, with random events spread over the whole
/// length, so nothing audibly repeats within a normal night's listening.
const int _seconds = 240;

/// Generates a seamless looping WAV (16-bit mono) for the given sound id.
/// Runs inside an isolate via `compute`.
Uint8List synthesizeWav(String id) {
  final n = _sr * _seconds;
  final fade = (_sr * 4).toInt();
  final total = n + fade;
  final rnd = math.Random(id.hashCode ^ 0x5eed);

  Float32List x;
  double gain;
  switch (id) {
    case 'rain':
      x = _rain(total, rnd);
      gain = 0.55;
      break;
    case 'thunder':
      x = _thunder(total, rnd);
      gain = 0.85;
      break;
    case 'waves':
      x = _waves(total, rnd);
      gain = 0.8;
      break;
    case 'train':
      x = _train(total, rnd);
      gain = 0.85;
      break;
    case 'wind':
      x = _wind(total, rnd);
      gain = 0.8;
      break;
    case 'fire':
      x = _fire(total, rnd);
      gain = 0.85;
      break;
    default:
      x = _birds(total, rnd);
      gain = 0.7;
  }

  // equal-power crossfade of the tail into the head => seamless loop (in place)
  for (var i = 0; i < fade; i++) {
    final w = i / fade;
    x[i] = x[i] * math.sin(w * math.pi / 2) + x[n + i] * math.cos(w * math.pi / 2);
  }

  var peak = 0.0001;
  for (var i = 0; i < n; i++) {
    final a = x[i].abs();
    if (a > peak) peak = a;
  }
  final scale = gain / peak;

  final bytes = ByteData(44 + n * 2);
  void ws(int off, String s) {
    for (var i = 0; i < s.length; i++) {
      bytes.setUint8(off + i, s.codeUnitAt(i));
    }
  }

  ws(0, 'RIFF');
  bytes.setUint32(4, 36 + n * 2, Endian.little);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  bytes.setUint32(16, 16, Endian.little);
  bytes.setUint16(20, 1, Endian.little);
  bytes.setUint16(22, 1, Endian.little);
  bytes.setUint32(24, _sr, Endian.little);
  bytes.setUint32(28, _sr * 2, Endian.little);
  bytes.setUint16(32, 2, Endian.little);
  bytes.setUint16(34, 16, Endian.little);
  ws(36, 'data');
  bytes.setUint32(40, n * 2, Endian.little);
  for (var i = 0; i < n; i++) {
    final v = math.max(-32768, math.min(32767, (x[i] * scale * 32767).round()));
    bytes.setInt16(44 + i * 2, v, Endian.little);
  }
  return bytes.buffer.asUint8List();
}

double _noise(math.Random r) => r.nextDouble() * 2 - 1;

/// Slow random drift with roughly unit spread (used to vary intensity over minutes).
class _Drift {
  final math.Random r;
  final double a;
  final double norm;
  double v = 0;
  _Drift(this.r, {double seconds = 12})
      : a = 1 / (seconds * _sr),
        norm = 1 / (0.577 * math.sqrt(1 / (2 * seconds * _sr)));
  double next() {
    v += (_noise(r) - v) * a;
    return v * norm;
  }
}

/// Soft rain on a window: only drops tapping the glass (no airy hush or wind),
/// lots of tiny ones, some bigger rounder ones.
Float32List _rain(int total, math.Random r) {
  final x = Float32List(total);
  final drift = _Drift(r, seconds: 25);
  var i = 0;
  while (i < total) {
    final k = (drift.next() * 0.5).clamp(-1.0, 1.0);
    final rate = 140 + 50 * k; // drops per second
    final gap = -math.log(1 - r.nextDouble()) / rate * _sr;
    i += gap.round() + 1;
    if (i >= total - 2000) break;
    final big = r.nextDouble() < 0.05;
    final amp = big ? 0.2 + r.nextDouble() * 0.15 : 0.03 + math.pow(r.nextDouble(), 2.0) * 0.2;
    final f0 = big ? 380 + r.nextDouble() * 420 : 1200 + r.nextDouble() * 2600;
    final glide = big ? 1.25 : 0.88 + r.nextDouble() * 0.2;
    final tau = (big ? 0.030 : 0.003 + r.nextDouble() * 0.008) * _sr;
    final len = (tau * 6).toInt();
    var ph = r.nextDouble() * 6.283;
    for (var j = 0; j < len; j++) {
      final p = i + j;
      if (p >= total) break;
      final env = math.exp(-j / tau);
      final f = f0 * (1 + (glide - 1) * (j / len));
      ph += 2 * math.pi * f / _sr;
      final attack = j < 6 ? j / 6 : 1.0;
      x[p] += (amp * env * attack * (math.sin(ph) + 0.25 * math.sin(2.1 * ph))).toDouble();
    }
  }
  // take the edge off the highs
  double lp = 0;
  for (var k = 0; k < total; k++) {
    lp += (x[k] - lp) * 0.6;
    x[k] = lp;
  }
  return x;
}

/// Distant, soft thunder every 5-10 seconds. Rumbles sit in the 100-500 Hz range
/// so a phone speaker can actually play them. No wind/air bed, no sharp cracks.
Float32List _thunder(int total, math.Random r) {
  final x = Float32List(total);
  var pos = (_sr * 2).toInt();
  while (pos < total - _sr * 12) {
    final strength = 0.6 + r.nextDouble() * 0.4;
    final rolls = 2 + r.nextInt(3);
    var off = 0.0;
    for (var k = 0; k < rolls; k++) {
      final att = (0.15 + r.nextDouble() * 0.4) * _sr;
      final dec = (0.9 + r.nextDouble() * 1.4) * _sr;
      final amp = strength * (k == 0 ? 1.0 : 0.4 + r.nextDouble() * 0.5);
      final cut = 0.05 + r.nextDouble() * 0.05;
      final start = pos + (off * _sr).toInt();
      final len = (att * 3 + dec * 4).toInt();
      double l1 = 0, l2 = 0;
      for (var j = 0; j < len; j++) {
        final p = start + j;
        if (p >= total) break;
        final w = _noise(r);
        l1 += (w - l1) * cut;
        l2 += (l1 - l2) * cut * 2;
        final env = (1 - math.exp(-j / att * 3)) * math.exp(-j / dec);
        x[p] += ((l1 * 0.7 + l2 * 0.5) * env * amp * 14).toDouble();
      }
      off += 0.35 + r.nextDouble() * 1.1;
    }
    pos += (_sr * (5 + r.nextDouble() * 5)).toInt();
  }
  return x;
}

/// Sea waves only: swells that rise, break into foam and fade, one after another.
Float32List _waves(int total, math.Random r) {
  final x = Float32List(total);
  var pos = 0;
  while (pos < total) {
    final att = (2.2 + r.nextDouble() * 1.8) * _sr;
    final dec = (3.2 + r.nextDouble() * 2.6) * _sr;
    final amp = 0.55 + r.nextDouble() * 0.45;
    final len = (att + dec * 3.5).toInt();
    double lo1 = 0, lo2 = 0, hi = 0;
    for (var j = 0; j < len; j++) {
      final p = pos + j;
      if (p >= total) break;
      final w = _noise(r);
      lo1 += (w - lo1) * 0.06;
      lo2 += (w - lo2) * 0.012;
      hi += (w - hi) * 0.35;
      final env = j < att
          ? math.pow(j / att, 1.6).toDouble()
          : math.exp(-(j - att) / dec);
      final mid = lo1 - lo2;
      final foam = (w - hi) * 0.25;
      x[p] += (amp * env * (mid * 3.2 + foam * env * env)).toDouble();
    }
    pos += (_sr * (6 + r.nextDouble() * 4)).toInt();
  }
  return x;
}

/// Train on rails: steady wheel clacks with a soft low rumble, now and then a
/// far-off horn.
Float32List _train(int total, math.Random r) {
  final x = Float32List(total);
  // rumble bed
  double a = 0, b = 0, c = 0;
  final dm = _Drift(r, seconds: 20);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    a += (w - a) * 0.12;
    b += (w - b) * 0.015;
    c += (a - c) * 0.5;
    x[i] = (c - b) * (0.55 + 0.15 * (dm.next() * 0.5).clamp(-1.0, 1.0)) * 0.9;
  }
  // wheel clacks: two bogies => a quick "ta-tak ... ta-tak" pattern
  final speed = _Drift(r, seconds: 40);
  var t = 0.2;
  const pattern = [0.0, 0.11, 0.30, 0.41];
  const amps = [1.0, 0.75, 0.9, 0.7];
  while (t < total / _sr - 1) {
    for (var q = 0; q < pattern.length; q++) {
      final start = ((t + pattern[q]) * _sr).toInt();
      final amp = amps[q] * (0.85 + 0.3 * r.nextDouble());
      final tau = 0.011 * _sr;
      final len = (tau * 6).toInt();
      double l = 0;
      var ph = 0.0;
      for (var j = 0; j < len; j++) {
        final p = start + j;
        if (p >= total) break;
        l += (_noise(r) - l) * 0.3;
        final env = math.exp(-j / tau);
        ph += 2 * math.pi * 140 / _sr;
        x[p] += (amp * env * (l * 1.1 + 0.6 * math.sin(ph) * math.exp(-j / (tau * 3)))).toDouble();
      }
    }
    t += 0.78 + 0.1 * (speed.next() * 0.5).clamp(-1.0, 1.0);
  }
  // distant horn every 45-80 s
  var h = _sr * (12 + r.nextDouble() * 20);
  while (h < total - _sr * 6) {
    final len = (_sr * 2.4).toInt();
    final f2 = r.nextBool() ? 392.0 : 349.0;
    double p1 = 0, p2 = 0;
    for (var j = 0; j < len; j++) {
      final p = h.toInt() + j;
      if (p >= total) break;
      final tt = j / len;
      final env = math.pow(math.sin(math.pi * tt), 1.4).toDouble();
      p1 += 2 * math.pi * 311 / _sr;
      p2 += 2 * math.pi * f2 / _sr;
      x[p] += (0.22 * env * (math.sin(p1) + math.sin(p2) + 0.3 * math.sin(2 * p1))).toDouble();
    }
    h += _sr * (45 + r.nextDouble() * 35);
  }
  return x;
}

Float32List _wind(int total, math.Random r) {
  final x = Float32List(total);
  double a = 0, b = 0, c = 0;
  final g1 = _Drift(r, seconds: 6);
  final g2 = _Drift(r, seconds: 2.5);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    a += (w - a) * 0.02;
    b += (a - b) * 0.05;
    c += (w - c) * 0.15;
    // gusts follow random slow drifts, never a fixed rhythm
    final gust = (0.55 + 0.35 * (g1.next() * 0.5).clamp(-1.0, 1.0) +
            0.15 * (g2.next() * 0.5).clamp(-1.0, 1.0))
        .clamp(0.12, 1.2);
    x[i] = ((b * 14 + c * 0.35) * gust).toDouble();
  }
  return x;
}

Float32List _fire(int total, math.Random r) {
  final x = Float32List(total);
  double rumble = 0, hiss = 0, pop = 0, big = 0, pl = 0, bl = 0;
  final d = _Drift(r, seconds: 15);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    rumble += (w - rumble) * 0.015;
    hiss += (w - hiss) * 0.3;
    final act = 1.0 + 0.5 * (d.next() * 0.5).clamp(-1.0, 1.0);
    if (r.nextDouble() < 0.0012 * act) pop = 0.3 + r.nextDouble() * 0.7;
    if (r.nextDouble() < 0.00008 * act) big = 1.0;
    pop *= 0.993;
    big *= 0.997;
    pl += (_noise(r) - pl) * 0.6;
    bl += (_noise(r) - bl) * 0.35;
    x[i] = (rumble * 7 * act + hiss * 0.06 + pl * pop * 0.8 + bl * big * 1.2).toDouble();
  }
  return x;
}

Float32List _birds(int total, math.Random r) {
  final x = Float32List(total);
  double amb = 0;
  for (var i = 0; i < total; i++) {
    amb += (_noise(r) - amb) * 0.05;
    x[i] = amb * 0.03;
  }
  // a chirp group about every 1.3 seconds, three kinds of birds
  final groups = (total / _sr / 1.3).round();
  for (var g = 0; g < groups; g++) {
    final start = r.nextInt(total - _sr * 2);
    final kind = r.nextInt(3);
    final amp = 0.35 + r.nextDouble() * 0.65;
    if (kind == 1) {
      // trill: many fast equal notes
      final f = 3000 + r.nextDouble() * 1500;
      final cnt = 6 + r.nextInt(6);
      for (var k = 0; k < cnt; k++) {
        final idx = start + (k * _sr * 0.045).toInt();
        final dur = (_sr * 0.03).toInt();
        var ph = 0.0;
        for (var j = 0; j < dur; j++) {
          final p = idx + j;
          if (p >= total) break;
          final env = math.sin(math.pi * j / dur);
          ph += 2 * math.pi * f / _sr;
          x[p] += (amp * 0.6 * env * (1 - k / (cnt * 1.4)) * math.sin(ph)).toDouble();
        }
      }
      continue;
    }
    final notes = kind == 2 ? 2 : 1 + r.nextInt(4);
    final f0 = kind == 2 ? 1800 + r.nextDouble() * 900 : 2400 + r.nextDouble() * 2600;
    final f1 = kind == 2 ? f0 * 1.35 : f0 * (r.nextBool() ? 0.7 : 1.5);
    final dur = (_sr * (kind == 2 ? 0.22 : 0.07 + r.nextDouble() * 0.09)).toInt();
    final gap = (_sr * (0.11 + r.nextDouble() * 0.07)).toInt();
    for (var k = 0; k < notes; k++) {
      final idx = start + k * (dur + gap);
      var phase = 0.0;
      for (var j = 0; j < dur; j++) {
        final p = idx + j;
        if (p >= total) break;
        final t = j / dur;
        final sec = j / _sr;
        var f = f0 + (f1 - f0) * t;
        f *= 1 + 0.03 * math.sin(2 * math.pi * 30 * sec);
        phase += 2 * math.pi * f / _sr;
        final env = math.pow(math.sin(math.pi * t), 1.5).toDouble();
        x[p] += (amp * env * (math.sin(phase) + 0.3 * math.sin(2 * phase))).toDouble();
      }
    }
  }
  return x;
}
