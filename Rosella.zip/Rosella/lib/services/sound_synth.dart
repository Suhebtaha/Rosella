import 'dart:math' as math;
import 'dart:typed_data';

const int _sr = 22050;

/// Length of every sound: 4 minutes, with random events spread over the whole
/// length, so nothing audibly repeats within a normal night's listening.
const int _seconds = 240;

/// Generates a seamless looping WAV (16-bit mono) for the given sound id.
/// Runs inside an isolate via `compute`.
Uint8List synthesizeWav(String id) {
  final n = _sr * _seconds;
  final fade = (_sr * 4).toInt();
  final total = n + fade;
  final rnd = math.Random(id.hashCode ^ 0x5eed);

  Float32List x;
  double gain;
  switch (id) {
    case 'rain':
      x = _rain(total, rnd);
      gain = 0.55;
      break;
    case 'thunder':
      x = _thunder(total, rnd);
      gain = 0.85;
      break;
    case 'wind':
      x = _wind(total, rnd);
      gain = 0.8;
      break;
    case 'fire':
      x = _fire(total, rnd);
      gain = 0.85;
      break;
    default:
      x = _birds(total, rnd);
      gain = 0.7;
  }

  // equal-power crossfade of the tail into the head => seamless loop (in place)
  for (var i = 0; i < fade; i++) {
    final w = i / fade;
    x[i] = x[i] * math.sin(w * math.pi / 2) + x[n + i] * math.cos(w * math.pi / 2);
  }

  var peak = 0.0001;
  for (var i = 0; i < n; i++) {
    final a = x[i].abs();
    if (a > peak) peak = a;
  }
  final scale = gain / peak;

  final bytes = ByteData(44 + n * 2);
  void ws(int off, String s) {
    for (var i = 0; i < s.length; i++) {
      bytes.setUint8(off + i, s.codeUnitAt(i));
    }
  }

  ws(0, 'RIFF');
  bytes.setUint32(4, 36 + n * 2, Endian.little);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  bytes.setUint32(16, 16, Endian.little);
  bytes.setUint16(20, 1, Endian.little);
  bytes.setUint16(22, 1, Endian.little);
  bytes.setUint32(24, _sr, Endian.little);
  bytes.setUint32(28, _sr * 2, Endian.little);
  bytes.setUint16(32, 2, Endian.little);
  bytes.setUint16(34, 16, Endian.little);
  ws(36, 'data');
  bytes.setUint32(40, n * 2, Endian.little);
  for (var i = 0; i < n; i++) {
    final v = math.max(-32768, math.min(32767, (x[i] * scale * 32767).round()));
    bytes.setInt16(44 + i * 2, v, Endian.little);
  }
  return bytes.buffer.asUint8List();
}

double _noise(math.Random r) => r.nextDouble() * 2 - 1;

/// Slow random drift with roughly unit spread (used to vary intensity over minutes).
class _Drift {
  final math.Random r;
  final double a;
  final double norm;
  double v = 0;
  _Drift(this.r, {double seconds = 12})
      : a = 1 / (seconds * _sr),
        norm = 1 / (0.577 * math.sqrt(1 / (2 * seconds * _sr)));
  double next() {
    v += (_noise(r) - v) * a;
    return v * norm;
  }
}

/// Soft rain on a window: a quiet, low hush plus many tiny glass "taps" of
/// random pitch and size, and now and then a bigger, rounder drop.
Float32List _rain(int total, math.Random r) {
  final x = Float32List(total);

  // 1) the hush (band-limited, low, smooth)
  double hi = 0, lo = 0, soft = 0;
  final drift = _Drift(r, seconds: 20);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    hi += (w - hi) * 0.22;
    lo += (w - lo) * 0.025;
    final band = hi - lo;
    soft += (band - soft) * 0.5;
    final inten = 1.0 + 0.55 * (drift.next() * 0.5).clamp(-1.0, 1.0);
    x[i] = soft * 1.2 * inten;
  }

  // 2) drops hitting the glass
  final drift2 = _Drift(r, seconds: 25);
  var i = 0;
  while (i < total) {
    // rate varies slowly: about 25..80 drops per second
    final k = (drift2.next() * 0.5).clamp(-1.0, 1.0);
    final rate = 50 + 30 * k;
    // jump to the next drop (exponential gap)
    final gap = -math.log(1 - r.nextDouble()) / rate * _sr;
    i += gap.round() + 1;
    if (i >= total - 2000) break;
    final big = r.nextDouble() < 0.06;
    final amp = big ? 0.2 + r.nextDouble() * 0.15 : 0.03 + math.pow(r.nextDouble(), 2.2) * 0.2;
    final f0 = big ? 380 + r.nextDouble() * 420 : 1100 + r.nextDouble() * 2400;
    final glide = big ? 1.25 : 0.88 + r.nextDouble() * 0.2;
    final tau = (big ? 0.030 : 0.004 + r.nextDouble() * 0.010) * _sr;
    final len = (tau * 6).toInt();
    var ph = r.nextDouble() * 6.283;
    for (var j = 0; j < len; j++) {
      final p = i + j;
      if (p >= total) break;
      final env = math.exp(-j / tau);
      final f = f0 * (1 + (glide - 1) * (j / len));
      ph += 2 * math.pi * f / _sr;
      final attack = j < 8 ? j / 8 : 1.0;
      x[p] += (amp * env * attack * (math.sin(ph) + 0.25 * math.sin(2.1 * ph))).toDouble();
    }
  }

  // 3) take the edge off the highs
  double lp = 0;
  for (var k = 0; k < total; k++) {
    lp += (x[k] - lp) * 0.55;
    x[k] = lp;
  }
  return x;
}

/// Distant, soft thunder: deep rolling rumbles every 20-50 seconds over a very
/// quiet low bed. No sharp cracks.
Float32List _thunder(int total, math.Random r) {
  final x = Float32List(total);
  double a = 0, b = 0;
  final drift = _Drift(r, seconds: 30);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    a += (w - a) * 0.01;
    b += (a - b) * 0.05;
    x[i] = b * (0.55 + 0.25 * (drift.next() * 0.5).clamp(-1.0, 1.0)) * 6.0;
  }

  var pos = (_sr * (3 + r.nextDouble() * 10)).toInt();
  while (pos < total - _sr * 10) {
    final strength = 0.55 + r.nextDouble() * 0.45;
    final rolls = 3 + r.nextInt(4);
    var off = 0.0;
    for (var k = 0; k < rolls; k++) {
      final att = (0.25 + r.nextDouble() * 0.7) * _sr;
      final dec = (1.6 + r.nextDouble() * 2.6) * _sr;
      final amp = strength * (k == 0 ? 1.0 : 0.35 + r.nextDouble() * 0.5);
      final cut = 0.012 + r.nextDouble() * 0.03;
      final start = pos + (off * _sr).toInt();
      final len = (att * 3 + dec * 4).toInt();
      double l1 = 0, l2 = 0;
      for (var j = 0; j < len; j++) {
        final p = start + j;
        if (p >= total) break;
        final w = _noise(r);
        l1 += (w - l1) * cut;
        l2 += (l1 - l2) * cut * 2.5;
        final env = (1 - math.exp(-j / att * 3)) * math.exp(-j / dec);
        x[p] += (l2 * env * amp * 55).toDouble();
      }
      off += 0.6 + r.nextDouble() * 2.2;
    }
    pos += (_sr * (20 + r.nextDouble() * 30)).toInt();
  }
  return x;
}

Float32List _wind(int total, math.Random r) {
  final x = Float32List(total);
  double a = 0, b = 0, c = 0;
  final g1 = _Drift(r, seconds: 6);
  final g2 = _Drift(r, seconds: 2.5);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    a += (w - a) * 0.02;
    b += (a - b) * 0.05;
    c += (w - c) * 0.15;
    // gusts follow random slow drifts, never a fixed rhythm
    final gust = (0.55 + 0.35 * (g1.next() * 0.5).clamp(-1.0, 1.0) +
            0.15 * (g2.next() * 0.5).clamp(-1.0, 1.0))
        .clamp(0.12, 1.2);
    x[i] = ((b * 14 + c * 0.35) * gust).toDouble();
  }
  return x;
}

Float32List _fire(int total, math.Random r) {
  final x = Float32List(total);
  double rumble = 0, hiss = 0, pop = 0, big = 0, pl = 0, bl = 0;
  final d = _Drift(r, seconds: 15);
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    rumble += (w - rumble) * 0.015;
    hiss += (w - hiss) * 0.3;
    final act = 1.0 + 0.5 * (d.next() * 0.5).clamp(-1.0, 1.0);
    if (r.nextDouble() < 0.0012 * act) pop = 0.3 + r.nextDouble() * 0.7;
    if (r.nextDouble() < 0.00008 * act) big = 1.0;
    pop *= 0.993;
    big *= 0.997;
    pl += (_noise(r) - pl) * 0.6;
    bl += (_noise(r) - bl) * 0.35;
    x[i] = (rumble * 7 * act + hiss * 0.06 + pl * pop * 0.8 + bl * big * 1.2).toDouble();
  }
  return x;
}

Float32List _birds(int total, math.Random r) {
  final x = Float32List(total);
  double amb = 0;
  for (var i = 0; i < total; i++) {
    amb += (_noise(r) - amb) * 0.05;
    x[i] = amb * 0.04;
  }
  // roughly one chirp group every 4 seconds, spread over the whole 4 minutes
  final groups = (total / _sr / 4).round();
  for (var g = 0; g < groups; g++) {
    final start = r.nextInt(total - _sr);
    final notes = 1 + r.nextInt(4);
    final f0 = 2400 + r.nextDouble() * 2600;
    final f1 = f0 * (r.nextBool() ? 0.7 : 1.5);
    final amp = 0.4 + r.nextDouble() * 0.6;
    final dur = (_sr * (0.07 + r.nextDouble() * 0.09)).toInt();
    final gap = (_sr * (0.11 + r.nextDouble() * 0.07)).toInt();
    for (var k = 0; k < notes; k++) {
      final idx = start + k * (dur + gap);
      var phase = 0.0;
      for (var j = 0; j < dur; j++) {
        final p = idx + j;
        if (p >= total) break;
        final t = j / dur;
        final sec = j / _sr;
        var f = f0 + (f1 - f0) * t;
        f *= 1 + 0.03 * math.sin(2 * math.pi * 30 * sec);
        phase += 2 * math.pi * f / _sr;
        final env = math.pow(math.sin(math.pi * t), 1.5).toDouble();
        x[p] += (amp * env * (math.sin(phase) + 0.3 * math.sin(2 * phase))).toDouble();
      }
    }
  }
  return x;
}
