import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Daily local notifications (morning dream reminder + lucid reality checks).
class Notifier {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    if (_ready) return;
    try {
      tzdata.initializeTimeZones();
      await _p.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ));
      _ready = true;
    } catch (_) {}
  }

  /// Asks for the Android 13+ notification permission. true if allowed.
  static Future<bool> requestPermission() async {
    await init();
    try {
      final a = _p.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final ok = await a?.requestNotificationsPermission();
      return ok ?? true;
    } catch (_) {
      return false;
    }
  }

  // Scheduled as an absolute instant (UTC) and repeated daily at that time of day.
  static tz.TZDateTime _next(int h, int m) {
    final now = DateTime.now();
    var t = DateTime(now.year, now.month, now.day, h, m);
    if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
    return tz.TZDateTime.from(t, tz.UTC);
  }

  static Future<void> _daily(
      int id, int h, int m, String title, String body, String channel) async {
    await _p.zonedSchedule(
      id,
      title,
      body,
      _next(h, m),
      NotificationDetails(
        android: AndroidNotificationDetails(
          'rosella_$channel',
          channel == 'morning' ? 'Dream reminder' : 'Lucid reality checks',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> apply({
    required bool morning,
    required int hour,
    required int minute,
    required bool lucid,
    required String morningTitle,
    required String morningBody,
    required String lucidTitle,
    required String lucidBody,
  }) async {
    await init();
    if (!_ready) return;
    try {
      await _p.cancelAll();
      if (morning) {
        await _daily(1, hour, minute, morningTitle, morningBody, 'morning');
      }
      if (lucid) {
        await _daily(11, 11, 0, lucidTitle, lucidBody, 'lucid');
        await _daily(12, 15, 0, lucidTitle, lucidBody, 'lucid');
        await _daily(13, 19, 30, lucidTitle, lucidBody, 'lucid');
      }
    } catch (_) {}
  }
}
