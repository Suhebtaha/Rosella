import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';

/// App-wide tactile feedback.
///
/// Phones differ: some have a real haptic engine, others only a plain vibration
/// motor (and system haptics do nothing). So there are two modes:
///  * system haptics (default) - crisp clicks on phones that have them
///  * vibration motor - short vibration pulses, works on every phone
class Haptics {
  /// 0 off, 1 light, 2 medium, 3 strong
  static int level = 2;

  /// true = drive the vibration motor directly
  static bool motor = false;

  static int _last = 0;
  static bool? _amp;

  static const List<int> _ms = [6, 12, 22, 40];
  static const List<int> _amplitude = [40, 90, 170, 255];

  static void selection() => _fire(0);
  static void light() => _fire(1);
  static void medium() => _fire(2);
  static void heavy() => _fire(3);

  /// Plays a pattern for the settings "test" button, ignoring the debounce.
  static void test() {
    _last = 0;
    _fire(2);
  }

  static void _fire(int kind) {
    if (level <= 0) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _last < 45) return; // several widgets can react to one touch
    _last = now;
    final k = (kind + level - 2).clamp(0, 3);
    if (motor) {
      _buzz(k);
      return;
    }
    switch (k) {
      case 0:
        HapticFeedback.selectionClick();
        break;
      case 1:
        HapticFeedback.lightImpact();
        break;
      case 2:
        HapticFeedback.mediumImpact();
        break;
      default:
        HapticFeedback.heavyImpact();
    }
  }

  static Future<void> _buzz(int k) async {
    try {
      if (!(await Vibration.hasVibrator())) return;
      _amp ??= await Vibration.hasAmplitudeControl();
      if (_amp == true) {
        Vibration.vibrate(duration: _ms[k], amplitude: _amplitude[k]);
      } else {
        Vibration.vibrate(duration: _ms[k] + 6);
      }
    } catch (_) {}
  }
}
