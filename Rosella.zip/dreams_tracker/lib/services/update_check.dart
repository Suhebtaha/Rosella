import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

/// Installed version. Publish GitHub releases with a tag like v1.1.1 (higher than this).
const String kAppVersion = '1.1.1';
const String kReleasesPage = 'https://github.com/Suhebtaha/Rosella/releases/latest';

class UpdateInfo {
  final bool available;
  final String tag;
  final String url;
  final bool failed;
  const UpdateInfo(
      {this.available = false, this.tag = '', this.url = kReleasesPage, this.failed = false});
}

class UpdateCheck {
  static List<int> _parts(String v) {
    final m = RegExp(r'\d+').allMatches(v).map((e) => int.parse(e.group(0)!)).toList();
    while (m.length < 3) {
      m.add(0);
    }
    return m;
  }

  static bool _newer(String a, String b) {
    final x = _parts(a), y = _parts(b);
    for (var i = 0; i < 3; i++) {
      if (x[i] != y[i]) return x[i] > y[i];
    }
    return false;
  }

  static Future<UpdateInfo> check() async {
    try {
      final res = await http
          .get(
            Uri.parse('https://api.github.com/repos/Suhebtaha/Rosella/releases/latest'),
            headers: {'Accept': 'application/vnd.github+json'},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 404) return const UpdateInfo(); // no release yet
      if (res.statusCode != 200) return const UpdateInfo(failed: true);
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final tag = (j['tag_name'] ?? '').toString();
      final url = (j['html_url'] ?? kReleasesPage).toString();
      if (tag.isEmpty) return const UpdateInfo();
      return UpdateInfo(available: _newer(tag, kAppVersion), tag: tag, url: url);
    } catch (_) {
      return const UpdateInfo(failed: true);
    }
  }

  /// Opens the link in the browser / GitHub app. Returns false if nothing could open it.
  static Future<bool> open(String url) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('open', {'url': url}) ??
          false;
    } catch (_) {
      return false;
    }
  }
}
