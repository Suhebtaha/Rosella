import 'dart:async';

import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart' show SpringDescription, SpringSimulation;
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/nav_bus.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'home_page.dart';
import 'insights_page.dart';
import 'quick_voice.dart';
import 'settings_page.dart';
import 'sounds_page.dart';
import '../services/haptics.dart';
import '../services/update_check.dart';
import 'update_dialog.dart';
import 'widgets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  int _tab = 0;
  int _prev = 0;
  final Set<int> _visited = {0};
  late final AnimationController _tc = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 300), value: 1);
  late final Animation<double> _fade =
      CurvedAnimation(parent: _tc, curve: Curves.easeOut);
  Animation<Offset> _slide = const AlwaysStoppedAnimation(Offset.zero);
  Animation<double> _scale = const AlwaysStoppedAnimation(1.0);

  bool _onScroll(ScrollNotification n) {
    if (n.metrics.axis != Axis.vertical || n.depth != 0) return false;
    if (n is ScrollUpdateNotification) {
      final d = n.scrollDelta ?? 0;
      if (n.metrics.pixels < 60) {
        navCollapsed.value = false;
      } else if (d > 3) {
        navCollapsed.value = true;
      } else if (d < -3) {
        navCollapsed.value = false;
      }
    }
    return false;
  }

  void _switchTo(int i) {
    if (i == _tab) return;
    navCollapsed.value = false;
    setState(() {
      _prev = _tab;
      _tab = i;
      _visited.add(i);
    });
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final dir = (_tab >= _prev ? 1.0 : -1.0) * (rtl ? -1.0 : 1.0);
    _slide = Tween<Offset>(begin: Offset(0.05 * dir, 0.012), end: Offset.zero)
        .animate(CurvedAnimation(parent: _tc, curve: Curves.easeOutCubic));
    _scale = Tween<double>(begin: 0.985, end: 1.0)
        .animate(CurvedAnimation(parent: _tc, curve: Curves.easeOutCubic));
    _tc.forward(from: 0);
  }
  StreamSubscription<AchievementDef>? _sub;
  DateTime? _lastRearm;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _sub = app.unlockStream.listen((a) => _onUnlock(app, a));
    WidgetsBinding.instance.addObserver(this);
    tabRequest.addListener(_onTabRequest);
    voiceRequest.addListener(_onVoice);
    UpdateJob.I.addListener(_onUpdateJob);
    UpdateJob.I.resume();
    WidgetsBinding.instance.addPostFrameCallback((_) => _onVoice());
    // build the Insights page quietly once the home page has settled, so the first switch
    // to it is smooth instead of building charts in the middle of the animation
    Future<void>.delayed(const Duration(milliseconds: 2200), () {
      if (mounted && !_visited.contains(1)) setState(() => _visited.add(1));
    });
    Future.delayed(const Duration(seconds: 4), () async {
      if (!mounted) return;
      await app.checkForUpdate();
      // a newer version exists: show the update sheet by itself (unless snoozed)
      if (mounted && app.updateAvailable && !app.updateSnoozed) {
        await Future<void>.delayed(const Duration(milliseconds: 600));
        if (mounted) showUpdateDialog(context, app.updateInfo);
      }
    });
  }

  /// Every time the app is opened again, make sure the daily alarms are scheduled.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      // re-arming the alarms makes ~10 platform calls: do it at most every 30 minutes so
      // coming back to the app stays smooth
      final now = DateTime.now();
      if (_lastRearm == null || now.difference(_lastRearm!).inMinutes >= 30) {
        _lastRearm = now;
        Future<void>.delayed(const Duration(seconds: 2), () {
          if (mounted) context.read<AppState>().applyReminders();
        });
      }
    }
  }

  void _onUpdateJob() {
    if (!mounted) return;
    final j = UpdateJob.I;
    if (j.finishedQuietly) {
      j.acknowledge();
      toast(context, context.t('update_downloaded_sub'));
    }
  }

  void _onVoice() {
    if (!pendingVoice || !mounted) return;
    if (context.read<AppState>().locked) return;
    pendingVoice = false;
    showQuickVoice(context);
  }

  void _onTabRequest() {
    final i = tabRequest.value;
    if (i < 0 || !mounted || i == _tab) return;
    _switchTo(i);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    tabRequest.removeListener(_onTabRequest);
    voiceRequest.removeListener(_onVoice);
    UpdateJob.I.removeListener(_onUpdateJob);
    _sub?.cancel();
    _tc.dispose();
    super.dispose();
  }

  void _onUnlock(AppState app, AchievementDef a) {
    Haptics.medium();
    final pal = AppColors.from(paletteById(app.themeId), app.dark);
    rootMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 120),
        duration: const Duration(seconds: 4),
        content: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: pal.gradient,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [BoxShadow(color: al(pal.a, 0.4), blurRadius: 24)],
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: al(Colors.white, 0.25)),
                child: Icon(a.icon, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(Strings.get(app.lang, 'ach_unlocked'),
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w600)),
                    Text(Strings.get(app.lang, a.titleKey),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ));
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const HomePage();
      case 1:
        return const InsightsPage();
      case 2:
        return const SoundsPage();
      default:
        return const SettingsPage();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final keyboard = MediaQuery.of(context).viewInsets.bottom > 0;
    return Scaffold(
      backgroundColor: c.bg,
      resizeToAvoidBottomInset: false,
      body: NotificationListener<ScrollNotification>(
        onNotification: _onScroll,
        child: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          // pages are built on first visit and then kept alive (no rebuild when switching)
          for (var i = 0; i < 4; i++)
            if (_visited.contains(i))
              Positioned.fill(
                child: Offstage(
                  offstage: i != _tab,
                  child: TickerMode(
                    enabled: i == _tab,
                    child: i == _tab
                        ? FadeTransition(
                            opacity: _fade,
                            child: SlideTransition(
                                position: _slide,
                                child: ScaleTransition(
                                    scale: _scale,
                                    child: RepaintBoundary(child: _page(i)))),
                          )
                        : RepaintBoundary(child: _page(i)),
                  ),
                ),
              ),
          if (!keyboard)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: GlassNavBar(
                index: _tab,
                onTap: _switchTo,
                onMic: () {
                  Haptics.medium();
                  showQuickVoice(context);
                },
                onMicHoldStart: () {
                  Haptics.medium();
                  QuickVoiceSheet.release.value = 0;
                  showQuickVoice(context, hold: true);
                },
                onMicHoldEnd: () => QuickVoiceSheet.release.value++,
              ),
            ),
        ],
      ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon; // filled: the selected tab
  final IconData outline; // outlined: the other tabs
  final String key;
  const _NavItem(this.icon, this.outline, this.key);
}

class GlassNavBar extends StatefulWidget {
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onMic;
  final VoidCallback? onMicHoldStart;
  final VoidCallback? onMicHoldEnd;
  const GlassNavBar(
      {super.key,
      required this.index,
      required this.onTap,
      required this.onMic,
      this.onMicHoldStart,
      this.onMicHoldEnd});

  static const List<_NavItem> items = [
    _NavItem(Icons.nights_stay_rounded, Icons.nights_stay_outlined, 'tab_dreams'),
    _NavItem(Icons.insights_rounded, Icons.insights_outlined, 'tab_insights'),
    _NavItem(Icons.headphones_rounded, Icons.headphones_outlined, 'tab_sounds'),
    _NavItem(Icons.settings_rounded, Icons.settings_outlined, 'tab_settings'),
  ];

  @override
  State<GlassNavBar> createState() => _GlassNavBarState();
}

class _GlassNavBarState extends State<GlassNavBar> with TickerProviderStateMixin {
  // the lens position in "tab units": 0.0 = first tab … 3.0 = last tab
  late final AnimationController _c =
      AnimationController.unbounded(vsync: this, value: widget.index.toDouble());
  static const double _pad = 6;
  static const SpringDescription _spring =
      SpringDescription(mass: 1, stiffness: 150, damping: 17);

  late final AnimationController _col = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 380));
  void _onCollapse() {
    final to = navCollapsed.value ? 1.0 : 0.0;
    _col.animateTo(to, curve: Curves.easeOutCubic);
  }

  final ValueNotifier<int> _target = ValueNotifier<int>(0);

  void _syncTarget() {
    // icons follow the finger only while dragging; a tap or a spring jump never touches the
    // icons in between (they used to flicker as the lens slid over them)
    if (_dragging) _target.value = _c.value.round().clamp(0, 3);
  }

  @override
  void initState() {
    super.initState();
    _target.value = widget.index;
    _c.addListener(_syncTarget);
    navCollapsed.addListener(_onCollapse);
  }

  bool _showLabels = true;
  bool _dragging = false;
  bool _pressed = false;
  bool _rtl = false;
  double _w = 240;
  int _lastTick = 0;

  double _gap = 0; // empty space in the middle of the bar when the mic sits there

  double get _tabW => (_w - _pad * 2 - _gap) / 4;

  double _slot(int i) => _pad + i * _tabW + (i >= 2 ? _gap : 0);

  /// left edge of the lens for a (fractional) tab position
  double _startFor(double p) {
    final i = p.floor().clamp(0, 2);
    final f = p - i;
    return _slot(i) + f * (_slot(i + 1) - _slot(i));
  }

  @override
  void didUpdateWidget(covariant GlassNavBar old) {
    super.didUpdateWidget(old);
    if (old.index != widget.index) {
      // changing tab never re-animates the bar: it snaps back to the full size at once
      _col.value = 0;
    }
    if (old.index != widget.index && !_dragging) _animateTo(widget.index);
  }

  @override
  void dispose() {
    navCollapsed.removeListener(_onCollapse);
    _c.removeListener(_syncTarget);
    _target.dispose();
    _col.dispose();
    _c.dispose();
    super.dispose();
  }

  void _animateTo(int i, {double velocity = 0}) {
    _target.value = i;
    _c.animateWith(SpringSimulation(_spring, _c.value, i.toDouble(), velocity));
  }

  double _posFromX(double x) {
    if (_rtl) x = _w - x;
    final half = _tabW / 2;
    if (x <= _slot(0) + half) return 0;
    if (x >= _slot(3) + half) return 3;
    for (var i = 0; i < 3; i++) {
      final a = _slot(i) + half;
      final b = _slot(i + 1) + half;
      if (x <= b) return i + (x - a) / (b - a);
    }
    return 3;
  }

  void _grab(double x) {
    if (!_dragging) {
      Haptics.light();
      setState(() {
        _dragging = true;
        _pressed = true;
      });
    }
    _c.stop();
    _c.value = _posFromX(x);
    final r = _c.value.round();
    if (r != _lastTick) {
      _lastTick = r;
      Haptics.selection();
    }
  }

  void _release() {
    final t = _c.value.round().clamp(0, 3);
    setState(() {
      _dragging = false;
      _pressed = false;
    });
    _animateTo(t);
    if (t != widget.index) widget.onTap(t);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final bottom = MediaQuery.of(context).padding.bottom;
    _rtl = Directionality.of(context) == TextDirection.rtl;
    final center = context.select<AppState, bool>((s) => s.micCenter);
    _showLabels = context.select<AppState, bool>((s) => s.navLabels);
    _gap = center ? 74 : 0;
    if (center) {
      return Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 10 + bottom),
        child: SizedBox(
          height: 94,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(left: 0, right: 0, bottom: 0, height: 68, child: _bar(c)),
              Positioned(
                  left: 0, right: 0, top: 0, child: Center(child: _MicButton(
                      onTap: widget.onMic,
                      onHoldStart: widget.onMicHoldStart,
                      onHoldEnd: widget.onMicHoldEnd))),
            ],
          ),
        ),
      );
    }
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 10 + bottom),
      child: SizedBox(
        height: 68,
        child: Row(
          children: [
            Expanded(child: _bar(c)),
            const SizedBox(width: 12),
            _MicButton(
                      onTap: widget.onMic,
                      onHoldStart: widget.onMicHoldStart,
                      onHoldEnd: widget.onMicHoldEnd),
          ],
        ),
      ),
    );
  }

  Widget _bar(AppColors c) {
    return AnimatedBuilder(
      animation: _col,
      builder: (context, _) {
        final k = Curves.easeOutCubic.transform(_col.value);
        return Align(
          alignment: Alignment.bottomCenter,
          child: Transform.translate(
            offset: Offset(0, 8 * k),
            child: SizedBox(
              height: 68 - 14 * k,
              child: FractionallySizedBox(
                widthFactor: 1 - 0.28 * k,
                child: _barBody(c, k),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _barBody(AppColors c, double k) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(34),
        boxShadow: [
          BoxShadow(
              color: al(Colors.black, c.isDark ? 0.5 : 0.12),
              blurRadius: 28,
              offset: const Offset(0, 10)),
        ],
      ),
      child: LayoutBuilder(builder: (ctx, cons) {
        _w = cons.maxWidth;
        return Stack(
          // the glass lens may bulge a little past the ends of the bar
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(34),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 26, sigmaY: 26),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: c.isDark
                            ? [al(const Color(0xFF111113), 0.52), al(Colors.black, 0.62)]
                            : [al(Colors.white, 0.8), al(Colors.white, 0.6)],
                      ),
                      borderRadius: BorderRadius.circular(34),
                      border: Border.all(
                          color: c.isDark ? al(Colors.white, 0.14) : al(Colors.black, 0.08),
                          width: 1.1),
                    ),
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapDown: (_) => setState(() => _pressed = true),
                onTapCancel: () => setState(() => _pressed = false),
                onTapUp: (d) {
                  final t = _posFromX(d.localPosition.dx).round().clamp(0, 3);
                  setState(() => _pressed = false);
                  if (t != widget.index) Haptics.selection();
                  _animateTo(t);
                  widget.onTap(t);
                },
                onLongPressStart: (d) => _grab(d.localPosition.dx),
                onLongPressMoveUpdate: (d) => _grab(d.localPosition.dx),
                onLongPressEnd: (_) => _release(),
                onHorizontalDragStart: (d) => _grab(d.localPosition.dx),
                onHorizontalDragUpdate: (d) => _grab(d.localPosition.dx),
                onHorizontalDragEnd: (_) => _release(),
                onHorizontalDragCancel: () {
                  if (_dragging) _release();
                },
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    // the glass lens: only this layer repaints while it slides
                    Positioned.fill(
                      child: AnimatedBuilder(
                        animation: _c,
                        builder: (_, __) {
                          final pos = _c.value;
                          final target = pos.round().clamp(0, 3);
                          final remain = (target - pos).abs().clamp(0.0, 1.0);
                          // liquid feel: it stretches while it travels and settles back
                          final stretch = 1 + 0.34 * remain;
                          final squash = 1 - 0.07 * remain;
                          return Stack(
                            clipBehavior: Clip.none,
                            children: [
                              PositionedDirectional(
                                start: _startFor(pos),
                                top: 7,
                                bottom: 7,
                                width: _tabW,
                                child: TweenAnimationBuilder<double>(
                                  tween: Tween(end: _dragging ? 1.12 : (_pressed ? 1.04 : 1.0)),
                                  duration: const Duration(milliseconds: 420),
                                  curve: Curves.easeOutCubic,
                                  builder: (_, sc, child) => Transform(
                                    alignment: Alignment.center,
                                    transform:
                                        Matrix4.diagonal3Values(sc * stretch, sc * squash, 1),
                                    child: child,
                                  ),
                                  child: _Lens(dragging: _dragging),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                    // the icons never animate with the lens: they only change when the
                    // selected tab changes (or the bar collapses)
                    Positioned.fill(
                      child: AnimatedBuilder(
                        animation: Listenable.merge([_target, _col]),
                        builder: (_, __) {
                          final lab = _showLabels
                              ? 1 - Curves.easeOutCubic.transform(_col.value)
                              : 0.0;
                          return Stack(
                            children: [
                              for (var i = 0; i < 4; i++)
                                PositionedDirectional(
                                  start: _slot(i),
                                  top: 0,
                                  bottom: 0,
                                  width: _tabW,
                                  child: _NavButton(
                                    item: GlassNavBar.items[i],
                                    selected: i == _target.value,
                                    label: lab,
                                  ),
                                ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

/// The sliding transparent glass lens behind the active tab (no colour of its own).
class _Lens extends StatelessWidget {
  final bool dragging;
  const _Lens({required this.dragging});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final base = c.isDark ? Colors.white : Colors.black;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            al(base, dragging ? 0.30 : 0.22),
            al(base, dragging ? 0.12 : 0.08),
          ],
        ),
        border: Border.all(color: al(base, dragging ? 0.38 : 0.24), width: 1.0),
        boxShadow: [
          BoxShadow(
              color: al(Colors.black, c.isDark ? 0.30 : 0.10),
              blurRadius: dragging ? 22 : 12,
              offset: const Offset(0, 5)),
        ],
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final bool selected;
  final double label; // 1 = text visible … 0 = icons only (bar collapsed)
  const _NavButton({required this.item, required this.selected, required this.label});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final color = selected ? c.text : c.dim;
    return IgnorePointer(
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(selected ? item.icon : item.outline, size: 26, color: color),
                if (item.key == 'tab_settings' &&
                    context.select<AppState, bool>((s) => s.updateAvailable))
                  Positioned(
                    right: -2,
                    top: -1,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF3B30),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF101018), width: 1.5),
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 3 * label),
            SizedBox(
              height: 13 * label,
              child: Opacity(
                opacity: label.clamp(0.0, 1.0),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(context.t(item.key),
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: color,
                      )),
                ),
              ),
            ),
          ],
        ),
    );
  }
}

class _MicButton extends StatefulWidget {
  final VoidCallback onTap;
  final VoidCallback? onHoldStart;
  final VoidCallback? onHoldEnd;
  const _MicButton({required this.onTap, this.onHoldStart, this.onHoldEnd});

  @override
  State<_MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<_MicButton> {
  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    // no pulsing glow: a constant blurred shadow repainting every frame is
    // expensive on weak phones, so the shadow is static now
    return RepaintBoundary(
      child: GestureDetector(
        onLongPressStart: (_) => widget.onHoldStart?.call(),
        onLongPressEnd: (_) => widget.onHoldEnd?.call(),
        child: Pressable(
          onTap: widget.onTap,
          scale: 0.9,
          child: Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: c.gradient,
              border: Border.all(color: al(Colors.white, 0.4), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: al(c.a, 0.32),
                  blurRadius: 14,
                  spreadRadius: 0.5,
                ),
              ],
            ),
            child: Icon(Icons.mic_rounded, color: onAccent(c.a, c.b), size: 30),
          ),
        ),
      ),
    );
  }
}
