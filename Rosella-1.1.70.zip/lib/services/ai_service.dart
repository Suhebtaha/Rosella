import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:http/http.dart' as http;

import '../core/models.dart';

class AiResult {
  final String text;
  final bool fromAi;
  final String error; // why the AI could not answer (empty when fromAi)
  const AiResult(this.text, this.fromAi, [this.error = '']);
}

// ------------------------------------------------------------------ offline
class _Sym {
  final List<String> keys;
  final Map<String, String> text;
  const _Sym(this.keys, this.text);
}

const List<_Sym> _syms = [
  _Sym([
    'zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'الموتي الاحياء', 'زۆمبي'
  ], {
    'en':
        'Zombies usually point to exhaustion, burnout, or a feeling that something in your daily life is relentless and draining. Being chased by them suggests you are avoiding a pressure instead of facing it.',
    'ar':
        'الزومبي يرمز غالباً إلى الإرهاق والاحتراق النفسي، أو إلى شعورك بأن أمراً في حياتك اليومية يلاحقك باستمرار ويستنزفك. والهرب منهم يوحي بأنك تتجنب ضغطاً بدل مواجهته.',
    'ckb':
        'زۆمبی زۆرجار هێمای ماندووبوون و سووتانی دەروونییە، یان هەستکردنە بەوەی شتێک لە ژیانی ڕۆژانەتدا بەردەوام دەتگرێت و وزەت دەبات. ڕاکردن لێیان ئاماژەیە بۆ دوورکەوتنەوە لە فشارێک لەجیاتی ڕووبەڕووبوونەوەی.',
  }),
  _Sym([
    'monster', 'ghost', 'demon', 'وحش', 'شبح', 'عفريت', 'دێو', 'تارمايي'
  ], {
    'en':
        'Monsters and ghosts often represent a fear or worry you have not named yet; it tends to shrink once you look at it directly.',
    'ar':
        'الوحوش والأشباح تمثل غالباً خوفاً أو قلقاً لم تسمّه بعد، وغالباً يصغر حجمه حين تنظر إليه بوضوح.',
    'ckb':
        'دێو و تارمایی زۆرجار هێمای ترس یان نیگەرانییەکن کە هێشتا ناویان نەناوە، و کاتێک ڕاستەوخۆ سەیریان دەکەیت بچووک دەبنەوە.',
  }),
  _Sym([
    'water', 'sea', 'ocean', 'river', 'swim', 'drown', 'wave', 'flood',
    'ماء', 'بحر', 'نهر', 'غرق', 'موج', 'سباح', 'فيضان',
    'ئاو', 'دەريا', 'ڕووبار'
  ], {
    'en':
        'Water usually mirrors your emotions. Calm water suggests inner peace, while rough or deep water points to feelings you are still processing.',
    'ar':
        'الماء يعكس عادةً مشاعرك؛ صفاؤه يدل على سكينة داخلية، واضطرابه أو عمقه يشير إلى مشاعر ما زلت تعالجها.',
    'ckb':
        'ئاو زۆرجار ڕەنگدانەوەی هەستەکانتە؛ ئاوی ئارام ئاشتی ناوەوە دەگەیەنێت و ئاوی شەپۆلدار یان قووڵ هەستی تەواونەکراو.',
  }),
  _Sym([
    'fly', 'flying', 'soar', 'plane', 'اطير', 'تحليق', 'طاير', 'فڕين'
  ], {
    'en':
        'Flying often stands for freedom, ambition, or a wish to rise above a problem.',
    'ar':
        'الطيران يرمز غالباً إلى الحرية والطموح أو الرغبة في التسامي فوق مشكلة ما.',
    'ckb':
        'فڕین زۆرجار هێمای ئازادی و ئامانجە یان ئارەزووی بەرزبوونەوە بەسەر کێشەیەکدا.',
  }),
  _Sym([
    'fall', 'falling', 'سقط', 'سقوط', 'وقعت', 'كەوتن', 'كەوتم'
  ], {
    'en':
        'Falling is commonly linked to feeling a loss of control or worry about something slipping away.',
    'ar':
        'السقوط يرتبط عادةً بالشعور بفقدان السيطرة أو القلق من أن شيئاً ما يفلت منك.',
    'ckb':
        'کەوتن زۆرجار بە هەستکردن بە لەدەستدانی کۆنترۆڵ یان نیگەرانی لە ڕۆیشتنی شتێکەوە دەبەسترێتەوە.',
  }),
  _Sym([
    'chase', 'chased', 'run away', 'escape', 'flee', 'هرب', 'يطارد', 'مطارد',
    'لاحق', 'هەڵات', 'ڕاو'
  ], {
    'en':
        'Being chased often means you are avoiding a situation or emotion that needs to be faced.',
    'ar':
        'أن يُطاردك أحد يعني غالباً أنك تتجنب موقفاً أو شعوراً يحتاج إلى مواجهة.',
    'ckb':
        'ڕاوەدوونران زۆرجار مانای دووركەوتنەوەیە لە دۆخ یان هەستێک کە پێویستی بە ڕووبەڕووبوونەوە هەیە.',
  }),
  _Sym(['teeth', 'tooth', 'اسنان', 'سن ', 'ددان'], {
    'en':
        'Teeth dreams tend to connect with stress, self-image, or fear of embarrassment.',
    'ar': 'أحلام الأسنان ترتبط عادةً بالتوتر وصورة الذات والخوف من الإحراج.',
    'ckb':
        'خەونی ددان زۆرجار پەیوەندی بە فشار و وێنەی خود و ترسی شەرمەزاری هەیە.',
  }),
  _Sym(['snake', 'serpent', 'ثعبان', 'افعي', 'حيه', 'مار'], {
    'en':
        "A snake can symbolize a hidden fear, a change, or something you sense but haven't fully noticed yet.",
    'ar':
        'قد ترمز الأفعى إلى خوف مخفي أو تغيير قادم أو أمر تشعر به دون أن تدركه تماماً.',
    'ckb':
        'مار دەکرێت هێمای ترسێکی شاراوە یان گۆڕانکاری یان شتێک بێت کە هەستی پێدەکەیت بەڵام تەواو تێینەگەیشتووی.',
  }),
  _Sym([
    'death', 'dead', 'die', 'funeral', 'موت', 'ميت', 'جنازه', 'مات', 'مردن'
  ], {
    'en':
        'Death in dreams rarely means literal loss — it more often signals an ending and a new beginning.',
    'ar':
        'الموت في الأحلام نادراً ما يعني فقداناً حرفياً، بل يشير غالباً إلى نهاية مرحلة وبداية جديدة.',
    'ckb':
        'مردن لە خەوندا بە ڕێژەیەکی کەم مردنی ڕاستەقینە دەگەیەنێت؛ زیاتر کۆتایی قۆناغێک و دەستپێکێکی نوێیە.',
  }),
  _Sym([
    'exam', 'test', 'late', 'school', 'امتحان', 'اختبار', 'تاخر', 'تاقيكردنەوە'
  ], {
    'en':
        'Exams or being late reflect pressure to perform and fear of being judged or unprepared.',
    'ar':
        'الامتحان أو التأخر يعكس ضغط الأداء والخوف من التقييم أو عدم الاستعداد.',
    'ckb':
        'تاقیکردنەوە یان دواکەوتن فشاری ئەنجامدان و ترسی هەڵسەنگاندن یان ئامادەنەبوون ڕەنگدەداتەوە.',
  }),
  _Sym(['house', 'room', 'بيت', 'منزل', 'غرفه', 'ماڵ', 'ژوور'], {
    'en':
        'A house usually mirrors your inner self; different rooms stand for different parts of your life, and hidden or unfamiliar rooms suggest unexplored parts of you.',
    'ar':
        'البيت يعكس غالباً ذاتك الداخلية؛ فالغرف المختلفة تمثل جوانب من حياتك، والغرف الغريبة أو المخفية تشير إلى جوانب لم تستكشفها بعد.',
    'ckb':
        'ماڵ زۆرجار ڕەنگدانەوەی ناخی خۆتە؛ ژوورە جیاوازەکان بەشەکانی ژیانت دەنوێنن، و ژووری نەناسراو یان شاراوە ئاماژەیە بۆ لایەنێکی نەدۆزراوەی خۆت.',
  }),
  _Sym(['baby', 'pregnan', 'طفل', 'رضيع', 'حامل', 'منداڵ', 'مناڵ'], {
    'en':
        'Babies and pregnancy often symbolize new beginnings, a new idea, or something fragile you want to protect and grow.',
    'ar':
        'الأطفال والحمل يرمزان غالباً إلى بدايات جديدة أو فكرة جديدة أو شيء هش تريد حمايته ورعايته.',
    'ckb':
        'منداڵ و سکپڕی زۆرجار هێمای دەستپێکێکی نوێ یان بیرۆکەیەکی نوێ یان شتێکی ناسکن کە دەتەوێت بیپارێزیت و گەشەی پێبدەیت.',
  }),
  _Sym(['money', 'gold', 'rich', 'فلوس', 'نقود', 'ذهب', 'پارە', 'زێڕ'], {
    'en':
        'Money or gold in dreams usually relates to self-worth, security, or how valued you feel.',
    'ar':
        'المال أو الذهب في الأحلام يرتبط غالباً بقيمة الذات والأمان وبمدى شعورك بالتقدير.',
    'ckb':
        'پارە یان زێڕ لە خەوندا زۆرجار پەیوەندی بە بەهای خود و ئاسایش و ئەو هەستەوە هەیە کە چەند بەهادار دەزانیت خۆت.',
  }),
  _Sym(['car', 'driving', 'train', 'سياره', 'قطار', 'سفر', 'ئۆتۆمبێل', 'گەشت'], {
    'en':
        'Vehicles and journeys reflect the direction of your life and how much control you feel you have over it.',
    'ar': 'المركبات والرحلات تعكس اتجاه حياتك ومقدار تحكمك فيها.',
    'ckb':
        'ئۆتۆمبێل و گەشت ڕەنگدانەوەی ئاراستەی ژیانتن و ئەوەی چەند کۆنترۆڵت بەسەریدا هەیە.',
  }),
  _Sym(['fire', 'burn', 'نار', 'حريق', 'ئاگر'], {
    'en':
        'Fire can mean strong passion or anger, or a need for deep change and cleansing.',
    'ar': 'النار قد تعني شغفاً أو غضباً قوياً، أو حاجة إلى تغيير عميق وتطهير.',
    'ckb':
        'ئاگر دەکرێت مانای خولیا یان توڕەیی بەهێز بێت، یان پێویستی بە گۆڕانکاری قووڵ و پاکبوونەوە.',
  }),
  _Sym(['war', 'gun', 'shoot', 'weapon', 'حرب', 'سلاح', 'رصاص', 'جەنگ', 'چەک'], {
    'en':
        'War or weapons usually reflect an inner conflict or a feeling of being under pressure or attack.',
    'ar': 'الحرب أو السلاح تعكس غالباً صراعاً داخلياً أو شعوراً بالضغط أو التهديد.',
    'ckb':
        'جەنگ یان چەک زۆرجار ڕەنگدانەوەی ململانێی ناوەوە یان هەستکردنە بە فشار و مەترسی.',
  }),
  _Sym(['dog', 'cat', 'كلب', 'قطه', 'سەگ', 'پشيلە'], {
    'en':
        'Animals often stand for instincts; dogs relate to loyalty and friendship, cats to independence and intuition.',
    'ar':
        'الحيوانات ترمز غالباً إلى الغرائز؛ فالكلب يرتبط بالوفاء والصداقة والقطة بالاستقلال والحدس.',
    'ckb':
        'ئاژەڵ زۆرجار هێمای غەریزەیە؛ سەگ پەیوەندی بە دڵسۆزی و دۆستایەتییەوە هەیە و پشیلە بە سەربەخۆیی و هەستی ناوەکی.',
  }),
  _Sym(['lost', 'maze', 'تهت', 'ضعت', 'ضايع', 'تايه'], {
    'en':
        'Feeling lost suggests uncertainty about a direction or decision in your waking life.',
    'ar': 'الشعور بالضياع يوحي بحيرة تجاه اتجاه أو قرار في حياتك اليقظة.',
    'ckb':
        'هەستکردن بە ون بوون ئاماژەیە بۆ دوودڵی لەبارەی ئاراستە یان بڕیارێک لە ژیانی ڕۆژانەتدا.',
  }),
];

const Map<String, String> _intro = {
  'en': "Here's a gentle reflection on your dream:",
  'ar': 'هذه قراءة هادئة لحلمك:',
  'ckb': 'ئەمە خوێندنەوەیەکی ئارامە بۆ خەونەکەت:',
};

const Map<String, String> _generic = {
  'en':
      "Dreams often blend the day's thoughts, memories and feelings. Notice which feeling stood out most — it is usually the real message of the dream.",
  'ar':
      'الأحلام غالباً تمزج أفكار اليوم وذكرياته ومشاعره. انتبه إلى الشعور الأبرز فيها، فهو عادةً الرسالة الحقيقية للحلم.',
  'ckb':
      'خەونەکان زۆرجار بیرکردنەوە و بیرەوەری و هەستی ڕۆژ تێکەڵ دەکەن. سەرنج بدە کام هەست زیاتر دیار بوو؛ ئەوە زۆرجار پەیامی ڕاستەقینەی خەونەکەیە.',
};

const Map<String, List<String>> _moodNote = {
  'en': [
    'You woke up with heavy feelings, so be kind to yourself today — talking it through with someone you trust can lighten it.',
    'A calm mood suggests this dream was more about processing the day than sending a strong message.',
    'You woke up feeling good — the dream likely carries encouraging energy you can take into your day.',
  ],
  'ar': [
    'استيقظت بمشاعر ثقيلة، فكن لطيفاً مع نفسك اليوم، والحديث مع شخص تثق به قد يخفف عنك.',
    'المزاج الهادئ يوحي بأن الحلم كان لمعالجة أحداث اليوم أكثر منه رسالة قوية.',
    'استيقظت بشعور جيد، وغالباً يحمل الحلم طاقة مشجعة يمكنك أخذها معك في يومك.',
  ],
  'ckb': [
    'بە هەستی قورس هەستایت، ئەمڕۆ میهرەبان بە لەگەڵ خۆت؛ قسەکردن لەگەڵ کەسێکی متمانەپێکراو دەتوانێت سووکی بکات.',
    'دۆخی ئارام ئاماژەیە بۆ ئەوەی خەونەکە زیاتر بۆ پڕۆسێسکردنی ڕۆژ بووە نەک پەیامێکی بەهێز.',
    'بە هەستێکی باش هەستایت؛ خەونەکە ئەگەر وزەیەکی هاندەر هەڵگرتبێت دەتوانیت لە ڕۆژەکەتدا بەکاری بهێنیت.',
  ],
};

// -------------------------------------------------- offline image vocabulary
class _Vis {
  final List<String> keys;
  final String en;
  const _Vis(this.keys, this.en);
}

const List<_Vis> _vis = [
  _Vis(['zombie', 'undead', 'زومبي', 'زمبي', 'موتي احياء', 'زۆمبي'],
      'a horde of zombies'),
  _Vis(['monster', 'وحش', 'دێو'], 'a giant monster'),
  _Vis(['ghost', 'شبح', 'تارمايي'], 'a pale ghost'),
  _Vis(['demon', 'عفريت', 'شيطان'], 'a dark demon'),
  _Vis(['snake', 'ثعبان', 'افعي', 'حيه', 'مار'], 'a large snake'),
  _Vis(['dog', 'كلب', 'سەگ'], 'a dog'),
  _Vis(['cat', 'قطه', 'پشيلە'], 'a cat'),
  _Vis(['bird', 'طير', 'طيور', 'باڵندە'], 'birds'),
  _Vis(['horse', 'حصان', 'ئەسپ'], 'a horse'),
  _Vis(['lion', 'اسد', 'شير', 'شێر'], 'a lion'),
  _Vis(['wolf', 'ذئب', 'گورگ'], 'a wolf'),
  _Vis(['spider', 'عنكبوت', 'جالەجاڵ'], 'a giant spider'),
  _Vis(['fish', 'سمك', 'ماسي'], 'fish'),
  _Vis(['sea', 'ocean', 'بحر', 'دەريا'], 'a vast sea'),
  _Vis(['river', 'نهر', 'ڕووبار'], 'a river'),
  _Vis(['rain', 'مطر', 'باران'], 'heavy rain'),
  _Vis(['flood', 'فيضان', 'لافاو'], 'a flood'),
  _Vis(['mountain', 'جبل', 'چيا'], 'tall mountains'),
  _Vis(['forest', 'غابه', 'دارستان'], 'a dark forest'),
  _Vis(['tree', 'شجره', 'شجر', 'دار '], 'a big tree'),
  _Vis(['desert', 'صحراء', 'بيابان'], 'a desert'),
  _Vis(['city', 'مدينه', 'شار'], 'a city'),
  _Vis(['house', 'بيت', 'منزل', 'ماڵ'], 'an old house'),
  _Vis(['school', 'مدرسه', 'قوتابخانە'], 'a school'),
  _Vis(['car', 'سياره', 'ئۆتۆمبێل'], 'a car'),
  _Vis(['train', 'قطار', 'شەمەندەفەر'], 'a train'),
  _Vis(['plane', 'airplane', 'طايره', 'طائره', 'فڕۆکە'], 'an airplane'),
  _Vis(['fly', 'flying', 'اطير', 'تحليق', 'فڕين'], 'a person flying in the sky'),
  _Vis(['moon', 'قمر', 'هلال', 'مانگ'], 'the moon'),
  _Vis(['star', 'نجوم', 'نجمه', 'ئەستێرە'], 'a sky full of stars'),
  _Vis(['sun', 'شمس', 'خۆر'], 'the sun'),
  _Vis(['fire', 'نار', 'حريق', 'ئاگر'], 'fire and flames'),
  _Vis(['snow', 'ثلج', 'بەفر'], 'snow'),
  _Vis(['war', 'حرب', 'جەنگ'], 'a battlefield'),
  _Vis(['gun', 'سلاح', 'چەک'], 'a gun'),
  _Vis(['baby', 'طفل', 'رضيع', 'منداڵ'], 'a baby'),
  _Vis(['mother', 'امي', 'والده', 'دايك'], 'a mother'),
  _Vis(['father', 'ابي', 'والدي', 'باوک'], 'a father'),
  _Vis(['wedding', 'عرس', 'زفاف', 'زەماوەند'], 'a wedding'),
  _Vis(['king', 'ملك', 'پاشا'], 'a king'),
  _Vis(['flower', 'ورد', 'زهور', 'گوڵ'], 'flowers'),
  _Vis(['bridge', 'جسر', 'پردێک', 'پرد'], 'a long bridge'),
  _Vis(['door', 'باب', 'دەرگا'], 'a mysterious door'),
  _Vis(['mirror', 'مرايه', 'ئاوێنە'], 'a mirror'),
  _Vis(['cave', 'كهف', 'ئەشکەوت'], 'a cave'),
  _Vis(['storm', 'عاصفه', 'ڕەشەبا'], 'a storm'),
  _Vis(['school', 'teacher', 'معلم', 'مامۆستا'], 'a classroom'),
  _Vis(['dead', 'death', 'ميت', 'موت', 'مردن'], 'a graveyard at night'),
];

// ------------------------------------------------------------------ service
class AiService {
  static const String _textUrl = 'https://text.pollinations.ai/';
  static const String _imgUrl = 'https://image.pollinations.ai/prompt/';

  /// tried in order: stronger model first, then the default one
  static const List<String> _models = ['openai', 'openai-large', 'openai-fast', 'mistral'];

  static const List<String> _moodNames = [
    '', 'nightmare', 'sad', 'neutral', 'good', 'amazing'
  ];

  static String _langName(String lang) => switch (lang) {
        'ar' => 'clear, natural Modern Standard Arabic',
        'ckb' => 'Central Kurdish (Sorani) in Kurdish Arabic script',
        'es' => 'natural, clear Spanish',
        'ko' => 'natural, polite Korean (Hangul)',
        _ => _extraNames[lang] == null ? 'English' : 'natural, clear ${_extraNames[lang]}',
      };

  /// English names of the languages added later (used in prompts).
  static const Map<String, String> _extraNames = {
    'ru': 'Russian', 'fr': 'French', 'de': 'German', 'ja': 'Japanese',
    'pt': 'Brazilian Portuguese', 'no': 'Norwegian (Bokmål)', 'sv': 'Swedish',
    'da': 'Danish', 'fa': 'Persian (Farsi)', 'ro': 'Romanian', 'el': 'Greek', 'hy': 'Armenian', 'az': 'Azerbaijani (Latin script)',
    'zh': 'Simplified Chinese',
    'it': 'Italian', 'tr': 'Turkish', 'et': 'Estonian', 'sr': 'Serbian (Cyrillic)',
    'uk': 'Ukrainian',
  };
  static const Set<String> _latinExtra = {'fr', 'de', 'pt', 'no', 'sv', 'da', 'it', 'tr', 'et'};

  // ---------- text helpers
  static String _norm(String s) {
    var t = s.toLowerCase();
    t = t.replaceAll(RegExp(r'[ً-ٰٟـ]'), '');
    t = t
        .replaceAll(RegExp('[أإآٱ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ی', 'ي')
        .replaceAll('ة', 'ه')
        .replaceAll('ک', 'ك');
    return t;
  }

  static int _find(String text, String key) {
    if (key.isEmpty) return -1;
    if (RegExp(r'^[a-z0-9 ]+$').hasMatch(key)) {
      final m = RegExp(r'\b' + RegExp.escape(key.trim())).firstMatch(text);
      return m?.start ?? -1;
    }
    return text.indexOf(key);
  }

  static String _clean(String s) {
    var t = s.trim();
    t = t.replaceAll(
        RegExp(r'\n*-{3,}\s*\n.*pollinations.*$',
            dotAll: true, caseSensitive: false),
        '');
    t = t
        .split('\n')
        .where((l) => !l.toLowerCase().contains('pollinations'))
        .join('\n');
    t = t.replaceAll('**', '').replaceAll('__', '');
    t = t.replaceAll(RegExp(r'^#+\s*', multiLine: true), '');
    t = t.replaceAll(RegExp(r'^\s*[-*•]\s+', multiLine: true), '');
    t = t.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return t.trim();
  }

  /// The language the dream itself is written in (so an Arabic dream gets an Arabic
  /// answer even when the app UI is English). Falls back to [fallback] when unsure.
  static String dreamLang(String text, String fallback) {
    final arabic = RegExp(r'[؀-ۿݐ-ݿ]').allMatches(text).length;
    final hangul = RegExp(r'[가-힣ᄀ-ᇿ㄰-㆏]').allMatches(text).length;
    final latin = RegExp(r'[A-Za-zÀ-ÿ]').allMatches(text).length;
    if (_extraNames.containsKey(fallback)) {
      // the app is set to one of the later languages: trust it when the script fits
      final cyr = RegExp(r'[Ѐ-ӿ]').allMatches(text).length;
      final kana = RegExp(r'[぀-ヿ一-鿿]').allMatches(text).length;
      final greek = RegExp(r'[Ͱ-Ͽ]').allMatches(text).length;
      final arm = RegExp(r'[԰-֏]').allMatches(text).length;
      final total = arabic + latin + hangul + cyr + kana + greek + arm;
      if (total >= 3) {
        if (cyr > total / 2) return const {'ru', 'uk', 'sr'}.contains(fallback) ? fallback : 'ru';
        if (kana > total / 2) return fallback == 'zh' ? 'zh' : 'ja';
        if (greek > total / 2) return 'el';
        if (arm > total / 2) return 'hy';
        if (kana > total / 2 && fallback == 'zh') return 'zh';
        if (arabic > total / 2) return fallback == 'fa' ? 'fa' : 'ar';
        if (hangul > total / 2) return 'ko';
        if (latin > total / 2 && _latinExtra.contains(fallback)) return fallback;
      }
    }
    if (arabic + latin + hangul < 3) return fallback;
    // whichever script dominates decides, whatever the app language is
    if (hangul >= arabic && hangul >= latin) return 'ko';
    if (arabic > latin) {
      // letters that exist only in Kurdish (not Arabic) => Sorani
      return RegExp(r'[ەێۆڕڵڤ]').allMatches(text).length >= 2 ? 'ckb' : 'ar';
    }
    // Latin script: Spanish vs English
    final t = ' ${text.toLowerCase()} ';
    final esMarks = RegExp(r'[ñáéíóú¿¡]').allMatches(t).length;
    final esWords = RegExp(
            r'\b(el|la|los|las|un|una|que|de|en|y|con|por|para|mi|me|fue|estaba|soñé|sueño|era|como|pero|muy|había|yo|su|se|del|al)\b')
        .allMatches(t)
        .length;
    final enWords = RegExp(
            r'\b(the|and|was|were|i|in|of|to|a|my|me|it|with|that|had|dream|dreamt|dreamed|then|but|this|were|on|for)\b')
        .allMatches(t)
        .length;
    if (esMarks + esWords > enWords) return 'es';
    return 'en';
  }

  static bool _validText(String t, String lang) {
    if (t.trim().length < 40) return false;
    final letters = RegExp(r'\p{L}', unicode: true).allMatches(t).length;
    if (letters == 0) return false;
    final arabic = RegExp(r'[؀-ۿݐ-ݿ]').allMatches(t).length;
    final latin = RegExp(r'[A-Za-zÀ-ÿ]').allMatches(t).length;
    if (lang == 'ko') {
      final h = RegExp(r'[가-힣]').allMatches(t).length;
      return h / letters > 0.5;
    }
    if (lang == 'en' || lang == 'es') return latin / letters > 0.8;
    if (_extraNames.containsKey(lang)) return true;
    if (arabic / letters < 0.75) return false;
    if (lang == 'ckb') {
      return RegExp(r'[ەێۆڕڵڤ]').allMatches(t).length >= 4;
    }
    return true;
  }

  // ---------- network
  /// Optional Google Gemini key (free from aistudio.google.com/apikey). When set it
  /// is tried first because it is far more reliable than the free anonymous endpoints.
  // one shared client => the TLS connection is reused (much faster after the first call)
  static final http.Client _client = http.Client();

  static final List<String> _trace = [];

  /// Per-attempt report (provider, result, seconds) for diagnosing slowness.
  static String get trace => _trace.join('\n');

  static String _secs(Stopwatch sw) => '${(sw.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';

  static String geminiKey = '';

  /// Key baked in at build time (--dart-define=GEMINI_KEY=...), used for everyone.
  static const String _builtInKey = String.fromEnvironment('GEMINI_KEY');
  static bool get hasBuiltIn => _builtInKey.isNotEmpty;

  // Identifies this app to Google so the key can be restricted to it.
  static const Map<String, String> _androidId = {
    'X-Android-Package': 'com.suhaib.rosella',
    'X-Android-Cert': 'C583A6CD590F56A454218ACE412EF433D00A0E04',
  };

  /// Last failure reason, shown to the user so problems can be diagnosed.
  static String lastError = '';

  static const List<String> _geminiModels = [
    'gemini-2.5-flash-lite', // fastest
    'gemini-flash-latest',
    'gemini-2.5-flash',
  ];

  // ---- model discovery: ask Google which models THIS key can use right now
  static final Map<String, List<List<String>>> _modelCache = {};

  static double _rank(String name, {bool image = false}) {
    final n = name.toLowerCase();
    var r = image
        ? (n.contains('pro') ? 1.0 : 0.0)
        : (n.contains('flash-lite') ? 0.0 : (n.contains('flash') ? 1.0 : 3.0));
    if (n.contains('preview')) r += 0.5;
    if (n.contains('latest')) r += 0.2;
    final v = RegExp(r'(\d+(?:\.\d+)?)').firstMatch(n);
    final ver = v == null ? 0.0 : (double.tryParse(v.group(1)!) ?? 0.0);
    return r - ver * 0.01; // newer first inside the same tier
  }

  /// models that answered 429/404 recently: skipped for a while (free keys have no quota for "pro")
  static final Map<String, DateTime> _badModels = {};
  static void _markBad(String m) => _badModels[m] = DateTime.now();
  static bool _isBad(String m) {
    final t = _badModels[m];
    return t != null && DateTime.now().difference(t).inMinutes < 20;
  }

  /// Text models for a call. [strong] (Kurdish, audio): fast flash models first, "pro" only
  /// as a late fallback, flash-lite last.
  static Future<List<String>> _textModels(String key, bool builtIn, bool strong) async {
    final d = await _discover(key, builtIn);
    var list = <String>[];
    if (!strong) {
      list = List<String>.of(d[0]);
    } else {
      final all = List<String>.of(d.length > 2 ? d[2] : d[0]);
      bool lite(String n) => n.toLowerCase().contains('lite');
      bool pro(String n) => n.toLowerCase().contains('pro');
      all.sort((a, b) => _rank(a).compareTo(_rank(b)));
      final flash = all.where((n) => !lite(n) && !pro(n)).take(2).toList();
      final pros = all.where(pro).take(1).toList();
      final lites = all.where(lite).take(1).toList();
      list = [...flash, ...pros, ...lites];
    }
    final ok = list.where((m) => !_isBad(m)).toList();
    return ok.isEmpty ? list : ok;
  }

  /// [text models, image models, all text models], best first.
  static Future<List<List<String>>> _discover(String key, bool builtIn) async {
    final cached = _modelCache[key];
    if (cached != null) return cached;
    try {
      final res = await _client
          .get(
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=$key'),
            headers: {if (builtIn) ..._androidId},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) throw Exception('list ${res.statusCode}');
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final text = <String>[];
      final image = <String>[];
      for (final m in (j['models'] as List? ?? const [])) {
        final mm = m as Map;
        final name = (mm['name'] ?? '').toString().replaceFirst('models/', '');
        final methods =
            (mm['supportedGenerationMethods'] as List? ?? const []).map((e) => '$e').toList();
        if (!name.startsWith('gemini') || !methods.contains('generateContent')) continue;
        final n = name.toLowerCase();
        if (n.contains('image')) {
          image.add(name);
          continue;
        }
        const skip = ['tts', 'audio', 'live', 'embedding', 'robotics', 'computer', 'thinking', 'exp'];
        if (skip.any((w) => n.contains(w))) continue;
        text.add(name);
      }
      text.sort((a, b) => _rank(a).compareTo(_rank(b)));
      image.sort((a, b) => _rank(a, image: true).compareTo(_rank(b, image: true)));
      final out = [text.take(3).toList(), image.take(3).toList(), List<String>.of(text)];
      if (text.isNotEmpty) _modelCache[key] = out;
      if (text.isEmpty) throw Exception('no models');
      return out;
    } catch (_) {
      return [_geminiModels, const ['gemini-2.5-flash-image'], _geminiModels];
    }
  }

  static bool get geminiAvailable => geminiKey.trim().isNotEmpty || _builtInKey.isNotEmpty;

  static String _apiMsg(String body) {
    try {
      final j = jsonDecode(body) as Map<String, dynamic>;
      final m = (j['error'] as Map)['message'] as String;
      return m.length > 80 ? m.substring(0, 80) : m;
    } catch (_) {
      return '';
    }
  }

  static String _cleanErr(Object e) {
    final m = e.toString().replaceAll('Exception: ', '').replaceAll('\n', ' ');
    return m.length > 90 ? m.substring(0, 90) : m;
  }

  static Future<String> _gemini(
      List<Map<String, String>> messages, int seconds, String key, bool builtIn,
      [bool strong = false]) async {
    final system = messages
        .where((m) => m['role'] == 'system')
        .map((m) => m['content']!)
        .join('\n');
    final contents = [
      for (final m in messages.where((m) => m['role'] != 'system'))
        {
          'role': m['role'] == 'assistant' ? 'model' : 'user',
          'parts': [
            {'text': m['content']}
          ],
        }
    ];
    Object? last;
    final textModels = await _textModels(key, builtIn, strong);
    for (final model in textModels) {
      try {
        final res = await _client
            .post(
              Uri.parse(
                  'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key'),
              headers: {
                'Content-Type': 'application/json',
                if (builtIn) ..._androidId,
              },
              body: jsonEncode({
                if (system.isNotEmpty)
                  'systemInstruction': {
                    'parts': [
                      {'text': system}
                    ]
                  },
                'contents': contents,
                'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 800},
              }),
            )
            .timeout(Duration(seconds: seconds));
        if (res.statusCode != 200) {
          final msg = _apiMsg(utf8.decode(res.bodyBytes, allowMalformed: true));
          last = 'gemini $model ${res.statusCode} $msg';
          if (res.statusCode == 429 || res.statusCode == 404) _markBad(model);
          final keyBad = msg.contains('API key') || msg.contains('API_KEY');
          if (res.statusCode == 403 || keyBad) {
            // bad key / blocked by restrictions: other models will fail the same way
            throw Exception(last);
          }
          continue;
        }
        final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
        final parts = (((j['candidates'] as List).first as Map)['content']
            as Map)['parts'] as List;
        final text = parts.map((p) => (p as Map)['text'] ?? '').join();
        if (text.trim().isEmpty) throw Exception('gemini empty');
        lastInfo = '$model';
        return _clean(text);
      } on TimeoutException {
        last = 'gemini timeout';
      }
    }
    throw Exception('${last ?? 'gemini failed'}');
  }

  /// provider/model and time of the last successful call (shown to the user)
  static String lastInfo = '';

  static bool _pollDown = false; // free endpoint failed this session: skip it

  /// Gemini with server-sent events: text arrives word by word via [onPartial].
  static Future<String> _geminiStream(List<Map<String, String>> messages, int seconds,
      String key, bool builtIn, void Function(String) onPartial,
      [bool strong = false]) async {
    final system = messages
        .where((m) => m['role'] == 'system')
        .map((m) => m['content']!)
        .join('\n');
    final contents = [
      for (final m in messages.where((m) => m['role'] != 'system'))
        {
          'role': m['role'] == 'assistant' ? 'model' : 'user',
          'parts': [
            {'text': m['content']}
          ],
        }
    ];
    Object? last;
    final textModels = await _textModels(key, builtIn, strong);
    for (final model in textModels) {
      final client = _client;
      final sw = Stopwatch()..start();
      var firstMs = -1;
      try {
        final req = http.Request(
            'POST',
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=$key'));
        req.headers['Content-Type'] = 'application/json';
        if (builtIn) req.headers.addAll(_androidId);
        req.body = jsonEncode({
          if (system.isNotEmpty)
            'systemInstruction': {
              'parts': [
                {'text': system}
              ]
            },
          'contents': contents,
          'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 800},
        });
        final resp = await client.send(req).timeout(Duration(seconds: seconds));
        if (resp.statusCode != 200) {
          final body = await resp.stream.bytesToString();
          final msg = _apiMsg(body);
          last = 'gemini $model ${resp.statusCode} $msg';
          if (resp.statusCode == 429 || resp.statusCode == 404) _markBad(model);
          final keyBad = msg.contains('API key') || msg.contains('API_KEY');
          if (resp.statusCode == 403 || keyBad) throw Exception(last);
          continue;
        }
        var acc = '';
        await for (final line in resp.stream
            .transform(utf8.decoder)
            .transform(const LineSplitter())
            .timeout(Duration(seconds: seconds))) {
          if (!line.startsWith('data:')) continue;
          final data = line.substring(5).trim();
          if (data.isEmpty) continue;
          try {
            final j = jsonDecode(data) as Map<String, dynamic>;
            final cands = j['candidates'] as List? ?? const [];
            if (cands.isEmpty) continue;
            final parts = ((cands.first as Map)['content'] as Map?)?['parts'] as List? ?? const [];
            for (final p in parts) {
              acc += ((p as Map)['text'] ?? '').toString();
            }
            if (firstMs < 0) firstMs = sw.elapsedMilliseconds;
            onPartial(_clean(acc));
          } catch (_) {}
        }
        if (acc.trim().isEmpty) {
          last = 'gemini empty';
          continue;
        }
        lastInfo =
            '$model • first ${(firstMs / 1000).toStringAsFixed(1)}s • total ${_secs(sw)}';
        return _clean(acc);
      } on TimeoutException {
        last = 'gemini timeout';
      }
    }
    throw Exception('${last ?? 'gemini failed'}');
  }

  static Future<String> _pollinations(
      List<Map<String, String>> messages, String model, int seconds) async {
    // 1) legacy plain-text endpoint
    try {
      final res = await _client
          .post(
            Uri.parse(_textUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'model': model,
              'private': true,
              'seed': math.Random().nextInt(1 << 30),
              'messages': messages,
            }),
          )
          .timeout(Duration(seconds: seconds));
      if (res.statusCode != 200) throw Exception('pollinations ${res.statusCode}');
      final body = utf8.decode(res.bodyBytes).trim();
      if (body.isEmpty) throw Exception('pollinations empty');
      if (body.startsWith('{')) {
        final j = jsonDecode(body);
        final ch = j is Map ? j['choices'] : null;
        if (ch is List && ch.isNotEmpty) {
          return _clean(((ch.first as Map)['message'] as Map)['content'] as String);
        }
        throw Exception('pollinations api error');
      }
      return _clean(body);
    } catch (e) {
      // 2) OpenAI-compatible endpoint of the same service
      final res = await _client
          .post(
            Uri.parse('https://text.pollinations.ai/openai'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'model': model, 'messages': messages}),
          )
          .timeout(Duration(seconds: seconds));
      if (res.statusCode != 200) {
        throw Exception('${_cleanErr(e)} / openai ${res.statusCode}');
      }
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final text = (((j['choices'] as List).first as Map)['message'] as Map)['content']
          as String;
      if (text.trim().isEmpty) throw Exception('pollinations empty');
      return _clean(text);
    }
  }

  /// One completion. Gemini first (if a key is set), then the free endpoints.
  static Future<String> _complete(List<Map<String, String>> messages,
      {int seconds = 30, void Function(String)? onPartial, bool strong = false}) async {
    _trace.clear();
    final errors = <String>[];
    final own = geminiKey.trim();
    for (final k in [own, _builtInKey]) {
      if (k.isEmpty) continue;
      final builtIn = k == _builtInKey && own != k;
      final label = builtIn ? 'Gemini (built-in key)' : 'Gemini (your key)';
      final sw = Stopwatch()..start();
      try {
        final out = onPartial != null
            ? await _geminiStream(messages, seconds, k, builtIn, onPartial, strong)
            : await _gemini(messages, seconds, k, builtIn, strong);
        _trace.add('$label: OK ${_secs(sw)}');
        return out;
      } catch (e) {
        _trace.add('$label: FAILED ${_secs(sw)} - ${_cleanErr(e)}');
        errors.add(_cleanErr(e));
      }
    }
    final fallbackModels = geminiAvailable ? _models.take(1) : _models;
    for (final model in fallbackModels) {
      if (_pollDown) {
        _trace.add('Pollinations: skipped (failed earlier this session)');
        break;
      }
      final sw = Stopwatch()..start();
      try {
        final out = await _pollinations(messages, model, geminiAvailable ? 15 : seconds);
        lastInfo = 'pollinations/$model • ${_secs(sw)}';
        _trace.add('Pollinations/$model: OK ${_secs(sw)}');
        onPartial?.call(out);
        return out;
      } catch (e) {
        _trace.add('Pollinations/$model: FAILED ${_secs(sw)} - ${_cleanErr(e)}');
        errors.add(_cleanErr(e));
        if (e is TimeoutException) _pollDown = true;
      }
    }
    lastError = errors.isEmpty ? 'unknown' : errors.take(3).join(' | ');
    throw Exception(lastError);
  }

  /// Tiny request used by the "test AI" button: returns a readable report.
  static Future<String> selfTest() async {
    final sw = Stopwatch()..start();
    _pollDown = false;
    try {
      await _complete([
        {'role': 'user', 'content': 'Reply with exactly one word: ok'}
      ], seconds: 20, onPartial: (_) {});
      final k = geminiKey.trim().isNotEmpty ? geminiKey.trim() : _builtInKey;
      final d = k.isEmpty ? <List<String>>[[], []] : await _discover(k, k == _builtInKey && geminiKey.trim().isEmpty);
      return 'OK in ${_secs(sw)}\n$trace\n\nText models: ${d[0]}\nImage models: ${d[1]}';
    } catch (e) {
      return 'FAILED after ${_secs(sw)}\n$trace';
    }
  }

  /// Short written recap of the given dreams (the caller leaves private ones out).
  static Future<String> recap(List<Dream> ds, int days, String lang) async {
    final ln = _langName(lang);
    String two(int n) => n.toString().padLeft(2, '0');
    final b = StringBuffer();
    for (final d in ds.take(40)) {
      final c = d.content.trim();
      b.writeln('- ${d.createdAt.year}-${two(d.createdAt.month)}-${two(d.createdAt.day)}'
          ' | mood ${d.mood}/5${d.lucid ? ' | lucid' : ''}'
          ' | ${d.title.trim()} | ${c.length > 400 ? c.substring(0, 400) : c}');
    }
    final sys = 'You are a warm, perceptive dream-journal analyst. Write the whole answer in $ln. '
        'Never give medical or religious claims; this is gentle reflection only.${_kuExtra(ln)}';
    final user = 'These are my dreams from the last $days days:\n$b\n'
        'Write a short recap (about 150 to 200 words, plain text, no markdown symbols): '
        '1) the main themes and recurring symbols, 2) how my mood moved, '
        '3) one gentle observation, 4) one small suggestion for the coming days.';
    final out = await _fastGemini(sys, user);
    return out.trim();
  }

  /// Search the journal by meaning: "dreams where I felt chased" finds the dreams about
  /// being chased even when those words are not in the text. Returns dream ids, best first.
  static Future<List<String>> semanticSearch(
      List<Dream> ds, String query, String lang) async {
    final pool = ds.where((d) => !d.priv).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final cand = pool.take(250).toList();
    if (cand.isEmpty) return const [];
    final b = StringBuffer();
    for (var i = 0; i < cand.length; i++) {
      final c = cand[i].content.trim().replaceAll(RegExp(r'\s+'), ' ');
      b.writeln('[$i] ${cand[i].title.trim()} | ${c.length > 170 ? c.substring(0, 170) : c}');
    }
    const sys = 'You are the search engine of a dream journal. The dreams and the query may be '
        'in Arabic, Kurdish, English, Spanish or Korean, in any mix. Match by meaning, theme, '
        'feeling, people, places and symbols, not only by exact words. '
        'Answer ONLY with a JSON array of dream numbers, most relevant first, at most 15. '
        'Include only dreams that really match. If none match, answer [].';
    final user = 'Query: ${query.trim()}\n\nDreams:\n$b';
    final out = await _fastGemini(sys, user);
    final m = RegExp(r'\[[^\]]*\]').firstMatch(out);
    if (m == null) return const [];
    final ids = <String>[];
    for (final x in RegExp(r'\d+').allMatches(m.group(0)!)) {
      final i = int.tryParse(x.group(0)!);
      if (i != null && i >= 0 && i < cand.length && !ids.contains(cand[i].id)) {
        ids.add(cand[i].id);
      }
    }
    return ids;
  }

  /// Warm written reflection for the yearly summary, built from the numbers and a sample
  /// of the year's dreams.
  static Future<String> yearReflection({
    required int year,
    required List<Dream> ds,
    required String stats,
    required String lang,
  }) async {
    final ln = _langName(lang);
    final sorted = [...ds]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
    // spread the sample over the whole year instead of taking only the first dreams
    final step = math.max(1, (sorted.length / 45).ceil());
    final b = StringBuffer();
    for (var i = 0; i < sorted.length; i += step) {
      final d = sorted[i];
      final c = d.content.trim().replaceAll(RegExp(r'\s+'), ' ');
      b.writeln('- ${d.createdAt.month}/${d.createdAt.day} | mood ${d.mood}/5'
          '${d.lucid ? ' | lucid' : ''} | ${d.title.trim()} | ${c.length > 220 ? c.substring(0, 220) : c}');
    }
    final sys = 'You are a warm, perceptive dream-journal writer. Write the whole answer in $ln. '
        'Never give medical or religious claims; this is gentle reflection only.${_kuExtra(ln)}';
    final user = 'My dream journal for $year.\nNumbers: $stats\nSample of my dreams:\n$b\n'
        'Write my "year in dreams" in about 170 to 230 words, plain text, no markdown symbols, '
        'speaking to me directly ("you"): the main themes and recurring symbols of the year, '
        'how my feelings moved, one surprising or beautiful pattern, and a short kind closing '
        'line for the year ahead.';
    final out = await _fastGemini(sys, user);
    return out.trim();
  }

  /// Quick Gemini call for long-ish answers: flash models first, thinking off,
  /// a short timeout per model and a roomy output limit.
  static Future<String> _fastGemini(String system, String user) async {
    final keys = [geminiKey.trim(), _builtInKey].where((k) => k.isNotEmpty).toList();
    final errs = <String>[];
    for (final k in keys) {
      final builtIn = k == _builtInKey && geminiKey.trim() != k;
      final models = (await _textModels(k, builtIn, false)).take(3);
      for (final model in models) {
        try {
          Future<http.Response> send(bool think) => _client
              .post(
                Uri.parse(
                    'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$k'),
                headers: {
                  'Content-Type': 'application/json',
                  if (builtIn) ..._androidId,
                },
                body: jsonEncode({
                  'systemInstruction': {
                    'parts': [
                      {'text': system}
                    ]
                  },
                  'contents': [
                    {
                      'role': 'user',
                      'parts': [
                        {'text': user}
                      ]
                    }
                  ],
                  'generationConfig': {
                    'temperature': 0.7,
                    'maxOutputTokens': 2000,
                    if (think) ..._noThinking(model),
                  },
                }),
              )
              .timeout(const Duration(seconds: 25));
          var res = await send(true);
          if (res.statusCode == 400) res = await send(false);
          if (res.statusCode != 200) {
            errs.add('$model ${res.statusCode}');
            if (res.statusCode == 429 || res.statusCode == 404) _markBad(model);
            if (res.statusCode == 403) break;
            continue;
          }
          final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
          final cands = j['candidates'] as List? ?? const [];
          if (cands.isEmpty) {
            errs.add('$model empty');
            continue;
          }
          final parts =
              ((cands.first as Map)['content'] as Map?)?['parts'] as List? ?? const [];
          final text = parts.map((p) => (p as Map)['text'] ?? '').join().trim();
          if (text.isEmpty) {
            errs.add('$model empty');
            continue;
          }
          return _clean(text);
        } catch (e) {
          errs.add('$model ${_cleanErr(e)}');
        }
      }
    }
    lastError = errs.join(' | ');
    throw Exception(lastError);
  }

  static Future<String> _chat(String system, String user,
      {String? model, int seconds = 30, void Function(String)? onPartial, bool strong = false}) {
    return _complete([
      {'role': 'system', 'content': system},
      {'role': 'user', 'content': user},
    ], seconds: seconds, onPartial: onPartial, strong: strong);
  }

  /// Extra rules whenever the answer must be Kurdish: models are weak at Sorani unless told.
  static const String _kuRules =
      '\nKurdish writing rules (very important): write natural, simple, spoken Central Kurdish '
      '(Sorani) like an educated native speaker from Sulaymaniyah or Erbil. Use SHORT, clear sentences. '
      'Use correct Sorani spelling and verb forms (e.g. دەکەم، دەکەیت، دەکات، هەست دەکەیت، بوو، هەیە، '
      'نییە، ئەگەر، چونکە، بەڵام). Use Sorani words (خەون، هەست، ترس، ژیان، ئارام، نیگەرانی، '
      'ماندووبوون) and do NOT use Arabic, Persian or Kurmanji words or grammar when a Sorani word '
      'exists. Do not translate word by word from Arabic or English. Write ی/ە/ێ/ۆ/ڕ/ڵ/ڤ correctly. '
      'Re-read the answer once and make sure every sentence is grammatical Sorani.';

  /// Added to the system prompt when the person taps "write it again".
  static String _redoNote(String? prev) {
    if (prev == null || prev.trim().isEmpty) return '';
    final p = prev.trim();
    return '\n\nThe person asked you to write your answer again. Your previous answer was between <<< and >>>:\n<<<'
        '${p.length > 700 ? p.substring(0, 700) : p}>>>\n'
        'Give a clearly different answer to the same question: new wording, a different structure '
        'and a fresh angle or example. Do not copy sentences from the previous answer. '
        'Keep the facts correct and the same language.';
  }

  static String _kuExtra(String langName) => langName.contains('Kurdish') ? _kuRules : '';

  static String _askSystem(String langName, String title, String content, int mood,
          String? interpretation) =>
      'You are a warm, insightful dream-interpretation assistant inside a dream journal app. '
      'The user is asking follow-up questions about THIS dream only.\n'
      'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
      'Dream: $content\n'
      '${interpretation == null ? '' : 'Interpretation already given: $interpretation\n'}'
      'Rules: answer the question directly in 30 to 70 words, plain text only (no markdown, '
      'no lists, no emojis). Use psychology and gentle symbolism. Never predict the future, '
      'never give medical or religious rulings, never be frightening, do not invent details '
      'that are not in the dream. Write the whole answer in $langName.${_kuExtra(langName)}';

  /// Follow-up question about a dream. [history] = alternating {role, content}.
  /// Returns null if the AI could not answer.
  static Future<String?> ask({
    required String title,
    required String content,
    required int mood,
    required String? interpretation,
    required String lang,
    required List<Map<String, String>> history,
    required String question,
    void Function(String)? onPartial,
    String? redo,
  }) async {
    lang = await resolveLang('$title $content $question', lang);
    final past = history.length > 8 ? history.sublist(history.length - 8) : history;
    final sysLang = lang == 'ckb' ? 'English' : _langName(lang);
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        if (lang == 'ckb' && geminiAvailable && attempt == 0) {
          final direct = await _complete([
            {
              'role': 'system',
              'content': _askSystem(_langName('ckb'), title, content, mood, interpretation) + _redoNote(redo)
            },
            ...past,
            {'role': 'user', 'content': question},
          ], onPartial: onPartial, seconds: 25);
          if (_validText(direct, 'ckb')) return direct;
        }
        final out = await _complete([
          {
            'role': 'system',
            'content': _askSystem(sysLang, title, content, mood, interpretation) + _redoNote(redo)
          },
          ...past,
          {'role': 'user', 'content': question},
        ], onPartial: lang == 'ckb' ? null : onPartial);
        if (lang == 'ckb') {
          if (!_validText(out, 'en')) throw Exception('bad en');
          final ku = await _chat(_soraniSystem, out, seconds: 45, strong: true);
          if (_validText(ku, 'ckb')) return ku;
          lastError = 'sorani check failed';
        } else if (_validText(out, lang)) {
          return out;
        } else {
          lastError = 'reply language check failed';
        }
      } catch (_) {}
    }
    return null;
  }

  // ---------- general chat (not about dreams)
  static String _generalSystem(String langName) =>
      'You are a helpful, friendly and knowledgeable assistant inside a personal app. '
      'Answer any everyday question clearly and honestly. Keep answers short (under 150 words) '
      'unless the person clearly needs more detail. Plain text only: no markdown, no asterisks, '
      'no headings; short numbered steps are fine when needed. If you are not sure, say so. '
      'For medical, legal or financial questions give general information and suggest a professional. '
      'Write the whole answer in $langName.${_kuExtra(langName)}';

  /// Language of the text: letters first, then (for Arabic script) the model decides
  /// between Arabic and Kurdish by meaning, since Kurdish is often typed with plain Arabic letters.
  static Future<String> resolveLang(String text, String app, {String extra = ''}) async {
    var lang = dreamLang(text, app);
    if (lang == 'ar' && app == 'ckb' && RegExp(r'[ەێۆڕڵڤ]').hasMatch(text)) lang = 'ckb';
    if (lang == 'ar' && geminiAvailable) {
      if (await _looksKurdish('$extra\n$text'.trim(), app == 'ckb')) lang = 'ckb';
    }
    return lang;
  }

  /// true when Arabic-script text is really Central Kurdish (Sorani), judged by the model.
  static Future<bool> _looksKurdish(String text, bool kurdishApp) async {
    try {
      final r = await _fastGemini(
        'You identify the language of short chat messages written in Arabic script. '
        'Two candidates: Arabic (any dialect, including Iraqi) or Central Kurdish (Sorani). '
        'Kurdish is often typed WITHOUT its special letters, using plain Arabic letters '
        '(ي for ێ, ه for ە, و for ۆ, ك for ک, ر for ڕ, ل for ڵ), so judge by vocabulary and '
        'grammar, not letters. Kurdish clues: slaw/سلاو, چۆنی/چونی, باشم, زۆر/زور, ئەتۆ, '
        'دەکەم/دەكەم, نییە/نيه, ترساوم/ترسناكم, ئەمڕۆ, خەون/خةون, کوي/كوي, ببینم. '
        '${kurdishApp ? 'The app interface is Kurdish, so when unsure answer KU. ' : ''}'
        'Answer with exactly one word: KU or AR.',
        text,
      ).timeout(const Duration(seconds: 8));
      return r.toUpperCase().contains('KU');
    } catch (_) {
      return false;
    }
  }

  /// Lenient check for chat replies: short answers are fine, only the script must match.
  static bool _okChat(String t, String lang) {
    t = t.trim();
    if (t.length < 2) return false;
    final letters = RegExp(r'\p{L}', unicode: true).allMatches(t).length;
    if (letters == 0) return false;
    final arabic = RegExp(r'[؀-ۿݐ-ݿ]').allMatches(t).length;
    if (lang == 'ckb') return arabic / letters >= 0.6;
    if (letters < 25) return true;
    final latin = RegExp(r'[A-Za-zÀ-ÿ]').allMatches(t).length;
    if (lang == 'en' || lang == 'es') return latin / letters > 0.6;
    if (lang == 'ar') return arabic / letters > 0.6;
    return true;
  }

  /// Open conversation with the AI. Returns null if no answer could be produced.
  static Future<String?> general({
    required String lang,
    required List<Map<String, String>> history,
    required String question,
    void Function(String)? onPartial,
    String? redo,
  }) async {
    final lastUser = history.where((m) => m['role'] == 'user').toList();
    lang = await resolveLang(question, lang,
        extra: lastUser.isEmpty ? '' : (lastUser.last['content'] ?? ''));
    final past = history.length > 10 ? history.sublist(history.length - 10) : history;
    String? best; // any usable text, returned instead of failing
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        if (lang == 'ckb') {
          if (attempt == 0 && geminiAvailable) {
            final direct = await _complete([
              {'role': 'system', 'content': _generalSystem(_langName('ckb')) + _redoNote(redo)},
              ...past,
              {'role': 'user', 'content': question},
            ], onPartial: onPartial, strong: true, seconds: 30);
            if (_okChat(direct, 'ckb')) return direct.trim();
            if (direct.trim().isNotEmpty) best ??= direct.trim();
          }
          final en = await _complete([
            {'role': 'system', 'content': _generalSystem('English') + _redoNote(redo)},
            ...past,
            {'role': 'user', 'content': question},
          ]);
          if (en.trim().isEmpty) throw Exception('empty');
          final ku = await _chat(_soraniSystem, en, seconds: 40, strong: true);
          if (_okChat(ku, 'ckb')) return ku.trim();
          best ??= en.trim();
          lastError = 'sorani check failed';
        } else {
          final out = await _complete([
            {'role': 'system', 'content': _generalSystem(_langName(lang)) + _redoNote(redo)},
            ...past,
            {'role': 'user', 'content': question},
          ], onPartial: onPartial);
          if (_okChat(out, lang)) return out.trim();
          if (out.trim().isNotEmpty) best ??= out.trim();
          lastError = 'reply language check failed';
        }
      } catch (e) {
        lastError = '$e';
      }
    }
    return best;
  }

  // ---------- interpretation
  static String _interpretSystem(String langName) =>
      'You are a thoughtful dream interpreter who combines psychology (emotions, stress, '
      'daily-life themes, Jungian and Freudian ideas) with gentle cultural symbolism.\n'
      'Interpret THIS specific dream. First name the real elements of the dream '
      '(creatures, people, places, actions, feelings) and explain what each most plausibly '
      'symbolizes. Example: zombies usually represent exhaustion, burnout, or something '
      'relentless and draining in daily life; being chased by them suggests avoiding a pressure. '
      'Then connect the dream to the mood the person woke up with. End with one practical, kind '
      'suggestion.\n'
      'Rules: 90 to 130 words. Plain text only: no markdown, no bullet points, no headings, '
      'no emojis. Never predict the future, never give medical or religious rulings, never be '
      'frightening. Do not invent details that are not in the dream. If the dream is very short, '
      'interpret what is there.\n'
      'Write the whole answer in $langName.${_kuExtra(langName)}';

  static const String _soraniSystem =
      'You are a professional translator into Central Kurdish (Sorani), written in the Kurdish '
      'Arabic script (for example: ئەم، ئەو، دەکات، خەون، ڕێگا، هەست). Translate the user\'s text '
      'faithfully into natural, fluent Sorani. Use Sorani-specific letters such as ە ێ ۆ ڕ ڵ ڤ. '
      'Never answer in Arabic, Persian or Kurmanji. Output only the translation, nothing else.';

  static Future<AiResult> interpret({
    required String title,
    required String content,
    required String lang,
    required int mood,
    void Function(String)? onPartial,
  }) async {
    lang = await resolveLang('$title $content', lang);
    final user =
        'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\n'
        'Dream (may be written in Arabic, Kurdish or English):\n$content';

    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        String out;
        if (lang == 'ckb' && geminiAvailable && attempt == 0) {
          // Gemini writes decent Sorani directly: one call instead of two (faster)
          final direct =
              await _chat(_interpretSystem(_langName('ckb')), user,
                  onPartial: onPartial, strong: true, seconds: 40);
          if (_validText(direct, 'ckb')) return AiResult(direct, true);
          lastError = 'sorani direct check failed';
        }
        if (lang == 'ckb') {
          // write the interpretation in English, then translate to Sorani:
          // models are much more reliable at translating than at writing Sorani
          final en = await _chat(_interpretSystem('English'), user);
          if (!_validText(en, 'en')) throw Exception('bad en');
          out = await _chat(_soraniSystem, en, seconds: 45, strong: true);
        } else {
          out = await _chat(_interpretSystem(_langName(lang)), user, onPartial: onPartial);
        }
        if (_validText(out, lang)) return AiResult(out, true);
        lastError = 'reply language check failed';
      } catch (_) {}
    }
    return AiResult(_local(title, content, lang, mood), false, lastError);
  }

  /// true when the offline dictionary recognised at least one symbol in the dream.
  static bool localHasMatch(String title, String content) {
    final text = _norm('$title $content');
    for (final s in _syms) {
      for (final k in s.keys) {
        if (_find(text, _norm(k)) >= 0) return true;
      }
    }
    return false;
  }

  static String _local(String title, String content, String lang, int mood) {
    final l = _intro.containsKey(lang) ? lang : 'en';
    final text = _norm('$title $content');
    final hits = <MapEntry<int, String>>[];
    for (final s in _syms) {
      var best = -1;
      for (final k in s.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0) hits.add(MapEntry(best, s.text[l]!));
    }
    hits.sort((a, b) => a.key.compareTo(b.key));
    final matched = hits.take(3).map((e) => e.value).toList();
    final notes = _moodNote[l]!;
    final note = mood <= 2 ? notes[0] : (mood == 3 ? notes[1] : notes[2]);
    final body = matched.isEmpty ? _generic[l]! : matched.join('\n\n');
    return '${_intro[l]}\n\n$body\n\n$note';
  }

  // ---------- image
  static const String _style =
      'surreal dreamlike digital painting, cinematic lighting, highly detailed';

  static String? _visualFromDictionary(String title, String content) {
    final text = _norm('$title $content');
    final found = <MapEntry<int, String>>[];
    final seen = <String>{};
    for (final v in _vis) {
      var best = -1;
      for (final k in v.keys) {
        final i = _find(text, _norm(k));
        if (i >= 0 && (best < 0 || i < best)) best = i;
      }
      if (best >= 0 && seen.add(v.en)) found.add(MapEntry(best, v.en));
    }
    if (found.isEmpty) return null;
    found.sort((a, b) => a.key.compareTo(b.key));
    return found.take(4).map((e) => e.value).join(', ');
  }

  static Future<String?> _imagePrompt(String title, String content) async {
    final src = '$title. $content'.trim();
    const system =
        'You turn dream descriptions (written in Arabic, Kurdish or English) into an English '
        'image-generation prompt. Output ONE line, at most 40 words. Start with the main '
        'subjects exactly as described in the dream, translated faithfully (for example '
        'زومبي = zombies, بحر = sea), then the setting, mood and lighting. Never add subjects or '
        'objects that are not in the dream. Never include nudity, sexual content or gore: if the '
        'dream has any, depict it only symbolically, fully clothed and non-explicit. '
        'No quotes, no explanation.';
    try {
      final p = await _chat(system, 'Dream: $src', seconds: 25);
      final firstLine = p.split('\n').first.trim();
      final hasArabic = RegExp(r'[؀-ۿ]').hasMatch(firstLine);
      if (!hasArabic && firstLine.length >= 8 && firstLine.length <= 500) {
        return firstLine;
      }
    } catch (_) {}
    final fromDict = _visualFromDictionary(title, content);
    if (fromDict != null) return fromDict;
    final ascii = RegExp(r'^[\x00-\x7F]+$');
    final short = src.length > 200 ? src.substring(0, 200) : src;
    if (short.isNotEmpty && ascii.hasMatch(short)) return short;
    return null; // never draw an unrelated generic scene
  }

  static bool _imgBlocked = false;

  /// Words (English, Arabic, Kurdish, Spanish, Korean) that must never be drawn.
  static final RegExp _adult = RegExp(
      r'nude|naked|nudity|topless|porn|nsfw|erotic|sexual|sex\b|genital|breast|boob|penis|vagina|'
      r'rape|عار[يى]|عاري|عراة|اباح|إباح|جنسي|الجنس|ممارسة|ممارسه|مؤخر|ثدي|اغتصاب|'
      r'ڕووت|رووت|سێکس|سیکس|پۆڕن|'
      r'desnud|porno|sexo|erótic|erotic|'
      r'나체|누드|포르노|성관계|야한',
      caseSensitive: false);

  static const String _safeTail =
      ', fully clothed, wholesome, family-friendly, non-sexual, no nudity';

  static void _imgFail(String m) {
    lastError = m;
    _trace.add(m);
  }

  /// Turns the model's "thinking" off (a transcript does not need it) so replies come faster.
  static Map<String, dynamic> _noThinking(String model) {
    final n = model.toLowerCase();
    if (n.contains('pro')) return const {};
    if (n.contains('2.5')) {
      return {
        'thinkingConfig': {'thinkingBudget': 0}
      };
    }
    if (n.contains('gemini-3')) {
      return {
        'thinkingConfig': {'thinkingLevel': 'minimal'}
      };
    }
    return const {};
  }

  /// Speech → text: Whisper (fast) then Gemini (Kurdish and fallback). Returns null on failure
  /// (see [lastError]).
  static Future<String?> transcribe(String path, String lang, {String appLang = 'ar'}) async {
    if (lang == 'auto') return _transcribeAuto(path, appLang);
    // Fast path: Whisper large-v3-turbo on Cloudflare (a few seconds, free tier).
    // Kurdish is not a Whisper language, so it goes straight to Gemini.
    if (lang != 'ckb' && _cfAcc.isNotEmpty && _cfTok.isNotEmpty) {
      final t = await _cfWhisper(path, lang);
      if (t != null) return t;
    }
    // Kurdish (Sorani): kurdishtts.com only. No Gemini: it answers in other languages.
    if (lang == 'ckb') {
      if (_kurdishKey.isEmpty) {
        lastError = 'kurdish: no key in this build';
        return null;
      }
      return _kurdishStt(path);
    }
    return _geminiTranscribe(path, lang);
  }

  static const String _kurdishKey = String.fromEnvironment('KURDISH_KEY');

  static Future<String?> _kurdishStt(String path) async {
    try {
      final req = http.MultipartRequest(
          'POST', Uri.parse('https://www.kurdishtts.com/api/stt-proxy'))
        ..headers['x-api-key'] = _kurdishKey
        ..fields['dialect'] = 'sorani';
      req.files.add(await http.MultipartFile.fromPath('file', path));
      final res = await http.Response.fromStream(
          await _client.send(req).timeout(const Duration(seconds: 40)));
      if (res.statusCode != 200) {
        lastError = 'kurdish ${res.statusCode}';
        return null;
      }
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final text = (j['text'] as String?)?.trim();
      if (text == null) {
        lastError = 'kurdish no text';
        return null;
      }
      return text; // '' when nobody spoke
    } catch (e) {
      lastError = 'kurdish ${_cleanErr(e)}';
      return null;
    }
  }

  static Future<String?> _cfWhisper(String path, String lang) async =>
      (await _cfWhisperRaw(path, lang))?.text;

  /// Whisper result with the language it detected (when Cloudflare reports it).
  static Future<_Heard?> _cfWhisperRaw(String path, String? lang) async {
    try {
      final bytes = await File(path).readAsBytes();
      final res = await _client
          .post(
            Uri.parse('https://api.cloudflare.com/client/v4/accounts/$_cfAcc'
                '/ai/run/@cf/openai/whisper-large-v3-turbo'),
            headers: {
              'Authorization': 'Bearer $_cfTok',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'audio': base64Encode(bytes),
              if (lang == 'ar' || lang == 'es' || lang == 'ko' || lang == 'en' || _extraNames.containsKey(lang))
                'language': lang,
            }),
          )
          .timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        lastError = 'whisper ${res.statusCode}';
        return null;
      }
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final r = j['result'] as Map?;
      final text = (r?['text'] as String?)?.trim();
      if (text == null) return null;
      final info = r?['transcription_info'] as Map?;
      final l = (info?['language'] as String?)?.toLowerCase();
      final pr = (info?['language_probability'] as num?)?.toDouble();
      return _Heard(text, l, pr);
    } catch (e) {
      lastError = 'whisper ${_cleanErr(e)}';
      return null;
    }
  }

  static final RegExp _soraniLetters = RegExp(r'[ەڕێۆڵڤ]');

  /// Works whatever the app language is: Whisper listens and names the language.
  /// A confident English / Spanish / Korean / Arabic result is used right away;
  /// anything else is treated as Kurdish and goes to the Kurdish engine.
  static Future<String?> _transcribeAuto(String path, String appLang) async {
    final kurdish = _kurdishKey.isEmpty ? null : _kurdishStt(path); // starts now
    final hasWhisper = _cfAcc.isNotEmpty && _cfTok.isNotEmpty;
    _Heard? w;
    if (hasWhisper) w = await _cfWhisperRaw(path, null);
    if (w != null) {
      final l = w.lang;
      final sure = (w.prob ?? 0) >= 0.85;
      if (l == null) {
        // Cloudflare did not report a language: keep the old behaviour
        if (appLang != 'ckb') return w.text;
      } else if (l == 'en' || l == 'es' || l == 'ko' || l == appLang || (l == 'ar' && sure)) {
        return w.text;
      }
    }
    // not one of the known languages (or Whisper failed): Kurdish
    if (kurdish != null) {
      final k = await kurdish;
      if (k != null && (k.isEmpty || _soraniLetters.allMatches(k).length >= 2)) return k;
      if (w != null && k == null) return w.text;
      if (k != null) return k;
    }
    if (w != null) return w.text;
    return _geminiTranscribe(path, appLang == 'ckb' ? 'ar' : appLang);
  }

  static Future<String?> _geminiTranscribe(String path, String lang) async {
    final keys = [geminiKey.trim(), _builtInKey].where((k) => k.isNotEmpty).toList();
    if (keys.isEmpty) {
      lastError = 'no Gemini key';
      return null;
    }
    final bytes = await File(path).readAsBytes();
    final primary = switch (lang) {
      'ar' => 'Arabic (Iraqi dialect)',
      'ckb' => 'Kurdish Sorani',
      'es' => 'Spanish',
      'ko' => 'Korean',
      _ => _extraNames[lang] ?? 'English',
    };
    final prompt = 'Transcribe this audio exactly as spoken, word for word. '
        'Detect the spoken language automatically (Arabic, Kurdish Sorani, English, Spanish or Korean; the phone is set to $primary but the speaker may use any of them and may mix them): '
        'keep every word in the language it was spoken, never translate. '
        'Write Arabic in Arabic script. Write Kurdish Sorani in correct Sorani spelling with the Kurdish Arabic script '
        '(use ە ێ ۆ ڕ ڵ ڤ properly, e.g. دەکەم، هەست، خەون، ئەو، نییە، بوو، لە، بە; never write Kurdish words with Arabic spellings). '
        'Listen carefully to Kurdish words and spell them as a native Sorani writer would. '
        'English and Spanish in Latin letters, Korean in Hangul. Add normal punctuation. '
        'Output ONLY the transcript, no notes. If there is no speech, output nothing.';
    final b64 = base64Encode(bytes);
    final errs = <String>[];
    for (final k in keys) {
      final builtIn = k == _builtInKey && geminiKey.trim() != k;
      final models = await _textModels(k, builtIn, true);
      for (final model in models) {
        try {
          Future<http.Response> send(bool think) => _client
              .post(
                Uri.parse(
                    'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$k'),
                headers: {
                  'Content-Type': 'application/json',
                  if (builtIn) ..._androidId,
                },
                body: jsonEncode({
                  'contents': [
                    {
                      'parts': [
                        {'text': prompt},
                        {
                          'inline_data': {'mime_type': 'audio/mp4', 'data': b64}
                        },
                      ]
                    }
                  ],
                  'generationConfig': {
                    'temperature': 0,
                    'maxOutputTokens': 4000,
                    if (think) ..._noThinking(model),
                  },
                }),
              )
              .timeout(const Duration(seconds: 45));
          // thinking off = much faster; if the model rejects the setting, retry plain
          var res = await send(true);
          if (res.statusCode == 400) res = await send(false);
          if (res.statusCode != 200) {
            errs.add('$model ${res.statusCode}');
            lastError = 'transcribe: ${errs.join(' | ')}';
            if (res.statusCode == 429 || res.statusCode == 404) _markBad(model);
            if (res.statusCode == 403) break; // key blocked: next key
            continue; // 404/429/400 on this model: try the next one
          }
          final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
          final cands = j['candidates'] as List? ?? const [];
          if (cands.isEmpty) {
            lastError = 'transcribe $model: empty';
            continue;
          }
          final parts = ((cands.first as Map)['content'] as Map?)?['parts'] as List? ?? const [];
          final text = parts.map((p) => (p as Map)['text'] ?? '').join().trim();
          return text; // may be '' when nobody spoke
        } catch (e) {
          errs.add('$model ${_cleanErr(e)}');
          lastError = 'transcribe: ${errs.join(' | ')}';
        }
      }
    }
    return null;
  }

  /// Image through Gemini (nano-banana). Returns true when a file was written.
  static Future<bool> _geminiImage(String prompt, String savePath) async {
    final keys = [geminiKey.trim(), _builtInKey].where((k) => k.isNotEmpty).toList();
    for (final k in keys) {
      final builtIn = k == _builtInKey && geminiKey.trim() != k;
      final models = (await _discover(k, builtIn))[1];
      if (models.isEmpty) {
        _imgFail('gemini-image: this key has no image model (models: ${(await _discover(k, builtIn))[1]})');
        continue;
      }
      for (final model in models) {
        try {
          final res = await _client
              .post(
                Uri.parse(
                    'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$k'),
                headers: {
                  'Content-Type': 'application/json',
                  if (builtIn) ..._androidId,
                },
                body: jsonEncode({
                  'contents': [
                    {
                      'parts': [
                        {'text': prompt}
                      ]
                    }
                  ],
                  'generationConfig': {
                    'responseModalities': ['IMAGE'],
                  },
                }),
              )
              .timeout(const Duration(seconds: 60));
          if (res.statusCode != 200) {
            _imgFail(
                'gemini-image $model ${res.statusCode} ${_apiMsg(utf8.decode(res.bodyBytes, allowMalformed: true))}');
            if (res.statusCode == 404) continue; // try the next model name
            break; // quota / key problem: next key
          }
          final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
          final cands = j['candidates'] as List? ?? const [];
          for (final cand in cands) {
            final parts = ((cand as Map)['content'] as Map?)?['parts'] as List? ?? const [];
            for (final part in parts) {
              final m = part as Map;
              final inline = (m['inlineData'] ?? m['inline_data']) as Map?;
              final b64 = inline?['data'] as String?;
              if (b64 != null && b64.isNotEmpty) {
                await File(savePath).writeAsBytes(base64Decode(b64), flush: true);
                return true;
              }
            }
          }
          final block = (j['promptFeedback'] as Map?)?['blockReason'];
          final finish = cands.isNotEmpty ? (cands.first as Map)['finishReason'] : null;
          _imgBlocked = true; // refused or text-only answer: retry with a softer prompt
          _imgFail('gemini-image $model: no image (${block ?? finish ?? 'declined'})');
        } catch (e) {
          _imgFail('gemini-image $model: ${_cleanErr(e)}');
        }
      }
    }
    return false;
  }

  static const String _cfAcc = String.fromEnvironment('CF_ACCOUNT');
  static const String _cfTok = String.fromEnvironment('CF_TOKEN');

  static Future<bool> _cfImage(String prompt, String savePath) async {
    final uri = Uri.parse('https://api.cloudflare.com/client/v4/accounts/$_cfAcc'
        '/ai/run/@cf/black-forest-labs/flux-1-schnell');
    for (var i = 0; i < 2; i++) {
      try {
        final res = await _client
            .post(uri,
                headers: {
                  'Authorization': 'Bearer $_cfTok',
                  'Content-Type': 'application/json',
                },
                body: jsonEncode({'prompt': prompt, 'steps': 6}))
            .timeout(const Duration(seconds: 60));
        if (res.statusCode == 200) {
          final j = jsonDecode(utf8.decode(res.bodyBytes));
          final b64 = (j['result'] as Map?)?['image'] as String?;
          if (b64 != null && b64.isNotEmpty) {
            final bytes = base64Decode(b64);
            if (bytes.length > 2000) {
              await File(savePath).writeAsBytes(bytes, flush: true);
              return true;
            }
          }
          _imgFail('cloudflare: empty image');
        } else {
          final b = utf8.decode(res.bodyBytes, allowMalformed: true);
          _imgFail('cloudflare ${res.statusCode} ${b.length > 160 ? b.substring(0, 160) : b}');
          if (res.statusCode == 401 || res.statusCode == 403 || res.statusCode == 429) return false;
        }
      } catch (e) {
        _imgFail('cloudflare ${_cleanErr(e)}');
      }
    }
    return false;
  }

  static Future<bool> generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    if (_adult.hasMatch(_norm('$title $content'))) {
      lastError = 'Adult or nude images are not allowed.';
      _trace.clear();
      return false;
    }
    final ok = await _generateImage(title: title, content: content, savePath: savePath);
    if (!ok) {
      final head = 'build: cloudflare=${_cfAcc.isNotEmpty && _cfTok.isNotEmpty ? "ON" : "OFF (secrets missing in this build)"}'
          ' • gemini=${geminiAvailable ? "ON" : "OFF"}';
      if (_trace.isEmpty) _trace.add('no details were recorded');
      _trace.insert(0, head);
      lastError = _trace.join('\n');
    }
    return ok;
  }

  static Future<bool> _generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    lastError = '';
    _trace.clear();
    _imgBlocked = false;
    final sw0 = Stopwatch()..start();
    if (_cfAcc.isNotEmpty && _cfTok.isNotEmpty) {
      final en = await _imagePrompt(title, content);
      if (en != null) {
        var cp = '$en, $_style$_safeTail';
        if (cp.length > 1400) cp = cp.substring(0, 1400);
        if (await _cfImage(cp, savePath)) {
          lastInfo = 'cloudflare-flux • ${(sw0.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';
          return true;
        }
      } else {
        _imgFail('could not understand the dream text');
      }
    }
    if (_cfAcc.isEmpty && geminiAvailable) {
      // one call only: Gemini reads the (Arabic/Kurdish/English) dream and paints it
      final dream = '$title. $content';
      final prompts = [
        'A surreal dreamlike digital painting, cinematic lighting, highly detailed. '
            'Illustrate ONLY what is described in this dream (translate it faithfully, add '
            'nothing that is not mentioned). Never show nudity or sexual content; keep every person '
            'fully clothed. No text in the image.\nDream: $dream',
        // second try if the first was refused: same story, told tastefully and symbolically
        'A tasteful, wholesome, artistic dreamlike painting with soft cinematic light. '
            'Show the main people, creatures, places and objects of this dream faithfully, '
            'fully clothed and non-explicit, expressing any romance or violence only through '
            'gentle, symbolic, silhouette-style imagery. No text.\nDream: $dream',
      ];
      final sw = Stopwatch()..start();
      for (final pr in prompts) {
        _imgBlocked = false;
        if (await _geminiImage(pr.length > 1500 ? pr.substring(0, 1500) : pr, savePath)) {
          lastInfo = 'gemini-image • ${(sw.elapsedMilliseconds / 1000).toStringAsFixed(1)}s';
          return true;
        }
        if (!_imgBlocked) break; // network/quota problem: retrying the prompt won't help
      }
    }
    final english = await _imagePrompt(title, content);
    if (english == null) {
      _imgFail('could not understand the dream text');
      return false;
    }
    var prompt = '$english, $_style$_safeTail';
    if (prompt.length > 480) prompt = prompt.substring(0, 480);
    final encoded = Uri.encodeComponent(prompt);
    final models = ['flux', 'turbo'];
    for (var i = 0; i < models.length; i++) {
      final seed = math.Random().nextInt(1 << 30);
      final uri = Uri.parse(
          '$_imgUrl$encoded?width=768&height=768&nologo=true&safe=true&model=${models[i]}&seed=$seed');
      try {
        final res = await _client.get(uri).timeout(Duration(seconds: i == 0 ? 60 : 40));
        final ct = res.headers['content-type'] ?? '';
        if (res.statusCode == 200 &&
            ct.startsWith('image') &&
            res.bodyBytes.length > 2000) {
          await File(savePath).writeAsBytes(res.bodyBytes, flush: true);
          return true;
        }
        _imgFail('pollinations-image ${models[i]} ${res.statusCode}');
      } catch (e) {
        _imgFail('pollinations-image ${models[i]} ${_cleanErr(e)}');
      }
    }
    return false;
  }
}

class _Heard {
  final String text;
  final String? lang;
  final double? prob;
  const _Heard(this.text, this.lang, this.prob);
}
