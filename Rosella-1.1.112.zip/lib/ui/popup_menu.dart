import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const MenuAction(this.icon, this.label, this.onTap);
}

/// A card that opens from the top corner (below the ⋮ button): two big tiles, a list and a footer.
Future<void> showPopupCard(
  BuildContext context, {
  required List<MenuAction> tiles,
  required List<MenuAction> rows,
  String? footer,
}) {
  final rtl = Directionality.of(context) == TextDirection.rtl;
  final top = MediaQuery.paddingOf(context).top + 66;
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.black.withOpacity(0.28),
    transitionDuration: const Duration(milliseconds: 240),
    pageBuilder: (ctx, _, __) {
      final c = ctx.colors;
      final inner = c.isDark ? Colors.black : c.surfaceHi;
      void run(VoidCallback f) {
        Haptics.selection();
        Navigator.of(ctx).pop();
        f();
      }

      return Align(
        alignment: AlignmentDirectional.topEnd,
        child: Padding(
          padding: EdgeInsetsDirectional.only(top: top, end: 16, start: 16),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 330),
            child: Material(
              color: c.surface,
              borderRadius: BorderRadius.circular(30),
              elevation: 12,
              shadowColor: Colors.black54,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        for (var i = 0; i < tiles.length; i++) ...[
                          if (i > 0) const SizedBox(width: 8),
                          Expanded(
                            child: Pressable(
                              scale: 0.97,
                              onTap: () => run(tiles[i].onTap),
                              child: Container(
                                height: 76,
                                decoration: BoxDecoration(
                                    color: inner, borderRadius: BorderRadius.circular(22)),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(tiles[i].icon, color: c.text, size: 26),
                                    const SizedBox(height: 6),
                                    Text(tiles[i].label,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 12.5,
                                            fontWeight: FontWeight.w700)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      decoration: BoxDecoration(
                          color: inner, borderRadius: BorderRadius.circular(22)),
                      child: Column(
                        children: [
                          for (var i = 0; i < rows.length; i++) ...[
                            if (i > 0)
                              Divider(
                                  height: 1,
                                  indent: 14,
                                  endIndent: 14,
                                  color: al(c.text, 0.10)),
                            Pressable(
                              scale: 0.99,
                              onTap: () => run(rows[i].onTap),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 15),
                                child: Row(
                                  children: [
                                    Icon(rows[i].icon, color: c.text, size: 22),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Text(rows[i].label,
                                          style: TextStyle(
                                              color: c.text,
                                              fontSize: 15.5,
                                              fontWeight: FontWeight.w700)),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    if (footer != null)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 10, 8, 4),
                        child: Text(footer,
                            style: TextStyle(color: c.dim, fontSize: 12.5)),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, _, child) {
      final curved = CurvedAnimation(
          parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
      return FadeTransition(
        opacity: curved,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.82, end: 1).animate(curved),
          alignment: Alignment(rtl ? -0.9 : 0.9, -1),
          child: child,
        ),
      );
    },
  );
}
