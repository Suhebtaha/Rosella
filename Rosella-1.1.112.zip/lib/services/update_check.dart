import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

import 'notifier.dart';

/// Installed version. Publish GitHub releases with a tag like v1.1.1 (higher than this).
const String kAppVersion = '1.1.112';
const String kReleasesPage = 'https://github.com/Suhebtaha/Rosella/releases/latest';

class UpdateInfo {
  final bool available;
  final String tag;
  final String url;
  final bool failed;
  final String apkUrl;
  final String notes; // release description (markdown) from GitHub
  final String apkName;
  final int apkSize; // bytes
  const UpdateInfo(
      {this.available = false,
      this.tag = '',
      this.url = kReleasesPage,
      this.failed = false,
      this.apkUrl = '',
      this.notes = '',
      this.apkName = '',
      this.apkSize = 0});
}

class UpdateCheck {
  static List<int> _parts(String v) {
    final m = RegExp(r'\d+').allMatches(v).map((e) => int.parse(e.group(0)!)).toList();
    while (m.length < 3) {
      m.add(0);
    }
    return m;
  }

  static bool _newer(String a, String b) {
    final x = _parts(a), y = _parts(b);
    for (var i = 0; i < 3; i++) {
      if (x[i] != y[i]) return x[i] > y[i];
    }
    return false;
  }

  static Future<UpdateInfo> check() async {
    try {
      final res = await http
          .get(
            Uri.parse('https://api.github.com/repos/Suhebtaha/Rosella/releases/latest'),
            headers: {'Accept': 'application/vnd.github+json'},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 404) return const UpdateInfo(); // no release yet
      if (res.statusCode != 200) return const UpdateInfo(failed: true);
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final tag = (j['tag_name'] ?? '').toString();
      final url = (j['html_url'] ?? kReleasesPage).toString();
      if (tag.isEmpty) return const UpdateInfo();
      var apk = '', apkName = '';
      var apkSize = 0;
      for (final a in (j['assets'] as List? ?? const [])) {
        final m = a as Map;
        final n = (m['name'] ?? '').toString().toLowerCase();
        if (n.endsWith('.apk')) {
          apk = (m['browser_download_url'] ?? '').toString();
          apkName = (m['name'] ?? '').toString();
          apkSize = (m['size'] as num?)?.toInt() ?? 0;
          break;
        }
      }
      return UpdateInfo(
          available: _newer(tag, kAppVersion),
          tag: tag,
          url: url,
          apkUrl: apk,
          notes: (j['body'] ?? '').toString(),
          apkName: apkName,
          apkSize: apkSize);
    } catch (_) {
      return const UpdateInfo(failed: true);
    }
  }

  /// Opens the link in the browser / GitHub app. Returns false if nothing could open it.
  static Future<bool> open(String url) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('open', {'url': url}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Downloads the APK to the cache folder; [onProgress] gets 0..1. Returns the file path.
  /// While downloading the bytes go to `rosella-update.part`. When [isPaused] turns true the part
  /// file is kept, and a later call with [resume] continues from where it stopped (HTTP Range).
  static Future<String> download(String url, void Function(double) onProgress,
      {void Function(http.Client)? onClient,
      bool Function()? isCancelled,
      bool Function()? isPaused,
      bool resume = false,
      int expected = 0}) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/rosella-update.apk');
    final part = File('${dir.path}/rosella-update.part');
    if (file.existsSync()) file.deleteSync();
    var have = 0;
    if (resume && part.existsSync()) {
      have = part.lengthSync();
    } else if (part.existsSync()) {
      part.deleteSync();
    }
    final client = http.Client();
    onClient?.call(client);
    var keepPart = false;
    try {
      final req = http.Request('GET', Uri.parse(url));
      if (have > 0) req.headers['Range'] = 'bytes=$have-';
      final resp = await client.send(req).timeout(const Duration(seconds: 30));
      var append = false;
      if (resp.statusCode == 206 && have > 0) {
        append = true;
      } else if (resp.statusCode == 200) {
        have = 0; // the server ignored the range: start again from the beginning
      } else {
        throw Exception('HTTP ${resp.statusCode}');
      }
      final total = (resp.contentLength ?? 0) + (append ? have : 0);
      var got = have;
      final sink = part.openWrite(mode: append ? FileMode.append : FileMode.write);
      await for (final chunk in resp.stream) {
        if (isCancelled?.call() == true) {
          await sink.close();
          throw Exception('cancelled');
        }
        if (isPaused?.call() == true) {
          await sink.flush();
          await sink.close();
          keepPart = true;
          throw Exception('paused');
        }
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) onProgress((got / total).clamp(0.0, 1.0));
      }
      await sink.flush();
      await sink.close();
      if (got < 1000000) throw Exception('file too small');
      // the whole file must have arrived: a cut-off APK is what makes Android say
      // "package appears to be invalid"
      final want = expected > 0 ? expected : total;
      if (want > 0 && got != want) throw Exception('incomplete download ($got / $want)');
      final head = await part.openRead(0, 4).first;
      if (head.length < 4 || head[0] != 0x50 || head[1] != 0x4B) {
        throw Exception('not an apk file');
      }
      part.renameSync(file.path);
      return file.path;
    } catch (_) {
      try {
        if (!keepPart && part.existsSync()) part.deleteSync();
        if (file.existsSync()) file.deleteSync();
      } catch (_) {}
      rethrow;
    } finally {
      client.close();
    }
  }

  /// Bytes already saved by a paused download (0 when there is none).
  static Future<int> partialBytes() async {
    try {
      final dir = await getTemporaryDirectory();
      final part = File('${dir.path}/rosella-update.part');
      return part.existsSync() ? part.lengthSync() : 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<void> clearPartial() async {
    try {
      final dir = await getTemporaryDirectory();
      final part = File('${dir.path}/rosella-update.part');
      if (part.existsSync()) part.deleteSync();
    } catch (_) {}
  }

  /// Remember which release the cached APK belongs to (the app may be restarted
  /// by Android while the user grants the install permission).
  static Future<void> markDownloaded(String tag) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('apk_tag', tag);
    } catch (_) {}
  }

  /// Path of an already downloaded APK for [tag], or null.
  static Future<String?> readyPath(String tag, {int expected = 0}) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (p.getString('apk_tag') != tag) return null;
      final ext = await getExternalStorageDirectory();
      final dirs = [if (ext != null) ext.path, (await getTemporaryDirectory()).path];
      for (final d in dirs) {
        final f = File('$d/rosella-update.apk');
        if (!f.existsSync()) continue;
        // a file of the wrong size is a broken / cut-off download: delete it, never install it
        if (f.lengthSync() > 1000000 && (expected <= 0 || f.lengthSync() == expected)) {
          return f.path;
        }
        try {
          f.deleteSync();
        } catch (_) {}
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  static const MethodChannel _ch = MethodChannel('rosella/haptic');

  /// Starts a system DownloadManager download (keeps going when the app is closed).
  /// Returns its id, or null when this phone / build cannot do it.
  static Future<String?> dlStart(String url, String title) async {
    try {
      final r = await _ch.invokeMethod<String>('dlStart', {'url': url, 'title': title});
      return (r == null || r.isEmpty) ? null : r;
    } catch (_) {
      return null;
    }
  }

  /// {status, done, total, path} or an empty map when the id is unknown (cancelled).
  static Future<Map<String, dynamic>> dlStatus(String id) async {
    try {
      final r = await _ch.invokeMethod<Map>('dlStatus', {'id': id});
      return {for (final e in (r ?? const {}).entries) e.key.toString(): e.value};
    } catch (_) {
      return {'status': -1};
    }
  }

  static Future<void> dlCancel(String id) async {
    try {
      await _ch.invokeMethod('dlCancel', {'id': id});
    } catch (_) {}
  }

  static Future<void> saveJob(String? id, String tag) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (id == null) {
        await p.remove('dl_id');
        await p.remove('dl_tag');
      } else {
        await p.setString('dl_id', id);
        await p.setString('dl_tag', tag);
      }
    } catch (_) {}
  }

  /// 'ok' (system install screen opened), 'perm' (user must allow installs from this app), 'fail'.
  static Future<String> install(String path) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<String>('install', {'path': path}) ??
          'fail';
    } catch (_) {
      return 'fail';
    }
  }
}

/// One update download for the whole app: keeps running when the dialog is hidden,
/// shows a progress notification and lets Settings display / cancel it.
class UpdateJob extends ChangeNotifier {
  static final UpdateJob I = UpdateJob._();
  UpdateJob._();

  bool downloading = false;
  double progress = 0;
  String tag = '';
  String? readyPath;
  String error = '';
  bool cancelled = false;
  /// the download is stopped but its bytes are kept, so it can continue
  bool paused = false;
  UpdateInfo? _info;
  String _title = '', _doneTitle = '', _doneBody = '';
  /// set when a download finished while nobody was looking at the dialog
  bool finishedQuietly = false;
  bool dialogOpen = false;
  http.Client? _client;
  int _lastPct = -1;

  String? _dlId;

  Future<void> start(UpdateInfo info,
      {required String title,
      required String doneTitle,
      required String doneBody,
      bool resume = false}) async {
    if (downloading) return;
    downloading = true;
    cancelled = false;
    paused = false;
    error = '';
    if (!resume) progress = 0;
    tag = info.tag;
    _info = info;
    _title = title;
    _doneTitle = doneTitle;
    _doneBody = doneBody;
    finishedQuietly = false;
    _lastPct = -1;
    notifyListeners();
    try {
      // downloaded inside the app (no system download manager), size-checked
      await _httpDownload(info, title, doneTitle, doneBody, resume);
    } catch (e) {
      downloading = false;
      await Notifier.updateClear();
      if (paused) {
        // stopped on purpose: no error, the saved bytes wait for "resume"
      } else if (!cancelled) {
        final m = e.toString().replaceAll('Exception: ', '');
        error = m.length > 70 ? m.substring(0, 70) : m;
      }
    }
    _client = null;
    notifyListeners();
  }

  /// After the app was closed and opened again: pick up a download that kept running.
  Future<void> resume() async {
    if (downloading) return;
    try {
      final p = await SharedPreferences.getInstance();
      final id = p.getString('dl_id');
      final t = p.getString('dl_tag');
      if (id == null || t == null) return;
      // a download started by an older version through the system download manager:
      // cancel it and forget it (downloads now happen inside the app)
      await UpdateCheck.dlCancel(id);
      await UpdateCheck.saveJob(null, '');
      return;
    } catch (_) {}
  }

  Future<void> _poll(String id, String t, String doneTitle, String doneBody) async {
    while (true) {
      if (cancelled) {
        await UpdateCheck.dlCancel(id);
        await UpdateCheck.saveJob(null, '');
        downloading = false;
        throw Exception('cancelled');
      }
      final st = await UpdateCheck.dlStatus(id);
      final status = (st['status'] as num?)?.toInt() ?? -1;
      if (status == 8) {
        final path = (st['path'] ?? '').toString();
        await UpdateCheck.saveJob(null, '');
        if (path.isEmpty || !File(path).existsSync() || File(path).lengthSync() < 1000000) {
          throw Exception('file too small');
        }
        await UpdateCheck.markDownloaded(t);
        readyPath = path;
        progress = 1;
        downloading = false;
        if (!dialogOpen) {
          finishedQuietly = true;
          if (doneTitle.isNotEmpty) await Notifier.updateDone(doneTitle, doneBody);
        }
        return;
      }
      if (status == 16) {
        await UpdateCheck.saveJob(null, '');
        throw Exception('download failed (${st['reason'] ?? ''})');
      }
      if (status == -1 || st.isEmpty) {
        // removed by the user from the system notification
        await UpdateCheck.saveJob(null, '');
        downloading = false;
        throw Exception('gone');
      }
      final total = (st['total'] as num?)?.toDouble() ?? 0;
      final done = (st['done'] as num?)?.toDouble() ?? 0;
      if (total > 0) {
        progress = (done / total).clamp(0.0, 1.0);
        notifyListeners();
      }
      await Future<void>.delayed(const Duration(milliseconds: 700));
    }
  }

  Future<void> _httpDownload(UpdateInfo info, String title, String doneTitle, String doneBody,
      [bool resume = false]) async {
    final path = await UpdateCheck.download(info.apkUrl, (v) {
      progress = v;
      final pct = (v * 100).round();
      if (pct != _lastPct) {
        _lastPct = pct;
        if (pct % 2 == 0) Notifier.updateProgress(pct, title);
        notifyListeners();
      }
    },
        onClient: (c) => _client = c,
        isCancelled: () => cancelled,
        isPaused: () => paused,
        resume: resume,
        expected: info.apkSize);
    await UpdateCheck.markDownloaded(info.tag);
    readyPath = path;
    downloading = false;
    if (!dialogOpen) {
      finishedQuietly = true;
      await Notifier.updateDone(doneTitle, doneBody);
    } else {
      await Notifier.updateClear();
    }
  }

  void cancel() {
    if (!downloading) {
      if (paused) {
        // cancelling a paused download throws the saved bytes away
        paused = false;
        progress = 0;
        UpdateCheck.clearPartial();
        notifyListeners();
      }
      return;
    }
    paused = false;
    cancelled = true;
    try {
      _client?.close();
    } catch (_) {}
  }

  /// Stops the download but keeps what was already saved.
  void pause() {
    if (!downloading) return;
    paused = true;
    notifyListeners();
  }

  /// Continues a paused download from the saved bytes.
  Future<void> resumePaused() async {
    final info = _info;
    if (!paused || downloading || info == null) return;
    await start(info, title: _title, doneTitle: _doneTitle, doneBody: _doneBody, resume: true);
  }

  void acknowledge() {
    finishedQuietly = false;
    notifyListeners();
  }
}
