## Rosella 1.1.112

- Share card: swipe sideways to browse different looks (your theme, aurora, sunset, violet, paper, mono, forest, blush) and layouts (classic, centered, quote). The card you see is the one that gets shared or saved.
