import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import '../services/update_check.dart';
import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/languages.dart';
import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import '../services/haptics.dart';
import 'legal_page.dart';
import 'update_dialog.dart';
import 'widgets.dart';

const String kSupportEmail = 'contact.somina@gmail.com';

class SettingsPage extends StatelessWidget {
  final ScrollController? controller;
  /// '' = the hub; otherwise the key of the sub-page to show
  final String section;
  const SettingsPage({super.key, this.controller, this.section = ''});

  static const String kShareLink = 'https://github.com/Suhebtaha/Rosella/releases/latest';

  Future<void> _sheet(BuildContext context, String title,
      List<(IconData, String, VoidCallback)> options) async {
    final c = context.colors;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 14),
                child: Text(title,
                    style: TextStyle(
                        color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              for (final o in options)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Pressable(
                    onTap: () {
                      Navigator.of(ctx).pop();
                      o.$3();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      decoration: BoxDecoration(
                        color: c.surfaceHi,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(o.$1, color: c.a),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Text(o.$2,
                                style: TextStyle(
                                    color: c.text,
                                    fontSize: 15.5,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// The small refresh icon: always looks for a newer release, even when one is already known.
  Future<void> _recheckUpdate(BuildContext context) async {
    final app = context.read<AppState>();
    if (app.checkingUpdate) return;
    final before = app.updateTag;
    final r = await app.checkForUpdate();
    if (!context.mounted) return;
    if (r.failed) {
      toast(context, context.t('update_failed'));
    } else if (!r.available) {
      toast(context, context.t('up_to_date'));
    } else if (r.tag != before || !UpdateJob.I.downloading) {
      await showUpdateDialog(context, r);
    }
  }

  Future<void> _update(BuildContext context) async {
    final app = context.read<AppState>();
    if (app.checkingUpdate) return;
    var r = app.updateInfo;
    if (!app.updateAvailable) {
      r = await app.checkForUpdate();
      if (!context.mounted) return;
      if (r.failed) {
        toast(context, context.t('update_failed'));
        return;
      }
      if (!r.available) {
        toast(context, context.t('up_to_date'));
        return;
      }
    }
    if (!context.mounted) return;
    await showUpdateDialog(context, r);
  }

  Future<void> _copy(BuildContext context, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (context.mounted) toast(context, context.t('copied'));
  }

  void _chooseShare(BuildContext context) {
    _sheet(context, context.t('share_app'), [
      (Icons.ios_share_rounded, context.t('share_now'), () => Share.share(context.t('share_text'))),
      (Icons.link_rounded, context.t('copy_link'), () => _copy(context, kShareLink)),
    ]);
  }

  void _chooseMail(BuildContext context) {
    _sheet(context, context.t('feedback'), [
      (Icons.mail_rounded, context.t('open_mail'), () => _mail(context)),
      (Icons.copy_rounded, context.t('copy_email'), () => _copy(context, kSupportEmail)),
    ]);
  }

  /// Writes every dream into one readable text file and shares it.
  Future<void> _exportText(BuildContext context, AppState app) async {
    final pub = app.dreams.where((d) => !d.priv).toList();
    if (pub.isEmpty) {
      toast(context, context.t('export_empty'));
      return;
    }
    final b = StringBuffer('Rosella\n${pub.length}\n\n');
    for (final d in pub) {
      final dt = d.createdAt;
      b.writeln('=== ${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}'
          '  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
          '${d.lucid ? '  *' : ''} ===');
      if (d.title.trim().isNotEmpty) b.writeln(d.title.trim());
      b.writeln(d.content.trim());
      if (d.interpretation != null && d.interpretation!.trim().isNotEmpty) {
        b.writeln('\n-- ${context.t('interpretation')} --');
        b.writeln(d.interpretation!.trim());
      }
      b.writeln('\n');
    }
    final bytes = Uint8List.fromList(utf8.encode(b.toString()));
    try {
      // system "save as" screen: the user picks the folder and the name
      final saved = await app.external(() => FilePicker.platform.saveFile(
            dialogTitle: context.t('export_txt'),
            fileName: 'Rosella-dreams.txt',
            bytes: bytes,
            type: FileType.custom,
            allowedExtensions: const ['txt'],
          ));
      if (saved != null && context.mounted) toast(context, context.t('export_saved'));
    } catch (_) {
      // fall back to the share sheet
      try {
        final dir = await getTemporaryDirectory();
        final f = File('${dir.path}/Rosella-dreams.txt');
        await f.writeAsBytes(bytes, flush: true);
        await app.external(() => Share.shareXFiles([XFile(f.path)], text: 'Rosella'));
      } catch (_) {
        if (context.mounted) toast(context, context.t('export_empty'));
      }
    }
  }

  /// Opens the mail app with the address filled in; copies it if no mail app answers.
  Future<void> _mail(BuildContext context) async {
    final subject = context.t('mail_subject');
    bool ok = false;
    try {
      ok = await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('mail', {'to': kSupportEmail, 'subject': subject}) ??
          false;
    } catch (_) {}
    if (!ok) {
      await Clipboard.setData(const ClipboardData(text: kSupportEmail));
      if (context.mounted) toast(context, context.t('email_copied'));
    }
  }

  Future<void> _toggleBio(BuildContext context, bool v) async {
    final app = context.read<AppState>();
    if (v) {
      final supported = await app.canAuth();
      if (!supported) {
        if (context.mounted) toast(context, app.tr('bio_unsupported'));
        return;
      }
      final ok = await app.authenticate();
      if (!ok) return;
    } else {
      // turning the lock OFF also needs fingerprint / PIN
      final ok = await app.external(() => app.authenticate());
      if (!ok) return;
    }
    app.setBio(v);
  }

  Future<void> _signIn(BuildContext context) async {
    final app = context.read<AppState>();
    final err = await app.googleSignIn();
    if (err != null && context.mounted) {
      toast(context, '${app.tr('signin_failed')}\n$err');
    }
  }

  Future<void> _editKey(BuildContext context) async {
    final app = context.read<AppState>();
    final c = context.colors;
    final ctrl = TextEditingController(text: app.geminiKey);
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(app.tr('gemini_key'),
            style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(app.tr('gemini_hint'),
                style: TextStyle(color: c.dim, fontSize: 13.5, height: 1.5)),
            const SizedBox(height: 14),
            TextField(
              controller: ctrl,
              autocorrect: false,
              enableSuggestions: false,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: c.text, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'AIza…',
                hintStyle: TextStyle(color: al(c.dim, 0.7)),
                filled: true,
                fillColor: c.surfaceHi,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(app.tr('cancel'), style: TextStyle(color: c.dim))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(app.tr('save'),
                  style: TextStyle(color: c.a, fontWeight: FontWeight.w800))),
        ],
      ),
    );
    if (res != null) {
      app.setGeminiKey(res);
      if (context.mounted) toast(context, app.tr('gemini_saved'));
    }
  }

  Future<void> _testAi(BuildContext context) async {
    final app = context.read<AppState>();
    final c = context.colors;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(app.tr('ai_test'),
            style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 18)),
        content: FutureBuilder<String>(
          future: AiService.selfTest(),
          builder: (_, snap) {
            if (!snap.hasData) {
              return SizedBox(
                height: 70,
                child: Center(child: CircularProgressIndicator(color: c.a)),
              );
            }
            return SingleChildScrollView(
              child: SelectableText(
                snap.data!,
                textDirection: TextDirection.ltr,
                style: TextStyle(color: c.text, fontSize: 13.5, height: 1.6),
              ),
            );
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(app.tr('done'),
                  style: TextStyle(color: c.a, fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }

  static String _syncMsg(AppState app, String err) =>
      err == 'api' ? app.tr('sync_api') : '${app.tr('sync_failed')}\n$err';

  static String _fmt(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String p(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${p(d.month)}-${p(d.day)} ${p(d.hour)}:${p(d.minute)}';
  }

  Future<void> _deleteAll(BuildContext context) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_all'),
      message: app.tr('delete_all_confirm'),
      confirm: app.tr('delete'),
    );
    if (ok) await app.deleteAll();
  }

  /// Items of one settings sub-page (the same sections as before, now grouped behind the hub).
  List<Widget> _items(String k, BuildContext context, AppState app) {
    final c = context.colors;
    const sky = Color(0xFF38A8FF);
    const amber = Color(0xFFFFA94D);
    const green = Color(0xFF34D399);
    const red = Color(0xFFFF5470);
    switch (k) {
      case 'appearance':
        return [
          const SizedBox(height: 20),
          _Label(context.t('appearance')),
          FadeSlide(
            delay: 80,
            child: _Group(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 12, 0, 12),
                child: Builder(builder: (context) {
                  const opts = [
                    ('system', 'tm_system'),
                    ('dark', 'tm_dark'),
                    ('light', 'tm_light'),
                    ('auto', 'tm_auto'),
                  ];
                  final sel = opts.indexWhere((o) => o.$1 == app.themeMode).clamp(0, 3);
                  return Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: c.isDark ? const Color(0xFF0E0E11) : al(c.text, 0.06),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: al(c.text, 0.10)),
                    ),
                    child: LayoutBuilder(builder: (context, cons) {
                      final w = cons.maxWidth / 4;
                      return SizedBox(
                        height: 38,
                        child: Stack(children: [
                          AnimatedPositionedDirectional(
                            duration: const Duration(milliseconds: 260),
                            curve: Curves.easeOutCubic,
                            start: w * sel,
                            top: 0,
                            bottom: 0,
                            width: w,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(17),
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: c.isDark ? const [_kGoldHi, _kGoldLo] : [c.a, c.b],
                                ),
                              ),
                            ),
                          ),
                          Row(children: [
                            for (var i = 0; i < 4; i++)
                              Expanded(
                                child: GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () {
                                    Haptics.selection();
                                    app.setThemeMode(opts[i].$1);
                                  },
                                  child: Center(
                                    child: AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 200),
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: sel == i
                                              ? (c.isDark ? _kOnGold : Colors.white)
                                              : c.dim),
                                      child: Text(context.t(opts[i].$2),
                                          maxLines: 1, overflow: TextOverflow.ellipsis),
                                    ),
                                  ),
                                ),
                              ),
                          ]),
                        ]),
                      );
                    }),
                  );
                }),
              ),
              if (app.themeMode == 'auto') ...[
                _Tile(
                  icon: Icons.nightlight_round,
                  tint: const Color(0xFF8B7BFF),
                  title: context.t('tm_from'),
                  subtitle: context.t('tm_auto_sub'),
                  trailing: Text(_hm(app.darkFromMin),
                      style: TextStyle(color: c.text, fontSize: 16, fontWeight: FontWeight.w700)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      builder: twelveHour,
                      initialTime: TimeOfDay(hour: app.darkFromMin ~/ 60, minute: app.darkFromMin % 60),
                    );
                    if (t != null) app.setDarkRange(t.hour * 60 + t.minute, app.darkToMin);
                  },
                ),
                _Tile(
                  icon: Icons.wb_sunny_rounded,
                  tint: const Color(0xFFFFB84D),
                  title: context.t('tm_to'),
                  trailing: Text(_hm(app.darkToMin),
                      style: TextStyle(color: c.text, fontSize: 16, fontWeight: FontWeight.w700)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      builder: twelveHour,
                      initialTime: TimeOfDay(hour: app.darkToMin ~/ 60, minute: app.darkToMin % 60),
                    );
                    if (t != null) app.setDarkRange(app.darkFromMin, t.hour * 60 + t.minute);
                  },
                ),
              ],
              if (app.themeMode == 'system')
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                  child: Text(context.t('tm_system_sub'),
                      style: const TextStyle(color: Color(0xFF85858F), fontSize: 12.5)),
                ),
              if (app.themeMode != 'light')
              _SwitchRow(
                icon: Icons.contrast_rounded,
                tint: const Color(0xFF8E8E93),
                title: context.t('amoled'),
                subtitle: context.t('amoled_sub'),
                value: app.amoled,
                onChanged: (v) {
                  Haptics.selection();
                  app.setAmoled(v);
                },
              ),
            ]),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 100,
            child: _Group(children: [
              _Tile(
                icon: Icons.vibration_rounded,
                tint: const Color(0xFFFFB84D),
                title: context.t('haptic_title'),
                subtitle: context.t('haptic_sub'),
                trailing: null,
                onTap: Haptics.test,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 2, 0, 14),
                child: Row(
                  children: [
                    for (var i = 0; i < 4; i++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 3),
                          child: Pressable(
                            onTap: () {
                              app.setHapticLevel(i);
                              Haptics.test();
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              height: 38,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                gradient: app.hapticLevel == i
                                    ? _kGoldGrad
                                    : null,
                                color: app.hapticLevel == i ? null : al(c.text, 0.07),
                                borderRadius: BorderRadius.circular(19),
                              ),
                              child: Text(
                                context.t(const ['haptic_off', 'haptic_light', 'haptic_medium', 'haptic_strong'][i]),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: app.hapticLevel == i ? _kOnGold : c.text,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              if (app.hapticLevel > 0)
                _SwitchRow(
                  icon: Icons.phone_android_rounded,
                  tint: const Color(0xFFFFB84D),
                  title: context.t('haptic_motor'),
                  subtitle: context.t('haptic_motor_sub'),
                  value: app.hapticMotor,
                  onChanged: (v) {
                    app.setHapticMotor(v);
                    Haptics.test();
                  },
                ),
            ]),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 10),
            child: Text(context.t('theme'),
                style: TextStyle(
                    color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          LayoutBuilder(builder: (context, cons) {
            const gap = 12.0;
            final w = (cons.maxWidth - gap) / 2;
            return Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                for (final p in kPalettes)
                  SizedBox(
                    width: w,
                    child: _ThemeCard(
                      palette: p,
                      selected: app.themeId == p.id,
                      label: Strings.get(app.lang, p.nameKey),
                      onTap: () {
                        Haptics.selection();
                        app.setTheme(p.id);
                      },
                    ),
                  ),
              ],
            );
          }),
          const SizedBox(height: 20),
          _Label(context.t('cards')),
          _ChoiceRow(
            value: app.cardStyle,
            onChanged: app.setCardStyle,
            options: [
              ('list', Icons.view_agenda_rounded, context.t('card_list')),
              ('grid', Icons.grid_view_rounded, context.t('card_grid')),
            ],
          ),
          const SizedBox(height: 20),
          _Label(context.t('home_filters')),
          _Group(children: [
            _SwitchRow(
              icon: Icons.star_border_rounded,
              tint: const Color(0xFFFFB020),
              title: context.t('hide_fav'),
              subtitle: context.t('hide_fav_sub'),
              value: app.hideFavFilter,
              onChanged: (v) {
                Haptics.selection();
                app.setHideFavFilter(v);
              },
            ),
            _SwitchRow(
              icon: Icons.lock_outline_rounded,
              tint: const Color(0xFF7C5CFF),
              title: context.t('hide_priv'),
              subtitle: context.t('hide_priv_sub'),
              value: app.hidePrivFilter,
              onChanged: (v) async {
                Haptics.selection();
                if (!v) {
                  final ok = await app.external(() => app.authenticate());
                  if (!ok) return;
                }
                app.setHidePrivFilter(v);
              },
            ),
          ]),
          const SizedBox(height: 20),
          _Label(context.t('mic_pos')),
          _ChoiceRow(
            value: app.micCenter ? 'center' : 'side',
            onChanged: (v) => app.setMicCenter(v == 'center'),
            options: [
              ('side', Icons.align_horizontal_right_rounded, context.t('mic_side')),
              ('center', Icons.adjust_rounded, context.t('mic_center')),
            ],
          ),
          const SizedBox(height: 10),
          _Group(children: [
            _SwitchRow(
              icon: Icons.label_outline_rounded,
              title: context.t('nav_labels'),
              value: app.navLabels,
              onChanged: (v) {
                Haptics.selection();
                app.setNavLabels(v);
              },
            ),
          ]),
        ];
      case 'language':
        return [
          const SizedBox(height: 20),
          _Label(context.t('language')),
          FadeSlide(
            delay: 100,
            child: _Card(
              padding: const EdgeInsets.all(8),
              child: _LangSegment(
                current: app.lang,
                onChanged: (v) {
                  Haptics.selection();
                  app.setLang(v);
                },
              ),
            ),
          ),
          const SizedBox(height: 20),
          _Label(context.t('speech_lang')),
          FadeSlide(
            delay: 110,
            child: _Card(
              padding: const EdgeInsets.all(8),
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 4, 4, 6),
                  child: Row(children: [
                    Expanded(
                      child: Text(context.t('speech_auto'),
                          style: TextStyle(
                              color: context.colors.text,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                    ),
                    Switch.adaptive(
                      value: app.speechLang.isEmpty,
                      onChanged: (v) {
                        Haptics.selection();
                        app.setSpeechLang(v ? '' : app.lang);
                      },
                    ),
                  ]),
                ),
                IgnorePointer(
                  ignoring: app.speechLang.isEmpty,
                  child: AnimatedOpacity(
                    opacity: app.speechLang.isEmpty ? 0.35 : 1,
                    duration: const Duration(milliseconds: 200),
                    child: _LangSegment(
                      current: app.speechLang.isEmpty ? app.lang : app.speechLang,
                      onChanged: (v) {
                        Haptics.selection();
                        app.setSpeechLang(v);
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                  child: Text(context.t('speech_lang_sub'),
                      style: TextStyle(color: context.colors.dim, fontSize: 12.5, height: 1.4)),
                ),
              ]),
            ),
          ),
        ];
      case 'notifications':
        return [
          const SizedBox(height: 20),
          _Label(context.t('reminders')),
          FadeSlide(
            delay: 60,
            child: _Group(children: [
              _SwitchRow(
                icon: Icons.notifications_active_rounded,
                tint: amber,
                title: context.t('morning_reminder'),
                subtitle: context.t('morning_reminder_sub'),
                value: app.reminder,
                onChanged: (v) async {
                  Haptics.selection();
                  final ok = await app.setReminder(v);
                  if (!ok && context.mounted) {
                    toast(context, app.tr('notif_denied'));
                  }
                },
              ),
              if (app.reminder)
                _Tile(
                  icon: Icons.schedule_rounded,
                  tint: amber,
                  title: context.t('reminder_time'),
                  trailing: Text(
                      fmtHm(app.reminderH, app.reminderM),
                      style: TextStyle(
                          color: c.a, fontSize: 17, fontWeight: FontWeight.w800)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      builder: twelveHour,
                      initialTime: TimeOfDay(hour: app.reminderH, minute: app.reminderM),
                    );
                    if (t != null) app.setReminderTime(t.hour, t.minute);
                  },
                ),
              _SwitchRow(
                icon: Icons.edit_notifications_rounded,
                tint: amber,
                title: context.t('nudge_reminder'),
                subtitle: context.t('nudge_reminder_sub'),
                value: app.nudge,
                onChanged: (v) async {
                  Haptics.selection();
                  final ok = await app.setNudge(v);
                  if (!ok && context.mounted) {
                    toast(context, app.tr('notif_denied'));
                  }
                },
              ),
              _SwitchRow(
                icon: Icons.bedtime_rounded,
                tint: const Color(0xFF7C5CFF),
                title: context.t('bedtime_reminder'),
                subtitle: context.t('bedtime_reminder_sub'),
                value: app.bedtime,
                onChanged: (v) async {
                  Haptics.selection();
                  final ok = await app.setBedtime(v);
                  if (!ok && context.mounted) {
                    toast(context, app.tr('notif_denied'));
                  }
                },
              ),
              if (app.bedtime)
                _Tile(
                  icon: Icons.schedule_rounded,
                  tint: const Color(0xFF7C5CFF),
                  title: context.t('bedtime_time'),
                  trailing: Text(
                      fmtHm(app.bedH, app.bedM),
                      style: TextStyle(
                          color: c.a, fontSize: 17, fontWeight: FontWeight.w800)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      builder: twelveHour,
                      initialTime: TimeOfDay(hour: app.bedH, minute: app.bedM),
                    );
                    if (t != null) app.setBedtimeTime(t.hour, t.minute);
                  },
                ),
            ]),
          ),
        ];
      case 'ai':
        return [
          const SizedBox(height: 20),
          _Label(context.t('ai_section')),
          FadeSlide(
            delay: 50,
            child: _Group(children: [
              _Tile(
                icon: Icons.auto_awesome_rounded,
                tint: const Color(0xFF8B7BFF),
                title: context.t('gemini_key'),
                subtitle: context.t('gemini_key_sub'),
                trailing: Text(
                    app.geminiKey.isEmpty && !AiService.hasBuiltIn
                        ? context.t('gemini_off')
                        : context.t('gemini_on'),
                    style: TextStyle(
                        color: app.geminiKey.isEmpty && !AiService.hasBuiltIn
                            ? c.dim
                            : const Color(0xFF34D399),
                        fontSize: 13,
                        fontWeight: FontWeight.w800)),
                onTap: () => _editKey(context),
              ),
              _Tile(
                icon: Icons.speed_rounded,
                tint: const Color(0xFF34D399),
                title: context.t('ai_test'),
                trailing: Icon(Icons.chevron_right_rounded, color: c.dim),
                onTap: () => _testAi(context),
              ),
            ]),
          ),
        ];
      case 'security':
        return [
          const SizedBox(height: 20),
          _Label(context.t('security')),
          FadeSlide(
            delay: 120,
            child: _Group(children: [
              _SwitchRow(
                icon: Icons.fingerprint_rounded,
                tint: green,
                title: context.t('bio_lock'),
                subtitle: context.t('bio_sub'),
                value: app.bioLock,
                onChanged: (v) => _toggleBio(context, v),
              ),
              _SwitchRow(
                icon: Icons.forum_rounded,
                tint: green,
                title: context.t('lock_chats'),
                subtitle: context.t('lock_chats_sub'),
                value: app.lockChats,
                onChanged: (v) async {
                  final ok = await app.external(() => app.authenticate());
                  if (!ok) return;
                  app.setLockChats(v);
                },
              ),
            ]),
          ),
        ];
      case 'data':
        return [
          const SizedBox(height: 20),
          _Label(context.t('data')),
          FadeSlide(
            delay: 140,
            child: _Group(children: [
              _Tile(
                icon: Icons.file_download_rounded,
                tint: sky,
                title: context.t('export_txt'),
                subtitle: context.t('export_txt_sub'),
                onTap: () => _exportText(context, app),
              ),
              if (app.userEmail != null) ...[
                _SwitchRow(
                  icon: Icons.cloud_sync_rounded,
                  tint: sky,
                  title: context.t('auto_backup'),
                  subtitle: context.t('auto_backup_sub'),
                  value: app.autoBackup,
                  onChanged: (v) {
                    Haptics.selection();
                    app.setAutoBackup(v);
                  },
                ),
                _Tile(
                  icon: Icons.cloud_upload_rounded,
                  tint: sky,
                  title: app.syncing ? context.t('syncing') : context.t('sync_now'),
                  subtitle: app.syncError != null
                      ? _syncMsg(app, app.syncError!)
                      : app.lastSync == 0
                          ? context.t('never_synced')
                          : '${context.t('last_sync')}: ${_fmt(app.lastSync)}',
                  subtitleColor: app.syncError != null ? red : null,
                  trailing: app.syncing
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2.4, color: c.a))
                      : Icon(Icons.chevron_right_rounded, color: c.dim),
                  onTap: () async {
                    if (app.syncing) return;
                    final err = await app.syncNow();
                    if (!context.mounted) return;
                    toast(context, err == null ? app.tr('sync_ok') : _syncMsg(app, err));
                  },
                ),
              ],
              _Tile(
                icon: Icons.delete_sweep_rounded,
                tint: red,
                title: context.t('delete_all'),
                subtitle: context.t('delete_all_sub'),
                titleColor: const Color(0xFFFF6B7D),
                onTap: () => _deleteAll(context),
              ),
            ]),
          ),
        ];
      case 'about':
        return [
          const SizedBox(height: 20),
          _Label(context.t('about_section')),
          FadeSlide(
            delay: 160,
            child: _Group(children: [
              ListenableBuilder(
                listenable: UpdateJob.I,
                builder: (context, _) => _Tile(
                icon: Icons.system_update_rounded,
                badge: app.updateAvailable,
                tint: const Color(0xFFFF6B6B),
                title: app.updateAvailable
                    ? '${context.t('update_available')} ${app.updateTag}'
                    : context.t('check_update'),
                subtitle: UpdateJob.I.downloading
                    ? '${context.t('downloading')} ${(100 * UpdateJob.I.progress).round()}%'
                    : UpdateJob.I.readyPath != null && app.updateAvailable
                        ? context.t('update_downloaded_sub')
                        : app.checkingUpdate
                    ? context.t('checking')
                    : (app.updateAvailable
                        ? context.t('update_tap')
                        : '${context.t('version')} $kAppVersion'),
                onTap: () => _update(context),
                trailing: Pressable(
                  onTap: () => _recheckUpdate(context),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: app.checkingUpdate
                        ? SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: c.dim))
                        : Icon(Icons.refresh_rounded, color: c.dim, size: 21),
                  ),
                ),
              ),
              ),
              _Tile(
                icon: Icons.ios_share_rounded,
                tint: const Color(0xFF38BDF8),
                title: context.t('share_app'),
                subtitle: context.t('share_app_sub'),
                onTap: () => _chooseShare(context),
              ),
              _Tile(
                icon: Icons.mail_rounded,
                tint: const Color(0xFF34D399),
                title: context.t('feedback'),
                subtitle: kSupportEmail,
                onTap: () => _chooseMail(context),
              ),
              _Tile(
                icon: Icons.privacy_tip_rounded,
                tint: const Color(0xFFA78BFA),
                title: context.t('privacy_policy'),
                onTap: () => LegalPage.open(context, privacy: true),
              ),
              _Tile(
                icon: Icons.description_rounded,
                tint: const Color(0xFF94A3B8),
                title: context.t('terms_of_use'),
                onTap: () => LegalPage.open(context, privacy: false),
              ),
            ]),
          ),
          const SizedBox(height: 34),
          Center(
            child: Column(
              children: [
                Text('Rosella', style: TextStyle(color: c.text, fontSize: 15, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text('${context.t('version')} $kAppVersion · ${context.t('made_for')}',
                    style: const TextStyle(color: Color(0xFF85858F), fontSize: 12.5)),
                const SizedBox(height: 14),
                Text(
                  'Developed by',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(
                      color: al(c.dim, 0.9), fontSize: 13, letterSpacing: 1.2),
                ),
                const SizedBox(height: 2),
                const Directionality(
                  textDirection: TextDirection.ltr,
                  child: DynamicText('Suhaib',
                      fontSize: 46, letterSpacing: 1.5, weight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ];
    }
    return const <Widget>[];
  }

  void _open(BuildContext context, String section) {
    Haptics.selection();
    Navigator.of(context)
        .push(CupertinoPageRoute<void>(builder: (_) => SettingsPage(section: section)));
  }

  static const _langNames = {'en': 'English', 'ar': 'العربية', 'ku': 'کوردی'};

  Widget _sub(BuildContext context) {
    final app = context.watch<AppState>();
    const titles = {'appearance': 'appearance', 'language': 'language', 'notifications': 'reminders', 'ai': 'ai_section', 'security': 'security', 'data': 'data', 'about': 'about_section'};
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t(titles[section] ?? 'set_title')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.fromLTRB(16, 4, 16, navPadding(context)),
              children: _items(section, context, app),
            ),
          ),
        ],
      ),
    );
  }

  Widget _hub(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final signed = app.userEmail != null;
    final mode = app.themeMode;
    return SafeArea(
      bottom: false,
      child: ListView(
        controller: controller,
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 0, 6, 4),
            child: Text(context.t('set_title'),
                style: TextStyle(
                    color: c.text, fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -0.8)),
          ),
          const _HubHeader(),
          const SizedBox(height: 14),
          FadeSlide(
            child: Pressable(
              scale: 0.985,
              onTap: signed ? null : () => _signIn(context),
              child: _Card(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF1B1B1E),
                        border: Border.all(color: const Color(0x1FFFFFFF)),
                        image: signed && app.userPhoto != null
                            ? DecorationImage(
                                image: NetworkImage(app.userPhoto!), fit: BoxFit.cover)
                            : null,
                      ),
                      child: signed && app.userPhoto != null
                          ? null
                          : Icon(Icons.person_rounded, color: c.text, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              signed
                                  ? ((app.userName ?? '').isEmpty ? 'Google' : app.userName!)
                                  : 'Google',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(signed ? (app.userEmail ?? '') : context.t('not_signed'),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Color(0xFF85858F), fontSize: 13)),
                        ],
                      ),
                    ),
                    if (!signed)
                      Text(context.t('sign_in_short'),
                          style: const TextStyle(
                              color: _kGold, fontSize: 14, fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          FadeSlide(
            delay: 40,
            child: _Group(children: [
              _Tile(
                icon: Icons.dark_mode_outlined,
                tint: _kGold,
                title: context.t('appearance'),
                subtitle: context.t(const {
                      'dark': 'tm_dark',
                      'light': 'tm_light',
                      'auto': 'tm_auto',
                    }[mode] ??
                    'tm_system'),
                onTap: () => _open(context, 'appearance'),
              ),
              _Tile(
                icon: Icons.language_rounded,
                tint: _kGold,
                title: context.t('language'),
                subtitle: _langNames[app.lang] ?? app.lang.toUpperCase(),
                onTap: () => _open(context, 'language'),
              ),
              _Tile(
                icon: Icons.notifications_none_rounded,
                tint: _kGold,
                title: context.t('reminders'),
                subtitle: context.t('hub_notif_sub'),
                onTap: () => _open(context, 'notifications'),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 80,
            child: _Group(children: [
              _Tile(
                icon: Icons.auto_awesome_outlined,
                tint: _kGold,
                title: context.t('ai_section'),
                subtitle: context.t('hub_ai_sub'),
                onTap: () => _open(context, 'ai'),
              ),
              _Tile(
                icon: Icons.cloud_outlined,
                tint: _kGold,
                title: context.t('data'),
                subtitle: context.t('hub_data_sub'),
                onTap: () => _open(context, 'data'),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 120,
            child: _Group(children: [
              _Tile(
                icon: Icons.verified_user_outlined,
                tint: _kGold,
                title: context.t('security'),
                subtitle: context.t('hub_security_sub'),
                onTap: () => _open(context, 'security'),
              ),
              _Tile(
                icon: Icons.help_outline_rounded,
                tint: _kGold,
                title: context.t('hub_help'),
                subtitle: context.t('hub_help_sub'),
                onTap: () => _chooseMail(context),
              ),
              _Tile(
                icon: Icons.info_outline_rounded,
                tint: _kGold,
                badge: app.updateAvailable,
                title: context.t('about_section'),
                subtitle: 'Rosella v$kAppVersion',
                onTap: () => _open(context, 'about'),
              ),
            ]),
          ),
          if (signed) ...[
            const SizedBox(height: 14),
            FadeSlide(
              delay: 160,
              child: _Group(children: [
                _Tile(
                  icon: Icons.logout_rounded,
                  tint: _kGold,
                  title: context.t('sign_out'),
                  onTap: () => app.googleSignOut(),
                ),
              ]),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => section.isEmpty ? _hub(context) : _sub(context);
}

/// Wave artwork + the wordmark and tagline at the top of the settings hub.
class _HubHeader extends StatelessWidget {
  const _HubHeader();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 190,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(child: CustomPaint(painter: _WavePainter())),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Rosella',
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'serif',
                      fontSize: 46,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(width: 46, height: 1, color: const Color(0x33FFFFFF)),
                    const SizedBox(width: 12),
                    const Text('Dream  •  Track  •  Discover',
                        style: TextStyle(color: Color(0xFF9A9AA3), fontSize: 13.5)),
                    const SizedBox(width: 12),
                    Container(width: 46, height: 1, color: const Color(0x33FFFFFF)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final a = Path()
      ..moveTo(0, h * 0.48)
      ..cubicTo(w * 0.28, h * 0.12, w * 0.55, h * 0.70, w, h * 0.28);
    final b = Path()
      ..moveTo(0, h * 0.86)
      ..cubicTo(w * 0.30, h * 0.46, w * 0.62, h * 1.0, w, h * 0.62);
    for (final e in [(a, 0.55), (b, 0.28)]) {
      final fill = Path.from(e.$1)
        ..lineTo(w, 0)
        ..lineTo(0, 0)
        ..close();
      canvas.drawPath(
          fill,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white.withOpacity(0.0), Colors.white.withOpacity(0.045 * e.$2)],
            ).createShader(Rect.fromLTWH(0, 0, w, h)));
      canvas.drawPath(
          e.$1,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.4
            ..shader = LinearGradient(colors: [
              Colors.white.withOpacity(0.0),
              Colors.white.withOpacity(0.5 * e.$2),
              Colors.white.withOpacity(0.0),
            ]).createShader(Rect.fromLTWH(0, 0, w, h)));
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter o) => false;
}

// ------------------------------------------------------------------ pieces
// black + light champagne gold (design option B)
const Color _kGold = Color(0xFFD9BF8C);
const Color _kGoldHi = Color(0xFFEBDAB4);
const Color _kGoldLo = Color(0xFFB59B68);
const LinearGradient _kGoldGrad = LinearGradient(
    begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [_kGoldHi, _kGoldLo]);
const Color _kOnGold = Color(0xFF1A1610);

class _ProfileCard extends StatelessWidget {
  final VoidCallback onSignIn;
  const _ProfileCard({required this.onSignIn});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final signed = app.userEmail != null;
    final name = signed ? (app.userName ?? '') : context.t('account');
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1B1B1E), Color(0xFF0B0B0C)],
        ),
        border: Border.all(color: const Color(0x1FFFFFFF)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.nightlight_round, size: 15, color: _kGold),
              const SizedBox(width: 10),
              const Text('R O S E L L A',
                  style: TextStyle(
                      color: _kGold, fontSize: 11.5, fontWeight: FontWeight.w700, letterSpacing: 1)),
              const Spacer(),
              Container(
                width: 34,
                height: 26,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [_kGoldHi, _kGoldLo]),
                ),
              ),
            ],
          ),
          const SizedBox(height: 26),
          Text(name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: _kGoldHi,
                  fontFamily: 'serif',
                  fontSize: 30,
                  fontWeight: FontWeight.w800)),
          if (signed)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(app.userEmail ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF85858F), fontSize: 12.5)),
            ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: Text(
                    '${app.dreams.length} ${context.t('dreams_count').toUpperCase()}'
                    '  ·  ${app.streakDays} ${context.t('streak_short')}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Color(0xFFB4B4BC),
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.1)),
              ),
              const SizedBox(width: 10),
              if (signed)
                Pressable(
                  onTap: () => app.googleSignOut(),
                  scale: 0.9,
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: _kGold.withOpacity(0.5))),
                    child: const Icon(Icons.logout_rounded, color: _kGold, size: 19),
                  ),
                )
              else
                Pressable(
                  onTap: onSignIn,
                  scale: 0.95,
                  child: Container(
                    height: 42,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(21),
                      gradient: _kGoldGrad,
                      boxShadow: [BoxShadow(color: _kGold.withOpacity(0.28), blurRadius: 14)],
                    ),
                    child: Text(context.t('sign_in_short'),
                        style: const TextStyle(
                            color: _kOnGold, fontSize: 15, fontWeight: FontWeight.w800)),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.fromSTEB(6, 6, 6, 10),
        child: Row(
          children: [
            Text(text.toUpperCase(),
                style: const TextStyle(
                    color: _kGoldLo,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.2)),
            const SizedBox(width: 12),
            Expanded(
              child: Container(height: 1, color: _kGold.withOpacity(0.16)),
            ),
          ],
        ),
      );
}

/// Rounded group of compact rows separated by thin dividers (iOS style).
/// Same faint card as _Group, for custom content.
class _Card extends StatelessWidget {
  final EdgeInsets padding;
  final Widget child;
  const _Card({required this.padding, required this.child});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: c.isDark
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF151517), Color(0xFF09090A)])
            : null,
        color: c.isDark ? null : c.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: c.isDark ? const Color(0x1AFFFFFF) : al(c.text, 0.08)),
      ),
      child: child,
    );
  }
}

class _Group extends StatelessWidget {
  final List<Widget> children;
  const _Group({required this.children});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    // one faint card per section: bg white 3.5%, 1px border white 7%, radius 22
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        gradient: c.isDark
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF151517), Color(0xFF09090A)])
            : null,
        color: c.isDark ? null : c.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: c.isDark ? const Color(0x1AFFFFFF) : al(c.text, 0.08)),
      ),
      child: Column(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0)
              Divider(
                  color: c.isDark ? const Color(0xFF1F1F25) : al(c.text, 0.10),
                  height: 1,
                  indent: 54,
                  endIndent: 0,
                  thickness: 1),
            children[i],
          ],
        ],
      ),
    );
  }
}

class _IconBox extends StatelessWidget {
  final IconData icon;
  final Color tint;
  final bool danger;
  const _IconBox(this.icon, this.tint, {this.danger = false});

  @override
  Widget build(BuildContext context) => Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF0D0D0F),
          border: Border.all(
              color: danger ? const Color(0x55FF6B7D) : const Color(0x1FFFFFFF)),
        ),
        child: Icon(icon,
            color: danger ? const Color(0xFFFF6B7D) : const Color(0xFFC4C4CD), size: 19),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final Color tint;
  final String title;
  final Color? titleColor;
  final String? subtitle;
  final Color? subtitleColor;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool badge;
  const _Tile({
    this.badge = false,
    required this.icon,
    required this.tint,
    required this.title,
    this.titleColor,
    this.subtitle,
    this.subtitleColor,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 11),
      child: Row(
        children: [
          _IconBox(icon, tint, danger: titleColor != null),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(title,
                          style: TextStyle(
                              color: titleColor ?? c.text,
                              fontSize: 16,
                              fontWeight: FontWeight.w600)),
                    ),
                    if (badge) ...[
                      const SizedBox(width: 8),
                      Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                            color: Color(0xFFFF3B30), shape: BoxShape.circle),
                      ),
                    ],
                  ],
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(subtitle!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: subtitleColor ?? const Color(0xFF85858F),
                            fontSize: 12.5,
                            height: 1.25)),
                  ),
              ],
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 10), trailing!],
          if (onTap != null && (trailing == null || trailing is Text)) ...[
            const SizedBox(width: 4),
            Icon(
                Directionality.of(context) == TextDirection.rtl
                    ? Icons.chevron_left_rounded
                    : Icons.chevron_right_rounded,
                color: c.dim,
                size: 22),
          ],
        ],
      ),
    );
    if (onTap == null) return row;
    return Pressable(onTap: onTap, scale: 0.985, child: row);
  }
}

String _hm(int m) => fmtHm(m ~/ 60, m % 60);

class _SwitchRow extends StatelessWidget {
  final IconData icon;
  final Color? tint;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({
    required this.icon,
    this.tint,
    required this.title,
    this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return _Tile(
      icon: icon,
      tint: tint ?? c.a,
      title: title,
      subtitle: subtitle,
      onTap: () {
        Haptics.selection();
        onChanged(!value);
      },
      trailing: Transform.scale(
        scale: 0.9,
        child: Switch(
        value: value,
        onChanged: (v) {
          Haptics.selection();
          onChanged(v);
        },
        activeTrackColor: _kGold,
        inactiveTrackColor: c.isDark ? const Color(0xFF1B1B20) : c.surfaceHi,
        thumbColor: WidgetStateProperty.resolveWith<Color>((st) =>
            st.contains(WidgetState.selected) ? const Color(0xFF16161A) : const Color(0xFF8E8E96)),
        trackOutlineColor: const WidgetStatePropertyAll<Color>(Colors.transparent),
      ),
      ),
    );
  }
}

/// Two big selectable cards (used for card shape and mic position).
class _ChoiceRow extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final List<(String, IconData, String)> options;
  const _ChoiceRow(
      {required this.value, required this.onChanged, required this.options});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Row(
      children: [
        for (var i = 0; i < options.length; i++) ...[
          if (i > 0) const SizedBox(width: 12),
          Expanded(
            child: Pressable(
              scale: 0.96,
              onTap: () {
                Haptics.selection();
                onChanged(options[i].$1);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                height: 76,
                decoration: BoxDecoration(
                  gradient: value == options[i].$1
                      ? c.gradient
                      : flatGradient(al(c.surface, c.isDark ? 0.75 : 0.95)),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: value == options[i].$1 ? Colors.transparent : c.border),
                  boxShadow: value == options[i].$1
                      ? [BoxShadow(color: al(c.a, 0.4), blurRadius: 18, offset: const Offset(0, 8))]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(options[i].$2,
                        size: 28,
                        color: value == options[i].$1 ? onAccent(c.a, c.b) : c.dim),
                    const SizedBox(height: 8),
                    Text(options[i].$3,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: value == options[i].$1 ? onAccent(c.a, c.b) : c.text)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

/// A theme preview card: miniature app mock on the theme's gradient.
class _ThemeCard extends StatelessWidget {
  final AppPalette palette;
  final bool selected;
  final String label;
  final VoidCallback onTap;
  const _ThemeCard(
      {required this.palette,
      required this.selected,
      required this.label,
      required this.onTap});

  static const List<Color> _dyn = [
    Color(0xFF12C2D6),
    Color(0xFF2F6BFF),
    Color(0xFF5B3DF5),
    Color(0xFFB23CFF),
    Color(0xFFE23DA8),
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final isDyn = palette.id == 'dynamic';
    final fg = isDyn ? Colors.white : onAccent(palette.a, palette.b);
    final grad = isDyn
        ? const LinearGradient(
            colors: _dyn, begin: Alignment.topLeft, end: Alignment.bottomRight)
        : LinearGradient(
            colors: [palette.a, palette.b],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight);
    return Pressable(
      onTap: onTap,
      scale: 0.96,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        height: 118,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: grad,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
              color: selected ? al(fg, 0.95) : al(fg, 0.0), width: 2.5),
          boxShadow: [
            BoxShadow(
              color: al(palette.a, selected ? 0.55 : 0.22),
              blurRadius: selected ? 22 : 12,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            // mini app mock
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      width: 46,
                      height: 7,
                      decoration: BoxDecoration(
                          color: al(fg, 0.85),
                          borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 8),
                  Container(
                      height: 22,
                      decoration: BoxDecoration(
                          color: al(Colors.black, 0.22),
                          borderRadius: BorderRadius.circular(9))),
                ],
              ),
            ),
            PositionedDirectional(
              start: 0,
              bottom: 0,
              end: 30,
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: fg, fontSize: 14.5, fontWeight: FontWeight.w800)),
            ),
            PositionedDirectional(
              end: 0,
              bottom: 0,
              child: AnimatedScale(
                scale: selected ? 1 : 0,
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutBack,
                child: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: fg),
                  child: Icon(Icons.check_rounded,
                      size: 16, color: isDyn ? palette.a : palette.b),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shows the chosen language; tapping opens a scrollable list of every language.
class _LangSegment extends StatelessWidget {
  final String current;
  final ValueChanged<String> onChanged;
  const _LangSegment({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      scale: 0.98,
      onTap: () async {
        Haptics.selection();
        final v = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _LangSheet(current: current),
        );
        if (v != null) onChanged(v);
      },
      child: Container(
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          gradient: c.gradient,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(children: [
          const Icon(Icons.language_rounded, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(languageName(current),
                style: const TextStyle(
                    color: Colors.white, fontSize: 15.5, fontWeight: FontWeight.w800)),
          ),
          const Icon(Icons.unfold_more_rounded, color: Colors.white70, size: 20),
        ]),
      ),
    );
  }
}

class _LangSheet extends StatelessWidget {
  final String current;
  const _LangSheet({required this.current});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final h = MediaQuery.sizeOf(context).height;
    return Container(
      constraints: BoxConstraints(maxHeight: h * 0.78),
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 10),
          SizedBox(
            height: 46,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                          color: c.dim.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(2))),
                ),
                PositionedDirectional(
                  end: 14,
                  top: 0,
                  child: RoundIconButton(
                      icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
                ),
              ],
            ),
          ),
          Flexible(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 16),
              children: [
                for (final o in kLanguages)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Pressable(
                      scale: 0.98,
                      onTap: () => Navigator.of(context).pop(o[0]),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: current == o[0] ? c.a.withOpacity(0.16) : c.surfaceHi,
                          border: Border.all(
                              color: current == o[0] ? c.a : Colors.transparent, width: 1.2),
                        ),
                        child: Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(o[1],
                                  style: TextStyle(
                                      color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                              Text(o[2], style: TextStyle(color: c.dim, fontSize: 12)),
                            ]),
                          ),
                          if (current == o[0]) Icon(Icons.check_circle_rounded, color: c.a),
                        ]),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
