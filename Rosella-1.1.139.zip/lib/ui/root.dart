import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/nav_bus.dart';
import '../core/theme.dart';
import 'aurora.dart';
import '../services/notifier.dart';
import 'shell.dart';
import 'warp_entry.dart';
import 'welcome_flow.dart';
import 'widgets.dart';

/// Splash (short, never blocks) → first-run onboarding → main shell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splash = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    splashShowing.value = true;
    _t = Timer(const Duration(milliseconds: 1500), () {
      splashShowing.value = false;
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final onboarded = context.select<AppState, bool>((s) => s.onboarded);
    final welcomed = context.select<AppState, bool>((s) => s.welcomed);
    return Stack(
      children: [
        Positioned.fill(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 260),
            child: onboarded
                ? const Shell(key: ValueKey('shell'))
                : welcomed
                    ? const OnboardingPage(key: ValueKey('onb'))
                    : const WelcomeFlow(key: ValueKey('welcome')),
          ),
        ),
        ValueListenableBuilder<bool>(
          valueListenable: entryReveal,
          builder: (_, on, __) =>
              on ? const Positioned.fill(child: _RevealFlash()) : const SizedBox.shrink(),
        ),
        Positioned.fill(
          child: IgnorePointer(
            ignoring: !_splash,
            child: AnimatedOpacity(
              opacity: _splash ? 1 : 0,
              duration: const Duration(milliseconds: 420),
              curve: Curves.easeOut,
              child: const _Splash(),
            ),
          ),
        ),
      ],
    );
  }
}

/// White flash that melts away to reveal the app after the onboarding's last animation.
class _RevealFlash extends StatelessWidget {
  const _RevealFlash();

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 1.0, end: 0.0),
      duration: const Duration(milliseconds: 1300),
      curve: Curves.easeInOut,
      onEnd: () => entryReveal.value = false,
      builder: (_, v, __) => IgnorePointer(
        child: Opacity(
          opacity: v,
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                radius: 0.4 + 1.4 * (1 - v),
                colors: const [Colors.white, Colors.white, Color(0x00FFFFFF)],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Opening: stars fade in, the wordmark appears and "by Suhaib" fades in underneath.
class _Splash extends StatefulWidget {
  const _Splash();

  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
        ..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static double _seg(double t, double a, double b) =>
      ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
      color: Colors.black,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final stars = Curves.easeOut.transform(_seg(t, 0.0, 0.3));
          final glow = Curves.easeOut.transform(_seg(t, 0.2, 0.7));
          final by = Curves.easeOut.transform(_seg(t, 0.82, 1.0));
          return Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(
                  child: CustomPaint(
                      painter: _HorizonGlow(
                    Curves.easeOutCubic.transform(_seg(t, 0.0, 0.6)),
                    Curves.easeInOutCubic.transform(_seg(t, 0.35, 1.0)),
                  )),
                ),
              ),
              Positioned.fill(
                child: RepaintBoundary(
                  child: Opacity(
                    opacity: stars,
                    child: const CustomPaint(painter: _SplashStars()),
                  ),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _SplashMark(t: t),
                    const SizedBox(height: 10),
                    Opacity(
                      opacity: by,
                      child: Text('by Suhaib',
                          style: TextStyle(
                            fontFamily: 'serif',
                            color: al(const Color(0xFFD9D9DE), 0.8),
                            fontSize: 16,
                            letterSpacing: 1.4,
                          )),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    ));
  }
}

class _SplashStars extends CustomPainter {
  const _SplashStars();

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(7);
    final p = Paint();
    for (var i = 0; i < 140; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final rad = 0.4 + r.nextDouble() * 0.9;
      p.color = Colors.white.withAlpha(30 + r.nextInt(120));
      canvas.drawCircle(Offset(x, y), rad, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// "Developed by Suhaib" with the flowing dynamic colours.
class _Credit extends StatelessWidget {
  final double size;
  const _Credit({required this.size});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: DynamicText('Developed by Suhaib',
          fontSize: size, letterSpacing: 0.8, weight: FontWeight.w800),
    );
  }
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pc = PageController();
  int _i = 0;
  bool _warping = false;

  static const int _n = 10; // page 0 = dark/light, then 9 features
  static const _icons = [
    Icons.mic_rounded,
    Icons.psychology_rounded,
    Icons.forum_rounded,
    Icons.auto_awesome_rounded,
    Icons.headphones_rounded,
    Icons.fingerprint_rounded,
    Icons.vibration_rounded,
    Icons.notifications_active_rounded,
    Icons.palette_rounded,
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  Future<void> _next() async {
    // page 8 is the notifications page: ask for the permission when the user continues from it
    if (_i == 8) {
      try {
        await Notifier.requestPermission();
      } catch (_) {}
      if (!mounted) return;
    }
    if (_i >= _n - 1) {
      setState(() => _warping = true); // stars rush at you, flash, "Welcome to Rosella"
    } else {
      _pc.nextPage(
          duration: const Duration(milliseconds: 380), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    // follows the light / dark choice made on the first page, instantly
    final dark = context.select<AppState, bool>((st) => st.dark);
    return Theme(
      data: buildTheme('onyx', dark),
      child: Builder(builder: (context) => _body(context)),
    );
  }

  Widget _body(BuildContext context) {
    final c = context.colors;
    final last = _i == _n - 1;
    final dark = c.isDark;
    return Scaffold(
      backgroundColor: dark ? Colors.black : c.bg,
      body: Stack(
        children: [
          if (dark) const Positioned.fill(child: AuroraBackground()),
          if (dark) const Positioned.fill(child: StarField()),
          IgnorePointer(
            ignoring: _warping,
            child: AnimatedOpacity(
              opacity: _warping ? 0 : 1,
              duration: const Duration(milliseconds: 650),
              curve: Curves.easeOut,
              child: SafeArea(
            child: Column(
              children: [
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                    child: AnimatedOpacity(
                      opacity: last ? 0 : 1,
                      duration: const Duration(milliseconds: 200),
                      child: TextButton(
                        onPressed:
                            last ? null : () => context.read<AppState>().completeOnboarding(),
                        child: Text(context.t('skip'),
                            style: TextStyle(
                                color: c.dim, fontSize: 15, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    itemCount: _n,
                    onPageChanged: (v) => setState(() => _i = v),
                    itemBuilder: (_, i) =>
                        i == 0 ? _modePage(context) : _featurePage(context, i - 1),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < _n; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _i == i ? 22 : 7,
                        height: 7,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: _i == i ? c.text : al(c.text, 0.25),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 22, 24, 26),
                  child: GradientButton(
                    label: context.t(last ? 'start' : 'next'),
                    icon: last ? Icons.check_rounded : Icons.arrow_forward_rounded,
                    expand: true,
                    onTap: _next,
                  ),
                ),
              ],
            ),
          ),
            ),
          ),
          if (_warping)
            Positioned.fill(
              child: WarpEntry(onDone: () => context.read<AppState>().completeOnboarding()),
            ),
        ],
      ),
    );
  }

  Widget _modePage(BuildContext context) {
    final app = context.read<AppState>();
    Widget card(bool dark, IconData icon, String key) {
      return Expanded(
        child: Selector<AppState, bool>(
          selector: (_, st) => st.dark,
          builder: (context, isDark, _) {
            final sel = isDark == dark;
            final cc = context.colors;
            final bg = dark ? const Color(0xFF000000) : const Color(0xFFFFFFFF);
            final fg = dark ? const Color(0xFFE8E8EC) : const Color(0xFF1A1A20);
            return Pressable(
              onTap: () => app.setDark(dark),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                height: 150,
                decoration: BoxDecoration(
                  color: sel ? (dark ? const Color(0xFF1C1C22) : const Color(0xFFF1F1F5)) : bg,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(
                      color: sel ? cc.text : al(dark ? Colors.white : Colors.black, 0.18),
                      width: sel ? 3 : 1.5),
                  boxShadow: sel
                      ? [BoxShadow(color: al(cc.text, 0.18), blurRadius: 24)]
                      : const [],
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icon, size: 42, color: sel ? fg : al(fg, 0.6)),
                          const SizedBox(height: 12),
                          Text(context.t(key),
                              style: TextStyle(
                                  color: sel ? fg : al(fg, 0.6),
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: AnimatedScale(
                        scale: sel ? 1 : 0,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutBack,
                        child: Container(
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                              color: cc.text, shape: BoxShape.circle),
                          child: Icon(Icons.check_rounded,
                              size: 18, color: cc.bg),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const _OrbIcon(icon: Icons.brightness_6_rounded, size: 96, variant: 0),
          const SizedBox(height: 26),
          _Reveal(
            delay: 200,
            child: Text(context.t('choose_mode'),
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: context.colors.text,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    height: 1.4)),
          ),
          const SizedBox(height: 8),
          _Reveal(
            delay: 380,
            child: Text(context.t('choose_mode_sub'),
                textAlign: TextAlign.center,
                style: TextStyle(color: context.colors.dim, fontSize: 14.5, height: 1.5)),
          ),
          const SizedBox(height: 26),
          _Reveal(
            delay: 500,
            child: Row(children: [
              card(true, Icons.dark_mode_rounded, 'mode_dark'),
              const SizedBox(width: 14),
              card(false, Icons.light_mode_rounded, 'mode_light'),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _featurePage(BuildContext context, int i) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _OrbIcon(icon: _icons[i], size: 112, variant: i + 1),
          const SizedBox(height: 34),
          _Reveal(
            delay: 250,
            child: Text(context.t('ob${i + 1}_t'),
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: context.colors.text,
                    fontSize: 27,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3)),
          ),
          const SizedBox(height: 14),
          _Reveal(
            delay: 550,
            child: Text(context.t('ob${i + 1}_d'),
                textAlign: TextAlign.center,
                style: TextStyle(color: c.dim, fontSize: 16, height: 1.6)),
          ),
        ],
      ),
    );
  }
}

/// Fades and slides its child up slowly once, after [delay] ms (staggered entrances).
class _Reveal extends StatelessWidget {
  final Widget child;
  final int delay;
  const _Reveal({required this.child, this.delay = 0});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 1100 + delay),
      curve: Curves.linear,
      builder: (_, v, ch) {
        final t = Curves.easeOutCubic
            .transform(((v * (1100 + delay) - delay) / 1100).clamp(0.0, 1.0));
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, 22 * (1 - t)), child: ch),
        );
      },
      child: child,
    );
  }
}

/// Icon in a dark disc that floats slowly, with a breathing glow, two turning dashed rings
/// and small dots orbiting it. One ticker, repaints only this widget.
class _OrbIcon extends StatefulWidget {
  final IconData icon;
  final double size;
  final int variant; // every page has its own motion
  const _OrbIcon({required this.icon, required this.size, this.variant = 0});

  @override
  State<_OrbIcon> createState() => _OrbIconState();
}

class _OrbIconState extends State<_OrbIcon> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final box = s * 1.9;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 1400),
      curve: Curves.easeOutBack,
      builder: (_, enter, child) => Opacity(
        opacity: enter.clamp(0.0, 1.0),
        child: Transform.scale(scale: 0.6 + 0.4 * enter, child: child),
      ),
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            final oc = context.colors;
            final ink = oc.isDark ? Colors.white : const Color(0xFF15151A);
            final t = _c.value;
            final v = widget.variant;
            final w = math.sin(t * math.pi * 2 * 2); // two slow cycles per loop
            // icon motion differs per page: float, pulse, sway, spin, hop…
            final bob = (v == 0 || v == 3 || v == 6) ? w * 6 : (v == 9 ? w * 3 : 0.0);
            final iconScale = (v == 1 || v == 4 || v == 7) ? 1 + 0.06 * w : 1.0;
            final iconTurn = switch (v) {
              2 => 0.12 * w,
              5 => t * math.pi * 2 * 2,
              8 => 0.18 * math.sin(t * math.pi * 2 * 3),
              _ => 0.0,
            };
            final breathe = 0.5 + 0.5 * math.sin(t * math.pi * 6);
            return SizedBox(
              width: box,
              height: box,
              child: Stack(alignment: Alignment.center, children: [
                CustomPaint(size: Size(box, box), painter: _OrbPainter(t, s, ink, widget.variant)),
                Transform.translate(
                  offset: Offset(0, bob),
                  child: Transform.rotate(
                    angle: iconTurn,
                    child: Transform.scale(
                      scale: iconScale,
                      child: Container(
                    width: s,
                    height: s,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: oc.isDark ? const Color(0xFF000000) : const Color(0xFFFFFFFF),
                      border: Border.all(color: al(ink, 0.18 + 0.12 * breathe)),
                      boxShadow: [
                        BoxShadow(
                            color: al(ink, 0.08 + 0.10 * breathe),
                            blurRadius: 30 + 20 * breathe,
                            spreadRadius: 1),
                      ],
                    ),
                    child: Icon(widget.icon, size: s * 0.46, color: oc.isDark ? const Color(0xFFE8E8EC) : const Color(0xFF15151A)),
                  ),
                    ),
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double t;
  final double s;
  final Color ink;
  final int v;
  _OrbPainter(this.t, this.s, this.ink, this.v);

  static const double _tau = math.pi * 2;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = ink.withOpacity(0.10);
    final fill = Paint();
    switch (v) {
      case 1: // soft ripples spreading outwards
        for (var k = 0; k < 3; k++) {
          final p = ((t * 4) + k / 3) % 1.0;
          line
            ..strokeWidth = 1.4
            ..color = ink.withOpacity(0.28 * (1 - p));
          canvas.drawCircle(c, s * (0.62 + 0.62 * p), line);
        }
        break;
      case 2: // radar sweep
        final r = s * 1.0;
        line.color = ink.withOpacity(0.10);
        canvas.drawCircle(c, r, line);
        canvas.drawCircle(c, r * 0.72, line);
        final a = t * _tau * 2;
        fill.shader = SweepGradient(
          startAngle: 0,
          endAngle: _tau,
          transform: GradientRotation(a - 1.2),
          colors: [ink.withOpacity(0), ink.withOpacity(0), ink.withOpacity(0.20)],
          stops: const [0.0, 0.8, 1.0],
        ).createShader(Rect.fromCircle(center: c, radius: r));
        canvas.drawCircle(c, r, fill);
        break;
      case 3: // particles rising
        for (var i = 0; i < 14; i++) {
          final seed = (i * 0.6180339) % 1.0;
          final p = (t * 3 + seed) % 1.0;
          final x = c.dx + (seed - 0.5) * s * 1.7 + math.sin((p + seed) * _tau) * 6;
          final y = c.dy + s * 0.9 - p * s * 1.8;
          fill.shader = null;
          fill.color = ink.withOpacity(0.5 * math.sin(p * math.pi));
          canvas.drawCircle(Offset(x, y), 1.4 + 1.8 * seed, fill);
        }
        break;
      case 4: // two tilted elliptical orbits, one dot each
        for (var k = 0; k < 2; k++) {
          canvas.save();
          canvas.translate(c.dx, c.dy);
          canvas.rotate(k == 0 ? 0.5 : -0.5);
          final rect = Rect.fromCenter(center: Offset.zero, width: s * 1.9, height: s * 0.9);
          line.color = ink.withOpacity(0.14);
          canvas.drawOval(rect, line);
          final a = t * _tau * 2 * (k == 0 ? 1 : -1) + k * 2;
          fill.shader = null;
          fill.color = ink.withOpacity(0.7);
          canvas.drawCircle(Offset(math.cos(a) * s * 0.95, math.sin(a) * s * 0.45), 3.2, fill);
          canvas.restore();
        }
        break;
      case 5: // four-point sparkles blinking around
        for (var i = 0; i < 6; i++) {
          final a = i * _tau / 6 + 0.4;
          final r = s * (0.85 + 0.12 * (i % 2));
          final p = (math.sin((t * 4 + i / 6) * _tau) + 1) / 2;
          final pt = c + Offset(math.cos(a), math.sin(a)) * r;
          final len = 3 + 7 * p;
          fill.shader = null;
          fill.color = ink.withOpacity(0.15 + 0.6 * p);
          final path = Path()
            ..moveTo(pt.dx, pt.dy - len)
            ..quadraticBezierTo(pt.dx, pt.dy, pt.dx + len, pt.dy)
            ..quadraticBezierTo(pt.dx, pt.dy, pt.dx, pt.dy + len)
            ..quadraticBezierTo(pt.dx, pt.dy, pt.dx - len, pt.dy)
            ..quadraticBezierTo(pt.dx, pt.dy, pt.dx, pt.dy - len);
          canvas.drawPath(path, fill);
        }
        break;
      case 6: // radial equaliser bars
        const bars = 36;
        for (var i = 0; i < bars; i++) {
          final a = i * _tau / bars;
          final h = 4 + 10 * (0.5 + 0.5 * math.sin((t * 6 + i / bars * 3) * _tau));
          final r0 = s * 0.74;
          line
            ..strokeWidth = 2
            ..strokeCap = StrokeCap.round
            ..color = ink.withOpacity(0.22);
          canvas.drawLine(c + Offset(math.cos(a), math.sin(a)) * r0,
              c + Offset(math.cos(a), math.sin(a)) * (r0 + h), line);
        }
        break;
      case 7: // dots spiralling outwards
        for (var i = 0; i < 18; i++) {
          final p = ((t * 2) + i / 18) % 1.0;
          final a = p * _tau * 1.5 + i * 0.35;
          final r = s * (0.58 + 0.5 * p);
          fill.shader = null;
          fill.color = ink.withOpacity(0.5 * math.sin(p * math.pi));
          canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * r, 2.2, fill);
        }
        break;
      case 8: // three arcs turning at different speeds
        for (var k = 0; k < 3; k++) {
          line
            ..strokeWidth = 2
            ..strokeCap = StrokeCap.round
            ..color = ink.withOpacity(0.30 - 0.07 * k);
          final r = s * (0.72 + 0.17 * k);
          final a = t * _tau * (k + 1) * (k.isEven ? 1 : -1);
          canvas.drawArc(Rect.fromCircle(center: c, radius: r), a, 1.5 - 0.3 * k, false, line);
        }
        break;
      case 9: // diamonds turning inside each other
        for (var k = 0; k < 3; k++) {
          canvas.save();
          canvas.translate(c.dx, c.dy);
          canvas.rotate(math.pi / 4 + t * _tau * (k.isEven ? 1 : -1));
          line
            ..strokeWidth = 1.2
            ..color = ink.withOpacity(0.18 - 0.04 * k);
          final h = s * (0.62 + 0.14 * k);
          canvas.drawRRect(
              RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: h * 1.5, height: h * 1.5),
                  const Radius.circular(10)),
              line);
          canvas.restore();
        }
        break;
      default: // 0: two dashed rings and orbiting dots
        for (var k = 0; k < 2; k++) {
          final r = s * (0.78 + 0.26 * k);
          final dir = k == 0 ? 1.0 : -1.0;
          final start = t * _tau * dir * (k == 0 ? 1 : 0.6);
          const dashes = 28;
          for (var i = 0; i < dashes; i++) {
            final a = start + i * (_tau / dashes);
            canvas.drawArc(Rect.fromCircle(center: c, radius: r), a, 0.09, false, line);
          }
        }
        for (var i = 0; i < 3; i++) {
          final a = t * _tau * (i.isEven ? 1 : -1) + i * 2.1;
          final r = s * (0.78 + 0.26 * (i % 2));
          final p = c + Offset(math.cos(a), math.sin(a)) * r;
          fill.shader = null;
          fill.color = ink.withOpacity(0.55);
          canvas.drawCircle(p, 2.6, fill);
          fill.color = ink.withOpacity(0.12);
          canvas.drawCircle(p, 7, fill);
        }
    }
  }

  @override
  bool shouldRepaint(_OrbPainter o) => o.t != t || o.ink != ink || o.v != v;
}

/// Crescent, then the letters of "rosella" appearing one after another (tinted blue → white).
class _SplashMark extends StatelessWidget {
  final double t;
  const _SplashMark({required this.t});

  static const _word = 'rosella';
  static const _tint = Color(0xFF7FA8FF);

  @override
  Widget build(BuildContext context) {
    double seg(double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();
    final logo = Curves.easeOut.transform(seg(0.0, 0.3));
    final logoColor = Color.lerp(_tint, Colors.white, Curves.easeIn.transform(seg(0.1, 0.4)))!;
    return SizedBox(
      width: 250,
      height: 75,
      child: FittedBox(
        fit: BoxFit.contain,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // the crescent swings in beside the name: turns, grows and breathes softly
            Opacity(
              opacity: logo,
              child: Transform.rotate(
                angle: -0.9 * (1 - Curves.easeOutCubic.transform(seg(0.0, 0.55))),
                child: Transform.scale(
                  scale: 0.55 + 0.45 * Curves.easeOutBack.transform(seg(0.0, 0.5)) +
                      0.03 * math.sin(t * 6.2832 * 1.5),
                  child: SizedBox(
                      width: 112,
                      height: 112,
                      child: CustomPaint(painter: CrescentPainter(logoColor))),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < _word.length; i++)
                    Builder(builder: (_) {
                      final a = 0.22 + i * 0.07;
                      final o = Curves.easeOut.transform(seg(a, a + 0.14));
                      final col = Color.lerp(_tint, Colors.white, Curves.easeIn.transform(seg(a + 0.04, a + 0.3)))!;
                      return Opacity(
                        opacity: o,
                        child: Text(_word[i],
                            style: TextStyle(
                              fontFamily: 'Inter',
                              color: col,
                              fontSize: 92,
                              fontWeight: FontWeight.w400,
                              letterSpacing: 2,
                              height: 1.1,
                              decoration: TextDecoration.none,
                            )),
                      );
                    }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A glowing planet rim: it appears at the bottom edge, then glides smoothly upward.
/// (Layered strokes instead of a blur mask: much cheaper to paint every frame.)
class _HorizonGlow extends CustomPainter {
  final double p; // appearance 0..1
  final double up; // upward glide 0..1
  const _HorizonGlow(this.p, this.up);

  @override
  void paint(Canvas canvas, Size size) {
    if (p <= 0) return;
    final r = size.width * 1.25;
    final rise = size.height * (0.10 * p + 0.34 * up);
    final c = Offset(size.width / 2, size.height - rise + r);
    final rect = Rect.fromCircle(center: c, radius: r);
    final shader = const LinearGradient(
      colors: [Color(0xFF6D5BFF), Color(0xFF3B82FF), Color(0xFF6D5BFF)],
    ).createShader(rect);
    final fade = 1 - 0.35 * up;
    for (final e in const [(34.0, 0.07), (20.0, 0.13), (9.0, 0.22)]) {
      canvas.drawCircle(
          c,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = e.$1
            ..shader = shader
            ..color = Colors.white.withOpacity(e.$2 * 2.2 * p * fade));
    }
    canvas.drawCircle(c, r - 2, Paint()..color = Colors.black);
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withOpacity(0.85 * p * fade));
  }

  @override
  bool shouldRepaint(covariant _HorizonGlow o) => o.p != p || o.up != up;
}
