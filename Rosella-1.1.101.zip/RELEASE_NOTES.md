## Rosella 1.1.101

- The bottom bar now recedes slightly while you press or drag the glass lens.
- Home-screen widget picker now shows a real preview of each widget size.
- Simpler, fully static first-run language page with a white Rosella wordmark.
- The default Dynamic theme is now saved on first launch, so the app keeps it after the welcome pages.
