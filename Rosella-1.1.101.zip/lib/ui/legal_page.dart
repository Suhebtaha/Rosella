import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'card_route.dart';
import 'widgets.dart';

const String _supportMail = 'contact.somina@gmail.com';

/// Privacy policy / terms of use, written in plain language. Arabic and English; every other
/// app language shows the English text.
class LegalPage extends StatelessWidget {
  final bool privacy;
  const LegalPage({super.key, required this.privacy});

  static void open(BuildContext context, {required bool privacy}) {
    Navigator.of(context).push(CardOpenRoute(builder: (_) => LegalPage(privacy: privacy)));
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final ar = context.watch<AppState>().lang == 'ar';
    final doc = privacy ? (ar ? _privacyAr : _privacyEn) : (ar ? _termsAr : _termsEn);
    final title = privacy ? context.t('privacy_policy') : context.t('terms_of_use');
    return Scaffold(
      backgroundColor: c.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                  child: Row(
                    children: [
                      RoundIconButton(
                          icon: Icons.arrow_back_rounded,
                          onTap: () => Navigator.of(context).maybePop()),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(title,
                            style: TextStyle(
                                color: c.text, fontSize: 24, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(22, 10, 22, 40),
                    children: [
                      Text(doc.updated,
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                      const SizedBox(height: 14),
                      Text(doc.intro,
                          style: TextStyle(color: c.text, fontSize: 15.5, height: 1.65)),
                      for (final s in doc.sections) ...[
                        const SizedBox(height: 26),
                        Text(s.$1,
                            style: TextStyle(
                                color: c.text, fontSize: 17.5, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 8),
                        Text(s.$2,
                            style: TextStyle(color: c.dim, fontSize: 15, height: 1.7)),
                      ],
                      const SizedBox(height: 30),
                      Text(doc.contact,
                          style: TextStyle(color: c.text, fontSize: 15, height: 1.6)),
                      const SizedBox(height: 4),
                      SelectableText(_supportMail,
                          textDirection: TextDirection.ltr,
                          style: TextStyle(
                              color: c.a, fontSize: 15, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Doc {
  final String updated;
  final String intro;
  final List<(String, String)> sections;
  final String contact;
  const _Doc(this.updated, this.intro, this.sections, this.contact);
}

const _privacyEn = _Doc(
  'Last updated: November 2026',
  'Rosella is a private dream journal. Your dreams belong to you, and most of what you write stays on your phone. This page explains, in plain words, what the app stores, what leaves your phone, and what you can control.',
  [
    ('What stays on your phone',
        'Your dreams (titles, text, mood, dates), voice recordings, images you add or generate, your settings and your achievements are stored locally on your device. Rosella has no servers of its own and no account system, so we do not receive or keep your dreams.'),
    ('When something leaves your phone',
        'Only when you use a feature that needs the internet:\n• AI interpretation, dream chat, recaps, search by meaning and year story: the dream text and your question are sent to an AI service (Google Gemini, or Pollinations when no Gemini key is available) to get an answer.\n• Image generation: the description of your dream is sent to an image service (Pollinations or Cloudflare) to create the picture.\n• Voice to text: the recording is sent to a speech service (Google Gemini, Cloudflare Workers AI, or a Kurdish speech service for Kurdish) to be turned into text.\n• Google sign-in and backup (optional): your dreams are saved in a hidden app folder inside your own Google Drive. Only you can open it, and we cannot read it.\n• Updates: the app asks GitHub whether a newer version exists and can download it from there.\nThese services have their own privacy policies. If you prefer nothing to leave your phone, simply do not use these features.'),
    ('Permissions we ask for',
        'Microphone: to record and dictate dreams.\nNotifications: for your reminders.\nFingerprint / screen lock: to lock the app and private dreams.\nInternet: for the features above.\nVibration: for touch feedback.\nInstall apps and battery settings: only so in-app updates and reminders can work. You can refuse any of these in your phone settings.'),
    ('What we do not do',
        'We do not show ads, we do not use analytics or trackers, and we do not sell or share your data with anyone for marketing.'),
    ('Private dreams and locks',
        'Dreams marked private are hidden from the main list and from sharing. The fingerprint lock uses your phone\'s own security; Rosella never sees your fingerprint.'),
    ('Your control',
        'You can edit or delete any dream, delete everything from Settings, export your dreams as a text file, and delete the backup from your Google Drive at any time. Uninstalling the app removes the data stored on your phone.'),
    ('Children',
        'Rosella is not designed for children under 13. If you are a parent and have a concern, please write to us.'),
    ('Changes',
        'If this policy changes, the new version will appear here with a new date.'),
  ],
  'Questions or requests? Write to us at:',
);

const _termsEn = _Doc(
  'Last updated: November 2026',
  'By using Rosella you agree to the simple terms below. Please read them once; they are short.',
  [
    ('Using the app',
        'Rosella is a personal dream journal. You can use it for free for your own personal use. Please do not use it to break the law or to harm others.'),
    ('Your content',
        'Everything you write, record or generate remains yours. You are responsible for what you save and share from the app.'),
    ('AI answers are not advice',
        'Interpretations, chat answers, recaps and images made by AI are for reflection and entertainment only. They can be wrong. They are not medical, psychological, legal or any other professional advice. If you feel unwell or unsafe, please talk to a qualified person. The "Nightmare SOS" breathing tool is a gentle exercise, not a treatment.'),
    ('Images',
        'The app does not allow creating sexual or nude images. Images are generated by third-party services, and results can vary.'),
    ('Third-party services',
        'Some features rely on services such as Google, Cloudflare, Pollinations and GitHub. They can change or stop working, and their own terms apply when you use them.'),
    ('Availability and updates',
        'The app is provided "as is", without promises that it will always work or be free of mistakes. Features can change, and updates may be released from time to time. Please keep a backup of dreams that matter to you.'),
    ('Responsibility',
        'To the extent the law allows, the developer is not responsible for losses caused by using the app, including lost data. We do our best, but please use backups and exports.'),
    ('Changes',
        'We may update these terms. Continuing to use the app after an update means you accept the new version.'),
  ],
  'Questions? Write to us at:',
);

const _privacyAr = _Doc(
  'آخر تحديث: نوفمبر 2026',
  'روسيلا مفكرة أحلام خاصة بك. أحلامك ملك لك، ومعظم ما تكتبه يبقى على هاتفك. نوضّح لك هنا بكلام بسيط ما الذي يحفظه التطبيق، وما الذي يخرج من هاتفك، وما الذي تتحكم به أنت.',
  [
    ('ما الذي يبقى على هاتفك',
        'أحلامك (العناوين والنصوص والمزاج والتواريخ) والتسجيلات الصوتية والصور التي تضيفها أو تولّدها وإعداداتك وإنجازاتك، كلها تُحفظ على جهازك. ليس لروسيلا خوادم خاصة ولا نظام حسابات، لذلك لا نستلم أحلامك ولا نحتفظ بها.'),
    ('متى يخرج شيء من هاتفك',
        'فقط عندما تستخدم ميزة تحتاج إلى الإنترنت:\n• تفسير الأحلام والدردشة والملخصات والبحث بالمعنى وقصة العام: يُرسل نص الحلم وسؤالك إلى خدمة ذكاء اصطناعي (Google Gemini، أو Pollinations إذا لم يكن لديك مفتاح Gemini) للحصول على الإجابة.\n• توليد الصور: يُرسل وصف حلمك إلى خدمة صور (Pollinations أو Cloudflare) لإنشاء الصورة.\n• تحويل الصوت إلى نص: يُرسل التسجيل إلى خدمة تعرّف على الكلام (Google Gemini أو Cloudflare Workers AI، وإلى خدمة كردية مخصصة عندما تكون اللغة كردية).\n• تسجيل الدخول بـ Google والنسخ الاحتياطي (اختياري): تُحفظ أحلامك في مجلد مخفي خاص بالتطبيق داخل Google Drive الخاص بك. أنت وحدك تستطيع فتحه، ولا نستطيع نحن قراءته.\n• التحديثات: يسأل التطبيق موقع GitHub هل يوجد إصدار أحدث، ويستطيع تنزيله منه.\nلهذه الخدمات سياسات خصوصية خاصة بها. وإن كنت تفضّل ألا يخرج شيء من هاتفك، فلا تستخدم هذه الميزات.'),
    ('الأذونات التي نطلبها',
        'الميكروفون: لتسجيل الأحلام وإملائها.\nالإشعارات: للتذكيرات.\nالبصمة أو قفل الشاشة: لقفل التطبيق والأحلام الخاصة.\nالإنترنت: للميزات المذكورة أعلاه.\nالاهتزاز: للإحساس عند اللمس.\nتثبيت التطبيقات وإعدادات البطارية: فقط ليعمل التحديث داخل التطبيق والتذكيرات. يمكنك رفض أي إذن من إعدادات هاتفك.'),
    ('ما الذي لا نفعله',
        'لا نعرض إعلانات، ولا نستخدم أدوات تحليل أو تتبّع، ولا نبيع بياناتك ولا نشاركها مع أحد لأغراض تسويقية.'),
    ('الأحلام الخاصة والقفل',
        'الأحلام التي تجعلها خاصة تختفي من القائمة الرئيسية ومن المشاركة. ويعتمد قفل البصمة على حماية هاتفك نفسه، ولا يرى روسيلا بصمتك أبدًا.'),
    ('تحكّمك ببياناتك',
        'يمكنك تعديل أي حلم أو حذفه، وحذف كل شيء من الإعدادات، وتصدير أحلامك كملف نصي، وحذف النسخة الاحتياطية من Google Drive في أي وقت. وعند حذف التطبيق تُمسح البيانات المخزّنة على هاتفك.'),
    ('الأطفال',
        'لم يُصمَّم روسيلا للأطفال دون 13 عامًا. وإن كنت وليّ أمر ولديك ملاحظة، فراسلنا.'),
    ('التغييرات',
        'إذا تغيّرت هذه السياسة، فستظهر النسخة الجديدة هنا مع تاريخ جديد.'),
  ],
  'لديك سؤال أو طلب؟ راسلنا على:',
);

const _termsAr = _Doc(
  'آخر تحديث: نوفمبر 2026',
  'باستخدامك روسيلا فأنت توافق على الشروط البسيطة التالية. اقرأها مرة واحدة، فهي قصيرة.',
  [
    ('استخدام التطبيق',
        'روسيلا مفكرة أحلام شخصية، ويمكنك استخدامها مجانًا لأغراضك الشخصية. نرجو ألّا تستخدمه لمخالفة القانون أو لإيذاء أحد.'),
    ('محتواك',
        'كل ما تكتبه أو تسجّله أو تولّده يبقى ملكًا لك، وأنت المسؤول عمّا تحفظه وتشاركه من التطبيق.'),
    ('إجابات الذكاء الاصطناعي ليست نصيحة',
        'التفسيرات وإجابات الدردشة والملخصات والصور التي ينتجها الذكاء الاصطناعي هي للتأمل والتسلية فقط، وقد تكون خاطئة. وهي ليست نصيحة طبية ولا نفسية ولا قانونية ولا أي نصيحة متخصصة. إذا شعرت بتعب أو بعدم أمان، فتحدّث مع شخص مختص. وأداة «طوارئ الكوابيس» تمرين تنفّس لطيف وليست علاجًا.'),
    ('الصور',
        'يمنع التطبيق توليد الصور الجنسية أو العارية. وتُولَّد الصور عبر خدمات خارجية، لذلك قد تختلف النتائج.'),
    ('الخدمات الخارجية',
        'تعتمد بعض الميزات على خدمات مثل Google وCloudflare وPollinations وGitHub. وقد تتغيّر هذه الخدمات أو تتوقف، وتسري شروطها الخاصة عند استخدامها.'),
    ('التوفّر والتحديثات',
        'يُقدَّم التطبيق «كما هو»، دون وعد بأنه سيعمل دائمًا أو يخلو من الأخطاء. قد تتغيّر الميزات، وتصدر تحديثات من وقت لآخر. احتفظ بنسخة احتياطية من الأحلام المهمة لك.'),
    ('المسؤولية',
        'بالقدر الذي يسمح به القانون، لا يتحمّل المطوّر مسؤولية أي خسارة ناتجة عن استخدام التطبيق، ومنها ضياع البيانات. نبذل جهدنا، لكن استخدم النسخ الاحتياطي والتصدير.'),
    ('التغييرات',
        'قد نحدّث هذه الشروط. واستمرارك في استخدام التطبيق بعد التحديث يعني قبولك للنسخة الجديدة.'),
  ],
  'لديك سؤال؟ راسلنا على:',
);
