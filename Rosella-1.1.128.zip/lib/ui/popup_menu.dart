import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  /// small grey line under the label
  final String? subtitle;
  /// colour of the icon square (defaults to the theme accent)
  final Color? color;
  /// small number in the corner of a tile
  final String? badge;
  /// marks the current option of a segmented switch
  final bool selected;
  const MenuAction(this.icon, this.label, this.onTap,
      {this.subtitle, this.color, this.badge, this.selected = false});
}

/// A solid card that opens from the top corner (below the ⋮ button):
/// a header line, two big tiles, an optional segmented switch and a list of rows.
/// It is deliberately NOT a live blur: a BackdropFilter flashes while it fades and makes the animation heavy.
Future<void> showPopupCard(
  BuildContext context, {
  required List<MenuAction> tiles,
  required List<MenuAction> rows,
  String? footer,
  String? footerEnd,
  String? viewLabel,
  List<MenuAction>? views,
}) {
  final rtl = Directionality.of(context) == TextDirection.rtl;
  final top = MediaQuery.paddingOf(context).top + 66;
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.black.withOpacity(0.35),
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      final c = ctx.colors;
      final card = c.isDark ? const Color(0xFF1C1C20) : c.surface;
      final inner = c.isDark ? const Color(0xFF232328) : c.surfaceHi;
      final line = al(c.text, c.isDark ? 0.08 : 0.10);
      void run(VoidCallback f) {
        Haptics.selection();
        Navigator.of(ctx).pop();
        f();
      }

      Widget square(MenuAction a, double size, double radius) {
        final base = a.color ?? c.a;
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color.lerp(base, Colors.white, 0.18)!, Color.lerp(base, Colors.black, 0.22)!],
            ),
            boxShadow: [BoxShadow(color: al(base, 0.35), blurRadius: 14, offset: const Offset(0, 4))],
          ),
          child: Icon(a.icon, color: Colors.white, size: size * 0.46),
        );
      }

      Widget tile(MenuAction a) => Expanded(
            child: Pressable(
              scale: 0.97,
              onTap: () => run(a.onTap),
              child: Container(
                height: 138,
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                decoration: BoxDecoration(
                  color: inner,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        square(a, 54, 17),
                        const Spacer(),
                        if (a.badge != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                            decoration: BoxDecoration(
                                color: al(c.text, 0.10), borderRadius: BorderRadius.circular(12)),
                            child: Text(a.badge!,
                                style: TextStyle(
                                    color: c.text, fontSize: 12.5, fontWeight: FontWeight.w800)),
                          ),
                      ],
                    ),
                    const Spacer(),
                    Text(a.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                    if (a.subtitle != null)
                      Text(a.subtitle!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                  ],
                ),
              ),
            ),
          );

      Widget row(MenuAction a) => Pressable(
            scale: 0.99,
            onTap: () => run(a.onTap),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              child: Row(
                children: [
                  square(a, 44, 14),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                        if (a.subtitle != null)
                          Text(a.subtitle!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: c.dim, fontSize: 12.5)),
                      ],
                    ),
                  ),
                  Icon(rtl ? Icons.chevron_left_rounded : Icons.chevron_right_rounded,
                      color: c.dim, size: 22),
                ],
              ),
            ),
          );

      Widget segmented(List<MenuAction> v) => Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: c.isDark ? const Color(0xFF111114) : al(c.text, 0.06),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: line),
            ),
            child: Row(
              children: [
                for (final a in v)
                  Expanded(
                    child: Pressable(
                      scale: 0.97,
                      onTap: () => run(a.onTap),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 160),
                        height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          gradient: a.selected
                              ? LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: c.isDark
                                      ? const [Color(0xFFF2F2F5), Color(0xFFC9C9CF)]
                                      : [c.a, c.b])
                              : null,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(a.icon,
                                size: 18,
                                color: a.selected
                                    ? (c.isDark ? const Color(0xFF16161A) : Colors.white)
                                    : c.dim),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(a.label,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w800,
                                      color: a.selected
                                          ? (c.isDark ? const Color(0xFF16161A) : Colors.white)
                                          : c.dim)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );

      return Align(
        alignment: AlignmentDirectional.topEnd,
        child: Padding(
          padding: EdgeInsetsDirectional.only(top: top, end: 14, start: 14),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 350),
            child: Material(
              color: card,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(32),
                side: BorderSide(color: line),
              ),
              shadowColor: Colors.black,
              clipBehavior: Clip.antiAlias,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (footer != null || footerEnd != null)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(6, 2, 6, 10),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(footer ?? '',
                                  style: TextStyle(
                                      color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                            ),
                            if (footerEnd != null)
                              Text(footerEnd,
                                  style: TextStyle(
                                      color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    Row(
                      children: [
                        for (var i = 0; i < tiles.length; i++) ...[
                          if (i > 0) const SizedBox(width: 10),
                          tile(tiles[i]),
                        ],
                      ],
                    ),
                    if (views != null) ...[
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 16, 8, 8),
                        child: Text((viewLabel ?? '').toUpperCase(),
                            style: TextStyle(
                                color: c.dim,
                                fontSize: 12,
                                letterSpacing: 1.2,
                                fontWeight: FontWeight.w800)),
                      ),
                      segmented(views),
                    ],
                    const SizedBox(height: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: inner,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: line),
                      ),
                      child: Column(
                        children: [
                          for (var i = 0; i < rows.length; i++) ...[
                            if (i > 0) Divider(height: 1, color: line),
                            row(rows[i]),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, _, child) {
      // the card is solid, so a fade is safe here (it was the blur that broke while fading)
      final curved = CurvedAnimation(
          parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
      return FadeTransition(
        opacity: curved,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.9, end: 1).animate(curved),
          alignment: Alignment(rtl ? -0.9 : 0.9, -1),
          child: child,
        ),
      );
    },
  );
}
