import 'dart:io';

import 'package:flutter/material.dart';

import 'widgets.dart';

/// Full-screen profile photo: pinch to zoom, tap anywhere to close.
class PhotoViewerPage extends StatelessWidget {
  final String path;
  final String tag;
  const PhotoViewerPage({super.key, required this.path, required this.tag});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Stack(
          children: [
            Center(
              child: Hero(
                tag: tag,
                child: InteractiveViewer(
                  minScale: 1,
                  maxScale: 5,
                  child: Image.file(File(path), fit: BoxFit.contain),
                ),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: AlignmentDirectional.topStart,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: RoundIconButton(
                      icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
