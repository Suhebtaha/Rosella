import 'package:flutter/material.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// "Add details (optional)": people, places and tags of a dream.
class DetailEditor extends StatelessWidget {
  final List<String> people, places, tags;
  final VoidCallback onChanged;
  const DetailEditor(
      {super.key,
      required this.people,
      required this.places,
      required this.tags,
      required this.onChanged});

  Future<void> _add(BuildContext context, String title, List<String> into) async {
    Haptics.selection();
    final c = context.colors;
    final ctl = TextEditingController();
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(title,
            style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
        content: TextField(
          controller: ctl,
          autofocus: true,
          textInputAction: TextInputAction.done,
          onSubmitted: (t) => Navigator.of(ctx).pop(t),
          style: TextStyle(color: c.text),
          decoration: InputDecoration(
            hintText: ctx.t('dt_hint'),
            hintStyle: TextStyle(color: c.dim),
            filled: true,
            fillColor: c.surfaceHi,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: Text(ctx.t('cancel'), style: TextStyle(color: c.dim))),
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(ctl.text),
              child: Text(ctx.t('dt_add'), style: TextStyle(color: c.a))),
        ],
      ),
    );
    if (v == null) return;
    var added = false;
    for (final part in v.split(RegExp(r'[,،\n]'))) {
      final t = part.trim();
      if (t.isNotEmpty && !into.contains(t)) {
        into.add(t);
        added = true;
      }
    }
    if (added) onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    Widget chip(IconData icon, String label, List<String> list) => Expanded(
          child: Pressable(
            scale: 0.97,
            onTap: () => _add(context, label, list),
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                color: c.surfaceHi,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: c.border),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: c.a, size: 19),
                  const SizedBox(width: 7),
                  Flexible(
                    child: Text(label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: c.text, fontSize: 14, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ),
        );
    Widget group(IconData icon, List<String> list) => list.isEmpty
        ? const SizedBox.shrink()
        : Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in list)
                  _Tag(
                      icon: icon,
                      text: t,
                      onRemove: () {
                        list.remove(t);
                        onChanged();
                      }),
              ],
            ),
          );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
          child: Text(context.t('dt_details'),
              style: TextStyle(color: c.dim, fontSize: 13, fontWeight: FontWeight.w600)),
        ),
        Row(
          children: [
            chip(Icons.people_alt_outlined, context.t('dt_people'), people),
            const SizedBox(width: 8),
            chip(Icons.location_on_outlined, context.t('dt_places'), places),
            const SizedBox(width: 8),
            chip(Icons.sell_outlined, context.t('dt_tags'), tags),
          ],
        ),
        group(Icons.person_rounded, people),
        group(Icons.place_rounded, places),
        group(Icons.tag_rounded, tags),
      ],
    );
  }
}

class _Tag extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onRemove;
  const _Tag({required this.icon, required this.text, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      padding: EdgeInsetsDirectional.fromSTEB(10, 6, onRemove == null ? 12 : 6, 6),
      decoration: BoxDecoration(
        color: al(c.a, 0.14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: al(c.a, 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: c.a),
          const SizedBox(width: 5),
          Text(text,
              style: TextStyle(color: c.text, fontSize: 13, fontWeight: FontWeight.w600)),
          if (onRemove != null) ...[
            const SizedBox(width: 4),
            GestureDetector(
              onTap: onRemove,
              child: Icon(Icons.close_rounded, size: 16, color: c.dim),
            ),
          ],
        ],
      ),
    );
  }
}

/// Read-only list of a dream's details (used on the dream page).
class DetailChips extends StatelessWidget {
  final List<String> people, places, tags;
  const DetailChips({super.key, required this.people, required this.places, required this.tags});

  @override
  Widget build(BuildContext context) {
    if (people.isEmpty && places.isEmpty && tags.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final t in people) _Tag(icon: Icons.person_rounded, text: t),
          for (final t in places) _Tag(icon: Icons.place_rounded, text: t),
          for (final t in tags) _Tag(icon: Icons.tag_rounded, text: t),
        ],
      ),
    );
  }
}
