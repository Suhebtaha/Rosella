import 'package:flutter/material.dart';

/// Opens a page by sliding it in from the left edge (and back out to the left): a plain, cheap
/// slide with no zoom or scale. The page is drawn once inside a cached layer (RepaintBoundary) and
/// only that layer is moved every frame. [from], [color] and [radius] are kept only so existing
/// callers keep compiling.
class CardOpenRoute extends PageRouteBuilder<void> {
  CardOpenRoute({
    Rect? from,
    Color? color,
    double radius = 0,
    required WidgetBuilder builder,
  }) : super(
          opaque: true,
          transitionDuration: const Duration(milliseconds: 300),
          reverseTransitionDuration: const Duration(milliseconds: 260),
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, secondary, child) {
            final slide = Tween<Offset>(begin: const Offset(-1.0, 0.0), end: Offset.zero)
                .animate(CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                    reverseCurve: Curves.easeInCubic));
            return SlideTransition(
              // physical left edge in every language
              textDirection: TextDirection.ltr,
              position: slide,
              child: RepaintBoundary(
                child: ColoredBox(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: child,
                ),
              ),
            );
          },
        );
}

/// Global rectangle of the widget behind [context] (null if it is not laid out).
Rect? rectOf(BuildContext context) {
  final ro = context.findRenderObject();
  if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}
