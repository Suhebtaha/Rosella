import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'card_route.dart';
import 'legal_doc.dart';
import 'legal_docs_a.dart';
import 'legal_docs_b.dart';
import 'legal_docs_base.dart';
import 'legal_docs_c.dart';
import 'legal_docs_d.dart';
import 'widgets.dart';

const String _supportMail = 'contact.somina@gmail.com';

/// Privacy policy / terms of use, written in plain language, in every app language.
class LegalPage extends StatelessWidget {
  final bool privacy;
  const LegalPage({super.key, required this.privacy});

  static void open(BuildContext context, {required bool privacy}) {
    Navigator.of(context).push(CardOpenRoute(builder: (_) => LegalPage(privacy: privacy)));
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    // written in the app language (English when a language has no translation)
    final lang = context.watch<AppState>().lang;
    final doc = _pick(lang, privacy);
    final title = privacy ? context.t('privacy_policy') : context.t('terms_of_use');
    return Scaffold(
      backgroundColor: c.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                  child: Row(
                    children: [
                      RoundIconButton(
                          icon: Icons.arrow_back_rounded,
                          onTap: () => Navigator.of(context).maybePop()),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(title,
                            style: TextStyle(
                                color: c.text, fontSize: 24, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(22, 10, 22, 40),
                    children: [
                      Text(doc.updated,
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                      const SizedBox(height: 14),
                      Text(doc.intro,
                          style: TextStyle(color: c.text, fontSize: 15.5, height: 1.65)),
                      for (final s in doc.sections) ...[
                        const SizedBox(height: 26),
                        Text(s.$1,
                            style: TextStyle(
                                color: c.text, fontSize: 17.5, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 8),
                        Text(s.$2,
                            style: TextStyle(color: c.dim, fontSize: 15, height: 1.7)),
                      ],
                      const SizedBox(height: 30),
                      Text(doc.contact,
                          style: TextStyle(color: c.text, fontSize: 15, height: 1.6)),
                      const SizedBox(height: 4),
                      SelectableText(_supportMail,
                          textDirection: TextDirection.ltr,
                          style: TextStyle(
                              color: c.a, fontSize: 15, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static LegalDoc _pick(String lang, bool privacy) {
    final LegalDoc? d;
    if (lang == 'ar') {
      d = privacy ? privacyAr : termsAr;
    } else if (lang == 'en') {
      d = privacy ? privacyEn : termsEn;
    } else {
      d = (privacy
          ? (kPrivacyA[lang] ?? kPrivacyB[lang] ?? kPrivacyC[lang] ?? kPrivacyD[lang])
          : (kTermsA[lang] ?? kTermsB[lang] ?? kTermsC[lang] ?? kTermsD[lang]));
    }
    return d ?? (privacy ? privacyEn : termsEn);
  }
}
