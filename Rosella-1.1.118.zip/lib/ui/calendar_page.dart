import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'dream_calendar.dart';
import 'widgets.dart';

/// Full page: the month calendar (days coloured by mood), the current streak and the badges.
class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final st = app.stats;
    final streakText = st.streak > 0
        ? context.t('cal_streak').replaceAll('%d', '${st.streak}')
        : context.t('cal_streak0');
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('cal_title')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 28),
              children: [
                const DreamCalendar(),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(shape: BoxShape.circle, gradient: c.gradient),
                        child: const Icon(Icons.local_fire_department_rounded,
                            color: Colors.white, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(streakText,
                            style: TextStyle(
                                color: c.text,
                                fontSize: 16.5,
                                fontWeight: FontWeight.w800,
                                height: 1.35)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(context.t('cal_badges'),
                          style: TextStyle(
                              color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 14,
                        runSpacing: 14,
                        children: [
                          for (final a in kAchievements)
                            _BadgeChip(
                                def: a,
                                unlocked: app.unlocked.contains(a.id),
                                lang: app.lang),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BadgeChip extends StatelessWidget {
  final AchievementDef def;
  final bool unlocked;
  final String lang;
  const _BadgeChip({required this.def, required this.unlocked, required this.lang});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return SizedBox(
      width: 78,
      child: Opacity(
        opacity: unlocked ? 1 : 0.45,
        child: Column(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: unlocked ? c.gradient : null,
                color: unlocked ? null : c.surfaceHi,
              ),
              child: Icon(def.icon, color: unlocked ? Colors.white : c.dim, size: 27),
            ),
            const SizedBox(height: 6),
            Text(Strings.get(lang, def.titleKey),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: c.text, fontSize: 11.5, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}
