/// One legal document (privacy policy or terms of use) in one language.
class LegalDoc {
  final String updated;
  final String intro;
  final List<(String, String)> sections;
  final String contact;
  const LegalDoc(this.updated, this.intro, this.sections, this.contact);
}
