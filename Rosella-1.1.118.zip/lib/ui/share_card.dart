import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// Preview of a shareable dream card + a button that shares it as a PNG image.
class ShareCardPage extends StatefulWidget {
  final String id;
  const ShareCardPage({super.key, required this.id});

  @override
  State<ShareCardPage> createState() => _ShareCardPageState();
}

class _ShareCardPageState extends State<ShareCardPage> {
  final GlobalKey _key = GlobalKey();
  bool _busy = false;
  final PageController _pc = PageController(viewportFraction: 0.86);
  int _page = 0;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  Future<void> _saveToGallery(Dream d) async {
    final app = context.read<AppState>();
    setState(() => _busy = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('png');
      if (!await Gal.hasAccess(toAlbum: true)) {
        await Gal.requestAccess(toAlbum: true);
      }
      await Gal.putImageBytes(data.buffer.asUint8List(), album: 'Rosella');
      if (mounted) toast(context, app.tr('saved_gallery'));
    } catch (_) {
      if (mounted) toast(context, app.tr('save_failed'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _share(Dream d) async {
    final app = context.read<AppState>();
    setState(() => _busy = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('png');
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/rosella_${d.id}.png');
      await f.writeAsBytes(data.buffer.asUint8List(), flush: true);
      await app.external(() => Share.shareXFiles([XFile(f.path)], text: 'Rosella'));
    } catch (_) {
      if (mounted) toast(context, app.tr('share_failed'));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final d = app.byId(widget.id);
    if (d == null) return const SizedBox.shrink();
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('share_title')),
          Expanded(
            child: Column(
              children: [
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    physics: const BouncingScrollPhysics(),
                    itemCount: kShareStyles.length + 1,
                    onPageChanged: (i) {
                      Haptics.light();
                      setState(() => _page = i);
                    },
                    itemBuilder: (_, i) {
                      final st = i == 0
                          ? ShareStyle.theme(paletteById(app.themeId), 0)
                          : kShareStyles[i - 1];
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(6, 6, 6, 10),
                        child: FittedBox(
                          fit: BoxFit.contain,
                          child: RepaintBoundary(
                            key: i == _page ? _key : null,
                            child: _Card(dream: d, app: app, style: st),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < kShareStyles.length + 1; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: i == _page ? 18 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3),
                          color: i == _page ? context.colors.text : context.colors.border,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 18),
            child: Column(
              children: [
                GradientButton(
                  label: context.t('share'),
                  icon: Icons.ios_share_rounded,
                  expand: true,
                  loading: _busy,
                  onTap: () => _share(d),
                ),
                const SizedBox(height: 10),
                SubtleButton(
                  label: context.t('save_gallery'),
                  icon: Icons.download_rounded,
                  onTap: _busy ? null : () => _saveToGallery(d),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// One look for the share card: colours + layout. Swipe sideways on the page to browse them.
class ShareStyle {
  final Color bg, a, b, text;
  final int layout; // 0 classic, 1 centered, 2 quote
  const ShareStyle(this.bg, this.a, this.b, this.text, this.layout);
  factory ShareStyle.theme(AppPalette p, int layout) =>
      ShareStyle(const Color(0xFF05050B), p.a, p.b, Colors.white, layout);
}

const kShareStyles = <ShareStyle>[
  ShareStyle(Color(0xFF061A2B), Color(0xFF2DD4BF), Color(0xFF3B82F6), Colors.white, 0),
  ShareStyle(Color(0xFF1A0B12), Color(0xFFFF6B6B), Color(0xFFFFB86B), Colors.white, 1),
  ShareStyle(Color(0xFF0D0820), Color(0xFF8B5CF6), Color(0xFFEC4899), Colors.white, 2),
  ShareStyle(Color(0xFFF7F3EA), Color(0xFFFFB38A), Color(0xFFA8B8FF), Color(0xFF1B1B22), 0),
  ShareStyle(Color(0xFF000000), Color(0xFF9CA3AF), Color(0xFFE5E7EB), Colors.white, 1),
  ShareStyle(Color(0xFF07140E), Color(0xFF34D399), Color(0xFFA3E635), Colors.white, 2),
  ShareStyle(Color(0xFFFBEFF3), Color(0xFFFF9EC0), Color(0xFFC9A7FF), Color(0xFF2A1B25), 1),
];

class _Card extends StatelessWidget {
  final Dream dream;
  final AppState app;
  final ShareStyle style;
  const _Card({required this.dream, required this.app, required this.style});

  String _excerpt() {
    final src = (dream.interpretation ?? '').trim().isNotEmpty
        ? dream.interpretation!.trim()
        : dream.content.trim();
    final flat = src.replaceAll(RegExp(r'[\*#>_`]+'), '').replaceAll(RegExp(r'\s+'), ' ');
    return flat.length > 230 ? '${flat.substring(0, 227)}…' : flat;
  }

  @override
  Widget build(BuildContext context) {
    final a = style.a;
    final b = style.b;
    final t = style.text;
    final light = style.bg.computeLuminance() > 0.5;
    final img = app.abs(dream.image);
    final title = dream.title.isEmpty ? fmtDate(dream.createdAt, app.lang) : dream.title;
    final center = style.layout == 1;
    final quote = style.layout == 2;
    final cross = center ? CrossAxisAlignment.center : CrossAxisAlignment.start;
    final ta = center ? TextAlign.center : TextAlign.start;
    final glow = light ? 0.8 : 0.5;
    return Container(
      width: 360,
      height: 450,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: style.bg,
      ),
      child: Stack(
        children: [
          Positioned(
            top: -90,
            left: -70,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [al(a, glow + 0.05), al(a, 0)]),
              ),
            ),
          ),
          Positioned(
            bottom: -110,
            right: -80,
            child: Container(
              width: 320,
              height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [al(b, glow), al(b, 0)]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: cross,
              children: [
                if (quote)
                  Text('\u201C',
                      style: TextStyle(
                          color: al(a, 0.9), fontSize: 80, height: 0.9, fontWeight: FontWeight.w900))
                else if (img != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.file(
                      File(img),
                      height: 190,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      cacheWidth: 900,
                      errorBuilder: (_, __, ___) => const SizedBox(height: 190),
                    ),
                  )
                else
                  Container(
                    height: center ? 140 : 120,
                    width: double.infinity,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(center ? 70 : 20),
                      gradient: LinearGradient(colors: [al(a, 0.35), al(b, 0.35)]),
                    ),
                    child: Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 52)),
                  ),
                const SizedBox(height: 14),
                if (dream.lucid) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: al(a, 0.4),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: al(t, 0.35)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.visibility_rounded, size: 14, color: t),
                        const SizedBox(width: 5),
                        Text(app.tr('lucid_tag'),
                            style: TextStyle(color: t, fontSize: 12, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                Text(title,
                    maxLines: 2,
                    textAlign: ta,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: t,
                        fontSize: quote ? 22 : 24,
                        fontWeight: FontWeight.w800,
                        fontStyle: quote ? FontStyle.italic : FontStyle.normal,
                        height: 1.25)),
                const SizedBox(height: 8),
                Expanded(
                  child: Text(_excerpt(),
                      textAlign: ta,
                      overflow: TextOverflow.fade,
                      style: TextStyle(color: al(t, 0.78), fontSize: 14.5, height: 1.5)),
                ),
                Row(
                  mainAxisAlignment:
                      center ? MainAxisAlignment.center : MainAxisAlignment.start,
                  children: [
                    Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(fmtDate(dream.createdAt, app.lang),
                        style: TextStyle(color: al(t, 0.6), fontSize: 12.5)),
                    if (!center) const Spacer() else const SizedBox(width: 14),
                    ShaderMask(
                      shaderCallback: (r) => LinearGradient(
                          colors: [light ? a.withBlue(120) : a, light ? b.withRed(120) : b])
                          .createShader(r),
                      child: const Text('Rosella',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
