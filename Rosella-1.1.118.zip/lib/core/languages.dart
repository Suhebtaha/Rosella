import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/widgets.dart' show Locale;

/// The app language to start with: the phone's language when the app has it, otherwise English.
String deviceLangCode() {
  final l = PlatformDispatcher.instance.locale;
  var code = l.languageCode.toLowerCase();
  if (code == 'ku') code = 'ckb';
  if (code == 'nb' || code == 'nn') code = 'no';
  return kLanguages.any((e) => e[0] == code) ? code : 'en';
}

/// code, native name, English name, two-letter badge
const List<List<String>> kLanguages = [
  ['ar', 'العربية', 'Arabic', 'AR'],
  ['ckb', 'کوردی', 'Kurdish · Sorani', 'KU'],
  ['en', 'English', 'English', 'EN'],
  ['es', 'Español', 'Spanish · Mexico & Spain', 'ES'],
  ['pt', 'Português', 'Portuguese · Brazil', 'PT'],
  ['fr', 'Français', 'French', 'FR'],
  ['de', 'Deutsch', 'German', 'DE'],
  ['it', 'Italiano', 'Italian', 'IT'],
  ['ru', 'Русский', 'Russian', 'RU'],
  ['uk', 'Українська', 'Ukrainian', 'UK'],
  ['sr', 'Српски', 'Serbian', 'SR'],
  ['tr', 'Türkçe', 'Turkish', 'TR'],
  ['fa', 'فارسی', 'Persian', 'FA'],
  ['ja', '日本語', 'Japanese', 'JA'],
  ['ko', '한국어', 'Korean', 'KO'],
  ['sv', 'Svenska', 'Swedish', 'SV'],
  ['no', 'Norsk', 'Norwegian', 'NO'],
  ['da', 'Dansk', 'Danish', 'DA'],
  ['et', 'Eesti', 'Estonian', 'ET'],
  ['ro', 'Română', 'Romanian', 'RO'],
  ['el', 'Ελληνικά', 'Greek', 'EL'],
  ['hy', 'Հայերեն', 'Armenian', 'HY'],
  ['az', 'Azərbaycanca', 'Azerbaijani', 'AZ'],
  ['zh', '中文', 'Chinese · Simplified', 'ZH'],
];

const Set<String> kRtlLangs = {'ar', 'ckb', 'fa'};

String languageName(String code) {
  for (final l in kLanguages) {
    if (l[0] == code) return l[1];
  }
  return code;
}

/// Flutter locale used for the Material widgets (Kurdish borrows Arabic, Norwegian is "nb").
Locale localeFor(String code) => switch (code) {
      'ckb' => const Locale('ar'),
      'no' => const Locale('nb'),
      _ => Locale(code),
    };

const List<Locale> kSupportedLocales = [
  Locale('ar'), Locale('en'), Locale('es'), Locale('ko'), Locale('pt'), Locale('fr'),
  Locale('de'), Locale('it'), Locale('ru'), Locale('uk'), Locale('sr'), Locale('tr'),
  Locale('fa'), Locale('ja'), Locale('sv'), Locale('nb'), Locale('da'),
  Locale('et'),
  Locale('ro'), Locale('el'), Locale('hy'), Locale('az'), Locale('zh'),
];
