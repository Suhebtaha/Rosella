import 'dart:async';
import 'dart:io';

import 'package:flutter/painting.dart';
import 'package:path_provider/path_provider.dart';

/// Throws away leftovers nobody needs any more: share-card pictures, voice clips already
/// sent for transcription, old installers. Kept on purpose: the generated sound files
/// (`dt_*`, they cost CPU to rebuild) and a download that is still waiting to be installed.
class CacheClean {
  static Future<void> run() async {
    // keep the in-memory picture cache small, too
    final ic = PaintingBinding.instance.imageCache;
    ic.maximumSize = 60;
    ic.maximumSizeBytes = 64 << 20;
    try {
      final dir = await getTemporaryDirectory();
      if (!dir.existsSync()) return;
      final now = DateTime.now();
      for (final e in dir.listSync(followLinks: false)) {
        final name = e.path.split('/').last;
        if (name.startsWith('dt_')) continue;
        final age = now.difference(e.statSync().modified);
        if (name.startsWith('rosella-update')) {
          // a finished or paused download is kept for a few days, then it is just clutter
          if (age < const Duration(days: 3)) continue;
        } else if (age < const Duration(minutes: 30)) {
          continue; // something may be using it right now
        }
        try {
          e.deleteSync(recursive: true);
        } catch (_) {}
      }
    } catch (_) {}
  }
}
