## Rosella 1.1.118

- New Feed view on the home page: big post-style cards with your photo, name, date and a large dream image. Feed is now the default (switch to Grid anytime from ⋮ > Switch views or in Settings).
- A soft ambient glow from the top of every page, in the theme colour (golden on the black theme).
