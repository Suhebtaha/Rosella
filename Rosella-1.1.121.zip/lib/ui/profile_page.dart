import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/achievements.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../core/strings.dart';
import '../core/symbols.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'dream_detail.dart';
import 'dream_editor.dart';
import 'settings_page.dart';
import 'share_card.dart';
import 'social_pages.dart';
import 'widgets.dart';

/// The 4th tab: your profile and dream statistics. Everything stays on this device.
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final name = app.profileName.trim().isNotEmpty
        ? app.profileName.trim()
        : (app.userName ?? context.t('prof_default_name'));
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    final hasPhoto = avatar != null && File(avatar).existsSync();
    final all = app.dreams;
    final lucid = all.where((d) => d.lucid).length;
    final recurring = recurringSymbols(all, max: 50);
    Widget stat(String n, String label) => Expanded(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(n, style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: c.dim, fontSize: 12.5)),
            ],
          ),
        );
    Widget section(String title, Widget child, {int delay = 0}) => Padding(
          padding: const EdgeInsets.only(top: 22),
          child: FadeSlide(
            delay: delay,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(6, 0, 6, 10),
                  child: Text(title,
                      style: TextStyle(color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                ),
                child,
              ],
            ),
          ),
        );
    // ---- mood overview
    final moodCounts = List<int>.generate(5, (i) => all.where((d) => d.mood == i + 1).length);
    final maxMood = moodCounts.fold<int>(1, (a, b) => b > a ? b : a);
    // ---- journey
    final first = all.isEmpty
        ? null
        : all.map((d) => d.createdAt).reduce((a, b) => a.isBefore(b) ? a : b);
    final words = all.fold<int>(
        0, (n, d) => n + d.content.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length);
    final voice = all.where((d) => d.audio != null).length;
    final images = all.where((d) => d.image != null).length;
    Widget tile(IconData icon, String value, String label) => Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.border),
              color: al(c.surface, 0.55),
            ),
            child: Column(
              children: [
                Icon(icon, size: 20, color: c.dim),
                const SizedBox(height: 6),
                Text(value,
                    style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.dim, fontSize: 11.5)),
              ],
            ),
          ),
        );
    final unlockedCount = kAchievements.where((a) => app.unlocked.contains(a.id)).length;
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text(context.t('prof_title'),
                      style: TextStyle(
                          color: c.text,
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.8)),
                ),
              ),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  RoundIconButton(
                    icon: Icons.settings_rounded,
                    onTap: () => Navigator.of(context).push(
                        CupertinoPageRoute<void>(builder: (_) => const AppSettingsRoute())),
                  ),
                  if (app.updateAvailable)
                    Positioned(
                      right: 2,
                      top: 2,
                      child: Container(
                        width: 11,
                        height: 11,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF3B30),
                          shape: BoxShape.circle,
                          border: Border.all(color: c.bg, width: 1.5),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),
          FadeSlide(
            child: Row(
              children: [
                Pressable(
                  scale: 0.95,
                  onTap: hasPhoto
                      ? () => Navigator.of(context).push(PageRouteBuilder<void>(
                            opaque: false,
                            transitionDuration: const Duration(milliseconds: 220),
                            pageBuilder: (_, a, __) => FadeTransition(
                                opacity: a,
                                child: PhotoViewerPage(path: avatar, tag: 'profile_photo')),
                          ))
                      : null,
                  child: Hero(
                      tag: 'profile_photo',
                      child: ProfileAvatar(path: avatar, name: name, size: 88)),
                ),
                const SizedBox(width: 12),
                if (app.profileShowCount) stat('${all.length}', context.t('prof_stat_dreams')),
                if (app.profileShowStreak) stat('${app.streakDays}', context.t('prof_stat_streak')),
                if (app.profileShowLucid) stat('$lucid', context.t('prof_stat_lucid')),
                if (app.profileShowRecurring)
                  stat('${recurring.length}', context.t('prof_stat_recurring')),
              ],
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 30,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  if (app.profileBio.trim().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(app.profileBio.trim(),
                          textDirection: textDirOf(app.profileBio, Directionality.of(context)),
                          style: TextStyle(color: c.text, fontSize: 14.5, height: 1.5)),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 60,
            child: GradientButton(
              label: context.t('prof_edit'),
              onTap: () => Navigator.of(context)
                  .push(CupertinoPageRoute<void>(builder: (_) => const ProfileEditPage())),
            ),
          ),
          section(
            context.t('prof_sec_journey'),
            Row(
              children: [
                tile(Icons.flag_rounded, first == null ? '-' : fmtDate(first, app.lang),
                    context.t('prof_since')),
                const SizedBox(width: 8),
                tile(Icons.edit_note_rounded, '$words', context.t('prof_words')),
                const SizedBox(width: 8),
                tile(Icons.mic_rounded, '$voice', context.t('prof_voice')),
                const SizedBox(width: 8),
                tile(Icons.image_rounded, '$images', context.t('prof_images')),
              ],
            ),
            delay: 90,
          ),
          section(
            context.t('prof_sec_moods'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: c.border),
                color: al(c.surface, 0.55),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  for (var i = 0; i < 5; i++)
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('${moodCounts[i]}',
                            style: TextStyle(
                                color: c.text, fontSize: 14, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          width: 26,
                          height: 8 + 62 * moodCounts[i] / maxMood,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: al(moodColor(i + 1), 0.85),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(moodEmoji(i + 1), style: const TextStyle(fontSize: 22)),
                      ],
                    ),
                ],
              ),
            ),
            delay: 120,
          ),
          if (recurring.isNotEmpty)
            section(
              context.t('prof_sec_symbols'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final s in recurring.take(10))
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: c.border),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(s.word,
                              style: TextStyle(
                                  color: c.text, fontSize: 13.5, fontWeight: FontWeight.w600)),
                          const SizedBox(width: 6),
                          Text('${s.dreams}', style: TextStyle(color: c.dim, fontSize: 12.5)),
                        ],
                      ),
                    ),
                ],
              ),
              delay: 150,
            ),
          section(
            '${context.t('prof_sec_ach')}  $unlockedCount/${kAchievements.length}',
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final a in kAchievements)
                  Opacity(
                    opacity: app.unlocked.contains(a.id) ? 1 : 0.3,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: c.border),
                        color: al(c.a, app.unlocked.contains(a.id) ? 0.2 : 0.06),
                      ),
                      child: Icon(a.icon, size: 24, color: c.text),
                    ),
                  ),
              ],
            ),
            delay: 180,
          ),
        ],
      ),
    );
  }
}

/// The app settings (the old 4th tab), opened from the gear on the profile page.
class AppSettingsRoute extends StatelessWidget {
  const AppSettingsRoute({super.key});

  @override
  Widget build(BuildContext context) => PageScaffold(
        child: Column(
          children: const [
            TopBar(),
            Expanded(child: SettingsPage()),
          ],
        ),
      );
}

class ProfileAvatar extends StatelessWidget {
  final String? path;
  final String name;
  final double size;
  const ProfileAvatar({required this.path, required this.name, required this.size});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final letter = name.trim().isEmpty ? 'R' : name.trim().characters.first.toUpperCase();
    final has = path != null && File(path!).existsSync();
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: al(c.text, 0.55), width: 2),
      ),
      child: ClipOval(
        child: has
            ? Image.file(File(path!),
                fit: BoxFit.cover, cacheWidth: (size * 3).toInt())
            : Container(
                color: c.surface,
                alignment: Alignment.center,
                child: Text(letter,
                    style: TextStyle(
                        color: c.text, fontSize: size * 0.42, fontWeight: FontWeight.w800)),
              ),
      ),
    );
  }
}

class _FeaturedCard extends StatelessWidget {
  final Dream dream;
  const _FeaturedCard({required this.dream});

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final c = context.colors;
    final img = app.abs(dream.image);
    final title = dream.title.trim().isEmpty ? fmtDate(dream.createdAt, app.lang) : dream.title;
    final body = dream.content.replaceAll(RegExp(r'\s+'), ' ').trim();
    return Pressable(
      scale: 0.98,
      onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: dream.id))),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: c.border),
          color: c.surface,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (img != null && File(img).existsSync())
              Image.file(File(img),
                  height: 180, width: double.infinity, fit: BoxFit.cover, cacheWidth: 900)
            else
              Container(
                height: 110,
                alignment: Alignment.center,
                decoration: BoxDecoration(gradient: LinearGradient(colors: [al(c.a, 0.4), al(c.b, 0.4)])),
                child: Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 44)),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Color(0xFFFFC94D), size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textDirection: textDirOf(title, Directionality.of(context)),
                            style: TextStyle(
                                color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                  if (body.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(body,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        textDirection: textDirOf(body, Directionality.of(context)),
                        style: TextStyle(color: c.dim, fontSize: 14, height: 1.45)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to choose the dream shown on the profile (private dreams are never offered).
Future<void> pickFeaturedDream(BuildContext context) async {
  final app = context.read<AppState>();
  final list = app.dreams.where((d) => !d.priv).toList();
  final c = context.colors;
  if (list.isEmpty) {
    toast(context, context.t('prof_no_dreams'));
    return;
  }
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: c.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.7),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(context.t('prof_featured_pick'),
                        style: TextStyle(
                            color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                  if (app.featuredId != null)
                    TextButton(
                      onPressed: () {
                        app.updateProfile(clearFeatured: true);
                        Navigator.of(ctx).pop();
                      },
                      child: Text(context.t('prof_featured_none')),
                    ),
                ],
              ),
            ),
            Flexible(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final d = list[i];
                  final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
                  return ListTile(
                    leading: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
                    title: Text(t,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                    subtitle: Text(fmtDate(d.createdAt, app.lang),
                        style: TextStyle(color: c.dim)),
                    trailing: app.featuredId == d.id
                        ? Icon(Icons.check_rounded, color: c.text)
                        : null,
                    onTap: () {
                      Haptics.selection();
                      app.updateProfile(featured: d.id);
                      Navigator.of(ctx).pop();
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Edit the profile: photo, name, bio and what is shown.
class ProfileEditPage extends StatefulWidget {
  const ProfileEditPage({super.key});

  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  late final TextEditingController _name;
  late final TextEditingController _bio;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _name = TextEditingController(text: app.profileName);
    _bio = TextEditingController(text: app.profileBio);
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final app = context.read<AppState>();
    try {
      final x = await app.external(() => ImagePicker().pickImage(
            source: ImageSource.gallery,
            maxWidth: 800,
            imageQuality: 85,
          ));
      if (x == null) return;
      final rel = app.newFileRel('images', 'jpg');
      await File(x.path).copy(app.abs(rel)!);
      app.updateProfile(avatar: rel);
    } catch (_) {}
  }

  Widget _switch(BuildContext context, String label, bool v, ValueChanged<bool> on) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(color: c.text, fontSize: 15, fontWeight: FontWeight.w600)),
          ),
          Switch(value: v, onChanged: (x) {
            Haptics.selection();
            on(x);
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    InputDecoration deco(String hint) => InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: c.dim),
          filled: true,
          fillColor: al(c.surface, 0.8),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        );
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('prof_edit')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: [
                Center(
                  child: Pressable(
                    onTap: _pickPhoto,
                    child: Stack(
                      children: [
                        ProfileAvatar(
                            path: avatar,
                            name: app.profileName.isEmpty ? (app.userName ?? '') : app.profileName,
                            size: 104),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(color: c.surfaceHi, shape: BoxShape.circle),
                            child: Icon(Icons.photo_camera_rounded, size: 18, color: c.text),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (app.profileAvatar != null)
                  Center(
                    child: TextButton(
                      onPressed: () => app.updateProfile(clearAvatar: true),
                      child: Text(context.t('prof_photo_remove')),
                    ),
                  ),
                const SizedBox(height: 14),
                TextField(
                  controller: _name,
                  maxLength: 40,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_name')),
                  onChanged: (v) => app.updateProfile(name: v),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _bio,
                  maxLength: 160,
                  maxLines: 3,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_bio')),
                  onChanged: (v) => app.updateProfile(bio: v),
                ),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    children: [
                      _switch(context, context.t('prof_show_count'), app.profileShowCount,
                          (v) => app.updateProfile(showCount: v)),
                      _switch(context, context.t('prof_show_streak'), app.profileShowStreak,
                          (v) => app.updateProfile(showStreak: v)),
                      _switch(context, context.t('prof_show_lucid'), app.profileShowLucid,
                          (v) => app.updateProfile(showLucid: v)),
                      _switch(context, context.t('prof_show_recurring'), app.profileShowRecurring,
                          (v) => app.updateProfile(showRecurring: v)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
