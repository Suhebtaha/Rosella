## Rosella 1.1.121

- Fixed: pressing the system Back button while dreams are selected now clears the selection instead of leaving the app.
- The Instagram-style feed cards were removed; the original square and long cards are back (square is the default).
- Profile no longer lists your dreams or a Private tab. It now shows your journey (start date, words, voice notes, images), a mood overview, recurring symbols and all achievements (locked ones dimmed).
