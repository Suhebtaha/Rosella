import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Material 3 "container transform" for the dream cards only: the tapped card grows smoothly into
/// the dream page and shrinks back into its place when you go back.
///
/// Cheap by design: the page is laid out once at full size inside a cached layer (RepaintBoundary);
/// every frame only moves/clips that layer and fades a plain colour box over it. The page itself
/// also postpones its heavy parts until the transition ends (see DreamDetailPage).
class CardOpenRoute extends PageRouteBuilder<void> {
  CardOpenRoute({
    Rect? from,
    required Color color,
    double radius = 24,
    required WidgetBuilder builder,
  }) : super(
          opaque: true,
          transitionDuration: const Duration(milliseconds: 460),
          reverseTransitionDuration: const Duration(milliseconds: 360),
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, secondary, child) {
            final size = MediaQuery.sizeOf(context);
            final full = Offset.zero & size;
            // no card to start from (opened from elsewhere): grow from a band in the middle
            final start = from ??
                Rect.fromLTWH(size.width * 0.06, size.height * 0.38, size.width * 0.88, 120);
            final page = RepaintBoundary(child: child);
            return AnimatedBuilder(
              animation: animation,
              child: page,
              builder: (context, page) {
                final reversing = animation.status == AnimationStatus.reverse;
                // Material 3 emphasized easing (decelerate in, accelerate out)
                final t = (reversing ? _emphOut : _emphIn).transform(animation.value);
                final rect = Rect.lerp(start, full, t)!;
                final r = lerpDouble(radius, 0, Curves.easeOut.transform(t))!;
                // the card colour gives way to the page content
                final reveal = const Interval(0.12, 0.62, curve: Curves.easeOut)
                    .transform(animation.value);
                return Stack(
                  children: [
                    Positioned.fromRect(
                      rect: rect,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(r),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            OverflowBox(
                              alignment: Alignment.topCenter,
                              minWidth: size.width,
                              maxWidth: size.width,
                              minHeight: size.height,
                              maxHeight: size.height,
                              child: page,
                            ),
                            if (reveal < 1)
                              IgnorePointer(
                                child: ColoredBox(color: color.withOpacity(1 - reveal)),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            );
          },
        );

  static const Cubic _emphIn = Cubic(0.2, 0.0, 0.0, 1.0);
  static const Cubic _emphOut = Cubic(0.3, 0.0, 0.8, 0.15);
}

/// Global rectangle of the widget behind [context] (null if it is not laid out).
Rect? rectOf(BuildContext context) {
  final ro = context.findRenderObject();
  if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}
