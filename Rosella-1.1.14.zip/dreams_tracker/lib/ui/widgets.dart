import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../services/haptics.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';

final GlobalKey<ScaffoldMessengerState> rootMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

extension TrX on BuildContext {
  String t(String key) =>
      Strings.get(select<AppState, String>((s) => s.lang), key);
}

String fmtDate(DateTime d, String lang) =>
    '${d.day} ${Strings.get(lang, 'm${d.month}')} ${d.year}';

String fmtTime(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

double navPadding(BuildContext c) => 118 + MediaQuery.of(c).padding.bottom;

void toast(BuildContext context, String msg) {
  final c = context.colors;
  rootMessengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
      behavior: SnackBarBehavior.floating,
      backgroundColor: c.surfaceHi,
      elevation: 0,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 112),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: c.border),
      ),
      duration: const Duration(seconds: 3),
    ));
}

const List<String> kMoodEmoji = ['😱', '😢', '😐', '🙂', '🤩'];
const List<Color> kMoodColors = [
  Color(0xFFFF5470),
  Color(0xFF5B8DEF),
  Color(0xFF9AA0B5),
  Color(0xFF34D399),
  Color(0xFFFFC857),
];
String moodEmoji(int m) => kMoodEmoji[(m.clamp(1, 5)) - 1];
Color moodColor(int m) => kMoodColors[(m.clamp(1, 5)) - 1];

// ---------------------------------------------------------------- background
class AppBackground extends StatelessWidget {
  const AppBackground({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final dynamicTheme = context.select<AppState, bool>((s) => s.themeId == 'dynamic');
    if (dynamicTheme) return DynamicGlowBackground(isDark: c.isDark, base: c.bg);
    return RepaintBoundary(
      child: Stack(
        fit: StackFit.expand,
        children: [
          ColoredBox(color: c.bg),
          Positioned(
              top: -150,
              right: -110,
              child: _Glow(color: c.a, size: 400, alpha: c.isDark ? 0.22 : 0.16)),
          Positioned(
              bottom: 100,
              left: -170,
              child: _Glow(color: c.b, size: 440, alpha: c.isDark ? 0.16 : 0.12)),
          if (c.isDark)
            const CustomPaint(painter: _StarPainter(), size: Size.infinite),
        ],
      ),
    );
  }
}

// ------------------------------------------------ dynamic (moving glow) theme
final Stopwatch _dynClock = Stopwatch()..start();

class DynamicGlowBackground extends StatefulWidget {
  final bool isDark;
  final Color base;
  const DynamicGlowBackground({super.key, required this.isDark, required this.base});

  @override
  State<DynamicGlowBackground> createState() => _DynamicGlowBackgroundState();
}

class _DynamicGlowBackgroundState extends State<DynamicGlowBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3600))
    ..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => CustomPaint(
          size: Size.infinite,
          painter: _DynamicPainter(
            // shared clock => every page shows the same phase (no jump between pages)
            // quantised to 20 steps/s: the glow drifts slowly, so this looks identical but
            // costs a third of the GPU work (the background is repainted ~20x, not 90x, per second)
            t: ((_dynClock.elapsedMilliseconds ~/ 50) * 0.05) / 9.0,
            isDark: widget.isDark,
            base: widget.base,
          ),
        ),
      ),
    );
  }
}

class _DynamicPainter extends CustomPainter {
  final double t;
  final bool isDark;
  final Color base;
  const _DynamicPainter({required this.t, required this.isDark, required this.base});

  static const List<Color> _cycle = [
    Color(0xFF12C2D6), // teal
    Color(0xFF2F6BFF), // blue
    Color(0xFF5B3DF5), // indigo
    Color(0xFFB23CFF), // violet
    Color(0xFFE23DA8), // magenta
    Color(0xFF2F6BFF), // blue
  ];

  Color _at(double p) {
    final n = _cycle.length;
    final x = (p % 1.0) * n;
    final i = x.floor() % n;
    final f = x - x.floor();
    return Color.lerp(_cycle[i], _cycle[(i + 1) % n], Curves.easeInOut.transform(f))!;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = base);

    final strength = isDark ? 0.60 : 0.42;
    const tau = 2 * math.pi;
    // four big glows wandering across the WHOLE screen, each with its own colour phase
    for (var i = 0; i < 3; i++) {
      final ph = t * (0.9 + 0.17 * i) + i * 0.27;
      final cx = w * (0.5 + 0.55 * math.sin(tau * ph + i * 1.7));
      final cy = h * (0.5 + 0.48 * math.cos(tau * ph * 0.78 + i * 2.3));
      final r = w * (0.95 + 0.25 * math.sin(tau * ph * 1.3 + i));
      final col = _at(t * 0.55 + i * 0.22);
      final shader = RadialGradient(
        colors: [al(col, strength), al(col, strength * 0.4), al(col, 0)],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r));
      canvas.drawRect(Rect.fromCircle(center: Offset(cx, cy), radius: r).intersect(rect),
          Paint()..shader = shader);
    }
    // gentle diagonal wash so the whole surface carries colour
    final wash = LinearGradient(
      begin: Alignment(-1 + 2 * ((t * 0.4) % 1.0), -1),
      end: Alignment(1 - 2 * ((t * 0.4) % 1.0), 1),
      colors: [al(_at(t * 0.55 + 0.1), 0.16), al(_at(t * 0.55 + 0.6), 0.16)],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = wash);

    // light veil keeps text readable on top of the colour
    canvas.drawRect(rect, Paint()..color = al(base, isDark ? 0.18 : 0.10));
  }

  @override
  bool shouldRepaint(covariant _DynamicPainter old) =>
      old.t != t || old.isDark != isDark || old.base != base;
}

class _Glow extends StatelessWidget {
  final Color color;
  final double size;
  final double alpha;
  const _Glow({required this.color, required this.size, required this.alpha});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [al(color, alpha), al(color, 0)]),
        ),
      ),
    );
  }
}

class _StarPainter extends CustomPainter {
  const _StarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(11);
    final p = Paint();
    for (var i = 0; i < 150; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final rad = 0.4 + r.nextDouble() * 1.1;
      p.color = Colors.white.withAlpha((50 + r.nextInt(170)));
      canvas.drawCircle(Offset(x, y), rad, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Text filled with the same flowing colours as the Dynamic theme.
class DynamicText extends StatefulWidget {
  final String text;
  final double fontSize;
  final FontWeight weight;
  final double letterSpacing;
  final TextAlign align;
  const DynamicText(
    this.text, {
    super.key,
    this.fontSize = 28,
    this.weight = FontWeight.w800,
    this.letterSpacing = 0.5,
    this.align = TextAlign.center,
  });

  @override
  State<DynamicText> createState() => _DynamicTextState();
}

class _DynamicTextState extends State<DynamicText> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat();

  static const List<Color> _cols = [
    Color(0xFF2DD4E6),
    Color(0xFF5B8CFF),
    Color(0xFF8B6CFF),
    Color(0xFFD25BFF),
    Color(0xFFFF5FBF),
    Color(0xFF2DD4E6),
  ];

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final t = _dynClock.elapsedMilliseconds / 1000.0;
          return ShaderMask(
            blendMode: BlendMode.srcIn,
            shaderCallback: (r) {
              final w = math.max(r.width, 1.0);
              // slide a mirrored gradient sideways => colours flow through the text
              final dx = -(t * 0.35 % 2.0) * w;
              return const LinearGradient(colors: _cols, tileMode: TileMode.mirror)
                  .createShader(Rect.fromLTWH(dx, 0, w, r.height));
            },
            child: Text(
              widget.text,
              textAlign: widget.align,
              style: TextStyle(
                color: Colors.white,
                fontSize: widget.fontSize,
                fontWeight: widget.weight,
                letterSpacing: widget.letterSpacing,
              ),
            ),
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------- primitives
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  final VoidCallback? onLongPress;
  const Pressable(
      {super.key, required this.child, this.onTap, this.onLongPress, this.scale = 0.97});

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.onTap == null ? null : (_) => setState(() => _down = true),
      onTapUp: widget.onTap == null ? null : (_) => setState(() => _down = false),
      onTapCancel: widget.onTap == null ? null : () => setState(() => _down = false),
      onTap: widget.onTap == null
          ? null
          : () {
              widget.onTap!();
              Haptics.selection();
            },
      onLongPress: widget.onLongPress == null
          ? null
          : () {
              Haptics.medium();
              widget.onLongPress!();
            },
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: Duration(milliseconds: _down ? 110 : 220),
        curve: _down ? Curves.easeOut : Curves.easeOutBack,
        child: widget.child,
      ),
    );
  }
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 22,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: c.isDark
              ? [al(const Color(0xFF1B1B27), 0.80), al(c.surface, 0.66)]
              : [al(Colors.white, 0.96), al(c.surface, 0.86)],
        ),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
            color: c.isDark ? al(Colors.white, 0.09) : al(Colors.black, 0.06)),
        boxShadow: c.isDark
            ? null
            : [BoxShadow(color: al(Colors.black, 0.05), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: child,
    );
    if (onTap == null) return box;
    return Pressable(onTap: onTap, onLongPress: onLongPress, child: box);
  }
}

class FadeSlide extends StatelessWidget {
  final Widget child;
  final int delay;
  final double dy;
  const FadeSlide({super.key, required this.child, this.delay = 0, this.dy = 18});

  @override
  Widget build(BuildContext context) {
    final total = 620 + delay;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: total),
      curve: Interval(delay / total, 1, curve: Curves.easeOutQuart),
      builder: (_, v, ch) => Opacity(
        opacity: Curves.easeOut.transform(v.clamp(0.0, 1.0)),
        child: Transform.translate(
          offset: Offset(0, (1 - v) * (dy + 6)),
          child: Transform.scale(scale: 0.94 + 0.06 * v, child: ch),
        ),
      ),
      child: child,
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool loading;
  final bool expand;
  const GradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.loading = false,
    this.expand = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: loading ? null : onTap,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          gradient: c.gradient,
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(color: al(c.a, 0.35), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (loading)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            else if (icon != null)
              Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SubtleButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final Color? color;
  const SubtleButton(
      {super.key, required this.label, required this.icon, this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final col = color ?? c.text;
    return Pressable(
      onTap: onTap,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        decoration: BoxDecoration(
          color: al(c.surface, c.isDark ? 0.7 : 0.9),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: c.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 19, color: col),
            const SizedBox(width: 8),
            Flexible(
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: col, fontWeight: FontWeight.w600, fontSize: 14.5)),
            ),
          ],
        ),
      ),
    );
  }
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  const RoundIconButton({super.key, required this.icon, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: onTap,
      scale: 0.9,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: al(c.surface, c.isDark ? 0.8 : 0.95),
          border: Border.all(color: c.border),
        ),
        child: Icon(icon, size: 20, color: color ?? c.text),
      ),
    );
  }
}

class TopBar extends StatelessWidget {
  final String? title;
  final List<Widget> actions;
  const TopBar({super.key, this.title, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          RoundIconButton(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.of(context).maybePop(),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                title ?? '',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: c.text, fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          for (final a in actions) ...[const SizedBox(width: 8), a],
        ],
      ),
    );
  }
}

class PageScaffold extends StatelessWidget {
  final Widget child;
  const PageScaffold({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Positioned.fill(child: SafeArea(child: child)),
        ],
      ),
    );
  }
}

InputDecoration bareInput(BuildContext context, String hint) {
  final c = context.colors;
  return InputDecoration(
    hintText: hint,
    hintStyle: TextStyle(color: al(c.dim, 0.8)),
    border: InputBorder.none,
    enabledBorder: InputBorder.none,
    focusedBorder: InputBorder.none,
    isDense: true,
    contentPadding: const EdgeInsets.symmetric(vertical: 12),
  );
}

/// Single-colour gradient with the same shape as the accent gradient: when a chip or card
/// switches on/off inside an AnimatedContainer it cross-fades cleanly (a null gradient
/// would make it flash dim for a moment).
LinearGradient flatGradient(Color c) =>
    LinearGradient(colors: [c, c], begin: Alignment.topLeft, end: Alignment.bottomRight);

class MoodPicker extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const MoodPicker({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Row(
      children: [
        for (var m = 1; m <= 5; m++)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Pressable(
                onTap: () {
                  Haptics.selection();
                  onChanged(m);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: value == m
                        ? al(moodColor(m), 0.22)
                        : al(c.surface, c.isDark ? 0.7 : 0.9),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: value == m ? moodColor(m) : c.border,
                      width: value == m ? 1.5 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedScale(
                        scale: value == m ? 1.2 : 1,
                        duration: const Duration(milliseconds: 250),
                        child: Text(moodEmoji(m), style: const TextStyle(fontSize: 26)),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        context.t('mood_$m'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10.5,
                          color: value == m ? c.text : c.dim,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirm,
  bool danger = true,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      final c = ctx.colors;
      return AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(26),
          side: BorderSide(color: c.border),
        ),
        title: Text(title, style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
        content: Text(message, style: TextStyle(color: c.dim)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(ctx.t('cancel'), style: TextStyle(color: c.dim)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              confirm,
              style: TextStyle(
                color: danger ? const Color(0xFFFF5470) : c.a,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      );
    },
  );
  return r ?? false;
}


/// Small pill shown on dreams that were lucid.
class LucidTag extends StatelessWidget {
  final bool compact;
  final bool onDark;
  const LucidTag({super.key, this.compact = false, this.onDark = false});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final fg = onDark ? Colors.white : c.a;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: compact ? 3 : 5),
      decoration: BoxDecoration(
        color: al(c.a, onDark ? 0.45 : 0.16),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: al(c.a, 0.55)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.visibility_rounded, size: compact ? 12 : 14, color: fg),
          const SizedBox(width: 4),
          Text(context.t('lucid_tag'),
              style: TextStyle(
                  color: fg,
                  fontSize: compact ? 10.5 : 12,
                  fontWeight: FontWeight.w800,
                  decoration: TextDecoration.none)),
        ],
      ),
    );
  }
}
