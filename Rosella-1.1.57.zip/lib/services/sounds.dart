import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../core/strings.dart';
import 'notifier.dart';
import 'sound_session.dart';
import 'sound_synth.dart';

class SoundDef {
  final String id;
  final String nameKey;
  final IconData icon;
  final List<Color> colors;
  const SoundDef(this.id, this.nameKey, this.icon, this.colors);
}

const List<SoundDef> kSounds = [
  SoundDef('wind', 'snd_wind', Icons.air_rounded,
      [Color(0xFF5B8DEF), Color(0xFF38BDF8)]),
  SoundDef('birds', 'snd_birds', Icons.emoji_nature_rounded,
      [Color(0xFF34D399), Color(0xFFA3E635)]),
  SoundDef('fire', 'snd_fire', Icons.local_fire_department_rounded,
      [Color(0xFFFF8A4C), Color(0xFFFF4F7B)]),
  SoundDef('rain', 'snd_rain', Icons.water_drop_rounded,
      [Color(0xFF7C5CFF), Color(0xFF3DD6F5)]),
  SoundDef('thunder', 'snd_thunder', Icons.thunderstorm_rounded,
      [Color(0xFF6D5BFF), Color(0xFFB36BFF)]),
  SoundDef('waves', 'snd_waves', Icons.waves_rounded,
      [Color(0xFF0EA5E9), Color(0xFF22D3EE)]),
  SoundDef('stream', 'snd_stream', Icons.opacity_rounded,
      [Color(0xFF14B8A6), Color(0xFF60A5FA)]),
  SoundDef('train', 'snd_train', Icons.train_rounded,
      [Color(0xFFF59E0B), Color(0xFFEF4444)]),
];

SoundDef soundDef(String id) => kSounds.firstWhere((d) => d.id == id, orElse: () => kSounds.first);

class SoundController extends ChangeNotifier {
  SoundController({this.handler, this.langOf}) {
    handler
      ?..onPlayReq = resumeAll
      ..onPauseReq = pauseAll
      ..onStopReq = stop;
  }

  final SoundAudioHandler? handler;
  final String Function()? langOf;
  bool paused = false;
  bool _askedNotif = false;

  void _syncSession() {
    final h = handler;
    if (h == null) return;
    try {
      if (active.isEmpty) {
        h.hide();
      } else {
        final lang = langOf?.call() ?? 'en';
        final title = active.map((id) => Strings.get(lang, soundDef(id).nameKey)).join(' + ');
        h.show(title, !paused);
      }
    } catch (e) {
      SoundAudioHandler.status = 'session error: $e';
    }
  }

  Future<void> pauseAll() async {
    paused = true;
    for (final p in _players.values) {
      try {
        await p.pause();
      } catch (_) {}
    }
    _syncSession();
    _notify();
  }

  Future<void> resumeAll() async {
    paused = false;
    for (final p in _players.values) {
      try {
        await p.resume();
      } catch (_) {}
    }
    _syncSession();
    _notify();
  }

  /// one player per running sound, so several sounds can be mixed
  final Map<String, AudioPlayer> _players = {};
  final Map<String, double> levels = {};

  /// ids in the order they were started
  final List<String> active = [];
  String? loadingId;
  double volume = 0.7;
  int timerTotal = 0; // minutes, 0 = off
  int remaining = 0; // seconds
  Timer? _timer;
  bool _disposed = false;

  bool get isPlaying => active.isNotEmpty;
  bool isActive(String id) => active.contains(id);
  double levelOf(String id) => levels[id] ?? 0.8;

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<String> _file(String id) async {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/dt_$id.v4.wav');
    if (!await f.exists() || await f.length() < 1000) {
      final bytes = await compute(synthesizeWav, id);
      await f.writeAsBytes(bytes, flush: true);
    }
    return f.path;
  }

  /// 1.0 normally; slides down to 0 during the last minutes of the sleep timer
  double _fade = 1.0;
  int _tickTotal = 0;

  double _eff(String id) => (volume * levelOf(id) * _fade).clamp(0.0, 1.0);

  Future<void> _applyVolumes() async {
    for (final e in _players.entries) {
      try {
        await e.value.setVolume(_eff(e.key));
      } catch (_) {}
    }
  }

  Future<void> toggle(String id) async {
    if (loadingId != null) return;
    if (isActive(id)) {
      await _stopOne(id);
      return;
    }
    loadingId = id;
    _notify();
    if (!_askedNotif) {
      _askedNotif = true;
      try {
        await Notifier.requestPermission();
      } catch (_) {}
    }
    try {
      final p = AudioPlayer();
      // mix with the other sounds instead of taking audio focus from them
      await p.setAudioContext(AudioContext(
        android: AudioContextAndroid(audioFocus: AndroidAudioFocus.none),
      ));
      await p.setReleaseMode(ReleaseMode.loop);
      levels.putIfAbsent(id, () => 0.8);
      await p.setVolume(_eff(id));
      try {
        // real recordings (CC0 / CC BY) shipped inside the app
        await p.play(AssetSource('sounds/$id.ogg'));
      } catch (_) {
        // fallback: the synthesized version
        final path = await _file(id);
        await p.play(DeviceFileSource(path));
      }
      _players[id] = p;
      active.add(id);
      paused = false;
      if (timerTotal > 0 && _timer == null) _startTicking(timerTotal * 60);
    } catch (_) {
      // leave the sound off
    }
    loadingId = null;
    _syncSession();
    _notify();
  }

  Future<void> _stopOne(String id) async {
    final p = _players.remove(id);
    active.remove(id);
    try {
      await p?.stop();
      await p?.dispose();
    } catch (_) {}
    if (active.isEmpty) {
      _cancelTimer();
      _fade = 1.0;
      if (timerTotal > 0) remaining = timerTotal * 60;
    }
    _syncSession();
    _notify();
  }

  Future<void> stop() async {
    _cancelTimer();
    final ps = _players.values.toList();
    _players.clear();
    active.clear();
    for (final p in ps) {
      try {
        await p.stop();
        await p.dispose();
      } catch (_) {}
    }
    _fade = 1.0;
    if (timerTotal > 0) remaining = timerTotal * 60;
    paused = false;
    _syncSession();
    _notify();
  }

  Future<void> setVolume(double v) async {
    volume = v;
    for (final e in _players.entries) {
      try {
        await e.value.setVolume(_eff(e.key));
      } catch (_) {}
    }
    _notify();
  }

  Future<void> setLevel(String id, double v) async {
    levels[id] = v;
    try {
      await _players[id]?.setVolume(_eff(id));
    } catch (_) {}
    _notify();
  }

  void setTimer(int minutes) {
    _cancelTimer();
    if (_fade != 1.0) {
      _fade = 1.0;
      _applyVolumes();
    }
    timerTotal = minutes;
    remaining = minutes * 60;
    if (minutes > 0 && isPlaying) _startTicking(minutes * 60);
    _notify();
  }

  void _startTicking(int seconds) {
    _cancelTimer();
    remaining = seconds;
    _tickTotal = seconds;
    // the sound fades out slowly over the last part of the timer (up to 5 minutes)
    final fadeSecs = math.min(300, (seconds * 0.3).round());
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      remaining--;
      if (remaining <= 0) {
        _fadeAndStop();
      } else {
        if (fadeSecs > 0 && remaining <= fadeSecs) {
          _fade = (remaining / fadeSecs).clamp(0.0, 1.0);
          _applyVolumes();
        }
        _notify();
      }
    });
  }

  void _cancelTimer() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _fadeAndStop() async {
    _cancelTimer();
    for (var i = 9; i >= 0; i--) {
      for (final e in _players.entries) {
        try {
          await e.value.setVolume(_eff(e.key) * i / 10);
        } catch (_) {}
      }
      await Future.delayed(const Duration(milliseconds: 180));
    }
    await stop();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    for (final p in _players.values) {
      p.dispose();
    }
    super.dispose();
  }
}
