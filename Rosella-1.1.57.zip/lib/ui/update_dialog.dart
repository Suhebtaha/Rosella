import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/update_check.dart';
import 'widgets.dart';

/// Update sheet: what changed, the file to install, one big progress button.
/// The download belongs to [UpdateJob], so it keeps going when the sheet is hidden.
Future<void> showUpdateDialog(BuildContext context, UpdateInfo info) {
  final c = context.colors;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: c.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
    ),
    builder: (_) => _UpdateSheet(info: info),
  );
}

enum _St { idle, perm, error }

class _UpdateSheet extends StatefulWidget {
  final UpdateInfo info;
  const _UpdateSheet({required this.info});

  @override
  State<_UpdateSheet> createState() => _UpdateSheetState();
}

class _UpdateSheetState extends State<_UpdateSheet> with WidgetsBindingObserver {
  final UpdateJob _job = UpdateJob.I;
  _St _st = _St.idle;
  String _err = '';
  String? _ready;
  bool _installing = false;

  bool get _mine => _job.tag == widget.info.tag;
  bool get _busy => _job.downloading && _mine;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _job.dialogOpen = true;
    _job.acknowledge();
    _job.addListener(_onJob);
    if (_job.readyPath != null && _mine) _ready = _job.readyPath;
    UpdateCheck.readyPath(widget.info.tag, expected: widget.info.apkSize).then((p) {
      if (mounted && p != null) setState(() => _ready = p);
    });
  }

  @override
  void dispose() {
    _job.dialogOpen = false;
    _job.removeListener(_onJob);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onJob() {
    if (!mounted) return;
    if (!_job.downloading && _mine) {
      if (_job.readyPath != null && _ready == null) {
        _ready = _job.readyPath;
        _installNow();
        return;
      }
      if (_job.error.isNotEmpty) {
        _st = _St.error;
        _err = _job.error;
      }
    }
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _st == _St.perm && _ready != null) {
      _installNow();
    }
  }

  Future<void> _installNow() async {
    final path = _ready;
    if (path == null) return _go();
    if (_installing) return;
    _installing = true;
    final r = await UpdateCheck.install(path);
    _installing = false;
    if (!mounted) return;
    if (r == 'ok') {
      Navigator.of(context).pop();
    } else if (r == 'perm') {
      setState(() => _st = _St.perm);
    } else {
      setState(() {
        _st = _St.error;
        _err = 'install';
      });
    }
  }

  Future<void> _go() async {
    if (_busy) {
      // pressing the progress button again cancels the download
      _job.cancel();
      return;
    }
    if (_ready != null) return _installNow();
    if (widget.info.apkUrl.isEmpty) return _github();
    setState(() => _st = _St.idle);
    _job.start(
      widget.info,
      title: '${context.t('downloading')} ${widget.info.tag}',
      doneTitle: context.t('update_downloaded'),
      doneBody: context.t('update_downloaded_sub'),
    );
  }

  Future<void> _github() async {
    final url = widget.info.url.isEmpty ? kReleasesPage : widget.info.url;
    final ok = await UpdateCheck.open(url);
    if (!ok) {
      await Clipboard.setData(ClipboardData(text: url));
      if (mounted) toast(context, context.t('copied'));
    }
  }

  void _cancelDownload() {
    _job.cancel();
    Navigator.of(context).pop();
  }

  void _later() {
    context.read<AppState>().snoozeUpdate();
    Navigator.of(context).pop();
  }

  /// GitHub markdown → short list of (isBullet, text) lines.
  List<(bool, String)> _lines(String md) {
    final out = <(bool, String)>[];
    for (var raw in md.split('\n')) {
      var l = raw.trim();
      if (l.isEmpty || l.startsWith('---') || l.startsWith('<')) continue;
      l = l.replaceAllMapped(RegExp(r'\[([^\]]*)\]\([^)]*\)'), (m) => m.group(1) ?? '');
      l = l.replaceAll(RegExp(r'[*_`]'), '');
      var bullet = false;
      if (l.startsWith('- ') || l.startsWith('• ')) {
        bullet = true;
        l = l.substring(2).trim();
      } else if (RegExp(r'^\d+[.)] ').hasMatch(l)) {
        bullet = true;
        l = l.replaceFirst(RegExp(r'^\d+[.)] '), '');
      } else if (l.startsWith('#')) {
        l = l.replaceFirst(RegExp(r'^#+\s*'), '');
      }
      if (l.isEmpty) continue;
      out.add((bullet, l));
      if (out.length >= 40) break;
    }
    return out;
  }

  String _mb(int b) => '${(b / 1048576).toStringAsFixed(1)} MB';

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final busy = _busy;
    final p = _job.progress;
    final info = widget.info;
    final lines = _lines(info.notes);

    String label;
    if (busy) {
      label = '${context.t('downloading')} ${(100 * p).round()}%  ·  ${context.t('cancel')}';
    } else if (_st == _St.perm) {
      label = context.t('update_perm');
    } else if (_st == _St.error) {
      label = '${context.t('try_again')}${_err.isEmpty ? '' : '  ·  $_err'}';
    } else if (_ready != null) {
      label = context.t('install_now');
    } else {
      label = context.t('update_inapp');
    }

    final size = MediaQuery.of(context).size;
    final land = size.width > size.height;

    final handle = Center(
      child: Container(
        width: 44,
        height: 5,
        decoration:
            BoxDecoration(color: al(c.text, 0.25), borderRadius: BorderRadius.circular(3)),
      ),
    );
    final logo = Container(
      width: land ? 50 : 62,
      height: land ? 50 : 62,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [c.a, c.b]),
      ),
      child: Icon(Icons.nights_stay_rounded, color: onAccent(c.a, c.b), size: land ? 25 : 30),
    );
    final title = Text(context.t('update_available'),
        style: TextStyle(color: c.text, fontSize: land ? 21 : 24, fontWeight: FontWeight.w800));
    final closeBtn =
        busy ? RoundIconButton(icon: Icons.close_rounded, onTap: _cancelDownload) : null;

    Widget notes({required bool fill}) {
      final box = Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
        decoration: BoxDecoration(
          color: al(c.text, 0.06),
          borderRadius: BorderRadius.circular(22),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${context.t('update_whatsnew')} ${info.tag}',
                  style: TextStyle(color: c.text, fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              if (lines.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(context.t('update_no_notes'),
                      style: TextStyle(color: c.dim, fontSize: 14.5)),
                ),
              for (final l in lines)
                Padding(
                  padding: const EdgeInsets.only(bottom: 9),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (l.$1)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(top: 8, end: 10),
                          child: Container(
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(color: c.dim, shape: BoxShape.circle),
                          ),
                        ),
                      Expanded(
                        child: Text(l.$2,
                            style: TextStyle(
                                color: l.$1 ? c.dim : c.text,
                                fontWeight: l.$1 ? FontWeight.w500 : FontWeight.w700,
                                fontSize: 14.5,
                                height: 1.4)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      );
      return box;
    }

    final apkCard = Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: al(c.text, 0.06),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(13),
              gradient: LinearGradient(colors: [c.a, c.b]),
            ),
            child: Icon(Icons.nights_stay_rounded, color: onAccent(c.a, c.b), size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(info.apkName.isEmpty ? 'Rosella ${info.tag}.apk' : info.apkName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.text, fontSize: 15.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text('com.suhaib.rosella${info.apkSize > 0 ? ' · ${_mb(info.apkSize)}' : ''}',
                    style: TextStyle(color: c.dim, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );

    // main button: fills up while downloading, press again to cancel
    final mainBtn = Pressable(
      onTap: _go,
      scale: 0.98,
      child: Container(
        height: 58,
        width: double.infinity,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: busy ? al(Colors.white, 0.10) : const Color(0xFFE8E8EC),
          borderRadius: BorderRadius.circular(29),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (busy)
              Positioned.fill(
                child: Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: FractionallySizedBox(
                    widthFactor: p <= 0 ? 0.02 : p.clamp(0.02, 1.0),
                    child: Container(color: al(Colors.white, 0.25)),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: busy ? Colors.white : Colors.black,
                      fontSize: 16.5,
                      fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
    final manualBtn = _SecondaryBtn(text: context.t('update_manual'), onTap: _github);
    final laterBtn = _SecondaryBtn(
      text: busy ? context.t('update_hide') : context.t('update_remind'),
      onTap: busy ? () => Navigator.of(context).pop() : _later,
    );
    final toInstall = Text(context.t('update_to_install'),
        style: TextStyle(color: c.dim, fontSize: 13.5, fontWeight: FontWeight.w600));

    if (land) {
      // landscape: file + buttons on one side, the release notes on the other (both scroll)
      return SafeArea(
        child: SizedBox(
          height: size.height,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 10, 24, 12),
            child: Column(
              children: [
                handle,
                const SizedBox(height: 10),
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        flex: 5,
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                logo,
                                const SizedBox(width: 14),
                                Expanded(child: title),
                                if (closeBtn != null) closeBtn,
                              ]),
                              const SizedBox(height: 14),
                              toInstall,
                              const SizedBox(height: 8),
                              apkCard,
                              const SizedBox(height: 12),
                              mainBtn,
                              const SizedBox(height: 8),
                              manualBtn,
                              const SizedBox(height: 8),
                              laterBtn,
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(flex: 6, child: notes(fill: true)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            handle,
            const SizedBox(height: 16),
            Row(children: [logo, const Spacer(), if (closeBtn != null) closeBtn]),
            const SizedBox(height: 14),
            title,
            const SizedBox(height: 14),
            Flexible(child: notes(fill: false)),
            const SizedBox(height: 16),
            toInstall,
            const SizedBox(height: 8),
            apkCard,
            const SizedBox(height: 16),
            mainBtn,
            const SizedBox(height: 10),
            manualBtn,
            const SizedBox(height: 10),
            laterBtn,
          ],
        ),
      ),
    );
  }
}

class _SecondaryBtn extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _SecondaryBtn({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: onTap,
      scale: 0.98,
      child: Container(
        height: 54,
        width: double.infinity,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: al(c.text, 0.06),
          borderRadius: BorderRadius.circular(27),
        ),
        child: Text(text,
            style: TextStyle(color: c.dim, fontSize: 15.5, fontWeight: FontWeight.w700)),
      ),
    );
  }
}
