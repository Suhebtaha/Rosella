import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/year_stats.dart';
import '../services/ai_service.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// Card on the Insights page that opens the yearly summary.
class YearRecapCard extends StatelessWidget {
  const YearRecapCard({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Panel(
        padding: const EdgeInsets.all(16),
        radius: 20,
        onTap: () {
          final app = context.read<AppState>();
          final years = YearStats.yearsWithDreams(app.dreams);
          if (years.isEmpty) {
            toast(context, app.tr('yr_none'));
            return;
          }
          Haptics.selection();
          final now = DateTime.now().year;
          Navigator.of(context).push(PageRouteBuilder<void>(
            transitionDuration: const Duration(milliseconds: 420),
            pageBuilder: (_, __, ___) =>
                YearRecapPage(year: years.contains(now) ? now : years.first),
            transitionsBuilder: (_, a, __, child) =>
                FadeTransition(opacity: CurvedAnimation(parent: a, curve: Curves.easeOut), child: child),
          ));
        },
        child: Row(children: [
          Icon(Icons.auto_stories_rounded, color: c.a, size: 26),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('yr_title'),
                    style: TextStyle(
                        color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(context.t('yr_sub'),
                    style: TextStyle(color: c.dim, fontSize: 12.5)),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: c.dim),
        ]),
      ),
    );
  }
}

const Color _ink = Color(0xFF05060F);

class YearRecapPage extends StatefulWidget {
  final int year;
  const YearRecapPage({super.key, required this.year});

  @override
  State<YearRecapPage> createState() => _YearRecapPageState();
}

class _YearRecapPageState extends State<YearRecapPage> with SingleTickerProviderStateMixin {
  final PageController _pc = PageController();
  final GlobalKey _shareKey = GlobalKey();
  late final AnimationController _tw =
      AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  late int _year = widget.year;
  YearStats? _st;
  int _page = 0;
  String? _ai;
  bool _aiBusy = false;
  bool _aiFail = false;
  bool _sharing = false;
  List<String> _ids = const [];

  @override
  void dispose() {
    _pc.dispose();
    _tw.dispose();
    super.dispose();
  }

  void _setYear(int y) {
    if (y == _year) return;
    setState(() {
      _year = y;
      _st = null;
      _ai = null;
      _aiBusy = false;
      _aiFail = false;
      _page = 0;
    });
    if (_pc.hasClients) _pc.jumpToPage(0);
  }

  Future<void> _loadAi() async {
    final st = _st;
    if (st == null || _ai != null || _aiBusy || st.count < 4) return;
    final app = context.read<AppState>();
    final cached = app.yearNote(st.year, st.count);
    if (cached != null) {
      setState(() => _ai = cached);
      return;
    }
    setState(() {
      _aiBusy = true;
      _aiFail = false;
    });
    try {
      final t = await AiService.yearReflection(
          year: st.year, ds: st.dreams, stats: st.forAi(), lang: app.lang);
      if (!mounted || _year != st.year) return;
      if (t.isEmpty) throw Exception('empty');
      app.setYearNote(st.year, st.count, t);
      Haptics.done();
      setState(() {
        _ai = t;
        _aiBusy = false;
      });
    } catch (_) {
      if (!mounted || _year != st.year) return;
      setState(() {
        _aiBusy = false;
        _aiFail = true;
      });
    }
  }

  Future<void> _share() async {
    final app = context.read<AppState>();
    setState(() => _sharing = true);
    try {
      final b = _shareKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('png');
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/rosella_year_$_year.png');
      await f.writeAsBytes(data.buffer.asUint8List(), flush: true);
      await app.external(() => Share.shareXFiles([XFile(f.path)], text: 'Rosella'));
    } catch (_) {
      if (mounted) toast(context, app.tr('share_failed'));
    }
    if (mounted) setState(() => _sharing = false);
  }

  void _next() {
    Haptics.selection();
    _pc.nextPage(duration: const Duration(milliseconds: 420), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final lang = app.lang;
    final st = _st ??= YearStats.of(_year, app.dreams);
    final years = YearStats.yearsWithDreams(app.dreams);

    // page list (ids first so the page-change hook knows which one is the AI page)
    final ids = <String>['intro', 'total', 'months', 'moods', 'tiles'];
    if (st.symbols.isNotEmpty) ids.add('symbols');
    ids..add('ai')..add('share');
    _ids = ids;

    Widget page(String id) => switch (id) {
          'intro' => _intro(st, c),
          'total' => _total(st, c),
          'months' => _months(st, c, lang),
          'moods' => _moods(st, c, lang),
          'tiles' => _tiles(st),
          'symbols' => _symbols(st, c),
          'ai' => _aiPage(st, c),
          _ => _sharePage(st, c),
        };

    return Scaffold(
      backgroundColor: _ink,
      body: Stack(children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF05060F), Color(0xFF0E0C2A), Color(0xFF241547)],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _tw,
            builder: (_, __) => CustomPaint(painter: _StarsPainter(_tw.value)),
          ),
        ),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(children: [
                RoundIconButton(
                  icon: Icons.close_rounded,
                  onTap: () => Navigator.of(context).maybePop(),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(children: [
                      for (var i = 0; i < ids.length; i++)
                        Expanded(
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            height: 3.5,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(3),
                              color: i <= _page
                                  ? Colors.white
                                  : Colors.white.withOpacity(0.22),
                            ),
                          ),
                        ),
                    ]),
                  ),
                ),
                if (years.length > 1)
                  PopupMenuButton<int>(
                    onSelected: _setYear,
                    color: const Color(0xFF1B1B27),
                    itemBuilder: (_) => [
                      for (final y in years)
                        PopupMenuItem<int>(
                          value: y,
                          child: Text('$y',
                              style: const TextStyle(
                                  color: Colors.white, fontWeight: FontWeight.w700)),
                        ),
                    ],
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text('$_year',
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.w700)),
                        const Icon(Icons.expand_more_rounded, color: Colors.white70, size: 18),
                      ]),
                    ),
                  )
                else
                  Text('$_year',
                      style: const TextStyle(
                          color: Colors.white70, fontWeight: FontWeight.w700)),
              ]),
            ),
            Expanded(
              child: PageView.builder(
                key: ValueKey(_year),
                controller: _pc,
                itemCount: ids.length,
                physics: const BouncingScrollPhysics(),
                onPageChanged: (i) {
                  setState(() => _page = i);
                  if (_ids[i] == 'ai') _loadAi();
                },
                itemBuilder: (_, i) => page(ids[i]),
              ),
            ),
            SizedBox(
              height: 64,
              child: _page >= ids.length - 1
                  ? const SizedBox.shrink()
                  : Center(
                      child: Pressable(
                        onTap: _next,
                        scale: 0.9,
                        child: Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white30),
                            color: Colors.white.withOpacity(0.06),
                          ),
                          child: const Icon(Icons.arrow_forward_rounded,
                              color: Colors.white, size: 22),
                        ),
                      ),
                    ),
            ),
          ]),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------------ pages
  Widget _slide(List<Widget> children) => LayoutBuilder(
        builder: (_, box) => SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: box.maxHeight),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: children),
          ),
        ),
      );

  Widget _grad(String text, double size, AppColors c, {FontWeight w = FontWeight.w900}) =>
      ShaderMask(
        shaderCallback: (r) =>
            LinearGradient(colors: [c.a, c.b]).createShader(Rect.fromLTWH(0, 0, r.width, r.height)),
        child: Text(text,
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white, fontSize: size, fontWeight: w, height: 1.05)),
      );

  Widget _count(int n, double size, {Color color = Colors.white}) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: n.toDouble()),
        duration: const Duration(milliseconds: 1400),
        curve: Curves.easeOutCubic,
        builder: (_, v, __) => Text('${v.round()}',
            style: TextStyle(
                color: color, fontSize: size, fontWeight: FontWeight.w900, height: 1.05)),
      );

  Widget _label(String s, {double size = 15, double alpha = 0.7}) => Text(s,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.white.withOpacity(alpha), fontSize: size, height: 1.4));

  Widget _intro(YearStats st, AppColors c) => _slide([
        _label(context.t('yr_title'), size: 16, alpha: 0.75),
        const SizedBox(height: 10),
        _grad('${st.year}', 104, c),
        const SizedBox(height: 14),
        _label(context.t('yr_sub'), size: 14.5, alpha: 0.6),
        const SizedBox(height: 36),
        _label(context.t('yr_swipe'), size: 13, alpha: 0.45),
      ]);

  Widget _total(YearStats st, AppColors c) => _slide([
        _count(st.count, 128),
        const SizedBox(height: 6),
        _label(context.t('yr_l_dreams'), size: 20, alpha: 0.9),
        const SizedBox(height: 30),
        _label('${st.days}  ${context.t('yr_l_days')}'),
        const SizedBox(height: 6),
        _label('${st.words}  ${context.t('yr_l_words')}'),
      ]);

  Widget _months(YearStats st, AppColors c, String lang) {
    final mx = math.max(1, st.monthCounts.reduce(math.max));
    return _slide([
      _label(context.t('yr_busy'), size: 16),
      const SizedBox(height: 8),
      if (st.busiestMonth > 0) ...[
        _grad(Strings.get(lang, 'm${st.busiestMonth}'), 44, c),
        const SizedBox(height: 4),
        _label('${st.monthCounts[st.busiestMonth - 1]} ${context.t('dreams_count')}',
            size: 14.5, alpha: 0.6),
      ],
      const SizedBox(height: 34),
      SizedBox(
        height: 170,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var i = 0; i < 12; i++)
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: st.monthCounts[i] / mx),
                      duration: Duration(milliseconds: 700 + i * 60),
                      curve: Curves.easeOutCubic,
                      builder: (_, v, __) => Container(
                        height: 4 + 120 * v,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          gradient: i + 1 == st.busiestMonth
                              ? LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [c.a, c.b])
                              : null,
                          color: i + 1 == st.busiestMonth
                              ? null
                              : Colors.white.withOpacity(st.monthCounts[i] == 0 ? 0.08 : 0.28),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('${i + 1}',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.5), fontSize: 11)),
                  ],
                ),
              ),
          ],
        ),
      ),
    ]);
  }

  Widget _moods(YearStats st, AppColors c, String lang) {
    final mx = math.max(1, st.moodCounts.reduce(math.max));
    Widget monthLine(String key, int m) => Padding(
          padding: const EdgeInsets.only(top: 6),
          child: _label('${context.t(key)}: ${Strings.get(lang, 'm$m')}', size: 14.5),
        );
    return _slide([
      _label(context.t('yr_mood'), size: 16),
      const SizedBox(height: 10),
      Text(st.topMood == 0 ? '' : moodEmoji(st.topMood), style: const TextStyle(fontSize: 64)),
      const SizedBox(height: 22),
      for (var m = 5; m >= 1; m--)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Text(moodEmoji(m), style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 12),
            Expanded(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: st.moodCounts[m - 1] / mx),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: FractionallySizedBox(
                    widthFactor: math.max(0.02, v),
                    child: Container(
                      height: 14,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: moodColor(m),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            SizedBox(
              width: 34,
              child: Text('${st.moodCounts[m - 1]}',
                  textAlign: TextAlign.end,
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
            ),
          ]),
        ),
      const SizedBox(height: 14),
      if (st.brightMonth > 0) monthLine('yr_bright', st.brightMonth),
      if (st.darkMonth > 0) monthLine('yr_dark', st.darkMonth),
    ]);
  }

  Widget _tile(int n, String label) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.07),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _count(n, 40),
            const SizedBox(height: 6),
            _label(label, size: 13, alpha: 0.7),
          ],
        ),
      );

  Widget _tiles(YearStats st) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Center(
          child: GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
            children: [
              _tile(st.longestStreak, context.t('yr_l_streak')),
              _tile(st.days, context.t('yr_l_days')),
              _tile(st.lucid, context.t('yr_l_lucid')),
              _tile(st.voice, context.t('yr_l_voice')),
              _tile(st.images, context.t('yr_l_images')),
              _tile(st.words, context.t('yr_l_words')),
            ],
          ),
        ),
      );

  Widget _symbols(YearStats st, AppColors c) {
    final mx = st.symbols.first.dreams;
    return _slide([
      _label(context.t('yr_symbols'), size: 18, alpha: 0.85),
      const SizedBox(height: 26),
      Wrap(
        alignment: WrapAlignment.center,
        spacing: 10,
        runSpacing: 12,
        children: [
          for (final s in st.symbols)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.white.withOpacity(0.07),
                border: Border.all(color: c.a.withOpacity(0.35 + 0.5 * s.dreams / mx)),
              ),
              child: Text('${s.word}  ×${s.dreams}',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15 + 9 * (s.dreams / mx))),
            ),
        ],
      ),
    ]);
  }

  Widget _aiPage(YearStats st, AppColors c) {
    Widget body;
    if (st.count < 4) {
      body = _label(context.t('yr_few'), size: 15);
    } else if (_aiBusy || (_ai == null && !_aiFail)) {
      body = Column(children: [
        SizedBox(
            width: 26,
            height: 26,
            child: CircularProgressIndicator(strokeWidth: 2.4, color: c.a)),
        const SizedBox(height: 16),
        _label(context.t('yr_ai_wait'), size: 14.5),
      ]);
    } else if (_aiFail) {
      body = Column(children: [
        _label(context.t('yr_ai_fail'), size: 15),
        const SizedBox(height: 14),
        SubtleButton(
          label: context.t('yr_retry'),
          icon: Icons.refresh_rounded,
          onTap: _loadAi,
        ),
      ]);
    } else {
      body = SelectableText(_ai!,
          style: const TextStyle(color: Colors.white, fontSize: 16.5, height: 1.75));
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 18, 28, 6),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.auto_awesome_rounded, color: c.a, size: 22),
          const SizedBox(width: 10),
          Expanded(child: _grad(context.t('yr_ai_title'), 24, c, w: FontWeight.w800)),
        ]),
        const SizedBox(height: 20),
        Expanded(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: SizedBox(width: double.infinity, child: body),
          ),
        ),
      ]),
    );
  }

  Widget _sharePage(YearStats st, AppColors c) {
    final words = st.symbols.take(4).map((s) => s.word).join(' · ');
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 8, 28, 0),
      child: Column(children: [
        Expanded(
          child: Center(
            child: AspectRatio(
              aspectRatio: 4 / 5,
              child: RepaintBoundary(
                key: _shareKey,
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF0B0A24), Color(0xFF2A1757), Color(0xFF0B0A24)],
                    ),
                    border: Border.all(color: Colors.white.withOpacity(0.14)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Rosella',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 15,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 14),
                      _grad('${st.year}', 52, c),
                      const SizedBox(height: 10),
                      Text('${st.count}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 76,
                              fontWeight: FontWeight.w900,
                              height: 1.0)),
                      _label(context.t('yr_l_dreams'), size: 16, alpha: 0.85),
                      const SizedBox(height: 22),
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        if (st.topMood > 0)
                          Text(moodEmoji(st.topMood), style: const TextStyle(fontSize: 34)),
                        if (st.topMood > 0) const SizedBox(width: 18),
                        Column(children: [
                          Text('${st.longestStreak}',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800)),
                          _label(context.t('yr_l_streak'), size: 11, alpha: 0.6),
                        ]),
                      ]),
                      if (words.isNotEmpty) ...[
                        const SizedBox(height: 22),
                        _label(words, size: 15, alpha: 0.8),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        GradientButton(
          label: context.t('yr_share'),
          icon: Icons.ios_share_rounded,
          loading: _sharing,
          expand: true,
          onTap: _share,
        ),
        const SizedBox(height: 8),
      ]),
    );
  }
}

class _StarsPainter extends CustomPainter {
  final double t;
  _StarsPainter(this.t);

  static final List<List<double>> _s = () {
    final r = math.Random(7);
    return [for (var i = 0; i < 70; i++) [r.nextDouble(), r.nextDouble(), r.nextDouble(), r.nextDouble()]];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    for (final s in _s) {
      final tw = 0.5 + 0.5 * math.sin((t + s[2]) * math.pi * 2);
      p.color = Colors.white.withOpacity(0.15 + 0.5 * tw * s[3]);
      canvas.drawCircle(Offset(s[0] * size.width, s[1] * size.height), 0.6 + 1.3 * s[3], p);
    }
  }

  @override
  bool shouldRepaint(_StarsPainter o) => o.t != t;
}
