import 'dart:async';

import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../services/haptics.dart';

/// Long scrub bar on the edge of the dream list. Drag it to jump through the list
/// quickly; a bubble shows the month and year of the dreams at that position.
class FastScroller extends StatefulWidget {
  final ScrollController controller;
  final List<Dream> dreams; // in the order shown (newest first)
  final String lang;
  final double top;
  final double bottom;
  const FastScroller({
    super.key,
    required this.controller,
    required this.dreams,
    required this.lang,
    this.top = 90,
    this.bottom = 130,
  });

  @override
  State<FastScroller> createState() => _FastScrollerState();
}

class _FastScrollerState extends State<FastScroller> {
  static const double _thumbH = 52;
  bool _drag = false;
  bool _active = false;
  double _f = 0;
  int _idx = 0;
  Timer? _fade;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() {});
    });
    // the list sizes itself over the first frames: re-check a couple of times
    for (final ms in const [250, 700, 1500]) {
      Future.delayed(Duration(milliseconds: ms), () {
        if (mounted && !_drag) setState(() {});
      });
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onScroll);
    _fade?.cancel();
    super.dispose();
  }

  void _onScroll() {
    if (!mounted || _drag) return;
    _active = true;
    _fade?.cancel();
    _fade = Timer(const Duration(milliseconds: 1400), () {
      if (mounted) setState(() => _active = false);
    });
    setState(() {});
  }

  void _move(double dy, double trackH) {
    final c = widget.controller;
    if (!c.hasClients) return;
    final room = trackH - _thumbH;
    if (room <= 0) return;
    final f = ((dy - _thumbH / 2) / room).clamp(0.0, 1.0);
    final n = widget.dreams.length;
    final idx = n == 0 ? 0 : (f * (n - 1)).round();
    final changed = _monthKey(idx) != _monthKey(_idx);
    c.jumpTo(f * c.position.maxScrollExtent);
    if (changed) Haptics.selection();
    setState(() {
      _f = f;
      _idx = idx;
    });
  }

  int _monthKey(int i) {
    if (widget.dreams.isEmpty) return 0;
    final d = widget.dreams[i.clamp(0, widget.dreams.length - 1)].createdAt;
    return d.year * 400 + d.month * 32 + d.day;
  }

  void _end() {
    setState(() {
      _drag = false;
      _active = true;
    });
    _fade?.cancel();
    _fade = Timer(const Duration(milliseconds: 1400), () {
      if (mounted) setState(() => _active = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final ctl = widget.controller;
    if (!ctl.hasClients || widget.dreams.length < 3) return const SizedBox.shrink();
    final max = ctl.position.maxScrollExtent;
    if (max < 80) return const SizedBox.shrink();
    return LayoutBuilder(builder: (ctx, cs) {
      final trackH = cs.maxHeight - widget.top - widget.bottom;
      if (trackH < _thumbH * 2) return const SizedBox.shrink();
      final f = _drag ? _f : (ctl.position.pixels / max).clamp(0.0, 1.0);
      final y = widget.top + f * (trackH - _thumbH);
      final hot = _drag || _active;
      final d = widget.dreams[_idx.clamp(0, widget.dreams.length - 1)].createdAt;
      return SizedBox.expand(
        child: Stack(children: [
          PositionedDirectional(
            end: 0,
            top: widget.top,
            height: trackH,
            width: 30,
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onVerticalDragStart: (e) {
                setState(() => _drag = true);
                _fade?.cancel();
                _move(e.localPosition.dy, trackH);
              },
              onVerticalDragUpdate: (e) => _move(e.localPosition.dy, trackH),
              onVerticalDragEnd: (_) => _end(),
              onVerticalDragCancel: _end,
            ),
          ),
          PositionedDirectional(
            end: 4,
            top: y,
            child: IgnorePointer(
              child: AnimatedOpacity(
                opacity: hot ? 1 : 0.7,
                duration: const Duration(milliseconds: 220),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  width: _drag ? 10 : 5,
                  height: _thumbH,
                  decoration: BoxDecoration(
                    color: _drag ? c.a : al(c.text, 0.55),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ),
          if (_drag)
            PositionedDirectional(
              end: 26,
              top: y + _thumbH / 2 - 26,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(
                    color: c.surfaceHi,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: c.border),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('${d.day}',
                        style: TextStyle(
                            color: c.a, fontSize: 24, fontWeight: FontWeight.w800)),
                    const SizedBox(width: 6),
                    Text(Strings.get(widget.lang, 'm${d.month}'),
                        style: TextStyle(
                            color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(width: 8),
                    Text('${d.year}',
                        style: TextStyle(
                            color: c.dim, fontSize: 14, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
            ),
        ]),
      );
    });
  }
}
