import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import '../services/sounds.dart';
import 'dream_editor.dart';
import 'widgets.dart';

/// Calm page for the middle of the night after a frightening dream: a slow breathing
/// circle, soft reassuring lines and a relaxing sound that starts by itself.
class SosPage extends StatefulWidget {
  const SosPage({super.key});

  @override
  State<SosPage> createState() => _SosPageState();
}

class _SosPageState extends State<SosPage> with TickerProviderStateMixin {
  // breathing rhythm in seconds: in, hold, out (slow, long exhale calms the body)
  static const int _in = 4, _hold = 4, _out = 6, _total = _in + _hold + _out;
  static const int _rounds = 5;
  static const List<String> _soundIds = ['rain', 'waves', 'stream', 'wind'];

  late final AnimationController _br =
      AnimationController(vsync: this, duration: const Duration(seconds: _total));
  late final AnimationController _stars =
      AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat();
  late final SoundController _sc;
  Timer? _lines;
  int _line = 0;
  int _phase = -1;
  int _cycle = 0;
  double _last = 0;
  bool _done = false;
  bool _startedSound = false;
  bool _keepSound = false;

  @override
  void initState() {
    super.initState();
    _sc = context.read<SoundController>();
    _br.addListener(_tick);
    _br.repeat();
    _lines = Timer.periodic(const Duration(seconds: 7), (_) {
      if (mounted) setState(() => _line = (_line + 1) % 4);
    });
    if (!_sc.isPlaying) {
      _startedSound = true;
      _sc.setVolume(0.5);
      _sc.toggle('rain');
    }
  }

  @override
  void dispose() {
    _lines?.cancel();
    _br.dispose();
    _stars.dispose();
    // stop the sound only if this page started it and the person did not ask to sleep to it
    if (_startedSound && !_keepSound) _sc.stop();
    super.dispose();
  }

  void _tick() {
    final sec = _br.value * _total;
    final ph = sec < _in ? 0 : (sec < _in + _hold ? 1 : 2);
    if (ph != _phase) {
      _phase = ph;
      Haptics.light();
    }
    if (_br.value < _last - 0.5) {
      _cycle++;
      if (_cycle >= _rounds) _finish();
    }
    _last = _br.value;
  }

  void _finish() {
    _br.stop();
    Haptics.done();
    if (mounted) setState(() => _done = true);
  }

  void _again() {
    _cycle = 0;
    _last = 0;
    _phase = -1;
    _br.value = 0;
    _br.repeat();
    setState(() => _done = false);
  }

  void _write() {
    _keepSound = false;
    Navigator.of(context)
        .pushReplacement(CupertinoPageRoute<void>(builder: (_) => const DreamEditorPage()));
  }

  void _sleep() {
    // keep the sound playing and let it fade out by itself in half an hour
    _keepSound = true;
    if (_sc.timerTotal == 0) _sc.setTimer(30);
    Navigator.of(context).pop();
  }

  Future<void> _pickSound(String id) async {
    Haptics.selection();
    _startedSound = true;
    if (_sc.isActive(id)) {
      await _sc.stop();
    } else {
      await _sc.stop();
      await _sc.toggle(id);
    }
    if (mounted) setState(() {});
  }

  double _scaleAt(double sec) {
    if (sec < _in) return 0.55 + 0.45 * Curves.easeInOut.transform(sec / _in);
    if (sec < _in + _hold) return 1.0;
    return 1.0 - 0.45 * Curves.easeInOut.transform((sec - _in - _hold) / _out);
  }

  @override
  Widget build(BuildContext context) {
    context.watch<SoundController>();
    String t(String k) => context.t(k);
    final size = MediaQuery.of(context).size;
    final d = math.min(size.width * 0.62, size.height * 0.34);

    return Scaffold(
      backgroundColor: const Color(0xFF050914),
      body: Stack(children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF050914), Color(0xFF0A1A2D), Color(0xFF12304D)],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _stars,
            builder: (_, __) => CustomPaint(painter: _SosStars(_stars.value)),
          ),
        ),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(children: [
                RoundIconButton(
                    icon: Icons.close_rounded, onTap: () => Navigator.of(context).maybePop()),
              ]),
            ),
            const SizedBox(height: 6),
            Text(t('sos_title'),
                style: const TextStyle(
                    color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 900),
                  child: Text(t('sos_l${_line + 1}'),
                      key: ValueKey(_line),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.72), fontSize: 16, height: 1.5)),
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: AnimatedBuilder(
                  animation: _br,
                  builder: (_, __) {
                    final sec = _br.value * _total;
                    final s = _done ? 0.8 : _scaleAt(sec);
                    final ph = sec < _in ? 0 : (sec < _in + _hold ? 1 : 2);
                    final end = ph == 0 ? _in : (ph == 1 ? _in + _hold : _total);
                    final left = math.max(1, (end - sec).ceil());
                    final label = _done
                        ? '✓'
                        : (ph == 0 ? t('br_in') : (ph == 1 ? t('br_hold') : t('br_out')));
                    return SizedBox(
                      width: d * 1.5,
                      height: d * 1.5,
                      child: Stack(alignment: Alignment.center, children: [
                        // soft outer glow
                        Container(
                          width: d * 1.5 * (0.7 + 0.3 * s),
                          height: d * 1.5 * (0.7 + 0.3 * s),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(colors: [
                              const Color(0xFF38BDF8).withOpacity(0.30 * s),
                              const Color(0x0038BDF8),
                            ]),
                          ),
                        ),
                        Container(
                          width: d * s,
                          height: d * s,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFF6C8CFF), Color(0xFF38BDF8)],
                            ),
                            boxShadow: [
                              BoxShadow(
                                  color: const Color(0xFF38BDF8).withOpacity(0.35),
                                  blurRadius: 40,
                                  spreadRadius: 2),
                            ],
                          ),
                          alignment: Alignment.center,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(label,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w800)),
                              if (!_done)
                                Text('$left',
                                    style: TextStyle(
                                        color: Colors.white.withOpacity(0.85), fontSize: 18)),
                            ],
                          ),
                        ),
                      ]),
                    );
                  },
                ),
              ),
            ),
            // sound choice
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 10,
                runSpacing: 8,
                children: [
                  for (final id in _soundIds)
                    Pressable(
                      onTap: () => _pickSound(id),
                      scale: 0.93,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          color: _sc.isActive(id)
                              ? Colors.white.withOpacity(0.18)
                              : Colors.white.withOpacity(0.06),
                          border: Border.all(
                              color: Colors.white.withOpacity(_sc.isActive(id) ? 0.45 : 0.15)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(soundDef(id).icon, color: Colors.white, size: 17),
                          const SizedBox(width: 7),
                          Text(t(soundDef(id).nameKey),
                              style: const TextStyle(color: Colors.white, fontSize: 13.5)),
                        ]),
                      ),
                    ),
                ],
              ),
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOutCubic,
              child: _done
                  ? Padding(
                      padding: const EdgeInsets.fromLTRB(22, 4, 22, 18),
                      child: Column(children: [
                        Text(t('sos_done'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text(t('sos_done_sub'),
                            style: TextStyle(color: Colors.white.withOpacity(0.65))),
                        const SizedBox(height: 14),
                        GradientButton(
                            label: t('sos_sleep'),
                            icon: Icons.bedtime_rounded,
                            expand: true,
                            onTap: _sleep),
                        const SizedBox(height: 10),
                        Row(children: [
                          Expanded(
                            child: SubtleButton(
                                label: t('sos_write'), icon: Icons.edit_rounded, onTap: _write),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: SubtleButton(
                                label: t('sos_again'), icon: Icons.refresh_rounded, onTap: _again),
                          ),
                        ]),
                      ]),
                    )
                  : const SizedBox(height: 18, width: double.infinity),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _SosStars extends CustomPainter {
  final double t;
  _SosStars(this.t);

  static final List<List<double>> _s = () {
    final r = math.Random(11);
    return [
      for (var i = 0; i < 60; i++) [r.nextDouble(), r.nextDouble(), r.nextDouble(), r.nextDouble()]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    for (final s in _s) {
      final tw = 0.5 + 0.5 * math.sin((t + s[2]) * math.pi * 2);
      p.color = Colors.white.withOpacity(0.12 + 0.4 * tw * s[3]);
      canvas.drawCircle(Offset(s[0] * size.width, s[1] * size.height), 0.6 + 1.1 * s[3], p);
    }
  }

  @override
  bool shouldRepaint(_SosStars o) => o.t != t;
}
