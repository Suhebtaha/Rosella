import 'models.dart';
import 'symbols.dart';

/// Numbers behind the yearly summary. Private dreams are left out because the summary
/// can be shared.
class YearStats {
  final int year;
  final List<Dream> dreams;
  final int days; // distinct days with a dream
  final int longestStreak;
  final int lucid;
  final int voice;
  final int images;
  final int words;
  final List<int> monthCounts; // 12
  final int busiestMonth; // 1..12 or 0
  final List<int> moodCounts; // 5
  final double avgMood;
  final int brightMonth; // best average mood, 0 if unknown
  final int darkMonth; // lowest average mood, 0 if unknown
  final List<SymbolCount> symbols;

  const YearStats({
    required this.year,
    required this.dreams,
    required this.days,
    required this.longestStreak,
    required this.lucid,
    required this.voice,
    required this.images,
    required this.words,
    required this.monthCounts,
    required this.busiestMonth,
    required this.moodCounts,
    required this.avgMood,
    required this.brightMonth,
    required this.darkMonth,
    required this.symbols,
  });

  int get count => dreams.length;

  /// 1..5 mood that appears most often (0 when empty).
  int get topMood {
    var best = 0;
    var n = 0;
    for (var i = 0; i < 5; i++) {
      if (moodCounts[i] > n) {
        n = moodCounts[i];
        best = i + 1;
      }
    }
    return best;
  }

  /// Short English line given to the AI together with a sample of dreams.
  String forAi() => 'dreams $count, days with a dream $days, longest streak $longestStreak days, '
      'lucid $lucid, voice recordings $voice, busiest month $busiestMonth, '
      'average mood ${avgMood.toStringAsFixed(1)}/5, '
      'top symbols ${symbols.take(6).map((s) => '${s.word} x${s.dreams}').join(', ')}';

  static List<int> yearsWithDreams(List<Dream> all) {
    final ys = {for (final d in all) if (!d.priv) d.createdAt.year}.toList()
      ..sort((a, b) => b.compareTo(a));
    return ys;
  }

  static YearStats of(int year, List<Dream> all) {
    final ds = [
      for (final d in all)
        if (!d.priv && d.createdAt.year == year) d
    ]..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    final dayset = {
      for (final d in ds) DateTime(d.createdAt.year, d.createdAt.month, d.createdAt.day)
    }.toList()
      ..sort();
    var longest = 0, run = 0;
    DateTime? prev;
    for (final day in dayset) {
      if (prev != null && DateTime(day.year, day.month, day.day - 1) == prev) {
        run++;
      } else {
        run = 1;
      }
      if (run > longest) longest = run;
      prev = day;
    }

    final months = List<int>.filled(12, 0);
    final moodSum = List<int>.filled(12, 0);
    final moods = List<int>.filled(5, 0);
    var words = 0, lucid = 0, voice = 0, images = 0, moodTotal = 0;
    for (final d in ds) {
      final m = d.createdAt.month - 1;
      months[m]++;
      moodSum[m] += d.mood;
      moods[(d.mood.clamp(1, 5)) - 1]++;
      moodTotal += d.mood;
      words += d.content.trim().isEmpty ? 0 : d.content.trim().split(RegExp(r'\s+')).length;
      if (d.lucid) lucid++;
      if (d.audio != null) voice++;
      if (d.image != null) images++;
    }
    var busiest = 0, bn = 0;
    for (var i = 0; i < 12; i++) {
      if (months[i] > bn) {
        bn = months[i];
        busiest = i + 1;
      }
    }
    var bright = 0, dark = 0;
    double bv = -1, dv = 99;
    for (var i = 0; i < 12; i++) {
      if (months[i] < 2) continue;
      final avg = moodSum[i] / months[i];
      if (avg > bv) {
        bv = avg;
        bright = i + 1;
      }
      if (avg < dv) {
        dv = avg;
        dark = i + 1;
      }
    }
    if (bright == dark) {
      bright = 0;
      dark = 0;
    }
    return YearStats(
      year: year,
      dreams: ds,
      days: dayset.length,
      longestStreak: longest,
      lucid: lucid,
      voice: voice,
      images: images,
      words: words,
      monthCounts: months,
      busiestMonth: busiest,
      moodCounts: moods,
      avgMood: ds.isEmpty ? 0 : moodTotal / ds.length,
      brightMonth: bright,
      darkMonth: dark,
      symbols: recurringSymbols(ds, max: 8),
    );
  }
}
