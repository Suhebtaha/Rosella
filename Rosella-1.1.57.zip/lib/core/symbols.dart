import 'dart:math' as math;

import 'models.dart';

class SymbolCount {
  final String word;
  final int dreams;
  const SymbolCount(this.word, this.dreams);
}

final Set<String> _stop = {
  // Arabic
  'في','من','على','الي','عن','مع','كان','كانت','كنت','ثم','هذا','هذه','ذلك','تلك','التي','الذي','انا','لكن','حتي','كل','بعد','قبل','عند','هو','هي','هم','او','ان','انه','انها','لم','لا','ما','ماذا','قد','كانوا','يكون','وكان','وكانت','فقط','جدا','هناك','هنا','حيث','بين','اني','لقد','اذا','ايضا','الا','له','لها','بها','به','منه','منها','فيه','فيها','عليه','عليها','حلمت','رايت','حلم','شفت','وانا','واني','لكني','وكنت','ثم','بعدها','فجاه','كأن','كان','يعني','شي','شيء','اللي','هاي','هذي','بس','مو','وين','شلون','ليش','كلها','كله','نفس','احد','شخص','اشخاص','اني','وبعدين',
  // English
  'the','and','was','were','that','this','with','for','you','had','have','has','but','not','are','from','they','them','his','her','she','him','then','there','their','what','when','where','who','into','out','about','just','like','very','been','being','would','could','dream','dreamed','dreamt','saw','one','all','got','get','went','came','some','also','still','even','while','after','before','over','back','around','through','than','too','can','did','does','its','our','your','mine','myself','because','were','which','will','much','more','many','made','make',
  // Kurdish (Sorani)
  'ئەو','ئەم','لە','بە','کە','من','لەگەڵ','بۆ','دا','هەبوو','بوو','بووم','ئەوە','ئەمە','یان','هەر','تەنها','زۆر','کاتێک','دواتر','پاشان','خەون','خەونم','بینیم','دەمبینی','لەناو','ئێمە','ئەوان','ئەویش','هیچ','هەموو','وەک','ڕۆیشتم','دوای','پێش','نێوان','چوومە','بووین','دەکرد','کرد','دەبوو','ئەگەر','بەڵام','چونکە','هێشتا','یەکێک','کەسێک','شتێک','لێ','پێ','تێ','ئەوەی','ئەوەش',
};

String _norm(String s) {
  var t = s.toLowerCase();
  t = t.replaceAll(RegExp('[ً-ْـ]'), '');
  t = t
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ک', 'ك')
      .replaceAll('ی', 'ي');
  return t;
}

/// Same spelling normalisation the symbol finder uses (for searching by symbol).
String normText(String s) => _norm(s);

final RegExp _split = RegExp(r'[^\p{L}\p{N}]+', unicode: true);
final Set<String> _stopN = _stop.map(_norm).toSet();

Set<String> _tokens(Dream d) {
  final out = <String>{};
  for (var w in _norm('${d.title} ${d.content}').split(_split)) {
    if (w.length > 4 && w.startsWith('ال')) w = w.substring(2);
    if (w.length < 3 || _stopN.contains(w)) continue;
    if (RegExp(r'^\d+$').hasMatch(w)) continue;
    out.add(w);
  }
  return out;
}

/// Words that show up in at least two different dreams, most frequent first.
List<SymbolCount> recurringSymbols(List<Dream> dreams, {int max = 10}) {
  final counts = <String, int>{};
  for (final d in dreams) {
    for (final w in _tokens(d)) {
      counts[w] = (counts[w] ?? 0) + 1;
    }
  }
  final list = counts.entries
      .where((e) => e.value >= 2)
      .map((e) => SymbolCount(e.key, e.value))
      .toList()
    ..sort((a, b) {
      final c = b.dreams.compareTo(a.dreams);
      return c != 0 ? c : a.word.compareTo(b.word);
    });
  return list.take(max).toList();
}

// ---------- similar dreams ----------

/// Loose tokenising for similarity: also drops a leading "و" / "ف" / "ب" / "ل"
/// prefix and the common ending letters so "البحر" / "بالبحر" / "وبحر" meet.
Set<String> _simTokens(Dream d) {
  final out = <String>{};
  for (var w in _norm('${d.title} ${d.content}').split(_split)) {
    if (w.length > 4 && w.startsWith('ال')) w = w.substring(2);
    if (w.length > 4 && (w.startsWith('وال') || w.startsWith('بال') || w.startsWith('لل'))) {
      w = w.substring(w.startsWith('لل') ? 2 : 3);
    }
    if (w.length > 4 && (w.startsWith('و') || w.startsWith('ب') || w.startsWith('ف'))) {
      w = w.substring(1);
    }
    if (w.length < 3 || _stopN.contains(w)) continue;
    if (RegExp(r'^\d+$').hasMatch(w)) continue;
    out.add(w);
  }
  return out;
}

class SimilarDream {
  final Dream dream;
  final List<String> words; // the shared words that made them similar
  final double score;
  const SimilarDream(this.dream, this.words, this.score);
}

/// Dreams from [all] that resemble [d]: shared rare words count more than common ones.
List<SimilarDream> similarDreams(Dream d, List<Dream> all, {int max = 5}) {
  final pool = [
    for (final x in all)
      if (x.id == d.id || (!x.priv || d.priv)) x
  ];
  final toks = {for (final x in pool) x.id: _simTokens(x)};
  final mine = toks[d.id] ?? _simTokens(d);
  if (mine.length < 2) return const [];
  final df = <String, int>{};
  for (final t in toks.values) {
    for (final w in t) {
      df[w] = (df[w] ?? 0) + 1;
    }
  }
  final n = pool.length + 1;
  double idf(String w) => math.log(1 + n / (df[w] ?? 1));
  final res = <SimilarDream>[];
  for (final x in pool) {
    if (x.id == d.id) continue;
    final t = toks[x.id]!;
    if (t.isEmpty) continue;
    final shared = [for (final w in mine) if (t.contains(w)) w];
    if (shared.length < 2) continue;
    var s = 0.0;
    for (final w in shared) {
      s += idf(w);
    }
    s = s / math.sqrt((mine.length + t.length) / 2);
    if (x.mood == d.mood) s *= 1.08;
    if (x.lucid && d.lucid) s *= 1.08;
    shared.sort((a, b) => idf(b).compareTo(idf(a)));
    res.add(SimilarDream(x, shared.take(3).toList(), s));
  }
  res.sort((a, b) => b.score.compareTo(a.score));
  return res.take(max).toList();
}
