import 'dart:math' as math;

import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';

Color al(Color c, double o) => c.withAlpha((o * 255).round().clamp(0, 255));

class AppPalette {
  final String id;
  final String nameKey;
  final Color a;
  final Color b;
  const AppPalette(this.id, this.nameKey, this.a, this.b);
}

const List<AppPalette> kPalettes = [
  AppPalette('dynamic', 'th_dynamic', Color(0xFF6C7BFF), Color(0xFF35D0E6)),
  AppPalette('space', 'th_space', Color(0xFF7C5CFF), Color(0xFF3DD6F5)),
  AppPalette('aurora', 'th_aurora', Color(0xFF2EE6A6), Color(0xFF3B82F6)),
  AppPalette('nebula', 'th_nebula', Color(0xFFFF4FD8), Color(0xFF7C5CFF)),
  AppPalette('sunset', 'th_sunset', Color(0xFFFF8A4C), Color(0xFFFF4F7B)),
  AppPalette('ocean', 'th_ocean', Color(0xFF38BDF8), Color(0xFF6366F1)),
  AppPalette('emerald', 'th_emerald', Color(0xFF34D399), Color(0xFFA3E635)),
  AppPalette('crimson', 'th_crimson', Color(0xFFFF4D6D), Color(0xFFFF9E5E)),
  AppPalette('gold', 'th_gold', Color(0xFFFFC857), Color(0xFFFF8A4C)),
  AppPalette('onyx', 'th_onyx', Color(0xFFF2F2F4), Color(0xFF8E8E96)),
  AppPalette('mono', 'th_mono', Color(0xFFE5E7EB), Color(0xFF9CA3AF)),
];

AppPalette paletteById(String id) =>
    kPalettes.firstWhere((p) => p.id == id, orElse: () => kPalettes.first);

Color _adapt(Color c, bool dark) {
  if (dark) return c;
  final hsl = HSLColor.fromColor(c);
  return hsl.withLightness(math.min(hsl.lightness, 0.5)).toColor();
}

/// Readable foreground for something painted with the accent gradient.
Color onAccent(Color a, Color b) =>
    (a.computeLuminance() + b.computeLuminance()) / 2 > 0.5
        ? const Color(0xFF111118)
        : Colors.white;

class AppColors extends ThemeExtension<AppColors> {
  final bool isDark;
  final Color bg;
  final Color surface;
  final Color surfaceHi;
  final Color text;
  final Color dim;
  final Color border;
  final Color a;
  final Color b;

  const AppColors({
    required this.isDark,
    required this.bg,
    required this.surface,
    required this.surfaceHi,
    required this.text,
    required this.dim,
    required this.border,
    required this.a,
    required this.b,
  });

  LinearGradient get gradient => LinearGradient(
        colors: [a, b],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  factory AppColors.from(AppPalette p, bool dark0) {
    final dark = dark0;
    final onyxLight = p.id == 'onyx' && !dark;
    return AppColors(
        isDark: dark,
        bg: dark ? Colors.black : const Color(0xFFF2F2F8),
        surface: dark ? (p.id == 'onyx' ? const Color(0xFF000000) : const Color(0xFF0F0F17)) : Colors.white,
        surfaceHi: dark ? (p.id == 'onyx' ? const Color(0xFF111113) : const Color(0xFF1A1A27)) : const Color(0xFFE9E9F2),
        text: dark ? const Color(0xFFF5F5FA) : const Color(0xFF14141F),
        dim: dark ? const Color(0xFF9494AB) : const Color(0xFF6A6A80),
        border: dark ? al(Colors.white, p.id == 'onyx' ? 0.16 : 0.08) : al(Colors.black, 0.07),
        a: onyxLight ? const Color(0xFF1A1A1F) : _adapt(p.a, dark),
        b: onyxLight ? const Color(0xFF5A5A64) : _adapt(p.b, dark),
      );
  }

  @override
  AppColors copyWith() => this;

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) return this;
    Color l(Color x, Color y) => Color.lerp(x, y, t)!;
    return AppColors(
      isDark: t < 0.5 ? isDark : other.isDark,
      bg: l(bg, other.bg),
      surface: l(surface, other.surface),
      surfaceHi: l(surfaceHi, other.surfaceHi),
      text: l(text, other.text),
      dim: l(dim, other.dim),
      border: l(border, other.border),
      a: l(a, other.a),
      b: l(b, other.b),
    );
  }
}

extension AppColorsX on BuildContext {
  AppColors get colors => Theme.of(this).extension<AppColors>()!;
}

ThemeData buildTheme(String paletteId, bool dark0) {
  final dark = dark0;
  final c = AppColors.from(paletteById(paletteId), dark);
  final br = dark ? Brightness.dark : Brightness.light;
  final base = ThemeData(brightness: br, useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: c.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: c.a, brightness: br)
        .copyWith(primary: c.a, secondary: c.b, surface: c.surface),
    textTheme: base.textTheme.apply(bodyColor: c.text, displayColor: c.text),
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      for (final p in TargetPlatform.values)
        p: const CupertinoPageTransitionsBuilder(),
    }),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected)
          ? onAccent(c.a, c.b)
          : (dark ? const Color(0xFFC4C4D2) : Colors.white)),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected)
          ? c.a
          : al(dark ? Colors.white : Colors.black, dark ? 0.14 : 0.14)),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
    ),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    dividerColor: c.border,
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: c.a,
      selectionColor: al(c.a, 0.3),
      selectionHandleColor: c.a,
    ),
    extensions: [c],
  );
}
