import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

/// Installed version. Publish GitHub releases with a tag like v1.1.1 (higher than this).
const String kAppVersion = '1.1.8';
const String kReleasesPage = 'https://github.com/Suhebtaha/Rosella/releases/latest';

class UpdateInfo {
  final bool available;
  final String tag;
  final String url;
  final bool failed;
  final String apkUrl;
  const UpdateInfo(
      {this.available = false,
      this.tag = '',
      this.url = kReleasesPage,
      this.failed = false,
      this.apkUrl = ''});
}

class UpdateCheck {
  static List<int> _parts(String v) {
    final m = RegExp(r'\d+').allMatches(v).map((e) => int.parse(e.group(0)!)).toList();
    while (m.length < 3) {
      m.add(0);
    }
    return m;
  }

  static bool _newer(String a, String b) {
    final x = _parts(a), y = _parts(b);
    for (var i = 0; i < 3; i++) {
      if (x[i] != y[i]) return x[i] > y[i];
    }
    return false;
  }

  static Future<UpdateInfo> check() async {
    try {
      final res = await http
          .get(
            Uri.parse('https://api.github.com/repos/Suhebtaha/Rosella/releases/latest'),
            headers: {'Accept': 'application/vnd.github+json'},
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 404) return const UpdateInfo(); // no release yet
      if (res.statusCode != 200) return const UpdateInfo(failed: true);
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final tag = (j['tag_name'] ?? '').toString();
      final url = (j['html_url'] ?? kReleasesPage).toString();
      if (tag.isEmpty) return const UpdateInfo();
      var apk = '';
      for (final a in (j['assets'] as List? ?? const [])) {
        final m = a as Map;
        final n = (m['name'] ?? '').toString().toLowerCase();
        if (n.endsWith('.apk')) {
          apk = (m['browser_download_url'] ?? '').toString();
          break;
        }
      }
      return UpdateInfo(available: _newer(tag, kAppVersion), tag: tag, url: url, apkUrl: apk);
    } catch (_) {
      return const UpdateInfo(failed: true);
    }
  }

  /// Opens the link in the browser / GitHub app. Returns false if nothing could open it.
  static Future<bool> open(String url) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<bool>('open', {'url': url}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Downloads the APK to the cache folder; [onProgress] gets 0..1. Returns the file path.
  static Future<String> download(String url, void Function(double) onProgress) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/rosella-update.apk');
    if (file.existsSync()) file.deleteSync();
    final client = http.Client();
    try {
      final resp = await client.send(http.Request('GET', Uri.parse(url)))
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) throw Exception('HTTP ${resp.statusCode}');
      final total = resp.contentLength ?? 0;
      var got = 0;
      final sink = file.openWrite();
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) onProgress((got / total).clamp(0.0, 1.0));
      }
      await sink.flush();
      await sink.close();
      if (got < 1000000) throw Exception('file too small');
      return file.path;
    } finally {
      client.close();
    }
  }

  /// 'ok' (system install screen opened), 'perm' (user must allow installs from this app), 'fail'.
  static Future<String> install(String path) async {
    try {
      return await const MethodChannel('rosella/haptic')
              .invokeMethod<String>('install', {'path': path}) ??
          'fail';
    } catch (_) {
      return 'fail';
    }
  }
}
