import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'widgets.dart';

/// Full-screen profile photo: pinch to zoom, tap anywhere to close.
class PhotoViewerPage extends StatelessWidget {
  final String path;
  final String tag;
  const PhotoViewerPage({super.key, required this.path, required this.tag});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Stack(
          children: [
            Center(
              child: Hero(
                tag: tag,
                child: InteractiveViewer(
                  minScale: 1,
                  maxScale: 5,
                  child: Image.file(File(path), fit: BoxFit.contain),
                ),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: AlignmentDirectional.topStart,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: RoundIconButton(
                      icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _empty(BuildContext context, IconData icon, String title, String sub) {
  final c = context.colors;
  return Padding(
    padding: const EdgeInsets.fromLTRB(32, 60, 32, 20),
    child: Column(
      children: [
        Container(
          width: 84,
          height: 84,
          decoration: BoxDecoration(
              shape: BoxShape.circle, border: Border.all(color: c.border, width: 1.5)),
          child: Icon(icon, size: 38, color: c.dim),
        ),
        const SizedBox(height: 18),
        Text(title,
            textAlign: TextAlign.center,
            style: TextStyle(color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text(sub,
            textAlign: TextAlign.center,
            style: TextStyle(color: c.dim, fontSize: 14, height: 1.5)),
      ],
    ),
  );
}

/// Followers / Following / Find. The screens are ready; the lists fill up once an online
/// service is connected (nothing is faked here).
class FriendsPage extends StatefulWidget {
  final int initialTab;
  const FriendsPage({super.key, this.initialTab = 0});

  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage> {
  late int _tab = widget.initialTab;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final tabs = [context.t('prof_followers'), context.t('prof_following'), context.t('fr_find')];
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('fr_title')),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Row(
              children: [
                for (var i = 0; i < tabs.length; i++)
                  Expanded(
                    child: Pressable(
                      scale: 0.97,
                      onTap: () => setState(() => _tab = i),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                                color: _tab == i ? c.text : c.border, width: _tab == i ? 2 : 1),
                          ),
                        ),
                        child: Text(tabs[i],
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: _tab == i ? c.text : c.dim,
                                fontSize: 14,
                                fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_tab == 2)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: TextField(
                style: TextStyle(color: c.text),
                decoration: InputDecoration(
                  hintText: context.t('fr_search'),
                  hintStyle: TextStyle(color: c.dim),
                  prefixIcon: Icon(Icons.search_rounded, color: c.dim),
                  filled: true,
                  fillColor: al(c.surface, 0.8),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                ),
                onSubmitted: (_) => toast(context, context.t('fr_soon_short')),
              ),
            ),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                _empty(
                  context,
                  _tab == 2 ? Icons.person_add_alt_1_rounded : Icons.group_rounded,
                  _tab == 0
                      ? context.t('fr_empty_followers')
                      : _tab == 1
                          ? context.t('fr_empty_following')
                          : context.t('fr_find'),
                  context.t('fr_soon'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    context.watch<AppState>();
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('nt_title')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                _empty(context, Icons.notifications_none_rounded, context.t('nt_empty'),
                    context.t('nt_soon')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
