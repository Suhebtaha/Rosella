## Rosella 1.1.115

- Profile redesigned like a social profile: photo, Posts / Followers / Following, bio, Edit profile and Add friends buttons, and tabs for a dreams grid, a posts feed and your private dreams (fingerprint/PIN to open).
- Tap your profile photo to view it full screen (pinch to zoom).
- New notifications button on the home page and on the profile, plus Friends and Notifications screens (they fill up once an online service is connected).
- When you write a dream you can now choose who can see it: Public, Friends or Private.
