import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/symbols.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'dream_detail.dart';
import 'widgets.dart';

/// Full-screen search: opens when the search field on the home page is tapped.
/// Empty query -> recent searches; every typed letter filters the dreams live,
/// dreams whose title starts with what you typed come first.
Route<void> searchRoute() => PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 240),
      reverseTransitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (_, __, ___) => const SearchPage(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero)
              .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: child,
        ),
      ),
    );

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  static const _kRecent = 'recent_searches';
  final _ctl = TextEditingController();
  final _focus = FocusNode();
  List<String> _recent = [];

  @override
  void initState() {
    super.initState();
    _loadRecent();
  }

  @override
  void dispose() {
    _ctl.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _loadRecent() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (mounted) setState(() => _recent = p.getStringList(_kRecent) ?? []);
    } catch (_) {}
  }

  Future<void> _saveRecent(String q) async {
    q = q.trim();
    if (q.isEmpty) return;
    _recent = [q, ..._recent.where((e) => e != q)].take(8).toList();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList(_kRecent, _recent);
    } catch (_) {}
  }

  Future<void> _setRecent(List<String> v) async {
    setState(() => _recent = v);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList(_kRecent, v);
    } catch (_) {}
  }

  /// 0 = title starts with q, 1 = a word of the title starts with q,
  /// 2 = a word of the text starts with q, 3 = q appears somewhere, -1 = no match
  int _score(Dream d, String q) {
    final nq = normText(q.toLowerCase());
    final t = normText(d.title.toLowerCase());
    final b = normText(d.content.toLowerCase());
    if (t.startsWith(nq)) return 0;
    bool wordStart(String s) =>
        s.split(RegExp(r'[\s,.;:!?؟،"()\-]+')).any((w) => w.startsWith(nq));
    if (wordStart(t)) return 1;
    if (q.trim().length == 1) return -1; // one letter: only things that start with it
    if (wordStart(b)) return 2;
    if (t.contains(nq) || b.contains(nq)) return 3;
    return -1;
  }

  void _open(Dream d) {
    Haptics.selection();
    _saveRecent(_ctl.text);
    FocusScope.of(context).unfocus();
    Navigator.of(context)
        .push(CupertinoPageRoute<void>(builder: (_) => DreamDetailPage(id: d.id)));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final q = _ctl.text.trim();
    final results = <Dream>[];
    if (q.isNotEmpty) {
      final scored = <(int, Dream)>[];
      for (final d in app.dreams) {
        if (d.priv) continue; // private dreams are never searched here
        final s = _score(d, q);
        if (s >= 0) scored.add((s, d));
      }
      scored.sort((a, b) {
        final k = a.$1.compareTo(b.$1);
        return k != 0 ? k : b.$2.createdAt.compareTo(a.$2.createdAt);
      });
      results.addAll(scored.map((e) => e.$2));
    }

    Widget body;
    if (q.isEmpty) {
      body = _recent.isEmpty
          ? const SizedBox.shrink()
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(context.t('search_recent'),
                          style: TextStyle(
                              color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                    ),
                    GestureDetector(
                      onTap: () => _setRecent([]),
                      child: Text(context.t('search_clear'),
                          style: TextStyle(
                              color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                for (final r in _recent)
                  InkWell(
                    onTap: () {
                      _ctl.text = r;
                      _ctl.selection = TextSelection.collapsed(offset: r.length);
                      setState(() {});
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      child: Row(
                        children: [
                          Icon(Icons.history_rounded, color: c.dim, size: 21),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Text(r,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: c.text, fontSize: 16, fontWeight: FontWeight.w600)),
                          ),
                          GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => _setRecent(_recent.where((e) => e != r).toList()),
                            child: Padding(
                              padding: const EdgeInsets.all(6),
                              child: Icon(Icons.close_rounded, color: c.dim, size: 19),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
    } else if (results.isEmpty) {
      body = Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search_off_rounded, color: c.dim, size: 44),
            const SizedBox(height: 10),
            Text(context.t('search_none'),
                style: TextStyle(color: c.dim, fontSize: 15, fontWeight: FontWeight.w600)),
          ],
        ),
      );
    } else {
      body = ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        itemCount: results.length,
        itemBuilder: (_, i) {
          final d = results[i];
          final title = d.title.isEmpty ? '—' : d.title;
          final n = q.length.clamp(0, title.length);
          final starts = normText(title.toLowerCase()).startsWith(normText(q.toLowerCase()));
          return InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => _open(d),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: al(moodColor(d.mood), 0.18),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 21)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(
                          TextSpan(children: [
                            TextSpan(
                                text: starts ? title.substring(0, n) : '',
                                style: TextStyle(color: c.text, fontWeight: FontWeight.w900)),
                            TextSpan(
                                text: starts ? title.substring(n) : title,
                                style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
                          ]),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textDirection: textDirOf(title, Directionality.of(context)),
                          style: const TextStyle(fontSize: 16),
                        ),
                        const SizedBox(height: 2),
                        Text(fmtDate(d.createdAt, app.lang),
                            style: TextStyle(color: c.dim, fontSize: 12.5)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
      backgroundColor: c.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).maybePop(),
                    icon: Icon(
                        Directionality.of(context) == TextDirection.rtl
                            ? Icons.arrow_forward_rounded
                            : Icons.arrow_back_rounded,
                        color: c.text),
                  ),
                  Expanded(
                    child: Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: c.isDark ? const Color(0xFF16161A) : c.surfaceHi,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: al(c.text, 0.10)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.search_rounded, color: c.dim, size: 22),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _ctl,
                              focusNode: _focus,
                              autofocus: true,
                              textInputAction: TextInputAction.search,
                              onChanged: (_) => setState(() {}),
                              onSubmitted: (v) => _saveRecent(v),
                              style: TextStyle(color: c.text, fontSize: 16),
                              decoration: bareInput(context, context.t('search_hint')),
                            ),
                          ),
                          if (_ctl.text.isNotEmpty)
                            GestureDetector(
                              onTap: () {
                                _ctl.clear();
                                setState(() {});
                              },
                              child: Icon(Icons.close_rounded, color: c.dim, size: 20),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: body),
          ],
        ),
      ),
    );
  }
}
