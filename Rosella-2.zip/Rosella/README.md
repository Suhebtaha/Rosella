# Dreams Tracker (مذكرات أحلام)

Flutter app. Push to GitHub → Actions builds the APK (Artifacts → dreams-tracker-apk).
The `android/` folder is generated in CI and patched by `tool/patch_android.py`.

Local: `flutter create --platforms=android . && python3 tool/patch_android.py && flutter run`
