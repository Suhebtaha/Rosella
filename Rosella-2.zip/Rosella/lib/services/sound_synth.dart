import 'dart:math' as math;
import 'dart:typed_data';

const int _sr = 22050;
const int _seconds = 14;

/// Generates a seamless looping WAV (16-bit mono) for the given sound id.
/// Runs inside an isolate via `compute`.
Uint8List synthesizeWav(String id) {
  final n = _sr * _seconds;
  final fade = (_sr * 1.5).toInt();
  final total = n + fade;
  final rnd = math.Random(id.hashCode ^ 0x5eed);

  Float64List x;
  double gain;
  switch (id) {
    case 'rain':
      x = _rain(total, rnd);
      gain = 0.85;
      break;
    case 'wind':
      x = _wind(total, rnd);
      gain = 0.8;
      break;
    case 'fire':
      x = _fire(total, rnd);
      gain = 0.85;
      break;
    default:
      x = _birds(total, rnd);
      gain = 0.7;
  }

  // equal-power crossfade of the tail into the head => seamless loop
  final out = Float64List(n);
  for (var i = 0; i < n; i++) {
    if (i < fade) {
      final w = i / fade;
      out[i] = x[i] * math.sin(w * math.pi / 2) +
          x[n + i] * math.cos(w * math.pi / 2);
    } else {
      out[i] = x[i];
    }
  }

  var peak = 0.0001;
  for (var i = 0; i < n; i++) {
    final a = out[i].abs();
    if (a > peak) peak = a;
  }
  final scale = gain / peak;

  final bytes = ByteData(44 + n * 2);
  void ws(int off, String s) {
    for (var i = 0; i < s.length; i++) {
      bytes.setUint8(off + i, s.codeUnitAt(i));
    }
  }

  ws(0, 'RIFF');
  bytes.setUint32(4, 36 + n * 2, Endian.little);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  bytes.setUint32(16, 16, Endian.little);
  bytes.setUint16(20, 1, Endian.little);
  bytes.setUint16(22, 1, Endian.little);
  bytes.setUint32(24, _sr, Endian.little);
  bytes.setUint32(28, _sr * 2, Endian.little);
  bytes.setUint16(32, 2, Endian.little);
  bytes.setUint16(34, 16, Endian.little);
  ws(36, 'data');
  bytes.setUint32(40, n * 2, Endian.little);
  for (var i = 0; i < n; i++) {
    final v = math.max(-32768, math.min(32767, (out[i] * scale * 32767).round()));
    bytes.setInt16(44 + i * 2, v, Endian.little);
  }
  return bytes.buffer.asUint8List();
}

double _noise(math.Random r) => r.nextDouble() * 2 - 1;

Float64List _rain(int total, math.Random r) {
  final x = Float64List(total);
  double lp1 = 0, lp2 = 0, drop = 0;
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    lp1 += (w - lp1) * 0.45;
    lp2 += (w - lp2) * 0.04;
    final hi = lp1 - lp2;
    if (r.nextDouble() < 0.0009) drop = 0.5 + r.nextDouble() * 0.5;
    drop *= 0.985;
    final tick = drop * _noise(r);
    final t = i / _sr;
    final mod = 1 + 0.07 * math.sin(2 * math.pi * t / 7);
    x[i] = (hi * 0.9 + tick * 0.5) * mod;
  }
  return x;
}

Float64List _wind(int total, math.Random r) {
  final x = Float64List(total);
  double a = 0, b = 0, c = 0;
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    a += (w - a) * 0.02;
    b += (a - b) * 0.05;
    c += (w - c) * 0.15;
    final t = i / _sr;
    final gust = 0.55 +
        0.3 * math.sin(2 * math.pi * t / 7 + 0.5) +
        0.15 * math.sin(2 * math.pi * t / 3.5 + 2);
    x[i] = (b * 14 + c * 0.35) * gust;
  }
  return x;
}

Float64List _fire(int total, math.Random r) {
  final x = Float64List(total);
  double rumble = 0, hiss = 0, pop = 0, big = 0, pl = 0, bl = 0;
  for (var i = 0; i < total; i++) {
    final w = _noise(r);
    rumble += (w - rumble) * 0.015;
    hiss += (w - hiss) * 0.3;
    if (r.nextDouble() < 0.0012) pop = 0.3 + r.nextDouble() * 0.7;
    if (r.nextDouble() < 0.00008) big = 1.0;
    pop *= 0.993;
    big *= 0.997;
    pl += (_noise(r) - pl) * 0.6;
    bl += (_noise(r) - bl) * 0.35;
    x[i] = rumble * 7 + hiss * 0.06 + pl * pop * 0.8 + bl * big * 1.2;
  }
  return x;
}

Float64List _birds(int total, math.Random r) {
  final x = Float64List(total);
  double amb = 0;
  for (var i = 0; i < total; i++) {
    amb += (_noise(r) - amb) * 0.05;
    x[i] = amb * 0.04;
  }
  final groups = 14;
  for (var g = 0; g < groups; g++) {
    final start = r.nextInt(total - _sr);
    final notes = 1 + r.nextInt(4);
    final f0 = 2400 + r.nextDouble() * 2600;
    final f1 = f0 * (r.nextBool() ? 0.7 : 1.5);
    final amp = 0.4 + r.nextDouble() * 0.6;
    final dur = (_sr * (0.07 + r.nextDouble() * 0.09)).toInt();
    final gap = (_sr * (0.11 + r.nextDouble() * 0.07)).toInt();
    for (var k = 0; k < notes; k++) {
      final idx = start + k * (dur + gap);
      var phase = 0.0;
      for (var j = 0; j < dur; j++) {
        final p = idx + j;
        if (p >= total) break;
        final t = j / dur;
        final sec = j / _sr;
        var f = f0 + (f1 - f0) * t;
        f *= 1 + 0.03 * math.sin(2 * math.pi * 30 * sec);
        phase += 2 * math.pi * f / _sr;
        final env = math.pow(math.sin(math.pi * t), 1.5).toDouble();
        x[p] += amp * env * (math.sin(phase) + 0.3 * math.sin(2 * phase));
      }
    }
  }
  return x;
}
