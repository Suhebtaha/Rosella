import 'package:flutter/material.dart';

class Stats {
  final int total;
  final int voice;
  final int streak;
  final int moods;
  final int ai;
  final int img;
  final int month;
  const Stats({
    required this.total,
    required this.voice,
    required this.streak,
    required this.moods,
    required this.ai,
    required this.img,
    required this.month,
  });
}

class AchievementDef {
  final String id;
  final IconData icon;
  final int target;
  final int Function(Stats) value;
  const AchievementDef(this.id, this.icon, this.target, this.value);
  String get titleKey => 'ach_$id';
  String get descKey => 'ach_${id}_d';
}

int _total(Stats s) => s.total;
int _streak(Stats s) => s.streak;
int _voice(Stats s) => s.voice;
int _ai(Stats s) => s.ai;
int _img(Stats s) => s.img;
int _moods(Stats s) => s.moods;

const List<AchievementDef> kAchievements = [
  AchievementDef('first', Icons.auto_awesome_rounded, 1, _total),
  AchievementDef('five', Icons.collections_bookmark_rounded, 5, _total),
  AchievementDef('twentyfive', Icons.explore_rounded, 25, _total),
  AchievementDef('hundred', Icons.workspace_premium_rounded, 100, _total),
  AchievementDef('streak3', Icons.local_fire_department_rounded, 3, _streak),
  AchievementDef('streak7', Icons.bolt_rounded, 7, _streak),
  AchievementDef('voice1', Icons.mic_rounded, 1, _voice),
  AchievementDef('voice5', Icons.record_voice_over_rounded, 5, _voice),
  AchievementDef('ai1', Icons.psychology_rounded, 1, _ai),
  AchievementDef('img1', Icons.palette_rounded, 1, _img),
  AchievementDef('moods4', Icons.emoji_emotions_rounded, 4, _moods),
];
