import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

import '../core/theme.dart';
import 'widgets.dart';

class AudioClip extends StatefulWidget {
  final String path;
  final int durationMs;
  const AudioClip({super.key, required this.path, required this.durationMs});

  @override
  State<AudioClip> createState() => _AudioClipState();
}

class _AudioClipState extends State<AudioClip> {
  final AudioPlayer _p = AudioPlayer();
  PlayerState _state = PlayerState.stopped;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;
  final List<StreamSubscription<dynamic>> _subs = [];

  @override
  void initState() {
    super.initState();
    _dur = Duration(milliseconds: widget.durationMs);
    _subs.add(_p.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _state = s);
    }));
    _subs.add(_p.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    }));
    _subs.add(_p.onDurationChanged.listen((d) {
      if (mounted && d.inMilliseconds > 0) setState(() => _dur = d);
    }));
    _subs.add(_p.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _pos = Duration.zero);
    }));
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _p.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (_state == PlayerState.playing) {
        await _p.pause();
      } else if (_state == PlayerState.paused) {
        await _p.resume();
      } else {
        await _p.play(DeviceFileSource(widget.path));
      }
    } catch (_) {}
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final playing = _state == PlayerState.playing;
    final total = _dur.inMilliseconds;
    final v = total <= 0 ? 0.0 : (_pos.inMilliseconds / total).clamp(0.0, 1.0);
    return Panel(
      padding: const EdgeInsets.fromLTRB(12, 10, 16, 10),
      radius: 24,
      child: Row(
        children: [
          Pressable(
            onTap: _toggle,
            scale: 0.9,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(shape: BoxShape.circle, gradient: c.gradient),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Icon(
                  playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  key: ValueKey(playing),
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 4,
                activeTrackColor: c.a,
                inactiveTrackColor: c.surfaceHi,
                thumbColor: c.a,
                overlayShape: SliderComponentShape.noOverlay,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
              ),
              child: Slider(
                value: v,
                onChanged: (x) async {
                  if (_state == PlayerState.playing || _state == PlayerState.paused) {
                    try {
                      await _p.seek(Duration(milliseconds: (x * total).toInt()));
                    } catch (_) {}
                  }
                },
              ),
            ),
          ),
          Text(
            '${_fmt(_pos)} / ${_fmt(_dur)}',
            textDirection: TextDirection.ltr,
            style: TextStyle(color: c.dim, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
