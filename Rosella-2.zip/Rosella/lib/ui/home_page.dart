import 'dart:math' as math;

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'dream_detail.dart';
import 'dream_editor.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _search = TextEditingController();
  String _q = '';
  int? _mood;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _openEditor() {
    Navigator.of(context)
        .push(CupertinoPageRoute<void>(builder: (_) => const DreamEditorPage()));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final q = _q.trim().toLowerCase();
    final list = app.dreams.where((d) {
      if (_mood != null && d.mood != _mood) return false;
      if (q.isEmpty) return true;
      return d.title.toLowerCase().contains(q) || d.content.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.t('home_title'),
                            style: TextStyle(
                                color: c.text,
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.5)),
                        const SizedBox(height: 2),
                        Text('${app.dreams.length} ${context.t('dreams_count')}',
                            style: TextStyle(color: c.dim, fontSize: 14)),
                      ],
                    ),
                  ),
                  Pressable(
                    onTap: _openEditor,
                    scale: 0.9,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: c.gradient,
                        boxShadow: [
                          BoxShadow(color: al(c.a, 0.35), blurRadius: 16, offset: const Offset(0, 6)),
                        ],
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Panel(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                radius: 18,
                child: Row(
                  children: [
                    Icon(Icons.search_rounded, color: c.dim),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _search,
                        onChanged: (v) => setState(() => _q = v),
                        style: TextStyle(color: c.text, fontSize: 16),
                        decoration: bareInput(context, context.t('search_hint')),
                      ),
                    ),
                    if (_q.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          _search.clear();
                          setState(() => _q = '');
                        },
                        child: Icon(Icons.close_rounded, color: c.dim, size: 20),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 56,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                children: [
                  _FilterChip(
                    label: context.t('filter_all'),
                    selected: _mood == null,
                    onTap: () => setState(() => _mood = null),
                  ),
                  for (var m = 1; m <= 5; m++)
                    _FilterChip(
                      label: moodEmoji(m),
                      selected: _mood == m,
                      onTap: () => setState(() => _mood = m),
                    ),
                ],
              ),
            ),
          ),
          if (list.isEmpty)
            SliverToBoxAdapter(child: _Empty(onWrite: _openEditor))
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => Padding(
                  key: ValueKey(list[i].id),
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: FadeSlide(
                    delay: math.min(i, 6) * 45,
                    child: _DreamCard(dream: list[i]),
                  ),
                ),
                childCount: list.length,
              ),
            ),
          SliverToBoxAdapter(child: SizedBox(height: navPadding(context))),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Pressable(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: selected ? c.gradient : null,
            color: selected ? null : al(c.surface, c.isDark ? 0.7 : 0.9),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: selected ? Colors.transparent : c.border),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : c.text,
              fontWeight: FontWeight.w700,
              fontSize: 14.5,
            ),
          ),
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final VoidCallback onWrite;
  const _Empty({required this.onWrite});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 60, 32, 0),
      child: Column(
        children: [
          Container(
            width: 104,
            height: 104,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(c.a, 0.12),
              border: Border.all(color: al(c.a, 0.3)),
            ),
            child: Icon(Icons.nights_stay_rounded, size: 50, color: c.a),
          ),
          const SizedBox(height: 22),
          Text(context.t('empty_title'),
              style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(context.t('empty_sub'),
              textAlign: TextAlign.center,
              style: TextStyle(color: c.dim, fontSize: 14.5, height: 1.5)),
          const SizedBox(height: 22),
          GradientButton(
              label: context.t('write_dream'), icon: Icons.edit_rounded, onTap: onWrite),
        ],
      ),
    );
  }
}

class _DreamCard extends StatelessWidget {
  final Dream dream;
  const _DreamCard({required this.dream});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final lang = context.select<AppState, String>((s) => s.lang);
    final d = dream;
    final preview = d.content.trim().isEmpty && d.audio != null
        ? context.t('voice_recording')
        : d.content.trim();
    final title = d.title.isEmpty ? fmtDate(d.createdAt, lang) : d.title;
    return Panel(
      onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: d.id))),
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(moodColor(d.mood), 0.18),
            ),
            child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: c.text, fontSize: 16.5, fontWeight: FontWeight.w700)),
                    ),
                    if (d.audio != null) _Badge(Icons.mic_rounded),
                    if (d.image != null) _Badge(Icons.image_rounded),
                    if (d.interpretation != null) _Badge(Icons.auto_awesome_rounded),
                  ],
                ),
                if (preview.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(preview,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: c.dim, fontSize: 14, height: 1.4)),
                ],
                const SizedBox(height: 8),
                Text('${fmtDate(d.createdAt, lang)} • ${fmtTime(d.createdAt)}',
                    style: TextStyle(color: al(c.dim, 0.8), fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  const _Badge(this.icon);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6),
        child: Icon(icon, size: 15, color: context.colors.a),
      );
}
