import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'widgets.dart';

class LockScreen extends StatelessWidget {
  const LockScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Material(
      color: c.bg,
      child: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 104,
                    height: 104,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: c.gradient,
                      boxShadow: [
                        BoxShadow(color: al(c.a, 0.45), blurRadius: 40, spreadRadius: 2),
                      ],
                    ),
                    child: const Icon(Icons.fingerprint_rounded, color: Colors.white, size: 56),
                  ),
                  const SizedBox(height: 28),
                  Text(context.t('locked_title'),
                      style: TextStyle(
                          color: c.text, fontSize: 24, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Text(context.t('locked_sub'),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: c.dim, fontSize: 15)),
                  const SizedBox(height: 28),
                  GradientButton(
                    label: context.t('unlock'),
                    icon: Icons.lock_open_rounded,
                    onTap: () => context.read<AppState>().tryUnlock(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LifecycleGate extends StatefulWidget {
  final Widget child;
  const LifecycleGate({super.key, required this.child});

  @override
  State<LifecycleGate> createState() => _LifecycleGateState();
}

class _LifecycleGateState extends State<LifecycleGate> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AppState>().tryUnlock();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final app = context.read<AppState>();
    if (state == AppLifecycleState.paused) {
      app.onBackground();
    } else if (state == AppLifecycleState.resumed) {
      app.tryUnlock();
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
