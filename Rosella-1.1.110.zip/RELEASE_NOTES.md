## Rosella 1.1.110

- On the dream page, the pin / favorite / lock / share / delete buttons moved into a ⋮ menu that opens as an animated card.
- New users now start with the microphone in the middle of the bar.
- New short opening animation: the moon appears, the letters of "rosella" appear one by one, and a soft blue glow rises from the bottom.
