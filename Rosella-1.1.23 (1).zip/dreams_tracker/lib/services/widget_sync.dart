import 'dart:async';
import 'dart:convert';

import 'package:home_widget/home_widget.dart';

import '../core/app_state.dart';
import '../core/models.dart';

/// Pushes a few numbers to the home-screen widget (dream count, streak).
class WidgetSync {
  static Timer? _t;

  /// Call whenever the state changes; the actual update is debounced.
  static void schedule(AppState app) {
    _t?.cancel();
    _t = Timer(const Duration(seconds: 2), () => push(app));
  }

  static Future<void> push(AppState app) async {
    try {
      final st = app.stats;
      await HomeWidget.saveWidgetData<String>(
          'wd_stats', '${st.total} ${app.tr('freq_dreams')}  ·  🔥 ${st.streak}');
      await HomeWidget.saveWidgetData<String>('wd_cta', '+ ${app.tr('wd_cta')}');
      final pub = app.dreams.where((d) => !d.priv).toList();
      final last = pub.isEmpty ? null : pub.first;
      final lastText = last == null
          ? ''
          : (last.title.trim().isNotEmpty ? last.title.trim() : last.content.trim());
      await HomeWidget.saveWidgetData<String>('wd_last', lastText);
      await HomeWidget.saveWidgetData<String>('wd_open', app.tr('wd_open'));
      for (final n in const ['RosellaWidget', 'RosellaWidgetSmall', 'RosellaWidgetWide', 'RosellaWidgetLarge']) {
        await HomeWidget.updateWidget(
          name: n,
          androidName: n,
          qualifiedAndroidName: 'com.suhaib.rosella.$n',
        );
      }
    } catch (_) {
      // no widget on the home screen, or the plugin is unavailable: ignore
    }
  }

  /// Dreams typed or dictated in the widget popup wait in storage until the app opens.
  static Future<void> importPending(AppState app) async {
    try {
      final raw = await HomeWidget.getWidgetData<String>('pending_dreams', defaultValue: '[]');
      if (raw == null || raw.trim().isEmpty || raw.trim() == '[]') return;
      final list = jsonDecode(raw) as List;
      await HomeWidget.saveWidgetData<String>('pending_dreams', '[]');
      for (final e in list) {
        final text = ((e as Map)['text'] ?? '').toString().trim();
        if (text.isEmpty) continue;
        final ts = (e['ts'] is num) ? (e['ts'] as num).toInt() : DateTime.now().millisecondsSinceEpoch;
        await app.addDream(Dream(
          id: app.newId(),
          title: '',
          content: text,
          createdAt: DateTime.fromMillisecondsSinceEpoch(ts),
        ));
      }
    } catch (_) {}
  }
}
