import '../core/nav_bus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Daily local notifications (morning dream reminder + lucid reality checks).
class Notifier {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  /// last scheduling problem (shown by the "test reminder" button)
  static String lastError = '';

  static void _tap(NotificationResponse r) {
    if (r.payload == 'voice') {
      pendingVoice = true;
      voiceRequest.value++;
    }
  }

  static Future<void> init() async {
    if (_ready) return;
    try {
      tzdata.initializeTimeZones();
      await _p.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
        onDidReceiveNotificationResponse: _tap,
      );
      _ready = true;
      try {
        final d = await _p.getNotificationAppLaunchDetails();
        if (d?.didNotificationLaunchApp == true &&
            d?.notificationResponse?.payload == 'voice') {
          pendingVoice = true;
          voiceRequest.value++;
        }
      } catch (_) {}
    } catch (_) {}
  }

  /// Asks for the Android 13+ notification permission. true if allowed.
  static Future<bool> requestPermission() async {
    await init();
    try {
      final a = _p.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final ok = await a?.requestNotificationsPermission();
      try {
        if (!(await a?.canScheduleExactNotifications() ?? true)) {
          await a?.requestExactAlarmsPermission();
        }
      } catch (_) {}
      return ok ?? true;
    } catch (_) {
      return false;
    }
  }

  // Scheduled as an absolute instant (UTC) and repeated daily at that time of day.
  static tz.TZDateTime _next(int h, int m) {
    final now = DateTime.now();
    var t = DateTime(now.year, now.month, now.day, h, m);
    if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
    return tz.TZDateTime.from(t, tz.UTC);
  }

  static NotificationDetails _details(String channel) => NotificationDetails(
        android: AndroidNotificationDetails(
          'rosella_$channel',
          channel == 'morning'
              ? 'Dream reminder'
              : channel == 'bedtime'
                  ? 'Bedtime reminder'
                  : channel == 'test'
                      ? 'Test'
                      : 'Lucid reality checks',
          importance: Importance.max,
          priority: Priority.high,
          category: AndroidNotificationCategory.reminder,
          visibility: NotificationVisibility.public,
        ),
      );

  static Future<bool> _canExact() async {
    try {
      final a = _p.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      return await a?.canScheduleExactNotifications() ?? false;
    } catch (_) {
      return false;
    }
  }

  /// exact alarm when allowed (on time even in Doze), otherwise the inexact one
  static Future<void> _schedule(int id, tz.TZDateTime when, String title, String body,
      String channel, {bool repeat = true}) async {
    Future<void> go(AndroidScheduleMode mode) => _p.zonedSchedule(
          id,
          title,
          body,
          when,
          _details(channel),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: repeat ? DateTimeComponents.time : null,
          payload: channel == 'morning' ? 'voice' : null,
        );
    if (await _canExact()) {
      try {
        await go(AndroidScheduleMode.exactAllowWhileIdle);
        return;
      } catch (e) {
        lastError = 'exact: $e';
      }
    }
    await go(AndroidScheduleMode.inexactAllowWhileIdle);
  }

  static Future<void> _daily(
      int id, int h, int m, String title, String body, String channel) {
    return _schedule(id, _next(h, m), title, body, channel);
  }

  /// Shows a notification right now and schedules another one in one minute.
  /// Returns '' when everything worked, otherwise the reason.
  static Future<String> test(String title, String body) async {
    await init();
    lastError = '';
    try {
      final ok = await requestPermission();
      if (!ok) return 'permission denied';
      await _p.show(98, title, body, _details('test'));
      final when = tz.TZDateTime.from(
          DateTime.now().add(const Duration(minutes: 1)), tz.UTC);
      await _schedule(99, when, title, body, 'test', repeat: false);
      final exact = await _canExact();
      return lastError.isEmpty ? (exact ? '' : 'inexact') : lastError;
    } catch (e) {
      return '$e';
    }
  }

  static Future<void> apply({
    required bool morning,
    required int hour,
    required int minute,
    required bool lucid,
    required bool bedtime,
    required int bedHour,
    required int bedMinute,
    required String bedTitle,
    required String bedBody,
    required String morningTitle,
    required String morningBody,
    required String lucidTitle,
    required String lucidBody,
  }) async {
    await init();
    if (!_ready) return;
    try {
      await _p.cancelAll();
      if (morning) {
        await _daily(1, hour, minute, morningTitle, morningBody, 'morning');
      }
      if (bedtime) {
        await _daily(2, bedHour, bedMinute, bedTitle, bedBody, 'bedtime');
      }
      if (lucid) {
        await _daily(11, 11, 0, lucidTitle, lucidBody, 'lucid');
        await _daily(12, 15, 0, lucidTitle, lucidBody, 'lucid');
        await _daily(13, 19, 30, lucidTitle, lucidBody, 'lucid');
      }
    } catch (e) {
      lastError = '$e';
    }
  }
}
