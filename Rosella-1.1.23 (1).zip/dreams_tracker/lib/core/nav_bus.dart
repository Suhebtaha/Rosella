import 'package:flutter/material.dart';

/// Lets widgets that live above the Navigator (like the now-playing island)
/// switch the main tab and close any open page.
final GlobalKey<NavigatorState> rootNavKey = GlobalKey<NavigatorState>();

/// Tab index requested from outside the Shell (-1 = none).
final ValueNotifier<int> tabRequest = ValueNotifier<int>(-1);

/// true while the splash screen is showing (overlays hide themselves then).
final ValueNotifier<bool> splashShowing = ValueNotifier<bool>(true);

void openTab(int i) {
  rootNavKey.currentState?.popUntil((r) => r.isFirst);
  tabRequest.value = -1;
  tabRequest.value = i;
}

/// Word the Home search should show (set by tapping a recurring symbol).
final ValueNotifier<String> searchRequest = ValueNotifier<String>('');

void searchFor(String w) {
  openTab(0);
  searchRequest.value = '';
  searchRequest.value = w;
}

/// A morning-reminder tap asks the Shell to open the quick voice recorder.
bool pendingVoice = false;
final ValueNotifier<int> voiceRequest = ValueNotifier<int>(0);
