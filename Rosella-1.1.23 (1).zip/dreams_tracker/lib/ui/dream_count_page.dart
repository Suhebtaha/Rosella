import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// "Dream count": total, this week / month, and a line chart you can filter by week, month or year.
class DreamCountPage extends StatefulWidget {
  const DreamCountPage({super.key});

  @override
  State<DreamCountPage> createState() => _DreamCountPageState();
}

class _DreamCountPageState extends State<DreamCountPage> {
  int _range = 0; // 0 week, 1 month, 2 year

  static const _wdEn = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const _wdAr = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
  static const _wdEs = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  static const _wdKo = ['월', '화', '수', '목', '금', '토', '일'];
  static const _wdKu = ['دووشەمە', 'سێشەمە', 'چوارشەمە', 'پێنجشەمە', 'هەینی', 'شەمە', 'یەکشەمە'];

  DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);

  ({List<double> values, List<String> labels}) _series(AppState app) {
    final now = _day(DateTime.now());
    final per = <DateTime, int>{};
    for (final d in app.dreams) {
      final k = _day(d.createdAt);
      per[k] = (per[k] ?? 0) + 1;
    }
    final wd = switch (app.lang) {
      'ar' => _wdAr,
      'ckb' => _wdKu,
      'es' => _wdEs,
      'ko' => _wdKo,
      _ => _wdEn,
    };
    final values = <double>[];
    final labels = <String>[];
    if (_range == 0) {
      for (var i = 6; i >= 0; i--) {
        final d = now.subtract(Duration(days: i));
        values.add((per[d] ?? 0).toDouble());
        labels.add(wd[d.weekday - 1]);
      }
    } else if (_range == 1) {
      for (var i = 29; i >= 0; i--) {
        final d = now.subtract(Duration(days: i));
        values.add((per[d] ?? 0).toDouble());
        labels.add(i % 6 == 0 ? '${d.day}/${d.month}' : '');
      }
    } else {
      for (var i = 11; i >= 0; i--) {
        final m = DateTime(now.year, now.month - i, 1);
        var n = 0;
        for (final d in app.dreams) {
          if (d.createdAt.year == m.year && d.createdAt.month == m.month) n++;
        }
        values.add(n.toDouble());
        labels.add('${m.month}');
      }
    }
    return (values: values, labels: labels);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final now = DateTime.now();
    final today = _day(now);
    final weekAgo = today.subtract(const Duration(days: 6));
    final total = app.dreams.length;
    final week = app.dreams.where((d) => !_day(d.createdAt).isBefore(weekAgo)).length;
    final month = app.dreams
        .where((d) => d.createdAt.year == now.year && d.createdAt.month == now.month)
        .length;
    final s = _series(app);

    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('count_title')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                FadeSlide(child: _Hero(total: total)),
                const SizedBox(height: 14),
                FadeSlide(
                  delay: 60,
                  child: Row(
                    children: [
                      Expanded(child: _Mini(Icons.star_rounded, week, context.t('count_week'))),
                      const SizedBox(width: 10),
                      Expanded(
                          child: _Mini(Icons.calendar_month_rounded, month, context.t('count_month'))),
                      const SizedBox(width: 10),
                      Expanded(
                          child: _Mini(Icons.bar_chart_rounded, total, context.t('count_all'))),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                FadeSlide(
                  delay: 120,
                  child: Panel(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.show_chart_rounded, color: c.a, size: 22),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(context.t('count_stats'),
                                  style: TextStyle(
                                      color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        _Segments(
                          index: _range,
                          labels: [
                            context.t('range_week'),
                            context.t('range_month'),
                            context.t('range_year'),
                          ],
                          onChanged: (i) {
                            Haptics.selection();
                            setState(() => _range = i);
                          },
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          height: 210,
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('$_range-${s.values.length}-${s.values.fold<double>(0, (a, b) => a + b)}'),
                            tween: Tween(begin: 0, end: 1),
                            duration: const Duration(milliseconds: 750),
                            curve: Curves.easeOutCubic,
                            builder: (_, t, __) => CustomPaint(
                              size: Size.infinite,
                              painter: _ChartPainter(
                                values: s.values,
                                labels: s.labels,
                                a: c.a,
                                b: c.b,
                                text: c.dim,
                                grid: c.border,
                                progress: t,
                                dots: _range != 1,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Segments extends StatelessWidget {
  final int index;
  final List<String> labels;
  final ValueChanged<int> onChanged;
  const _Segments({required this.index, required this.labels, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: c.surfaceHi,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: Pressable(
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: index == i ? c.gradient : flatGradient(Colors.transparent),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Text(labels[i],
                      style: TextStyle(
                        color: index == i ? onAccent(c.a, c.b) : c.dim,
                        fontWeight: FontWeight.w800,
                        fontSize: 13.5,
                      )),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  final IconData icon;
  final int value;
  final String label;
  const _Mini(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Panel(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
      child: Column(
        children: [
          Icon(icon, color: c.a, size: 24),
          const SizedBox(height: 6),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: value.toDouble()),
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) => Text('${v.round()}',
                style: TextStyle(color: c.text, fontSize: 24, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 2),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(label, style: TextStyle(color: c.dim, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final int total;
  const _Hero({required this.total});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final dark = c.isDark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: Container(
        height: 330,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: dark
                ? [const Color(0xFF05050A), al(c.b, 0.35), al(c.a, 0.30)]
                : [al(c.a, 0.18), al(c.b, 0.16), c.surface],
          ),
          border: Border.all(color: c.border),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _SkyPainter(a: c.a, b: c.b, dark: dark),
              ),
            ),
            Positioned(
              top: 18,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  Text(context.t('count_title'),
                      style: TextStyle(
                          color: dark ? Colors.white : c.text,
                          fontSize: 22,
                          fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text(context.t('count_sub'),
                      style: TextStyle(
                          color: dark ? al(Colors.white, 0.65) : c.dim, fontSize: 13)),
                ],
              ),
            ),
            Positioned(
              left: 14,
              right: 14,
              bottom: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: dark ? al(Colors.black, 0.35) : al(Colors.white, 0.72),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: dark ? al(Colors.white, 0.14) : c.border),
                ),
                child: Column(
                  children: [
                    Text(context.t('count_total'),
                        style: TextStyle(
                            color: dark ? al(Colors.white, 0.8) : c.dim,
                            fontSize: 14,
                            fontWeight: FontWeight.w600)),
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: total.toDouble()),
                      duration: const Duration(milliseconds: 1100),
                      curve: Curves.easeOutCubic,
                      builder: (_, v, __) => ShaderMask(
                        shaderCallback: (r) => c.gradient.createShader(r),
                        child: Text('${v.round()}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 56,
                                height: 1.1,
                                fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Stars, a crescent moon and an open book with a soft glow, tinted by the theme.
class _SkyPainter extends CustomPainter {
  final Color a;
  final Color b;
  final bool dark;
  _SkyPainter({required this.a, required this.b, required this.dark});

  @override
  void paint(Canvas canvas, Size size) {
    final rnd = math.Random(7);
    final starP = Paint();
    for (var i = 0; i < 46; i++) {
      final x = rnd.nextDouble() * size.width;
      final y = rnd.nextDouble() * size.height * 0.62;
      starP.color = (dark ? Colors.white : a).withOpacity(0.15 + rnd.nextDouble() * 0.6);
      canvas.drawCircle(Offset(x, y), 0.6 + rnd.nextDouble() * 1.3, starP);
    }

    // crescent moon
    final moonC = Offset(size.width * 0.26, size.height * 0.30);
    const r = 40.0;
    final disc = Path()..addOval(Rect.fromCircle(center: moonC, radius: r));
    final cut = Path()
      ..addOval(Rect.fromCircle(center: moonC.translate(r * 0.42, -r * 0.18), radius: r * 0.86));
    final moon = Path.combine(PathOperation.difference, disc, cut);
    final moonColor = dark ? const Color(0xFFF6E3B8) : a;
    canvas.drawPath(
        moon,
        Paint()
          ..color = moonColor.withOpacity(0.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));
    canvas.drawPath(moon, Paint()..color = moonColor);

    // open book + glow
    final cx = size.width / 2;
    final by = size.height * 0.60;
    canvas.drawCircle(
        Offset(cx, by - 6),
        90,
        Paint()
          ..shader = RadialGradient(colors: [
            (dark ? const Color(0xFFFFE2A8) : b).withOpacity(0.55),
            Colors.transparent,
          ]).createShader(Rect.fromCircle(center: Offset(cx, by - 6), radius: 90)));
    final pageColor = dark ? const Color(0xFFF3E6C8) : Colors.white;
    final edge = dark ? const Color(0xFF9C8660) : a;
    Path page(double dir) => Path()
      ..moveTo(cx, by)
      ..quadraticBezierTo(cx + dir * 38, by - 22, cx + dir * 86, by - 8)
      ..lineTo(cx + dir * 86, by + 26)
      ..quadraticBezierTo(cx + dir * 38, by + 10, cx, by + 30)
      ..close();
    for (final d in [-1.0, 1.0]) {
      canvas.drawPath(page(d), Paint()..color = pageColor);
      canvas.drawPath(
          page(d),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.4
            ..color = edge.withOpacity(0.8));
    }
    // sparks rising from the book
    for (var i = 0; i < 14; i++) {
      final x = cx + (rnd.nextDouble() - 0.5) * 80;
      final y = by - 14 - rnd.nextDouble() * 70;
      canvas.drawCircle(Offset(x, y), 0.8 + rnd.nextDouble() * 1.4,
          Paint()..color = (dark ? const Color(0xFFFFE2A8) : b).withOpacity(0.7));
    }
  }

  @override
  bool shouldRepaint(_SkyPainter o) => o.a != a || o.b != b || o.dark != dark;
}

class _ChartPainter extends CustomPainter {
  final List<double> values;
  final List<String> labels;
  final Color a;
  final Color b;
  final Color text;
  final Color grid;
  final double progress;
  final bool dots;
  _ChartPainter({
    required this.values,
    required this.labels,
    required this.a,
    required this.b,
    required this.text,
    required this.grid,
    required this.progress,
    required this.dots,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const left = 26.0, bottom = 24.0, top = 8.0;
    final w = size.width - left - 6;
    final h = size.height - bottom - top;
    final maxV = math.max(4.0, values.fold<double>(0, math.max));
    final top5 = ((maxV / 4).ceil() * 4).toDouble();
    final gp = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = top + h - h * i / 4;
      canvas.drawLine(Offset(left, y), Offset(left + w, y), gp);
      _text(canvas, '${(top5 * i / 4).round()}', Offset(0, y - 6), 10);
    }
    final n = values.length;
    Offset pt(int i) => Offset(
        left + (n == 1 ? w / 2 : w * i / (n - 1)),
        top + h - h * (values[i] / top5) * progress);
    final pts = [for (var i = 0; i < n; i++) pt(i)];

    final line = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 0; i < n - 1; i++) {
      final p0 = pts[math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1];
      final p3 = pts[math.min(n - 1, i + 2)];
      final c1 = Offset(p1.dx + (p2.dx - p0.dx) / 6, p1.dy + (p2.dy - p0.dy) / 6);
      final c2 = Offset(p2.dx - (p3.dx - p1.dx) / 6, p2.dy - (p3.dy - p1.dy) / 6);
      line.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }
    final area = Path.from(line)
      ..lineTo(pts.last.dx, top + h)
      ..lineTo(pts.first.dx, top + h)
      ..close();
    canvas.drawPath(
        area,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [a.withOpacity(0.32), a.withOpacity(0.0)],
          ).createShader(Rect.fromLTWH(left, top, w, h)));
    canvas.drawPath(
        line,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round
          ..shader = LinearGradient(colors: [a, b]).createShader(Rect.fromLTWH(left, top, w, h)));
    if (dots) {
      for (final p in pts) {
        canvas.drawCircle(p, 6, Paint()..color = a.withOpacity(0.25));
        canvas.drawCircle(p, 3.6, Paint()..color = a);
      }
    }
    for (var i = 0; i < n; i++) {
      if (labels[i].isEmpty) continue;
      _text(canvas, labels[i], Offset(pts[i].dx, size.height - 16), 10, center: true);
    }
  }

  void _text(Canvas canvas, String s, Offset o, double size, {bool center = false}) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(color: text, fontSize: size)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center ? Offset(o.dx - tp.width / 2, o.dy) : o);
  }

  @override
  bool shouldRepaint(_ChartPainter o) =>
      o.progress != progress || o.values != values || o.a != a || o.b != b;
}
