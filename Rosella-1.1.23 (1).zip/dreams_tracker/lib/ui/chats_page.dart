import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'dream_chat.dart';
import 'widgets.dart';

/// All saved AI conversations, one per dream.
class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final list = app.dreams.where((d) => d.chat.isNotEmpty).toList();
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('chats_title')),
          Expanded(
            child: ListView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: Panel(
                          onTap: () => Navigator.of(context).push(
                              CupertinoPageRoute<void>(builder: (_) => const DreamChatPage())),
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle, gradient: c.gradient),
                                child: Icon(Icons.add_rounded, color: onAccent(c.a, c.b)),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(context.t('gen_title'),
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 17,
                                            fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 3),
                                    Text(context.t('gen_card_sub'),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: c.dim, fontSize: 13.5, height: 1.4)),
                                  ],
                                ),
                              ),
                              Icon(Icons.chevron_right_rounded, color: c.dim),
                            ],
                          ),
                        ),
                      ),
                      if (app.generalChats.isNotEmpty) ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(4, 4, 4, 10),
                          child: Text(context.t('gen_history'),
                              style: TextStyle(
                                  color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                        ),
                        for (final g in app.generalChats)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Panel(
                              onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                                  builder: (_) => DreamChatPage(gid: g['id'] as String))),
                              padding: const EdgeInsets.all(14),
                              child: Row(
                                children: [
                                  Icon(Icons.chat_bubble_outline_rounded, color: c.a),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          (g['title'] ?? '').toString(),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: c.text,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w800),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          ((g['msgs'] as List).isEmpty
                                                  ? ''
                                                  : (g['msgs'] as List).last['t'] ?? '')
                                              .toString(),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: c.dim, fontSize: 13.5, height: 1.4),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        if (list.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(4, 10, 4, 10),
                            child: Text(context.t('dream_chats'),
                                style: TextStyle(
                                    color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                          ),
                      ],
                      for (final d in list)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Panel(
                            onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                                builder: (_) => DreamChatPage(id: d.id))),
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Icon(Icons.forum_rounded, color: c.a),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w800),
                                      ),
                                      const SizedBox(height: 4),
                                      Text((d.chat.last['t'] ?? '').toString(),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: c.dim, fontSize: 13.5, height: 1.4)),
                                      const SizedBox(height: 6),
                                      Text('${d.chat.length} ${context.t('chat_msgs')}',
                                          style: TextStyle(
                                              color: al(c.dim, 0.8), fontSize: 12)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
