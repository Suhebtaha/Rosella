import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Opens a page by growing it out of the card that was tapped (and shrinking back into it on
/// return), like a container transform. [from] is the card's rectangle on screen.
class CardOpenRoute extends PageRouteBuilder<void> {
  CardOpenRoute({
    required Rect from,
    required Color color,
    required double radius,
    required WidgetBuilder builder,
  }) : super(
          opaque: false,
          transitionDuration: const Duration(milliseconds: 460),
          reverseTransitionDuration: const Duration(milliseconds: 380),
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, _, child) {
            final curved = CurvedAnimation(
              parent: animation,
              curve: Curves.easeInOutCubicEmphasized,
              reverseCurve: Curves.easeInOutCubic,
            );
            final size = MediaQuery.of(context).size;
            final full = Offset.zero & size;
            return AnimatedBuilder(
              animation: curved,
              builder: (_, __) {
                final v = curved.value;
                final rect = Rect.lerp(from, full, v)!;
                final r = lerpDouble(radius, 0, v.clamp(0.0, 1.0))!;
                // page content appears after the card has started to grow
                final fade = Interval(0.18, 0.7, curve: Curves.easeOut).transform(animation.value);
                return Stack(
                  children: [
                    Positioned.fromRect(
                      rect: rect,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(r),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            ColoredBox(color: color),
                            OverflowBox(
                              alignment: Alignment.topCenter,
                              minWidth: size.width,
                              maxWidth: size.width,
                              minHeight: size.height,
                              maxHeight: size.height,
                              child: Opacity(opacity: fade, child: child),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            );
          },
        );
}

/// Global rectangle of the widget behind [context] (null if it is not laid out).
Rect? rectOf(BuildContext context) {
  final ro = context.findRenderObject();
  if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}
