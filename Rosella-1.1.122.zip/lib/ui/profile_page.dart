import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/strings.dart';
import '../core/symbols.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'dream_detail.dart';
import 'dream_editor.dart';
import 'settings_page.dart';
import 'share_card.dart';
import 'social_pages.dart';
import 'widgets.dart';

/// The 4th tab: your profile and dream statistics. Everything stays on this device.
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final name = app.profileName.trim().isNotEmpty
        ? app.profileName.trim()
        : (app.userName ?? context.t('prof_default_name'));
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    final hasPhoto = avatar != null && File(avatar).existsSync();
    final all = app.dreams;
    final lucid = all.where((d) => d.lucid).length;
    final recurring = recurringSymbols(all, max: 50);
    Widget stat(String n, String label) => Expanded(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(n, style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: c.dim, fontSize: 12.5)),
            ],
          ),
        );
    Widget section(String title, Widget child, {int delay = 0}) => Padding(
          padding: const EdgeInsets.only(top: 22),
          child: FadeSlide(
            delay: delay,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(6, 0, 6, 10),
                  child: Text(title,
                      style: TextStyle(color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                ),
                child,
              ],
            ),
          ),
        );
    final favs = all.where((d) => d.fav).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final first = all.isEmpty
        ? null
        : all.map((d) => d.createdAt).reduce((a, b) => a.isBefore(b) ? a : b);
    int wordsOf(Dream d) =>
        d.content.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
    final longest = all.isEmpty ? 0 : all.map(wordsOf).reduce((a, b) => a > b ? a : b);
    final dayCounts = List<int>.filled(8, 0);
    for (final d in all) {
      dayCounts[d.createdAt.weekday]++;
    }
    var bestDay = 0;
    for (var i = 1; i <= 7; i++) {
      if (dayCounts[i] > (bestDay == 0 ? 0 : dayCounts[bestDay])) bestDay = i;
    }
    List<MapEntry<String, int>> top(Iterable<String> items) {
      final m = <String, int>{};
      for (final x in items) {
        final k = x.trim();
        if (k.isNotEmpty) m[k] = (m[k] ?? 0) + 1;
      }
      final l = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      return l.take(8).toList();
    }
    final people = top(all.expand((d) => d.people));
    final places = top(all.expand((d) => d.places));
    final tags = top(all.expand((d) => d.tags));
    Widget chips(List<MapEntry<String, int>> l, {String prefix = ''}) => Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final e in l)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: c.border),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('$prefix${e.key}',
                        style: TextStyle(
                            color: c.text, fontSize: 13.5, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 6),
                    Text('${e.value}', style: TextStyle(color: c.dim, fontSize: 12.5)),
                  ],
                ),
              ),
          ],
        );
    Widget tile(IconData icon, String value, String label) => Expanded(
          child: Container(
            height: 104,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.border),
              color: al(c.surface, 0.55),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 20, color: c.dim),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(value,
                        maxLines: 1,
                        style: TextStyle(
                            color: c.text, fontSize: 19, fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(height: 2),
                Text(label,
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.dim, fontSize: 11.5)),
              ],
            ),
          ),
        );
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text(context.t('prof_title'),
                      style: TextStyle(
                          color: c.text,
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.8)),
                ),
              ),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  RoundIconButton(
                    icon: Icons.settings_rounded,
                    onTap: () => Navigator.of(context).push(
                        CupertinoPageRoute<void>(builder: (_) => const AppSettingsRoute())),
                  ),
                  if (app.updateAvailable)
                    Positioned(
                      right: 2,
                      top: 2,
                      child: Container(
                        width: 11,
                        height: 11,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF3B30),
                          shape: BoxShape.circle,
                          border: Border.all(color: c.bg, width: 1.5),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),
          FadeSlide(
            child: Row(
              children: [
                Pressable(
                  scale: 0.95,
                  onTap: hasPhoto
                      ? () => Navigator.of(context).push(PageRouteBuilder<void>(
                            opaque: false,
                            transitionDuration: const Duration(milliseconds: 220),
                            pageBuilder: (_, a, __) => FadeTransition(
                                opacity: a,
                                child: PhotoViewerPage(path: avatar, tag: 'profile_photo')),
                          ))
                      : null,
                  child: Hero(
                      tag: 'profile_photo',
                      child: ProfileAvatar(path: avatar, name: name, size: 88)),
                ),
                const SizedBox(width: 12),
                if (app.profileShowCount) stat('${all.length}', context.t('prof_stat_dreams')),
                if (app.profileShowStreak) stat('${app.streakDays}', context.t('prof_stat_streak')),
                if (app.profileShowLucid) stat('$lucid', context.t('prof_stat_lucid')),
                if (app.profileShowRecurring)
                  stat('${recurring.length}', context.t('prof_stat_recurring')),
              ],
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 30,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  if (app.profileBio.trim().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(app.profileBio.trim(),
                          textDirection: textDirOf(app.profileBio, Directionality.of(context)),
                          style: TextStyle(color: c.text, fontSize: 14.5, height: 1.5)),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FadeSlide(
            delay: 60,
            child: GradientButton(
              label: context.t('prof_edit'),
              onTap: () => Navigator.of(context)
                  .push(CupertinoPageRoute<void>(builder: (_) => const ProfileEditPage())),
            ),
          ),
          section(
            context.t('prof_sec_journey'),
            Row(
              children: [
                tile(Icons.flag_rounded, first == null ? '-' : '${first.year}',
                    first == null ? context.t('prof_since') : '${context.t('prof_since')} ${first.day}/${first.month}'),
                const SizedBox(width: 8),
                tile(Icons.calendar_today_rounded, bestDay == 0 ? '-' : context.t('d$bestDay'),
                    context.t('prof_active_day')),
                const SizedBox(width: 8),
                tile(Icons.notes_rounded, '$longest', context.t('prof_longest')),
              ],
            ),
            delay: 90,
          ),
          section(
            context.t('prof_fav_title'),
            favs.isEmpty
                ? Container(
                    height: 90,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: c.border),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star_border_rounded, color: c.dim, size: 20),
                        const SizedBox(width: 8),
                        Text(context.t('prof_fav_empty'),
                            style: TextStyle(color: c.dim, fontSize: 13.5)),
                      ],
                    ),
                  )
                : SizedBox(
                    height: 190,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: favs.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (_, i) {
                        final d = favs[i];
                        final img = app.abs(d.image);
                        final has = img != null && File(img).existsSync();
                        final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
                        return Pressable(
                          scale: 0.97,
                          onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                              builder: (_) => DreamDetailPage(id: d.id))),
                          child: Container(
                            width: 150,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: c.border),
                              color: c.surface,
                              gradient: has
                                  ? null
                                  : LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [al(moodColor(d.mood), 0.35), al(c.surface, 0.8)]),
                            ),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                if (has)
                                  Image.file(File(img), fit: BoxFit.cover, cacheWidth: 400),
                                if (has)
                                  const DecoratedBox(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [Color(0x00000000), Color(0xCC000000)],
                                      ),
                                    ),
                                  ),
                                const Positioned(
                                  top: 10,
                                  right: 10,
                                  child: Icon(Icons.star_rounded,
                                      color: Color(0xFFFFC94D), size: 20),
                                ),
                                Positioned(
                                  left: 12,
                                  right: 12,
                                  bottom: 12,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 20)),
                                      const SizedBox(height: 4),
                                      Text(t,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textDirection:
                                              textDirOf(t, Directionality.of(context)),
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.w800)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
            delay: 120,
          ),
          if (people.isNotEmpty)
            section(context.t('prof_sec_people'), chips(people), delay: 150),
          if (places.isNotEmpty)
            section(context.t('prof_sec_places'), chips(places), delay: 170),
          if (tags.isNotEmpty)
            section(context.t('prof_sec_tags'), chips(tags, prefix: '#'), delay: 190),
        ],
      ),
    );
  }
}

/// The app settings (the old 4th tab), opened from the gear on the profile page.
class AppSettingsRoute extends StatelessWidget {
  const AppSettingsRoute({super.key});

  @override
  Widget build(BuildContext context) => PageScaffold(
        child: Column(
          children: const [
            TopBar(),
            Expanded(child: SettingsPage()),
          ],
        ),
      );
}

class ProfileAvatar extends StatelessWidget {
  final String? path;
  final String name;
  final double size;
  const ProfileAvatar({required this.path, required this.name, required this.size});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final letter = name.trim().isEmpty ? 'R' : name.trim().characters.first.toUpperCase();
    final has = path != null && File(path!).existsSync();
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: al(c.text, 0.55), width: 2),
      ),
      child: ClipOval(
        child: has
            ? Image.file(File(path!),
                fit: BoxFit.cover, cacheWidth: (size * 3).toInt())
            : Container(
                color: c.surface,
                alignment: Alignment.center,
                child: Text(letter,
                    style: TextStyle(
                        color: c.text, fontSize: size * 0.42, fontWeight: FontWeight.w800)),
              ),
      ),
    );
  }
}

class _FeaturedCard extends StatelessWidget {
  final Dream dream;
  const _FeaturedCard({required this.dream});

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final c = context.colors;
    final img = app.abs(dream.image);
    final title = dream.title.trim().isEmpty ? fmtDate(dream.createdAt, app.lang) : dream.title;
    final body = dream.content.replaceAll(RegExp(r'\s+'), ' ').trim();
    return Pressable(
      scale: 0.98,
      onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: dream.id))),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: c.border),
          color: c.surface,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (img != null && File(img).existsSync())
              Image.file(File(img),
                  height: 180, width: double.infinity, fit: BoxFit.cover, cacheWidth: 900)
            else
              Container(
                height: 110,
                alignment: Alignment.center,
                decoration: BoxDecoration(gradient: LinearGradient(colors: [al(c.a, 0.4), al(c.b, 0.4)])),
                child: Text(moodEmoji(dream.mood), style: const TextStyle(fontSize: 44)),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Color(0xFFFFC94D), size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textDirection: textDirOf(title, Directionality.of(context)),
                            style: TextStyle(
                                color: c.text, fontSize: 18, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                  if (body.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(body,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        textDirection: textDirOf(body, Directionality.of(context)),
                        style: TextStyle(color: c.dim, fontSize: 14, height: 1.45)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to choose the dream shown on the profile (private dreams are never offered).
Future<void> pickFeaturedDream(BuildContext context) async {
  final app = context.read<AppState>();
  final list = app.dreams.where((d) => !d.priv).toList();
  final c = context.colors;
  if (list.isEmpty) {
    toast(context, context.t('prof_no_dreams'));
    return;
  }
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: c.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.7),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(context.t('prof_featured_pick'),
                        style: TextStyle(
                            color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                  if (app.featuredId != null)
                    TextButton(
                      onPressed: () {
                        app.updateProfile(clearFeatured: true);
                        Navigator.of(ctx).pop();
                      },
                      child: Text(context.t('prof_featured_none')),
                    ),
                ],
              ),
            ),
            Flexible(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final d = list[i];
                  final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
                  return ListTile(
                    leading: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
                    title: Text(t,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                    subtitle: Text(fmtDate(d.createdAt, app.lang),
                        style: TextStyle(color: c.dim)),
                    trailing: app.featuredId == d.id
                        ? Icon(Icons.check_rounded, color: c.text)
                        : null,
                    onTap: () {
                      Haptics.selection();
                      app.updateProfile(featured: d.id);
                      Navigator.of(ctx).pop();
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Edit the profile: photo, name, bio and what is shown.
class ProfileEditPage extends StatefulWidget {
  const ProfileEditPage({super.key});

  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  late final TextEditingController _name;
  late final TextEditingController _bio;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _name = TextEditingController(text: app.profileName);
    _bio = TextEditingController(text: app.profileBio);
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final app = context.read<AppState>();
    try {
      final x = await app.external(() => ImagePicker().pickImage(
            source: ImageSource.gallery,
            maxWidth: 800,
            imageQuality: 85,
          ));
      if (x == null) return;
      final rel = app.newFileRel('images', 'jpg');
      await File(x.path).copy(app.abs(rel)!);
      app.updateProfile(avatar: rel);
    } catch (_) {}
  }

  Widget _switch(BuildContext context, String label, bool v, ValueChanged<bool> on) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(color: c.text, fontSize: 15, fontWeight: FontWeight.w600)),
          ),
          Switch(value: v, onChanged: (x) {
            Haptics.selection();
            on(x);
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final avatar = app.profileAvatar != null ? app.abs(app.profileAvatar) : null;
    InputDecoration deco(String hint) => InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: c.dim),
          filled: true,
          fillColor: al(c.surface, 0.8),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        );
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('prof_edit')),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: [
                Center(
                  child: Pressable(
                    onTap: _pickPhoto,
                    child: Stack(
                      children: [
                        ProfileAvatar(
                            path: avatar,
                            name: app.profileName.isEmpty ? (app.userName ?? '') : app.profileName,
                            size: 104),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(color: c.surfaceHi, shape: BoxShape.circle),
                            child: Icon(Icons.photo_camera_rounded, size: 18, color: c.text),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (app.profileAvatar != null)
                  Center(
                    child: TextButton(
                      onPressed: () => app.updateProfile(clearAvatar: true),
                      child: Text(context.t('prof_photo_remove')),
                    ),
                  ),
                const SizedBox(height: 14),
                TextField(
                  controller: _name,
                  maxLength: 40,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_name')),
                  onChanged: (v) => app.updateProfile(name: v),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _bio,
                  maxLength: 160,
                  maxLines: 3,
                  style: TextStyle(color: c.text),
                  decoration: deco(context.t('prof_bio')),
                  onChanged: (v) => app.updateProfile(bio: v),
                ),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    children: [
                      _switch(context, context.t('prof_show_count'), app.profileShowCount,
                          (v) => app.updateProfile(showCount: v)),
                      _switch(context, context.t('prof_show_streak'), app.profileShowStreak,
                          (v) => app.updateProfile(showStreak: v)),
                      _switch(context, context.t('prof_show_lucid'), app.profileShowLucid,
                          (v) => app.updateProfile(showLucid: v)),
                      _switch(context, context.t('prof_show_recurring'), app.profileShowRecurring,
                          (v) => app.updateProfile(showRecurring: v)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
