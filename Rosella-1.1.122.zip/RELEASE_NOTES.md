## Rosella 1.1.122

- Profile: fixed the oversized start date; the three info tiles are now the same size.
- Profile no longer repeats the Insights page (mood chart, recurring symbols, achievements). New: your favorite dreams, most active day, longest dream, and the people, places and tags that appear most in your dreams.
