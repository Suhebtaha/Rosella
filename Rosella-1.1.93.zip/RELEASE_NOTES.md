## Rosella 1.1.93

- New full-screen language page on first launch: moving violet light, drifting stars, the app mark and rows that rise in one by one.
- "Discover the secrets of your dreams" now flies in letter by letter with a soft blur, in a more elegant font.
- Background stars never stop moving and twinkling.
- Welcome pages (sky, quotes, onboarding and "Welcome") have a black background with slowly moving violet and magenta gradients.
- The app mark in the welcome page has a colour gradient that keeps turning.
- Automatic cleanup of unneeded cache files, and a smaller picture cache.
