## Rosella 1.1.114

- The 4th tab is now Profile (photo, name, bio, stats, a featured dream). App settings moved behind the gear icon on the profile page.
- Edit profile: change photo and name, write a bio, hide the email, and choose which stats are shown (dream count, streak, lucid, recurring), plus pick a featured dream.
- Home ⋮ menu: Private replaces the view tile; "Switch views" is a row with a small arrow that expands into List / Cards with a smooth animation.
- The "+" button now has a dark glass look on dark themes.
