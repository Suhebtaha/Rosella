import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/nav_bus.dart';
import '../core/theme.dart';
import 'widgets.dart';

double _seg(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

/// Last step of the onboarding: the page fades away, stars flow towards you,
/// a flash, "Welcome to Rosella", a second flash, then the app appears.
class WarpEntry extends StatefulWidget {
  final VoidCallback onDone;
  const WarpEntry({super.key, required this.onDone});

  @override
  State<WarpEntry> createState() => _WarpEntryState();
}

class _WarpEntryState extends State<WarpEntry> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 6200));
  bool _b1 = false, _b2 = false;

  @override
  void initState() {
    super.initState();
    _c.addListener(() {
      if (!_b1 && _c.value > 0.50) {
        _b1 = true;
        HapticFeedback.mediumImpact();
      }
      if (!_b2 && _c.value > 0.88) {
        _b2 = true;
        HapticFeedback.heavyImpact();
      }
    });
    _c.forward().whenComplete(() {
      if (mounted) {
        entryReveal.value = true;
        widget.onDone();
      }
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = _c.value;
        final bg = Curves.easeOut.transform(_seg(t, 0.0, 0.07));
        final flashUp = Curves.easeIn.transform(_seg(t, 0.44, 0.54));
        final flashDown = Curves.easeOut.transform(_seg(t, 0.54, 0.66));
        final flash1 = flashUp * (1 - flashDown);
        final text = Curves.easeOut.transform(_seg(t, 0.62, 0.74));
        final textOut = Curves.easeIn.transform(_seg(t, 0.82, 0.88));
        final flash2 = Curves.easeIn.transform(_seg(t, 0.86, 0.98));
        return Stack(
          children: [
            Positioned.fill(
              child: Opacity(opacity: bg, child: Container(color: const Color(0xFF040813))),
            ),
            Positioned.fill(child: CustomPaint(painter: WarpPainter(t))),
            Positioned.fill(
              child: IgnorePointer(
                child: Opacity(opacity: flash1, child: Container(color: Colors.white)),
              ),
            ),
            Center(
              child: Opacity(
                opacity: text * (1 - textOut),
                child: Transform.scale(
                  scale: 0.94 + 0.06 * text,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(context.t('w_welcome'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                                fontWeight: FontWeight.w800,
                                height: 1.35,
                                decoration: TextDecoration.none)),
                        const SizedBox(height: 10),
                        Text(context.t('w_welcome_sub'),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: al(Colors.white, 0.62),
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.4,
                                decoration: TextDecoration.none)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: IgnorePointer(
                child: Opacity(opacity: flash2, child: Container(color: Colors.white)),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// A short burst of stars flowing towards the viewer (used after choosing the language).
class WarpBurst extends StatelessWidget {
  final Animation<double> animation;
  const WarpBurst({super.key, required this.animation});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: animation,
        builder: (_, __) => CustomPaint(
          size: Size.infinite,
          painter: WarpPainter(animation.value, warpEnd: 1.0, fadeFrom: 0.55, fadeLen: 0.45, glow: false),
        ),
      ),
    );
  }
}

class WarpPainter extends CustomPainter {
  final double t;
  final double warpEnd, fadeFrom, fadeLen;
  final bool glow;
  WarpPainter(this.t,
      {this.warpEnd = 0.6, this.fadeFrom = 0.50, this.fadeLen = 0.12, this.glow = true});

  static final List<List<double>> _s = () {
    final r = math.Random(5);
    return [
      for (var i = 0; i < 320; i++)
        [r.nextDouble() * 2 - 1, r.nextDouble() * 2 - 1, r.nextDouble(), 0.6 + r.nextDouble()]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final f = size.shortestSide * 0.22;
    final span = (t / warpEnd).clamp(0.0, 1.0);
    final fade = 1 - ((t - fadeFrom) / fadeLen).clamp(0.0, 1.0);
    if (fade <= 0 || t <= 0) return;
    // slow at first, then faster and faster: stars drift towards you smoothly
    final travel = 0.10 * span + 2.4 * span * span * span;
    final streak = 0.008 + 0.22 * span * span;
    final appear = (t / 0.08).clamp(0.0, 1.0);
    final p = Paint()..strokeCap = StrokeCap.round;
    for (final s in _s) {
      var z = (s[2] - travel) % 1.0;
      if (z < 0.03) z += 1.0;
      final near = 1 - z;
      final a = Offset(s[0], s[1]);
      final head = c + a * (f / z);
      final tail = c + a * (f / (z + streak));
      final alpha =
          (near * 255 * fade * appear * (0.35 + 0.65 * span.clamp(0.15, 1.0))).clamp(0, 255);
      p
        ..color = Color.fromARGB(alpha.toInt(), 215, 228, 255)
        ..strokeWidth = (0.6 + near * 2.2) * s[3];
      canvas.drawLine(tail, head, p);
    }
    if (glow) {
      final g = ((t - 0.25) / 0.3).clamp(0.0, 1.0) * fade;
      if (g > 0) {
        canvas.drawCircle(
          c,
          size.shortestSide * (0.15 + 0.4 * g),
          Paint()
            ..shader = RadialGradient(colors: [
              al(Colors.white, 0.55 * g),
              al(const Color(0xFF8DB4FF), 0.0),
            ]).createShader(Rect.fromCircle(center: c, radius: size.shortestSide * 0.55)),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant WarpPainter o) => o.t != t;
}
