import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import 'widgets.dart';

/// Last step of the onboarding: stars rush towards you, a flash, then "Welcome to Rosella".
class WarpEntry extends StatefulWidget {
  final VoidCallback onDone;
  const WarpEntry({super.key, required this.onDone});

  @override
  State<WarpEntry> createState() => _WarpEntryState();
}

class _WarpEntryState extends State<WarpEntry> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 4200));
  bool _buzzed = false;

  @override
  void initState() {
    super.initState();
    _c.addListener(() {
      if (!_buzzed && _c.value > 0.52) {
        _buzzed = true;
        HapticFeedback.mediumImpact();
      }
    });
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static double _seg(double t, double a, double b) =>
      ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF040813),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final flashUp = Curves.easeIn.transform(_seg(t, 0.46, 0.60));
          final flashDown = Curves.easeOut.transform(_seg(t, 0.60, 0.74));
          final flash = flashUp * (1 - flashDown);
          final text = Curves.easeOut.transform(_seg(t, 0.70, 0.84));
          final out = _seg(t, 0.94, 1.0);
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(painter: _WarpPainter(t)),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: Opacity(opacity: flash, child: Container(color: Colors.white)),
                ),
              ),
              Center(
                child: Opacity(
                  opacity: text * (1 - out),
                  child: Transform.scale(
                    scale: 0.94 + 0.06 * text,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(context.t('w_welcome'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                              height: 1.35,
                              decoration: TextDecoration.none)),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _WarpPainter extends CustomPainter {
  final double t;
  _WarpPainter(this.t);

  static final List<List<double>> _s = () {
    final r = math.Random(5);
    return [
      for (var i = 0; i < 320; i++)
        [r.nextDouble() * 2 - 1, r.nextDouble() * 2 - 1, r.nextDouble(), 0.6 + r.nextDouble()]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final f = size.shortestSide * 0.22;
    final span = (t / 0.6).clamp(0.0, 1.0); // warp phase
    final fade = 1 - ((t - 0.50) / 0.12).clamp(0.0, 1.0);
    if (fade <= 0) return;
    // distance travelled: slow at first, then faster and faster
    final travel = 0.12 * span + 3.2 * span * span * span;
    final streak = 0.01 + 0.30 * span * span;
    final p = Paint()..strokeCap = StrokeCap.round;
    for (final s in _s) {
      var z = (s[2] - travel) % 1.0;
      if (z < 0.03) z += 1.0;
      final near = 1 - z;
      final a = Offset(s[0], s[1]);
      final head = c + a * (f / z);
      final tail = c + a * (f / (z + streak));
      final alpha = (near * 255 * fade * (0.35 + 0.65 * span.clamp(0.15, 1.0))).clamp(0, 255);
      p
        ..color = Color.fromARGB(alpha.toInt(), 215, 228, 255)
        ..strokeWidth = (0.6 + near * 2.2) * s[3];
      canvas.drawLine(tail, head, p);
    }
    // soft glow in the middle building up to the flash
    final g = ((t - 0.25) / 0.3).clamp(0.0, 1.0) * fade;
    if (g > 0) {
      canvas.drawCircle(
        c,
        size.shortestSide * (0.15 + 0.4 * g),
        Paint()
          ..shader = RadialGradient(colors: [
            al(Colors.white, 0.55 * g),
            al(const Color(0xFF8DB4FF), 0.0),
          ]).createShader(Rect.fromCircle(center: c, radius: size.shortestSide * 0.55)),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WarpPainter o) => o.t != t;
}
