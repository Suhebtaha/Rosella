import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/nav_bus.dart';
import '../core/theme.dart';
import 'aurora.dart';
import 'shell.dart';
import 'warp_entry.dart';
import 'welcome_flow.dart';
import 'widgets.dart';

/// Splash (short, never blocks) → first-run onboarding → main shell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splash = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    splashShowing.value = true;
    _t = Timer(const Duration(milliseconds: 850), () {
      splashShowing.value = false;
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final onboarded = context.select<AppState, bool>((s) => s.onboarded);
    final welcomed = context.select<AppState, bool>((s) => s.welcomed);
    return Stack(
      children: [
        Positioned.fill(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 260),
            child: onboarded
                ? const Shell(key: ValueKey('shell'))
                : welcomed
                    ? const OnboardingPage(key: ValueKey('onb'))
                    : const WelcomeFlow(key: ValueKey('welcome')),
          ),
        ),
        ValueListenableBuilder<bool>(
          valueListenable: entryReveal,
          builder: (_, on, __) =>
              on ? const Positioned.fill(child: _RevealFlash()) : const SizedBox.shrink(),
        ),
        Positioned.fill(
          child: IgnorePointer(
            ignoring: !_splash,
            child: AnimatedOpacity(
              opacity: _splash ? 1 : 0,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              child: const _Splash(),
            ),
          ),
        ),
      ],
    );
  }
}

/// White flash that melts away to reveal the app after the onboarding's last animation.
class _RevealFlash extends StatelessWidget {
  const _RevealFlash();

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 1.0, end: 0.0),
      duration: const Duration(milliseconds: 1300),
      curve: Curves.easeInOut,
      onEnd: () => entryReveal.value = false,
      builder: (_, v, __) => IgnorePointer(
        child: Opacity(
          opacity: v,
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                radius: 0.4 + 1.4 * (1 - v),
                colors: const [Colors.white, Colors.white, Color(0x00FFFFFF)],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Opening: stars fade in, the wordmark appears and "by Suhaib" fades in underneath.
class _Splash extends StatefulWidget {
  const _Splash();

  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 750))
        ..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static double _seg(double t, double a, double b) =>
      ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
      color: Colors.black,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final stars = Curves.easeOut.transform(_seg(t, 0.0, 0.3));
          final glow = Curves.easeOut.transform(_seg(t, 0.2, 0.7));
          final by = Curves.easeOut.transform(_seg(t, 0.82, 1.0));
          return Stack(
            children: [
              Positioned.fill(
                child: Opacity(
                  opacity: stars,
                  child: const CustomPaint(painter: _SplashStars()),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Opacity(
                      opacity: glow,
                      child: BrandWordmark(width: 250, twinkle: t * 2),
                    ),
                    const SizedBox(height: 10),
                    Opacity(
                      opacity: by,
                      child: Text('by Suhaib',
                          style: TextStyle(
                            fontFamily: 'serif',
                            color: al(const Color(0xFFD9D9DE), 0.8),
                            fontSize: 16,
                            letterSpacing: 1.4,
                          )),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    ));
  }
}

class _SplashStars extends CustomPainter {
  const _SplashStars();

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(7);
    final p = Paint();
    for (var i = 0; i < 140; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final rad = 0.4 + r.nextDouble() * 0.9;
      p.color = Colors.white.withAlpha(30 + r.nextInt(120));
      canvas.drawCircle(Offset(x, y), rad, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// "Developed by Suhaib" with the flowing dynamic colours.
class _Credit extends StatelessWidget {
  final double size;
  const _Credit({required this.size});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: DynamicText('Developed by Suhaib',
          fontSize: size, letterSpacing: 0.8, weight: FontWeight.w800),
    );
  }
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pc = PageController();
  int _i = 0;
  bool _warping = false;

  static const int _n = 10; // page 0 = dark/light, then 9 features
  static const _icons = [
    Icons.mic_rounded,
    Icons.psychology_rounded,
    Icons.forum_rounded,
    Icons.auto_awesome_rounded,
    Icons.headphones_rounded,
    Icons.fingerprint_rounded,
    Icons.vibration_rounded,
    Icons.notifications_active_rounded,
    Icons.palette_rounded,
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _next() {
    if (_i >= _n - 1) {
      setState(() => _warping = true); // stars rush at you, flash, "Welcome to Rosella"
    } else {
      _pc.nextPage(
          duration: const Duration(milliseconds: 380), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    // always the deep black theme here, whatever theme the app uses
    return Theme(
      data: buildTheme('onyx', true),
      child: Builder(builder: (context) => _body(context)),
    );
  }

  Widget _body(BuildContext context) {
    final c = context.colors;
    final last = _i == _n - 1;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          const Positioned.fill(child: AuroraBackground()),
          const Positioned.fill(child: StarField()),
          IgnorePointer(
            ignoring: _warping,
            child: AnimatedOpacity(
              opacity: _warping ? 0 : 1,
              duration: const Duration(milliseconds: 650),
              curve: Curves.easeOut,
              child: SafeArea(
            child: Column(
              children: [
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                    child: AnimatedOpacity(
                      opacity: last ? 0 : 1,
                      duration: const Duration(milliseconds: 200),
                      child: TextButton(
                        onPressed:
                            last ? null : () => context.read<AppState>().completeOnboarding(),
                        child: Text(context.t('skip'),
                            style: TextStyle(
                                color: c.dim, fontSize: 15, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    itemCount: _n,
                    onPageChanged: (v) => setState(() => _i = v),
                    itemBuilder: (_, i) =>
                        i == 0 ? _modePage(context) : _featurePage(context, i - 1),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < _n; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _i == i ? 22 : 7,
                        height: 7,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: _i == i ? const Color(0xFFE8E8EC) : al(Colors.white, 0.25),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 22, 24, 26),
                  child: GradientButton(
                    label: context.t(last ? 'start' : 'next'),
                    icon: last ? Icons.check_rounded : Icons.arrow_forward_rounded,
                    expand: true,
                    onTap: _next,
                  ),
                ),
              ],
            ),
          ),
            ),
          ),
          if (_warping)
            Positioned.fill(
              child: WarpEntry(onDone: () => context.read<AppState>().completeOnboarding()),
            ),
        ],
      ),
    );
  }

  Widget _modePage(BuildContext context) {
    final app = context.read<AppState>();
    Widget card(bool dark, IconData icon, String key) {
      return Expanded(
        child: Selector<AppState, bool>(
          selector: (_, st) => st.dark,
          builder: (context, isDark, _) {
            final sel = isDark == dark;
            const bg = Color(0xFF000000);
            const fg = Color(0xFFE8E8EC);
            return Pressable(
              onTap: () => app.setDark(dark),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                height: 150,
                decoration: BoxDecoration(
                  color: sel ? const Color(0xFF1C1C22) : bg,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(
                      color: sel ? const Color(0xFFE8E8EC) : al(Colors.white, 0.18),
                      width: sel ? 3 : 1.5),
                  boxShadow: sel
                      ? [BoxShadow(color: al(Colors.white, 0.18), blurRadius: 24)]
                      : const [],
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icon, size: 42, color: sel ? fg : al(fg, 0.6)),
                          const SizedBox(height: 12),
                          Text(context.t(key),
                              style: TextStyle(
                                  color: sel ? fg : al(fg, 0.6),
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: AnimatedScale(
                        scale: sel ? 1 : 0,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutBack,
                        child: Container(
                          width: 26,
                          height: 26,
                          decoration: const BoxDecoration(
                              color: Color(0xFFE8E8EC), shape: BoxShape.circle),
                          child: const Icon(Icons.check_rounded,
                              size: 18, color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const _OrbIcon(icon: Icons.brightness_6_rounded, size: 96),
          const SizedBox(height: 26),
          _Reveal(
            delay: 200,
            child: Text(context.t('choose_mode'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Color(0xFFF2F2F5),
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    height: 1.4)),
          ),
          const SizedBox(height: 8),
          _Reveal(
            delay: 380,
            child: Text(context.t('choose_mode_sub'),
                textAlign: TextAlign.center,
                style: TextStyle(color: al(Colors.white, 0.6), fontSize: 14.5, height: 1.5)),
          ),
          const SizedBox(height: 26),
          _Reveal(
            delay: 500,
            child: Row(children: [
              card(true, Icons.dark_mode_rounded, 'mode_dark'),
              const SizedBox(width: 14),
              card(false, Icons.light_mode_rounded, 'mode_light'),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _featurePage(BuildContext context, int i) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _OrbIcon(icon: _icons[i], size: 112),
          const SizedBox(height: 34),
          _Reveal(
            delay: 250,
            child: Text(context.t('ob${i + 1}_t'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Color(0xFFF2F2F5),
                    fontSize: 27,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3)),
          ),
          const SizedBox(height: 14),
          _Reveal(
            delay: 550,
            child: Text(context.t('ob${i + 1}_d'),
                textAlign: TextAlign.center,
                style: TextStyle(color: c.dim, fontSize: 16, height: 1.6)),
          ),
        ],
      ),
    );
  }
}

/// Fades and slides its child up slowly once, after [delay] ms (staggered entrances).
class _Reveal extends StatelessWidget {
  final Widget child;
  final int delay;
  const _Reveal({required this.child, this.delay = 0});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 1100 + delay),
      curve: Curves.linear,
      builder: (_, v, ch) {
        final t = Curves.easeOutCubic
            .transform(((v * (1100 + delay) - delay) / 1100).clamp(0.0, 1.0));
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, 22 * (1 - t)), child: ch),
        );
      },
      child: child,
    );
  }
}

/// Icon in a dark disc that floats slowly, with a breathing glow, two turning dashed rings
/// and small dots orbiting it. One ticker, repaints only this widget.
class _OrbIcon extends StatefulWidget {
  final IconData icon;
  final double size;
  const _OrbIcon({required this.icon, required this.size});

  @override
  State<_OrbIcon> createState() => _OrbIconState();
}

class _OrbIconState extends State<_OrbIcon> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final box = s * 1.9;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 1400),
      curve: Curves.easeOutBack,
      builder: (_, enter, child) => Opacity(
        opacity: enter.clamp(0.0, 1.0),
        child: Transform.scale(scale: 0.6 + 0.4 * enter, child: child),
      ),
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            final t = _c.value;
            final bob = math.sin(t * math.pi * 4) * 6; // 2 slow bobs per loop
            final breathe = 0.5 + 0.5 * math.sin(t * math.pi * 6);
            return SizedBox(
              width: box,
              height: box,
              child: Stack(alignment: Alignment.center, children: [
                CustomPaint(size: Size(box, box), painter: _OrbPainter(t, s)),
                Transform.translate(
                  offset: Offset(0, bob),
                  child: Container(
                    width: s,
                    height: s,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF000000),
                      border: Border.all(color: al(Colors.white, 0.18 + 0.12 * breathe)),
                      boxShadow: [
                        BoxShadow(
                            color: al(Colors.white, 0.08 + 0.10 * breathe),
                            blurRadius: 30 + 20 * breathe,
                            spreadRadius: 1),
                      ],
                    ),
                    child: Icon(widget.icon, size: s * 0.46, color: const Color(0xFFE8E8EC)),
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double t;
  final double s;
  _OrbPainter(this.t, this.s);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withOpacity(0.10);
    // two dashed rings turning in opposite directions
    for (var k = 0; k < 2; k++) {
      final r = s * (0.78 + 0.26 * k);
      final dir = k == 0 ? 1.0 : -1.0;
      final start = t * math.pi * 2 * dir * (k == 0 ? 1 : 0.6);
      const dashes = 28;
      for (var i = 0; i < dashes; i++) {
        final a = start + i * (math.pi * 2 / dashes);
        canvas.drawArc(Rect.fromCircle(center: c, radius: r), a, 0.09, false, ring);
      }
    }
    // orbiting dots
    final dot = Paint();
    for (var i = 0; i < 3; i++) {
      final a = t * math.pi * 2 * (i.isEven ? 1 : -1) + i * 2.1;
      final r = s * (0.78 + 0.26 * (i % 2));
      final p = c + Offset(math.cos(a), math.sin(a)) * r;
      dot.color = Colors.white.withOpacity(0.55);
      canvas.drawCircle(p, 2.6, dot);
      dot.color = Colors.white.withOpacity(0.12);
      canvas.drawCircle(p, 7, dot);
    }
  }

  @override
  bool shouldRepaint(_OrbPainter o) => o.t != t;
}

