## Rosella 1.1.99

- New app icon: a glowing white crescent beside "rosella" on black.
- The same mark (white on black) now appears in the opening screen and the welcome screens.
- New look for delete and confirmation dialogs: a card rising from the bottom with a separate Cancel button.
