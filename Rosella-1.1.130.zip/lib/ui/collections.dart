import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../services/haptics.dart';
import 'dream_detail.dart';
import 'widgets.dart';

String collectionName(BuildContext context, DreamCollection c) {
  if (c.name != null) return c.name!;
  switch (c.id) {
    case 'c_strange':
      return context.t('col_strange');
    case 'c_night':
      return context.t('col_night');
    case 'c_beauty':
      return context.t('col_beauty');
    case 'c_lucid':
      return context.t('col_lucid');
  }
  return c.id;
}

IconData collectionIcon(DreamCollection c) {
  switch (c.id) {
    case 'c_strange':
      return Icons.blur_on_rounded;
    case 'c_night':
      return Icons.thunderstorm_rounded;
    case 'c_beauty':
      return Icons.auto_awesome_rounded;
    case 'c_lucid':
      return Icons.visibility_rounded;
  }
  return Icons.folder_rounded;
}

Future<void> promptNewCollection(BuildContext context) async {
  final app = context.read<AppState>();
  final c = context.colors;
  final ctrl = TextEditingController();
  final name = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: c.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Text(context.t('col_new'), style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        maxLength: 30,
        style: TextStyle(color: c.text),
        decoration: InputDecoration(hintText: context.t('col_name_hint'), hintStyle: TextStyle(color: c.dim)),
        onSubmitted: (v) => Navigator.of(ctx).pop(v),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text(context.t('cancel'))),
        TextButton(
            onPressed: () => Navigator.of(ctx).pop(ctrl.text),
            child: Text(context.t('cf_confirm'))),
      ],
    ),
  );
  if (name != null && name.trim().isNotEmpty) app.addCollection(name);
}

/// Bottom sheet: tick the collections a dream belongs to.
Future<void> showAssignCollections(BuildContext context, String dreamId) {
  final c = context.colors;
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: c.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: Consumer<AppState>(
        builder: (_, app, __) {
          final d = app.byId(dreamId);
          if (d == null) return const SizedBox.shrink();
          return ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.7),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(context.t('col_add'),
                        style: TextStyle(color: c.text, fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                ),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      for (final col in app.collections)
                        ListTile(
                          leading: Icon(collectionIcon(col), color: c.text),
                          title: Text(collectionName(context, col),
                              style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                          trailing: app.inCollection(d, col.id)
                              ? Icon(Icons.check_circle_rounded, color: c.a)
                              : Icon(Icons.circle_outlined, color: c.dim),
                          onTap: () {
                            Haptics.selection();
                            app.toggleDreamCollection(d, col.id);
                          },
                        ),
                      ListTile(
                        leading: Icon(Icons.add_rounded, color: c.dim),
                        title: Text(context.t('col_new'), style: TextStyle(color: c.dim)),
                        onTap: () => promptNewCollection(context),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    ),
  );
}

class CollectionPage extends StatelessWidget {
  final String id;
  const CollectionPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final col = app.collections.where((x) => x.id == id).firstOrNull;
    if (col == null) return const PageScaffold(child: SizedBox.shrink());
    final list = app.dreamsIn(id);
    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            title: collectionName(context, col),
            actions: [
              RoundIconButton(
                icon: Icons.delete_outline_rounded,
                onTap: () async {
                  final ok = await confirmDialog(
                    context,
                    title: context.t('col_delete'),
                    message: context.t('col_delete_msg'),
                    confirm: context.t('mn_delete'),
                  );
                  if (!ok) return;
                  app.deleteCollection(id);
                  if (context.mounted) Navigator.of(context).pop();
                },
              ),
            ],
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(context.t('col_empty'),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: c.dim, fontSize: 14.5, height: 1.5)),
                    ),
                  )
                : ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 6, 16, 28),
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final d = list[i];
                      final t = d.title.trim().isEmpty ? fmtDate(d.createdAt, app.lang) : d.title;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Panel(
                          onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                              builder: (_) => DreamDetailPage(id: d.id))),
                          child: Row(
                            children: [
                              Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(t,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        textDirection: textDirOf(t, Directionality.of(context)),
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 15.5,
                                            fontWeight: FontWeight.w800)),
                                    Text(fmtDate(d.createdAt, app.lang),
                                        style: TextStyle(color: c.dim, fontSize: 12.5)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

/// A calm label for the way the user records dreams. It only describes what is in the journal
/// (moods, lucid dreams, length): it is not a psychological analysis.
({String key, IconData icon})? dreamPersonality(List<Dream> all) {
  if (all.length < 3) return null;
  final n = all.length;
  final lucid = all.where((d) => d.lucid).length / n;
  final scary = all.where((d) => d.mood == 1).length / n;
  final happy = all.where((d) => d.mood >= 4).length / n;
  final words = all
          .map((d) => d.content.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length)
          .fold<int>(0, (a, b) => a + b) /
      n;
  if (lucid >= 0.25) return (key: 'pers_lucid', icon: Icons.visibility_rounded);
  if (scary >= 0.35) return (key: 'pers_night', icon: Icons.nightlight_round);
  if (happy >= 0.45) return (key: 'pers_gentle', icon: Icons.wb_twilight_rounded);
  if (words >= 60) return (key: 'pers_story', icon: Icons.menu_book_rounded);
  return (key: 'pers_quiet', icon: Icons.auto_stories_rounded);
}
