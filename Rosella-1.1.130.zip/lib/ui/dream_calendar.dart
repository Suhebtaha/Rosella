import 'dart:ui' show ImageFilter;

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import '../core/languages.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'dream_detail.dart';
import 'widgets.dart';

/// Month calendar: days with dreams are coloured by the average mood.
class DreamCalendar extends StatefulWidget {
  const DreamCalendar({super.key});

  @override
  State<DreamCalendar> createState() => _DreamCalendarState();
}

class _DreamCalendarState extends State<DreamCalendar> {
  late DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);

  static const _wdAr = ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']; // Sat..Fri
  static const _wdEn = ['S', 'M', 'T', 'W', 'T', 'F', 'S']; // Sun..Sat

  void _shift(int d) => setState(() => _month = DateTime(_month.year, _month.month + d));

  void _openDay(BuildContext context, List<Dream> ds) {
    if (ds.length == 1) {
      Navigator.of(context).push(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: ds.first.id)));
      return;
    }
    final c = context.colors;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(16),
          children: [
            for (final d in ds)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Panel(
                  onTap: () {
                    Navigator.of(ctx).pop();
                    Navigator.of(context).push(CupertinoPageRoute<void>(
                        builder: (_) => DreamDetailPage(id: d.id)));
                  },
                  child: Row(
                    children: [
                      Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          d.title.isEmpty ? fmtTime(d.createdAt) : d.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: c.text, fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                      ),
                      Text(fmtTime(d.createdAt),
                          style: TextStyle(color: c.dim, fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final rtl = kRtlLangs.contains(app.lang);
    final first = DateTime(_month.year, _month.month, 1);
    final daysIn = DateTime(_month.year, _month.month + 1, 0).day;
    // Arabic/Kurdish weeks start on Saturday, English on Sunday
    final offset = rtl ? (first.weekday + 1) % 7 : first.weekday % 7;
    final wd = rtl ? _wdAr : _wdEn;
    final now = DateTime.now();

    final byDay = <int, List<Dream>>{};
    for (final d in app.dreams) {
      if (d.createdAt.year == _month.year && d.createdAt.month == _month.month) {
        byDay.putIfAbsent(d.createdAt.day, () => []).add(d);
      }
    }

    // how many dreams of each mood this month (for the legend under the card)
    final moodCount = List<int>.filled(6, 0);
    for (final l in byDay.values) {
      for (final d in l) {
        if (d.mood >= 1 && d.mood <= 5) moodCount[d.mood]++;
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(6, 0, 0, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${_month.year}',
                        style: TextStyle(
                            color: c.dim, fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1)),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(context.t('m${_month.month}'),
                          style: TextStyle(
                              color: c.text,
                              fontSize: 44,
                              height: 1.05,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -1.5)),
                    ),
                  ],
                ),
              ),
              RoundIconButton(
                  icon: rtl ? Icons.chevron_right_rounded : Icons.chevron_left_rounded,
                  onTap: () => _shift(-1)),
              const SizedBox(width: 8),
              RoundIconButton(
                  icon: rtl ? Icons.chevron_left_rounded : Icons.chevron_right_rounded,
                  onTap: () => _shift(1)),
            ],
          ),
        ),
        // frosted-glass card
        ClipRRect(
          borderRadius: BorderRadius.circular(32),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 26, sigmaY: 26),
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 18, 10, 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: const Color(0x30FFFFFF)),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: c.isDark
                      ? const [Color(0x26FFFFFF), Color(0x0DFFFFFF)]
                      : const [Color(0x99FFFFFF), Color(0x55FFFFFF)],
                ),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      for (final w in wd)
                        Expanded(
                          child: Center(
                            child: Text(w,
                                style: TextStyle(
                                    color: c.dim,
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1)),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  for (var row = 0; row < 6; row++)
                    if (row * 7 - offset < daysIn)
                      Row(
                        children: [
                          for (var col = 0; col < 7; col++)
                            Expanded(
                                child: _cell(
                                    context, c, row * 7 + col - offset + 1, daysIn, byDay, now)),
                        ],
                      ),
                ],
              ),
            ),
          ),
        ),
        if (moodCount.any((n) => n > 0)) ...[
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('cal_legend'),
                    style: TextStyle(
                        color: c.text, fontSize: 14, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                for (var m = 1; m <= 5; m++)
                  if (moodCount[m] > 0)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Container(
                            width: 22,
                            height: 4,
                            decoration: BoxDecoration(
                                color: moodColor(m), borderRadius: BorderRadius.circular(3)),
                          ),
                          const SizedBox(width: 10),
                          Text(moodEmoji(m), style: const TextStyle(fontSize: 15)),
                          const SizedBox(width: 8),
                          Text('${moodCount[m]}',
                              style: TextStyle(
                                  color: c.dim, fontSize: 13, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _cell(BuildContext context, AppColors c, int day, int daysIn,
      Map<int, List<Dream>> byDay, DateTime now) {
    if (day < 1 || day > daysIn) return const SizedBox(height: 50);
    final ds = byDay[day];
    final isToday = now.year == _month.year && now.month == _month.month && now.day == day;
    Color? fill;
    if (ds != null) {
      final avg = ds.map((d) => d.mood).reduce((a, b) => a + b) / ds.length;
      fill = moodColor(avg.round());
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: ds == null ? null : () => _openDay(context, ds),
      child: SizedBox(
        height: 50,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 34,
              height: 34,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: fill == null ? null : al(fill, 0.5),
                border: isToday
                    ? Border.all(color: c.text, width: 1.6)
                    : (fill == null ? null : Border.all(color: al(fill, 0.8))),
              ),
              child: Text('$day',
                  style: TextStyle(
                      color: c.text,
                      fontSize: 14,
                      fontWeight: fill != null || isToday ? FontWeight.w800 : FontWeight.w500)),
            ),
            const SizedBox(height: 3),
            if (fill != null)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < (ds!.length > 1 ? 2 : 1); i++) ...[
                    if (i > 0) const SizedBox(width: 3),
                    Container(
                      width: ds.length > 1 ? 9 : 18,
                      height: 3,
                      decoration: BoxDecoration(
                          color: fill, borderRadius: BorderRadius.circular(2)),
                    ),
                  ],
                ],
              )
            else
              const SizedBox(height: 3),
          ],
        ),
      ),
    );
  }
}
