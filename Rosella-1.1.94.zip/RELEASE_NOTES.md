## Rosella 1.1.94

- Fixed the language page: rows no longer disappear and come back while scrolling.
- The Dynamic theme now uses the same violet, magenta and indigo colours as the welcome screens.
- Dynamic is now the default theme for new users.
