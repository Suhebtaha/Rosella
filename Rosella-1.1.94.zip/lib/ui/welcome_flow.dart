import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/languages.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import 'aurora.dart';
import 'warp_entry.dart';
import 'widgets.dart';

/// First-run flow for new users:
/// 1. night sky + mountain + "Discover the secrets of your dreams" + arrow
/// 2. the sky tilts up, an eclipse appears, sign-in buttons (email / Google)
/// 3. a short quotes carousel, then the normal onboarding
class WelcomeFlow extends StatefulWidget {
  const WelcomeFlow({super.key});

  @override
  State<WelcomeFlow> createState() => _WelcomeFlowState();
}

class _WelcomeFlowState extends State<WelcomeFlow> with TickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200));
  // stars flowing towards you right after the language is chosen
  late final AnimationController _b =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2000));
  bool _burst = false;
  bool _langDone = false; // until the language is chosen the screen stays plain dark
  // never stops: drives the drifting / twinkling stars
  late final AnimationController _loop =
      AnimationController(vsync: this, duration: const Duration(seconds: 150))..repeat();
  bool _typed = false;
  int _stage = 0; // 0 intro, 1 sign-in, 2 quotes
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    // first thing a new user sees: a small card asking for the language
    WidgetsBinding.instance.addPostFrameCallback((_) => _askLanguage());
  }

  Future<void> _askLanguage() async {
    if (!mounted) return;
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'language',
      barrierColor: Colors.black,
      transitionDuration: const Duration(milliseconds: 500),
      pageBuilder: (_, __, ___) => const _LanguagePage(),
      transitionBuilder: (_, a, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
        child: child,
      ),
    );
    if (!mounted) return;
    setState(() {
      _burst = true;
      _langDone = true;
    });
    HapticFeedback.lightImpact();
    await _b.forward();
    if (mounted) setState(() => _burst = false);
  }

  /// the title flies in letter by letter
  void _startTyping() {
    if (_typed || !mounted) return;
    setState(() => _typed = true);
  }

  @override
  void dispose() {
    _loop.dispose();
    _b.dispose();
    _c.dispose();
    super.dispose();
  }

  void _go() {
    if (_stage != 0) return;
    HapticFeedback.selectionClick();
    setState(() => _stage = 1);
    _c.forward();
  }

  void _toQuotes() {
    if (!mounted) return;
    setState(() => _stage = 2);
  }

  Future<void> _google() async {
    if (_busy) return;
    final app = context.read<AppState>();
    setState(() => _busy = true);
    final err = await app.googleSignIn();
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      toast(context, err);
      return;
    }
    if (app.userEmail != null) _toQuotes();
  }

  Widget _flyTitle(BuildContext context) {
    return FlyText(
      context.t('w_title'),
      play: _typed,
      style: const TextStyle(
        fontFamily: 'serif',
        fontSize: 38,
        fontWeight: FontWeight.w600,
        height: 1.3,
        letterSpacing: 0.4,
        color: Colors.white,
        shadows: [Shadow(color: Color(0x88A78BFA), blurRadius: 22)],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: buildTheme('onyx', true),
      child: Builder(builder: (context) {
        return Scaffold(
          backgroundColor: const Color(0xFF000000),
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: _stage == 2
                ? _Quotes(key: const ValueKey('q'), onDone: () => context.read<AppState>().setWelcomed())
                : _sky(context),
          ),
        );
      }),
    );
  }

  Widget _sky(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    return AnimatedBuilder(
      key: const ValueKey('sky'),
      animation: Listenable.merge([_c, _b, _loop]),
      builder: (_, __) {
        if (_burst && _b.value > 0.55) WidgetsBinding.instance.addPostFrameCallback((_) => _startTyping());
        final skyOn = _burst ? ((_b.value - 0.15) / 0.55).clamp(0.0, 1.0) : (_langDone ? 1.0 : 0.0);
        final t = Curves.easeInOutCubic.transform(_c.value);
        final introIn = _burst ? ((_b.value - 0.55) / 0.45).clamp(0.0, 1.0) : 1.0;
        final intro = (1 - (t / 0.35)).clamp(0.0, 1.0) * introIn;
        final eclipse = ((t - 0.55) / 0.45).clamp(0.0, 1.0);
        final ui = ((t - 0.8) / 0.2).clamp(0.0, 1.0);
        return Stack(
          children: [
            Positioned.fill(child: Container(color: const Color(0xFF000000))),
            Positioned.fill(
              child: Opacity(opacity: skyOn * 0.85, child: const AuroraBackground(intensity: 0.8)),
            ),
            Positioned.fill(
              child: Opacity(
                opacity: skyOn,
                child: RepaintBoundary(
                  child: CustomPaint(painter: _SkyPainter(t, eclipse, _loop.value)),
                ),
              ),
            ),
            if (_burst)
              Positioned.fill(child: WarpBurst(animation: _b)),
            // intro: title + arrow
            if (intro > 0)
              Positioned.fill(
                child: Opacity(
                  opacity: intro,
                  child: SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 56),
                        SizedBox(height: size.height * 0.1),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 36),
                          child: _flyTitle(context),
                        ),
                        const Spacer(),
                        Pressable(
                          onTap: _go,
                          scale: 0.9,
                          child: Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFF000000),
                              border: Border.all(color: al(Colors.white, 0.18)),
                              boxShadow: [
                                BoxShadow(color: al(Colors.white, 0.12), blurRadius: 22),
                              ],
                            ),
                            child: const Icon(Icons.arrow_forward_rounded,
                                color: Colors.white, size: 26),
                          ),
                        ),
                        SizedBox(height: size.height * 0.07),
                      ],
                    ),
                  ),
                ),
              ),
            // sign-in
            if (ui > 0)
              Positioned.fill(
                child: SafeArea(
                  child: Opacity(
                    opacity: ui,
                    child: Column(
                      children: [
                        const SizedBox(height: 56),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(24, 0, 24, 30),
                          child: Column(
                            children: [
                              _AuthButton(
                                onTap: _busy ? () {} : _google,
                                label: context.t('w_google'),
                                busy: _busy,
                                leading: const Text('G',
                                    style: TextStyle(
                                        color: Color(0xFF4285F4),
                                        fontSize: 21,
                                        fontWeight: FontWeight.w900)),
                              ),
                              const SizedBox(height: 10),
                              TextButton(
                                onPressed: _busy ? null : _toQuotes,
                                child: Text(context.t('skip'),
                                    style: TextStyle(
                                        color: al(Colors.white, 0.55),
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _AuthButton extends StatelessWidget {
  final VoidCallback onTap;
  final String label;
  final Widget leading;
  final bool busy;
  const _AuthButton(
      {required this.onTap, required this.label, required this.leading, this.busy = false});

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      scale: 0.97,
      child: MovingGray(
        radius: 28,
        height: 56,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (busy)
              const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white))
            else
              leading,
            const SizedBox(width: 12),
            Text(label,
                style: const TextStyle(
                    color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

/// Night sky: three star layers (parallax), mountain, eclipse with a glowing corona.
class _SkyPainter extends CustomPainter {
  final double t; // 0..1 camera tilt
  final double eclipse; // 0..1
  final double drift; // 0..1 endless loop: stars keep moving and twinkling
  _SkyPainter(this.t, this.eclipse, this.drift);

  static final List<List<double>> _stars = () {
    final r = math.Random(21);
    return [
      for (var i = 0; i < 420; i++)
        [r.nextDouble(), r.nextDouble() * 2 - 1, 0.3 + r.nextDouble() * 1.0, 30 + r.nextDouble() * 200, (r.nextInt(3)).toDouble()]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final p = Paint();
    for (final s in _stars) {
      final depth = 0.45 + 0.25 * s[4]; // 3 layers
      var y = s[1] * h + t * h * depth * 0.9 + drift * 2 * h * (1 + s[4]);
      y = ((y + h) % (2 * h)) - h; // endless slow drift, wraps seamlessly
      if (y < -4 || y > h + 4) continue;
      final tw = 0.6 + 0.4 * math.sin(drift * math.pi * 2 * (24 + 8 * s[4]) + s[0] * 40);
      p.color = Color.fromARGB((s[3] * tw).toInt().clamp(0, 255).toInt(), 215, 208, 255);
      canvas.drawCircle(Offset(s[0] * w, y), s[2], p);
    }
    // eclipse
    if (eclipse > 0) {
      final c = Offset(w / 2, h * 0.34);
      final rad = w * 0.15 * (0.88 + 0.12 * eclipse);
      final corona = Paint()
        ..shader = RadialGradient(
          colors: [
            al(Colors.white, 0.95 * eclipse),
            al(const Color(0xFFE6E6EA), 0.45 * eclipse),
            al(const Color(0xFFFFFFFF), 0.0),
          ],
          stops: const [0.5, 0.72, 1.0],
        ).createShader(Rect.fromCircle(center: c, radius: rad * 2.1));
      canvas.drawCircle(c, rad * 2.1, corona);
      canvas.drawCircle(
        c,
        rad * 1.04,
        Paint()
          ..color = al(Colors.white, 0.9 * eclipse)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(c, rad, Paint()..color = Colors.black);
    }
    // mountain silhouette sliding down as the camera tilts up
    final dy = t * h * 0.6;
    if (dy < h * 0.45) {
      final top = h * 0.70 + dy;
      final path = Path()
        ..moveTo(0, h)
        ..lineTo(0, top + h * 0.02)
        ..lineTo(w * 0.10, top - h * 0.015)
        ..lineTo(w * 0.22, top + h * 0.012)
        ..lineTo(w * 0.36, top - h * 0.045)
        ..lineTo(w * 0.47, top - h * 0.02)
        ..lineTo(w * 0.60, top - h * 0.06)
        ..lineTo(w * 0.74, top - h * 0.015)
        ..lineTo(w * 0.86, top + h * 0.01)
        ..lineTo(w, top - h * 0.02)
        ..lineTo(w, h + dy)
        ..lineTo(0, h + dy)
        ..close();
      canvas.drawPath(path, Paint()..color = const Color(0xFF000000));
    }
  }

  @override
  bool shouldRepaint(covariant _SkyPainter o) => o.t != t || o.eclipse != eclipse || o.drift != drift;
}

class _Quotes extends StatefulWidget {
  final VoidCallback onDone;
  const _Quotes({super.key, required this.onDone});

  @override
  State<_Quotes> createState() => _QuotesState();
}

class _QuotesState extends State<_Quotes> {
  final PageController _pc = PageController();
  int _i = 0;

  // name, quote key, role key, initials
  static const _q = [
    ['Sigmund Freud', 'w_q1', 'w_r1', 'SF', 'assets/people/freud.jpg'],
    ['Carl G. Jung', 'w_q2', 'w_r2', 'CJ', 'assets/people/jung.jpg'],
    ['Rosella', 'w_q3', 'w_r3', 'R', ''],
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Stack(children: [
        const Positioned.fill(child: AuroraBackground()),
        const Positioned.fill(child: StarField()),
        SafeArea(
        child: Column(
          children: [
            const Spacer(flex: 2),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(context.t('w_join'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      height: 1.3)),
            ),
            const SizedBox(height: 26),
            SizedBox(
              height: 330,
              child: PageView.builder(
                controller: _pc,
                itemCount: _q.length,
                onPageChanged: (v) => setState(() => _i = v),
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _card(context, _q[i]),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < _q.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: _i == i ? 26 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: _i == i ? Colors.white : al(Colors.white, 0.22),
                    ),
                  ),
              ],
            ),
            const Spacer(flex: 3),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
              child: GradientButton(
                label: context.t(_i >= _q.length - 1 ? 'start' : 'next'),
                icon: Icons.arrow_forward_rounded,
                expand: true,
                onTap: () {
                  if (_i >= _q.length - 1) {
                    widget.onDone();
                  } else {
                    _pc.nextPage(
                        duration: const Duration(milliseconds: 420),
                        curve: Curves.easeOutCubic);
                  }
                },
              ),
            ),
          ],
        ),
      ),
      ]),
    );
  }

  Widget _card(BuildContext context, List<String> q) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xA6000000),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: al(Colors.white, 0.13)),
      ),
      child: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.format_quote_rounded, color: al(Colors.white, 0.35), size: 38),
                  const SizedBox(height: 8),
                  Text(context.t(q[1]),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          height: 1.5)),
                ],
              ),
            ),
          ),
          Container(height: 1, color: al(Colors.white, 0.08)),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(q[0],
                          style: const TextStyle(
                              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 5),
                      Text(context.t(q[2]),
                          style: TextStyle(
                              color: al(Colors.white, 0.6), fontSize: 13.5, height: 1.4)),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                q[4].isEmpty
                    ? Container(
                        width: 72,
                        height: 72,
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: [Color(0xFF3B82F6), Color(0xFF9CC4FF)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight),
                        ),
                        child: Text(q[3],
                            style: const TextStyle(
                                color: Colors.black, fontSize: 21, fontWeight: FontWeight.w900)),
                      )
                    : Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF0A0A0A),
                          border: Border.all(color: al(Colors.white, 0.28), width: 2),
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            q[4],
                            width: 68,
                            height: 68,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Center(
                              child: Text(q[3],
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 21,
                                      fontWeight: FontWeight.w900)),
                            ),
                          ),
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Full-screen language page: moving violet light, drifting stars, the app mark in the middle
/// of the top, a flying title and rows that rise in one after another.
class _LanguagePage extends StatelessWidget {
  const _LanguagePage();

  static const _opts = kLanguages;

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    return Theme(
      data: buildTheme('onyx', true),
      child: Material(
        color: Colors.black,
        child: Stack(
          children: [
            const Positioned.fill(child: AuroraBackground()),
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  const SizedBox(height: 14),
                  const AppMark(size: 96),
                  const SizedBox(height: 6),
                  Text('LANGUAGE',
                      style: TextStyle(
                          color: al(Colors.white, 0.45),
                          fontSize: 11.5,
                          letterSpacing: 5,
                          fontWeight: FontWeight.w700,
                          decoration: TextDecoration.none)),
                  const SizedBox(height: 8),
                  Directionality(
                    textDirection: TextDirection.rtl,
                    child: const FlyText('اختر اللغة',
                        delayMs: 250,
                        style: TextStyle(
                            fontFamily: 'serif',
                            fontSize: 36,
                            fontWeight: FontWeight.w700,
                            height: 1.25,
                            color: Colors.white)),
                  ),
                  const SizedBox(height: 4),
                  _Rise(
                    delay: 900,
                    child: Text('Choose your language  ·  زمان هەڵبژێرە',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: al(Colors.white, 0.55),
                            fontSize: 13.5,
                            decoration: TextDecoration.none)),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: Selector<AppState, String>(
                      selector: (_, st) => st.lang,
                      // every row is built once (not lazily), so scrolling never replays the
                      // entrance animation and rows never vanish and reappear
                      builder: (context, lang, _) => SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(20, 4, 20, 26),
                        child: Column(children: [
                          for (var i = 0; i < _opts.length; i++)
                            Builder(builder: (context) {
                          final o = _opts[i];
                          final sel = lang == o[0];
                          return _Rise(
                            delay: 700 + math.min(i, 7) * 90,
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Pressable(
                                onTap: () async {
                                  HapticFeedback.selectionClick();
                                  app.setLang(o[0]);
                                  await Future<void>.delayed(const Duration(milliseconds: 320));
                                  if (context.mounted) Navigator.of(context).pop();
                                },
                                scale: 0.98,
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 260),
                                  curve: Curves.easeOutCubic,
                                  height: 68,
                                  padding: const EdgeInsets.symmetric(horizontal: 16),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(24),
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: sel
                                          ? [
                                              al(const Color(0xFFA78BFA), 0.34),
                                              al(const Color(0xFFF472B6), 0.18),
                                            ]
                                          : [
                                              al(Colors.white, 0.07),
                                              al(Colors.white, 0.02),
                                            ],
                                    ),
                                    border: Border.all(
                                        color: sel
                                            ? al(const Color(0xFFD8C8FF), 0.8)
                                            : al(Colors.white, 0.10),
                                        width: sel ? 1.4 : 1),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: al(Colors.white, sel ? 0.18 : 0.07),
                                        ),
                                        child: Text(o[3],
                                            style: TextStyle(
                                                color: al(Colors.white, 0.85),
                                                fontSize: 12,
                                                fontWeight: FontWeight.w800,
                                                letterSpacing: 0.5,
                                                decoration: TextDecoration.none)),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(o[1],
                                                style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.w800,
                                                    height: 1.15,
                                                    decoration: TextDecoration.none)),
                                            Text(o[2],
                                                style: TextStyle(
                                                    color: al(Colors.white, 0.5),
                                                    fontSize: 12,
                                                    decoration: TextDecoration.none)),
                                          ],
                                        ),
                                      ),
                                      AnimatedScale(
                                        scale: sel ? 1 : 0,
                                        duration: const Duration(milliseconds: 280),
                                        curve: Curves.easeOutBack,
                                        child: Container(
                                          width: 26,
                                          height: 26,
                                          decoration: const BoxDecoration(
                                              shape: BoxShape.circle, color: Colors.white),
                                          child: const Icon(Icons.check_rounded,
                                              color: Colors.black, size: 17),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                        ]),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Rises and fades in once, after [delay] ms.
class _Rise extends StatelessWidget {
  final Widget child;
  final int delay;
  const _Rise({required this.child, this.delay = 0});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 900 + delay),
      curve: Curves.linear,
      builder: (_, v, ch) {
        final t = Curves.easeOutCubic.transform(((v * (900 + delay) - delay) / 900).clamp(0.0, 1.0));
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, 26 * (1 - t)), child: ch),
        );
      },
      child: child,
    );
  }
}
