import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'dart:ui' show ImageFilter;

import '../core/theme.dart';

/// Black background with slow violet / magenta light swooshes drifting across it
/// (the look of the welcome screens). One controller, repaints only itself.
class AuroraBackground extends StatefulWidget {
  /// 1 = normal speed
  final double speed;
  final double intensity;
  const AuroraBackground({super.key, this.speed = 1, this.intensity = 1});

  @override
  State<AuroraBackground> createState() => _AuroraBackgroundState();
}

class _AuroraBackgroundState extends State<AuroraBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 36))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(
          size: Size.infinite,
          painter: _AuroraPainter(_c.value, widget.speed.round().clamp(1, 3).toInt(), widget.intensity),
        ),
      ),
    );
  }
}

class _AuroraPainter extends CustomPainter {
  final double t;
  final int k; // integer speed multiplier keeps the loop seamless
  final double inten;
  _AuroraPainter(this.t, this.k, this.inten);

  // fx, fy, radius (of width), rotation speed, colour, phase, harmonic
  static const _blobs = [
    [0.25, 0.30, 0.95, 1.0, 0xFF7C3AED, 0.0, 1.0],
    [0.80, 0.62, 1.05, -1.0, 0xFFC026D3, 2.1, 1.0],
    [0.40, 0.92, 0.90, 1.0, 0xFF4F46E5, 4.2, 2.0],
    [0.85, 0.10, 0.70, -1.0, 0xFFDB2777, 1.1, 2.0],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.black);
    final a = t * math.pi * 2 * k;
    for (final b in _blobs) {
      final h = b[6];
      final cx = size.width * (b[0] + 0.22 * math.sin(a * h + b[5]));
      final cy = size.height * (b[1] + 0.14 * math.cos(a * h + b[5] * 1.3));
      final r = size.width * b[2];
      final col = Color(b[4].toInt());
      canvas.save();
      canvas.translate(cx, cy);
      canvas.rotate(b[3] * a * 0.5 + b[5]);
      canvas.scale(1.0, 0.42); // flatten the glow into a sweeping ribbon
      canvas.drawCircle(
        Offset.zero,
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [
              al(col, 0.55 * inten),
              al(col, 0.20 * inten),
              al(col, 0.0),
            ],
            stops: const [0.0, 0.45, 1.0],
          ).createShader(Rect.fromCircle(center: Offset.zero, radius: r)),
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_AuroraPainter o) => o.t != t || o.inten != inten;
}

/// Stars that never stop: slow parallax drift plus twinkling.
class StarField extends StatefulWidget {
  final int count;
  const StarField({super.key, this.count = 150});

  @override
  State<StarField> createState() => _StarFieldState();
}

class _StarFieldState extends State<StarField> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 150))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) =>
              CustomPaint(size: Size.infinite, painter: _StarPainter(_c.value, widget.count)),
        ),
      ),
    );
  }
}

class _StarPainter extends CustomPainter {
  final double t;
  final int n;
  _StarPainter(this.t, this.n);

  static final List<List<double>> _s = () {
    final r = math.Random(33);
    return [
      for (var i = 0; i < 260; i++)
        [r.nextDouble(), r.nextDouble(), 0.4 + r.nextDouble() * 1.1, 40 + r.nextDouble() * 190, (i % 3).toDouble(), r.nextDouble() * 6.28]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    final w = size.width, h = size.height;
    for (var i = 0; i < n && i < _s.length; i++) {
      final s = _s[i];
      final layer = s[4].toInt() + 1; // 1..3, integer => seamless loop
      final y = ((s[1] + t * layer) % 1.0) * h;
      final tw = 0.55 + 0.45 * math.sin(t * math.pi * 2 * (20 + 8 * layer) + s[5]);
      p.color = Color.fromARGB((s[3] * tw).toInt().clamp(0, 255).toInt(), 215, 205, 255);
      canvas.drawCircle(Offset(s[0] * w, y), s[2], p);
    }
  }

  @override
  bool shouldRepaint(_StarPainter o) => o.t != t;
}

bool _isArabicScript(String s) => RegExp(r'[\u0600-\u06FF\u0750-\u077F]').hasMatch(s);

/// Title whose letters fly in one by one (soft blur, rise, fade) - like the kinetic-text
/// reference. Arabic-script text flies in word by word so the letters keep their joins.
class FlyText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final bool play;
  final int delayMs;
  final TextAlign align;
  const FlyText(this.text,
      {super.key, required this.style, this.play = true, this.delayMs = 0, this.align = TextAlign.center});

  @override
  State<FlyText> createState() => _FlyTextState();
}

class _FlyTextState extends State<FlyText> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late List<String> _words;
  late bool _byWord;
  int _units = 1;

  void _prep() {
    _byWord = _isArabicScript(widget.text);
    _words = widget.text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    _units = _byWord ? _words.length : _words.fold<int>(0, (a, w) => a + w.characters.length);
    final ms = 900 + _units * (_byWord ? 170 : 55);
    _c.duration = Duration(milliseconds: ms);
  }

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this);
    _prep();
    if (widget.play) _start();
  }

  void _start() {
    Future.delayed(Duration(milliseconds: widget.delayMs), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void didUpdateWidget(FlyText o) {
    super.didUpdateWidget(o);
    if (o.text != widget.text) {
      _prep();
      if (widget.play) _c.forward(from: 0);
    }
    if (widget.play && !o.play) _start();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Widget _unit(Widget child, int idx, double v) {
    final total = _units;
    final dur = 900.0 / _c.duration!.inMilliseconds;
    final step = total <= 1 ? 0.0 : (1 - dur) / (total - 1);
    final p = Curves.easeOutCubic.transform(((v - idx * step) / dur).clamp(0.0, 1.0));
    if (p >= 1) return child;
    if (p <= 0) return Opacity(opacity: 0, child: child);
    return Opacity(
      opacity: p,
      child: Transform.translate(
        offset: Offset(0, 30 * (1 - p)),
        child: Transform.scale(
          scale: 0.7 + 0.3 * p,
          child: ImageFiltered(
            imageFilter: ImageFilter.blur(
                sigmaX: 9 * (1 - p) + 0.01, sigmaY: 9 * (1 - p) + 0.01, tileMode: TileMode.decal),
            child: child,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.style.copyWith(decoration: TextDecoration.none);
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (r) => const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFFFFFFFF), Color(0xFFEBDDFF), Color(0xFFC9B2FF)],
      ).createShader(r),
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final v = _c.value;
          var idx = 0;
          final spaceW = (st.fontSize ?? 30) * 0.3;
          final wrap = <Widget>[];
          for (final w in _words) {
            if (_byWord) {
              wrap.add(_unit(Text(w, style: st), idx++, v));
            } else {
              final letters = <Widget>[];
              for (final ch in w.characters) {
                letters.add(_unit(Text(ch, style: st), idx++, v));
              }
              wrap.add(Row(mainAxisSize: MainAxisSize.min, children: letters));
            }
          }
          return Directionality(
            textDirection: Directionality.of(context),
            child: Wrap(
              alignment: WrapAlignment.center,
              runAlignment: WrapAlignment.center,
              spacing: spaceW,
              runSpacing: 4,
              children: wrap,
            ),
          );
        },
      ),
    );
  }
}

/// The app mark (crescent + rose) drawing itself, then floating, its colours turning slowly.
class AppMark extends StatefulWidget {
  final double size;
  const AppMark({super.key, this.size = 110});

  @override
  State<AppMark> createState() => _AppMarkState();
}

class _AppMarkState extends State<AppMark> with TickerProviderStateMixin {
  late final AnimationController _in =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1700))..forward();
  late final AnimationController _loop =
      AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();

  @override
  void dispose() {
    _in.dispose();
    _loop.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: Listenable.merge([_in, _loop]),
        builder: (_, __) {
          final draw = Curves.easeInOutCubic.transform((_in.value / 0.75).clamp(0.0, 1.0));
          final glow = Curves.easeOut.transform(((_in.value - 0.2) / 0.6).clamp(0.0, 1.0));
          final bob = math.sin(_loop.value * math.pi * 2) * 5;
          return Transform.translate(
            offset: Offset(0, bob),
            child: SizedBox(
              width: s,
              height: s,
              child: CustomPaint(painter: RoseMoonPainter(draw, glow, spin: _loop.value)),
            ),
          );
        },
      ),
    );
  }
}

/// Line-art crescent moon holding a rose, drawn progressively.
class RoseMoonPainter extends CustomPainter {
  final double progress;
  final double glow;
  /// when set, the lines are filled with a colour gradient turning with this 0..1 value
  final double? spin;
  const RoseMoonPainter(this.progress, this.glow, {this.spin});

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 150;
    canvas.save();
    canvas.scale(s);

    // soft warm halo behind the mark
    final halo = Paint()
      ..shader = RadialGradient(colors: [
        al(spin == null ? const Color(0xFFE9D6B0) : const Color(0xFFA78BFA), 0.30 * glow),
        al(spin == null ? const Color(0xFFE9D6B0) : const Color(0xFFA78BFA), 0),
      ]).createShader(Rect.fromCircle(center: const Offset(75, 75), radius: 95));
    canvas.drawRect(const Rect.fromLTWH(-40, -40, 230, 230), halo);

    // crescent = big circle minus a shifted circle
    final outer = Path()..addOval(Rect.fromCircle(center: const Offset(70, 76), radius: 56));
    final inner = Path()..addOval(Rect.fromCircle(center: const Offset(92, 66), radius: 50));
    final crescent = Path.combine(PathOperation.difference, outer, inner);

    // rose
    final rose = Path();
    final c = const Offset(82, 56);
    // spiral bud
    var first = true;
    for (var a = 0.0; a <= 6.2 * 1.7; a += 0.12) {
      final rr = 1.5 + a * 1.15;
      final pt = Offset(c.dx + rr * math.cos(a), c.dy + rr * math.sin(a) * 0.9);
      if (first) {
        rose.moveTo(pt.dx, pt.dy);
        first = false;
      } else {
        rose.lineTo(pt.dx, pt.dy);
      }
    }
    // outer petals (cup shape)
    rose.moveTo(c.dx - 19, c.dy - 6);
    rose.cubicTo(c.dx - 24, c.dy + 16, c.dx - 8, c.dy + 26, c.dx, c.dy + 25);
    rose.cubicTo(c.dx + 8, c.dy + 26, c.dx + 24, c.dy + 16, c.dx + 19, c.dy - 6);
    rose.moveTo(c.dx - 13, c.dy - 17);
    rose.cubicTo(c.dx - 6, c.dy - 24, c.dx + 6, c.dy - 24, c.dx + 13, c.dy - 17);
    // stem and leaves
    rose.moveTo(c.dx, c.dy + 25);
    rose.cubicTo(c.dx - 2, c.dy + 45, c.dx + 2, c.dy + 62, c.dx, c.dy + 78);
    rose.moveTo(c.dx - 1, c.dy + 58);
    rose.cubicTo(c.dx - 18, c.dy + 54, c.dx - 28, c.dy + 62, c.dx - 30, c.dy + 72);
    rose.cubicTo(c.dx - 16, c.dy + 76, c.dx - 4, c.dy + 70, c.dx - 1, c.dy + 58);
    rose.moveTo(c.dx + 1, c.dy + 66);
    rose.cubicTo(c.dx + 14, c.dy + 60, c.dx + 24, c.dy + 64, c.dx + 28, c.dy + 72);
    rose.cubicTo(c.dx + 14, c.dy + 76, c.dx + 4, c.dy + 74, c.dx + 1, c.dy + 66);

    Path trim(Path p, double f) {
      final out = Path();
      for (final m in p.computeMetrics()) {
        out.addPath(m.extractPath(0, m.length * f), Offset.zero);
      }
      return out;
    }

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = 2.2
      ..color = const Color(0xFFE6E6EA);
    final soft = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 5
      ..color = al(const Color(0xFFF3E3C2), 0.35 * glow)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
    if (spin != null) {
      final sh = SweepGradient(
        transform: GradientRotation(spin! * math.pi * 2),
        colors: const [
          Color(0xFFF5EEFF),
          Color(0xFFA78BFA),
          Color(0xFFF472B6),
          Color(0xFF60A5FA),
          Color(0xFFF5EEFF),
        ],
      ).createShader(const Rect.fromLTWH(0, 0, 150, 150));
      line.shader = sh;
      soft
        ..shader = sh
        ..color = al(Colors.white, 0.55 * glow);
    }
    final cp = trim(crescent, progress);
    final rp = trim(rose, progress);
    canvas.drawPath(cp, soft);
    canvas.drawPath(rp, soft);
    canvas.drawPath(cp, line);
    canvas.drawPath(rp, line);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant RoseMoonPainter old) =>
      old.progress != progress || old.glow != glow || old.spin != spin;
}

