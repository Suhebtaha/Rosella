import 'dart:async';

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  /// small grey line under the label
  final String? subtitle;
  /// colour of the icon square
  final Color? color;
  /// small number in the corner of a tile
  final String? badge;
  /// marks the current option of a segmented switch / an inline list
  final bool selected;
  /// when set, the row opens an inline list (slides open, the menu stays open)
  final List<MenuAction>? children;
  /// shows a small arrow (the row opens another page)
  final bool chevron;
  const MenuAction(this.icon, this.label, this.onTap,
      {this.subtitle,
      this.color,
      this.badge,
      this.selected = false,
      this.children,
      this.chevron = false});
}

/// Carries a finger that started on the ⋮ button (press-hold-slide) into the open menu.
class PopupDrag {
  void Function(Offset)? _move;
  void Function(Offset)? _up;
  void move(Offset p) => _move?.call(p);
  void up(Offset p) => _up?.call(p);
}

/// The ⋮ button: a tap opens the menu; press-and-hold opens it too and the same finger can slide
/// down over the items and release on one to choose it (like the iPhone).
class HoldMenuButton extends StatefulWidget {
  final IconData icon;
  final Future<void> Function(PopupDrag? drag) open;
  const HoldMenuButton({super.key, required this.icon, required this.open});

  @override
  State<HoldMenuButton> createState() => _HoldMenuButtonState();
}

class _HoldMenuButtonState extends State<HoldMenuButton> {
  Timer? _t;
  Offset? _down;
  bool _opened = false;
  PopupDrag? _drag;
  DateTime _suppress = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (e) {
        _down = e.position;
        _opened = false;
        _t?.cancel();
        _t = Timer(const Duration(milliseconds: 320), () {
          if (!mounted) return;
          _opened = true;
          Haptics.selection();
          _drag = PopupDrag();
          widget.open(_drag);
        });
      },
      onPointerMove: (e) {
        if (_opened) {
          _drag?.move(e.position);
        } else if (_down != null && (e.position - _down!).distance > 14) {
          _t?.cancel();
        }
      },
      onPointerUp: (e) {
        _t?.cancel();
        if (_opened) {
          _drag?.up(e.position);
          _suppress = DateTime.now().add(const Duration(milliseconds: 500));
          _opened = false;
          _drag = null;
        }
      },
      onPointerCancel: (_) {
        _t?.cancel();
        _opened = false;
        _drag = null;
      },
      child: RoundIconButton(
        icon: widget.icon,
        onTap: () {
          if (_opened || DateTime.now().isBefore(_suppress)) return;
          widget.open(null);
        },
      ),
    );
  }
}

/// A solid card that opens from the top corner (below the ⋮ button): a header line, two big tiles,
/// an optional segmented switch and a list of rows. The whole card supports "press and slide":
/// keep the finger down, slide over the items (they light up) and release on one to choose it.
Future<void> showPopupCard(
  BuildContext context, {
  required List<MenuAction> tiles,
  required List<MenuAction> rows,
  String? footer,
  String? footerEnd,
  String? viewLabel,
  List<MenuAction>? views,
  PopupDrag? drag,
}) {
  final rtl = Directionality.of(context) == TextDirection.rtl;
  final top = MediaQuery.paddingOf(context).top + 66;
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.black.withOpacity(0.35),
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (ctx, _, __) {
      final c = ctx.colors;
      final card = c.isDark ? const Color(0xFF1C1C20) : c.surface;
      final inner = c.isDark ? const Color(0xFF232328) : c.surfaceHi;
      final line = al(c.text, c.isDark ? 0.08 : 0.10);
      void run(VoidCallback f) {
        Haptics.selection();
        Navigator.of(ctx).pop();
        f();
      }

      // ---- press-and-slide: every item registers a key + an action ----
      final keys = <String, GlobalKey>{};
      final acts = <String, VoidCallback>{};
      final hover = ValueNotifier<String?>(null);
      int? openRow; // row whose inline list is open

      String? hit(Offset p) {
        for (final e in keys.entries) {
          if (e.key.startsWith('k') && !e.key.startsWith('k${openRow}_')) continue;
          final box = e.value.currentContext?.findRenderObject();
          if (box is! RenderBox || !box.attached || !box.hasSize) continue;
          if ((box.localToGlobal(Offset.zero) & box.size).contains(p)) return e.key;
        }
        return null;
      }

      void moveTo(Offset p) {
        final h = hit(p);
        if (h != hover.value) {
          hover.value = h;
          if (h != null) Haptics.selection();
        }
      }

      if (drag != null) {
        drag._move = moveTo;
        drag._up = (p) {
          final h = hover.value ?? hit(p);
          hover.value = null;
          if (h != null) acts[h]?.call(); // released on nothing: the menu just stays open
        };
      }

      Widget item(String id, VoidCallback act, Widget child, {double? radius}) {
        keys.putIfAbsent(id, () => GlobalKey());
        acts[id] = act;
        return KeyedSubtree(
          key: keys[id],
          child: radius == null
              ? child
              : Stack(
                  children: [
                    child,
                    Positioned.fill(
                      child: IgnorePointer(
                        child: ValueListenableBuilder<String?>(
                          valueListenable: hover,
                          builder: (_, h, __) => AnimatedContainer(
                            duration: const Duration(milliseconds: 120),
                            decoration: BoxDecoration(
                              color: h == id ? al(c.text, 0.12) : const Color(0x00000000),
                              borderRadius: BorderRadius.circular(radius),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
        );
      }

      Widget square(MenuAction a, double size, double radius) {
        final base = a.color ?? c.a;
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color.lerp(base, Colors.white, 0.18)!, Color.lerp(base, Colors.black, 0.22)!],
            ),
            boxShadow: [BoxShadow(color: al(base, 0.30), blurRadius: 10, offset: const Offset(0, 3))],
          ),
          child: Icon(a.icon, color: Colors.white, size: size * 0.5),
        );
      }

      Widget tile(MenuAction a, int i) => Expanded(
            child: item(
              't$i',
              () => run(a.onTap),
              Container(
                height: 108,
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
                decoration: BoxDecoration(
                  color: inner,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        square(a, 42, 14),
                        const Spacer(),
                        if (a.badge != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                            decoration: BoxDecoration(
                                color: al(c.text, 0.10), borderRadius: BorderRadius.circular(12)),
                            child: Text(a.badge!,
                                style: TextStyle(
                                    color: c.text, fontSize: 12.5, fontWeight: FontWeight.w800)),
                          ),
                      ],
                    ),
                    const Spacer(),
                    Text(a.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontSize: 15.5, fontWeight: FontWeight.w800)),
                    if (a.subtitle != null)
                      Text(a.subtitle!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: c.dim, fontSize: 12)),
                  ],
                ),
              ),
              radius: 24,
            ),
          );

      int? viewSel; // current option of the segmented switch (kept inside the open menu)
      final childSel = <int, int>{}; // chosen child per row

      return StatefulBuilder(builder: (ctx, setS) {
        if (viewSel == null) {
          final k = views?.indexWhere((v) => v.selected) ?? 0;
          viewSel = k < 0 ? 0 : k;
        }

        Widget rowTile(MenuAction a, int i, {String? sub}) {
          final hasKids = a.children != null;
          final isOpen = openRow == i;
          return item(
            'r$i',
            () {
              if (hasKids) {
                Haptics.selection();
                setS(() => openRow = isOpen ? null : i);
              } else {
                run(a.onTap);
              }
            },
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(
                children: [
                  square(a, 38, 12),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontSize: 15, fontWeight: FontWeight.w800)),
                        if ((sub ?? a.subtitle) != null)
                          Text(sub ?? a.subtitle!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: c.dim, fontSize: 12)),
                      ],
                    ),
                  ),
                  if (hasKids)
                    AnimatedRotation(
                      turns: isOpen ? 0.25 : (rtl ? 0.5 : 0),
                      duration: const Duration(milliseconds: 240),
                      curve: Curves.easeOutCubic,
                      child: Icon(Icons.chevron_right_rounded, color: c.dim, size: 21),
                    )
                  else if (a.chevron)
                    Icon(rtl ? Icons.chevron_left_rounded : Icons.chevron_right_rounded,
                        color: c.dim, size: 21),
                ],
              ),
            ),
            radius: 20,
          );
        }

        Widget kids(MenuAction a, int i) {
          final cur = childSel[i] ?? a.children!.indexWhere((k) => k.selected);
          return ClipRect(
            child: AnimatedAlign(
              alignment: Alignment.topCenter,
              heightFactor: openRow == i ? 1 : 0,
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              child: AnimatedOpacity(
                opacity: openRow == i ? 1 : 0,
                duration: const Duration(milliseconds: 200),
                child: Column(
                  children: [
                    Divider(height: 1, indent: 12, endIndent: 12, color: line),
                    for (var k = 0; k < a.children!.length; k++)
                      item(
                        'k${i}_$k',
                        () {
                          Haptics.selection();
                          a.children![k].onTap();
                          setS(() => childSel[i] = k);
                        },
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                          child: Row(
                            children: [
                              Icon(a.children![k].icon,
                                  size: 18, color: cur == k ? c.text : c.dim),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(a.children![k].label,
                                    style: TextStyle(
                                        color: cur == k ? c.text : c.dim,
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w700)),
                              ),
                              if (cur == k) Icon(Icons.check_rounded, color: c.text, size: 19),
                            ],
                          ),
                        ),
                        radius: 16,
                      ),
                  ],
                ),
              ),
            ),
          );
        }

        Widget segmented(List<MenuAction> v) {
          final fg = c.isDark ? const Color(0xFF16161A) : Colors.white;
          return Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: c.isDark ? const Color(0xFF111114) : al(c.text, 0.06),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: line),
            ),
            child: LayoutBuilder(builder: (ctx, cons) {
              final w = cons.maxWidth / v.length;
              return SizedBox(
                height: 38,
                child: Stack(
                  children: [
                    AnimatedPositionedDirectional(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOutCubic,
                      start: w * viewSel!,
                      top: 0,
                      bottom: 0,
                      width: w,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(17),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: c.isDark
                                ? const [Color(0xFFF2F2F5), Color(0xFFC9C9CF)]
                                : [c.a, c.b],
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        for (var i = 0; i < v.length; i++)
                          Expanded(
                            child: item(
                              'v$i',
                              () {
                                if (viewSel == i) return;
                                Haptics.selection();
                                setS(() => viewSel = i);
                                v[i].onTap(); // the menu stays open
                              },
                              SizedBox(
                                height: 38,
                                child: Center(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(v[i].icon, size: 17, color: viewSel == i ? fg : c.dim),
                                      const SizedBox(width: 6),
                                      AnimatedDefaultTextStyle(
                                        duration: const Duration(milliseconds: 200),
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w800,
                                            color: viewSel == i ? fg : c.dim),
                                        child: Text(v[i].label),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              );
            }),
          );
        }

        return Align(
          alignment: AlignmentDirectional.topEnd,
          child: Padding(
            padding: EdgeInsetsDirectional.only(top: top, end: 14, start: 14),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 310),
              child: Listener(
                onPointerDown: (e) => moveTo(e.position),
                onPointerMove: (e) => moveTo(e.position),
                onPointerUp: (e) {
                  final h = hover.value ?? hit(e.position);
                  hover.value = null;
                  if (h != null) acts[h]?.call();
                },
                onPointerCancel: (_) => hover.value = null,
                child: Material(
                  color: card,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                    side: BorderSide(color: line),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (footer != null || footerEnd != null)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(footer ?? '',
                                      style: TextStyle(
                                          color: c.dim,
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w700)),
                                ),
                                if (footerEnd != null)
                                  Text(footerEnd,
                                      style: TextStyle(
                                          color: c.dim,
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w700)),
                              ],
                            ),
                          ),
                        Row(
                          children: [
                            for (var i = 0; i < tiles.length; i++) ...[
                              if (i > 0) const SizedBox(width: 8),
                              tile(tiles[i], i),
                            ],
                          ],
                        ),
                        if (views != null) ...[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(8, 12, 8, 6),
                            child: Text((viewLabel ?? '').toUpperCase(),
                                style: TextStyle(
                                    color: c.dim,
                                    fontSize: 11.5,
                                    letterSpacing: 1.2,
                                    fontWeight: FontWeight.w800)),
                          ),
                          segmented(views!),
                        ],
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            color: inner,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: line),
                          ),
                          child: Column(
                            children: [
                              for (var i = 0; i < rows.length; i++) ...[
                                if (i > 0) Divider(height: 1, color: line),
                                rowTile(rows[i], i,
                                    sub: rows[i].children != null && childSel[i] != null
                                        ? rows[i].children![childSel[i]!].label
                                        : null),
                                if (rows[i].children != null) kids(rows[i], i),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      });
    },
    transitionBuilder: (ctx, anim, _, child) {
      // grows out of the ⋮ button and shrinks back into it (no overshoot)
      final curved = CurvedAnimation(
          parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
      final fade = CurvedAnimation(
          parent: anim,
          curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
          reverseCurve: const Interval(0.3, 1.0, curve: Curves.easeIn));
      return FadeTransition(
        opacity: fade,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.2, end: 1).animate(curved),
          alignment: Alignment(rtl ? -0.93 : 0.93, -1),
          child: child,
        ),
      );
    },
  );
}
