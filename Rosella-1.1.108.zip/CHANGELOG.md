## Rosella 1.1.108

- The first-run language page is gone: the app opens in the phone's language, or English when that language is not available.
- Fixed the "Generating · Cancel" button shrinking while it animates.
- When the bottom bar collapses on scroll, the icons are bigger and the lens is a little larger; the bar shrinks less.
- The date shown while scrolling no longer overlaps the scroll-up arrow.
- Added a close (X) button to the language list in Settings.

## Rosella 1.1.107

- New "+" button inside the bottom bar (circle in the theme colour) to add a dream.
- Full calendar page (open it from Insights): monthly view with mood colours, a streak line ("Logged N days in a row") and badges.
- Generating an image or an interpretation can now be cancelled; while an image is generating a black/white (per theme) frame with "Generating…" is shown, and the finished image fades in. The button has a moving "working" animation.
- Search by meaning is much faster: instant word results first, then a shorter AI query.
- "Restoring your dreams…" line on the home screen during the first restore.
- A small date line appears at the bottom while scrolling the dream list.
- Dream titles and text follow their own direction (Arabic dreams read right-to-left even in an English app).
- Close (X) button in the chats window and the chats drawer.

## Rosella 1.1.106

- Fixed the welcome title animation playing twice, and the title is now plain white.
- The flashes in the welcome animation are now black instead of violet.
- The "new chat" button in the general chat only shows when there is a conversation on screen.

## Rosella 1.1.105

- The small "Rosella" word at the top of every page is now plain white (follows light/dark) instead of coloured.
- Every welcome/feature page now has its own animation: theme, voice, interpretation, chat, AI image, sounds, lock, haptics, reminders and colours each move differently.

## Rosella 1.1.104

- Privacy Policy and Terms of Use are now shown in the language you chose in the app (24 languages), with English as the fallback.

## Rosella 1.1.103

- The welcome and feature pages now switch instantly between light and dark when you choose a mode.
- Selecting dreams: the pin and favorite icons are now empty until they apply to the selection, then turn blue / yellow.
- Added an edit (pencil) icon inside the dream text card.
- Privacy Policy and Terms of Use are now always shown in English, whatever the app language.

## Rosella 1.1.102

- The bottom bar now recedes with a much lighter, simpler animation.
- The welcome title ("Discover the secrets of your dreams") no longer plays its animation twice.
- New users now start with the black theme by default.
- The dream-count card (moon and book) now has a pure black background.

## Rosella 1.1.101

- The bottom bar now recedes slightly while you press or drag the glass lens.
- Home-screen widget picker now shows a real preview of each widget size.
- Simpler, fully static first-run language page with a white Rosella wordmark.
- The default Dynamic theme is now saved on first launch, so the app keeps it after the welcome pages.

## Rosella 1.1.100

- New Privacy Policy and Terms of Use pages, in Settings (Arabic and English).
- Friendlier, more natural wording for welcome messages, errors and buttons in Arabic.

## Rosella 1.1.99

- New app icon: a glowing white crescent beside "rosella" on black.
- The same mark (white on black) now appears in the opening screen and the welcome screens.
- New look for delete and confirmation dialogs: a card rising from the bottom with a separate Cancel button.

## Rosella 1.1.98

- Fixed the build error in the update sheet (missing helper functions).
- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.

## Rosella 1.1.97

- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.
- The same wordmark appears in the opening screen and the welcome screens.

## Rosella 1.1.96

- New app icon: the name written in bold lettering with sparkles, over a soft violet background.
- The same wordmark with sparkles now appears in the opening screen and the welcome screens.
- Welcome and feature screens are plain black now, without colour gradients.

## Rosella 1.1.95

- Fixed Settings jumping back to the top while scrolling quickly right after opening the app.
- Dream search by meaning is more reliable: it retries another route and falls back to a word search instead of failing.
- "Check again" moved from the update sheet to a small refresh icon next to "Check for update" in Settings.
- Removed the Gold, Sunset and Space themes.
- New users start with the phone's own haptics only; the motor vibration is off by default.

## Rosella 1.1.94

- Fixed the language page: rows no longer disappear and come back while scrolling.
- The Dynamic theme now uses the same violet, magenta and indigo colours as the welcome screens.
- Dynamic is now the default theme for new users.

## Rosella 1.1.93

- New full-screen language page on first launch: moving violet light, drifting stars, the app mark and rows that rise in one by one.
- "Discover the secrets of your dreams" now flies in letter by letter with a soft blur, in a more elegant font.
- Background stars never stop moving and twinkling.
- Welcome pages (sky, quotes, onboarding and "Welcome") have a black background with slowly moving violet and magenta gradients.
- The app mark in the welcome page has a colour gradient that keeps turning.
- Automatic cleanup of unneeded cache files, and a smaller picture cache.

## Rosella 1.1.92

- New settings icon: a detailed gear with fine teeth, matching the reference design.
- In-app update: you can now pause and resume the download, and it continues from where it stopped.
- You can cancel a download at any time from the update sheet.
- "Check again" button in the update sheet, so you can look for a newer release even when an update is already available.

- Settings tab: new gear icon (12 teeth, three spokes and a hub) drawn in the same single colour as the other tab icons
- Round buttons and filter chips (moods, favourites, private, week/month/year) now use the dark glass look of the "Ask AI" reference: soft top-lit fill and a thin bright rim
- Bottom bar: smaller, flatter and faster glass pill (soft light fill, hairline rim, no shadow), like the reference designs
- Smoothness: the app asks the phone for its highest refresh rate again whenever it opens or returns, and the round buttons no longer blur the background (up to 8 blur layers per screen removed)
- Dream page opens with a plain slide from the left (no zoom/scale)
- Fewer effects: the moving sheen on buttons is removed to save battery and keep scrolling smooth
- Bottom bar: the glass lens now follows slow drags smoothly
- Dream page: the edit (pencil) button moved down next to the title
- Dream cards: Material 3 container transform (the card grows into the dream page and shrinks back to its place)
- Fixed: opening a picture no longer pushes the dream page to the left behind it
- You can now delete a dream's interpretation (trash icon in the interpretation card)
- Bottom bar: the glass lens follows your finger again while dragging, and still glides smoothly to the tab on a long press
- Opening a dream is smoother: the heavy parts (picture, selectable text, audio, similar dreams) now load right after the page finishes sliding in
- Bottom bar: bigger glass lens
- Bottom bar: long-pressing a tab now slides the glass lens to it smoothly instead of jumping
- Performance: pages no longer rebuild while the keyboard opens, lighter image filtering on dream cards
- Static interface: no more entrance animations; counters, progress bars and charts show their final value at once and never replay when scrolling or reopening a page
- Opening a dream: the card-grow animation is removed; the page now slides in from the right
- Cards: smoother entrance of the dream cards (one short ease-out, no bounce) and a cleaner open animation
- Themes: the deep black theme now sits right next to the Dynamic theme at the top
- Performance: faster and lighter bottom-bar glass slider, quicker tab switching (all pages are prepared quietly in the background), lighter blur and cached layers
- Voice to text: other languages (Russian, French, German, Turkish, Japanese, Chinese and more) are recognised in automatic mode instead of being sent to the Kurdish engine
- Voice to text: Arabic now uses the most accurate engine (better with Iraqi dialect), language detection no longer misroutes Arabic to Kurdish, invented phrases and repeated loops are removed, and recording uses noise suppression and auto gain
- Smoother dream-card opening animation
- Update window: full-width download button, icons always grey in every theme
- Bottom bar: icons between the old and new tab no longer flicker when jumping tabs
- Onboarding: animated floating icons with orbiting rings, slow staggered text and drifting light behind every page
- AMOLED is on by default for new users, and its switch is hidden in light mode
- Search: the keyboard no longer closes after typing the first letter
- Bottom bar is now clearly blurred (frosted glass); settings cards are deep black
- Home: removed the large grey top card (mood colour bar and dream counter) that overlapped the header
- Bottom bar: switching tabs no longer animates the bar or its icons
- AMOLED black mode (Settings → Appearance): everything pure black in dark mode
- Moving dark-grey metal surface on the search field, the update button and the sign-in buttons; main buttons get a gliding light sheen
- Bottom bar: dark transparent black, icons no longer react while the glass slider passes
- The + buttons are dark glass like the rest; Mono theme removed
- Welcome screen is pure black with its animations
- New Inter font (free open-source, very close to the iPhone look)
- Round icon buttons and the + button are frosted glass; bottom bar uses filled icon for the selected tab and outlined icons for the others
- Setting: show or hide the tab names under the bottom-bar icons
- Bottom bar: removed the orange rim and the icon pulsing; slower, smoother liquid-glass slider that stretches while it moves and may bulge past the ends
- Bottom bar redesigned: light-orange rim, transparent glass slider that magnifies the active tab, and it shrinks to icons only (and drops lower) while you scroll down
- Removed the Glass theme
- New home header: big gradient card in the colour of your overall mood, with your latest dream, a large dream counter and a mood scale
- New languages: Romanian, Greek, Armenian, Azerbaijani, Chinese (Hindi removed)
- Times now use the 12-hour clock (AM/PM)
- Nightmare SOS: added the birds sound
- Appearance: choose Dark, Light, Auto (pick the hours dark mode switches on and off) or System (follows your device)
- Fixed the build failure caused by a crash inside the Android lint check
- Late-recording reminder: an optional gentle notification if you haven't logged a dream today (Settings)
- Nightmare SOS: a calm page in Sounds with a slow breathing circle, soothing sounds and a quick way to sleep or write the dream
- The sleep timer now fades the sound out gradually at the end instead of cutting it
- A round arrow button jumps back to the top of your dreams list, and to the latest message in chats
- Updates now download inside Rosella (no system download app) and the file is checked to be complete before installing
- Tap the progress button again to cancel a download
- The update sheet now has a proper landscape layout
- AI chat: a rewrite button next to the last answer writes it again in a different way
- Fixed the flicker in the filter rows when switching week / month / year
- Lighter, smoother page transitions; the Insights page is prepared in the background
- A softer, more refined look: glassy card edges, glossy buttons, gentle vignette
- New suggestion prompts in the AI chat, with a calm moving glow
- Haptic feedback when an AI answer finishes and when a voice recording stops
- New: your year in dreams, an animated yearly summary you can share
- New: search your dreams by meaning, not only by exact words
- New: similar dreams are suggested under every dream
- Fixed uneven white edges around dream cards that have an image
- Welcome: a small language card appears first, then the night-sky intro
- New first-run experience: night sky, eclipse and Google sign-in
- Language picker is now a grid of tiles
- A warp-speed "Welcome to Rosella" entrance after setup
- New update sheet with release notes, file size and download progress
- Pin dreams to the top of your list
- Update downloads keep running in the background
- Kurdish typed with Arabic letters is now understood by the AI
- Smoother and clearer app opening animation
