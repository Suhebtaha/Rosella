## Rosella 1.1.108

- The first-run language page is gone: the app opens in the phone's language, or English when that language is not available.
- Fixed the "Generating · Cancel" button shrinking while it animates.
- When the bottom bar collapses on scroll, the icons are bigger and the lens is a little larger; the bar shrinks less.
- The date shown while scrolling no longer overlaps the scroll-up arrow.
- Added a close (X) button to the language list in Settings.
