## Rosella 1.1.97

- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.
- The same wordmark appears in the opening screen and the welcome screens.
