import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'widgets.dart';

class _Msg {
  final bool user;
  final String text;
  final bool error;
  const _Msg(this.user, this.text, {this.error = false});
}

/// Follow-up conversation with the AI about one dream (saved with the dream).
class DreamChatPage extends StatefulWidget {
  /// null = the open "general chat" that has nothing to do with dreams
  final String? id;
  const DreamChatPage({super.key, this.id});

  @override
  State<DreamChatPage> createState() => _DreamChatPageState();
}

class _DreamChatPageState extends State<DreamChatPage> {
  final TextEditingController _ctrl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<_Msg> _msgs = [];
  bool _busy = false;
  String _partial = '';

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    final chat = widget.id == null ? app.generalChat : app.byId(widget.id!)?.chat;
    for (final m in chat ?? const <Map<String, dynamic>>[]) {
      _msgs.add(_Msg(m['u'] == true, (m['t'] ?? '').toString()));
    }
  }

  Future<void> _persist() async {
    final app = context.read<AppState>();
    final list = <Map<String, dynamic>>[
      for (final m in _msgs.where((m) => !m.error)) {'u': m.user, 't': m.text}
    ];
    if (widget.id == null) {
      app.setGeneralChat(list);
      return;
    }
    final d = app.byId(widget.id!);
    if (d == null) return;
    await app.updateDream(d.copyWith(chat: list));
  }

  Future<void> _clear() async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('chat_clear'),
      message: app.tr('chat_clear_confirm'),
      confirm: app.tr('delete'),
    );
    if (!ok || !mounted) return;
    setState(_msgs.clear);
    await _persist();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic);
      }
    });
  }

  Future<void> _send(String text) async {
    final q = text.trim();
    final app = context.read<AppState>();
    final general = widget.id == null;
    final d = general ? null : app.byId(widget.id!);
    if (q.isEmpty || _busy || (!general && d == null)) return;
    final history = [
      for (final m in _msgs.where((m) => !m.error))
        {'role': m.user ? 'user' : 'assistant', 'content': m.text}
    ];
    setState(() {
      _msgs.add(_Msg(true, q));
      _busy = true;
      _partial = '';
      _ctrl.clear();
    });
    _toEnd();
    void partial(String t) {
      if (!mounted) return;
      setState(() => _partial = t);
      _toEnd();
    }

    final res = general
        ? await AiService.general(
            lang: app.lang, history: history, question: q, onPartial: partial)
        : await AiService.ask(
            title: d!.title,
            content: d.content,
            mood: d.mood,
            interpretation: d.interpretation,
            lang: app.lang,
            history: history,
            question: q,
            onPartial: partial,
          );
    if (!mounted) return;
    setState(() {
      _msgs.add(res == null ? _Msg(false, '${app.tr('chat_failed')}\n${AiService.trace}', error: true) : _Msg(false, res));
      _busy = false;
      _partial = '';
    });
    if (res != null) app.bumpAi();
    _persist();
    _toEnd();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final general = widget.id == null;
    final d = general ? null : app.byId(widget.id!);
    final c = context.colors;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return PageScaffold(
      child: Column(
        children: [
          TopBar(
            title: context.t(general ? 'gen_title' : 'chat_title'),
            actions: [
              if (_msgs.isNotEmpty && !_busy)
                RoundIconButton(icon: Icons.delete_outline_rounded, onTap: _clear),
            ],
          ),
          Expanded(
            child: ListView(
              controller: _scroll,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              children: [
                if (d != null)
                  Panel(
                    radius: 20,
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Icon(Icons.nights_stay_rounded, color: c.a),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontWeight: FontWeight.w800, fontSize: 15),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 14),
                if (_msgs.isEmpty) ...[
                  Text(context.t(general ? 'gen_intro' : 'chat_intro'),
                      style: TextStyle(color: c.dim, fontSize: 14, height: 1.5)),
                  const SizedBox(height: 14),
                  for (final k in general
                      ? const ['gen_s1', 'gen_s2', 'gen_s3']
                      : const ['chat_s1', 'chat_s2', 'chat_s3'])
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Pressable(
                        onTap: () => _send(app.tr(k)),
                        child: Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            color: al(c.a, 0.12),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: al(c.a, 0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: c.a, size: 18),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(context.t(k),
                                    style: TextStyle(
                                        color: c.text,
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
                for (final m in _msgs) _Bubble(msg: m),
                if (_busy && _partial.isNotEmpty) _Bubble(msg: _Msg(false, _partial)),
                if (_busy && _partial.isEmpty)
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: SizedBox(
                        width: 26,
                        height: 26,
                        child: CircularProgressIndicator(strokeWidth: 2.6, color: c.a),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 14 + (bottom > 0 ? 0 : 0)),
            child: Panel(
              padding: const EdgeInsetsDirectional.fromSTEB(16, 4, 6, 4),
              radius: 26,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: _send,
                      style: TextStyle(color: c.text, fontSize: 15.5),
                      decoration: bareInput(context, context.t('chat_hint')),
                    ),
                  ),
                  Pressable(
                    onTap: () => _send(_ctrl.text),
                    scale: 0.9,
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration:
                          BoxDecoration(shape: BoxShape.circle, gradient: c.gradient),
                      child: Icon(Icons.arrow_upward_rounded,
                          color: onAccent(c.a, c.b), size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final _Msg msg;
  const _Bubble({required this.msg});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final user = msg.user;
    final fg = user ? onAccent(c.a, c.b) : (msg.error ? const Color(0xFFFF5470) : c.text);
    return Align(
      alignment: user ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: FadeSlide(
        dy: 10,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          constraints:
              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: user ? c.gradient : null,
            color: user ? null : al(c.surface, c.isDark ? 0.85 : 0.95),
            borderRadius: BorderRadius.circular(20),
            border: user ? null : Border.all(color: c.border),
          ),
          child: SelectableText(msg.text,
              style: TextStyle(color: fg, fontSize: 15, height: 1.55)),
        ),
      ),
    );
  }
}
