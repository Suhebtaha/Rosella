## Rosella 1.1.105

- The small "Rosella" word at the top of every page is now plain white (follows light/dark) instead of coloured.
- Every welcome/feature page now has its own animation: theme, voice, interpretation, chat, AI image, sounds, lock, haptics, reminders and colours each move differently.
