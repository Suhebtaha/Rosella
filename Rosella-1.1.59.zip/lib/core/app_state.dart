import '../services/update_check.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' show Brightness;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:flutter/widgets.dart' show AppLifecycleState, WidgetsBinding, WidgetsBindingObserver;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'achievements.dart';
import '../services/ai_service.dart';
import '../services/drive_backup.dart';
import '../services/haptics.dart';
import '../services/notifier.dart';
import 'models.dart';
import 'strings.dart';

class AppState extends ChangeNotifier with WidgetsBindingObserver {
  late SharedPreferences _prefs;
  late Directory _docs;

  List<Dream> dreams = [];
  String lang = 'ar';
  String themeId = 'onyx';
  bool dark = true; // the look actually in use right now
  String themeMode = 'dark'; // dark | light | auto (by time) | system
  int darkFromMin = 20 * 60, darkToMin = 6 * 60;
  Timer? _themeTimer;
  bool bioLock = false;
  bool lockChats = false;
  bool locked = false;
  bool ready = false;
  int aiCount = 0;
  int imgCount = 0;
  String? userName;
  String? userEmail;
  String? userPhoto;
  Set<String> unlocked = {};

  String cardStyle = 'list'; // 'list' | 'grid'
  bool hideFavFilter = false;
  String speechLang = ''; // language you speak when dictating ('' = detect automatically)
  String get sttLang => speechLang.isEmpty ? 'auto' : speechLang;
  /// open AI conversations (not about dreams), newest first: {id, title, ts, msgs}
  List<Map<String, dynamic>> generalChats = [];
  bool hidePrivFilter = false;
  bool micCenter = false; // false = beside the bar, true = in the middle of it
  String geminiKey = '';
  bool welcomed = true; // false until a new user finished the welcome / sign-in screens
  String profileName = '';
  String profileEmail = '';
  bool onboarded = true; // flipped to false in init() on first run
  bool reminder = false;
  int reminderH = 8;
  int reminderM = 0;
  bool bedtime = false;
  bool nudge = false; // "you have not recorded a dream yet" notification
  int hapticLevel = 2;
  bool updateAvailable = false;
  String updateTag = '';
  String updateUrl = '';
  String updateApk = '';
  String updateNotes = '';
  String updateApkName = '';
  int updateApkSize = 0;
  bool checkingUpdate = false;
  bool hapticMotor = true;
  int bedH = 23;
  int bedM = 0;
  bool lucidMode = false;
  bool autoBackup = true;
  bool syncing = false;
  bool _syncAgain = false;
  int lastSync = 0;
  String? syncError; // null ok, 'api' = Drive API disabled, else raw message
  Set<String> _deleted = {};
  Timer? _syncTimer;

  bool authenticating = false;
  bool _external = false;

  final StreamController<AchievementDef> _unlockCtrl =
      StreamController<AchievementDef>.broadcast();
  Stream<AchievementDef> get unlockStream => _unlockCtrl.stream;

  final GoogleSignIn _google = GoogleSignIn(scopes: ['email', DriveBackup.scope]);
  final LocalAuthentication _auth = LocalAuthentication();

  String tr(String key) => Strings.get(lang, key);
  String get docsPath => _docs.path;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _docs = await getApplicationDocumentsDirectory();
    for (final sub in ['audio', 'images']) {
      final d = Directory('${_docs.path}/$sub');
      if (!await d.exists()) await d.create(recursive: true);
    }
    lang = _prefs.getString('lang') ?? 'ar';
    themeId = _prefs.getString('theme') ?? 'onyx';
    themeMode = _prefs.getString('themeMode') ?? ((_prefs.getBool('dark') ?? true) ? 'dark' : 'light');
    darkFromMin = _prefs.getInt('darkFrom') ?? 20 * 60;
    darkToMin = _prefs.getInt('darkTo') ?? 6 * 60;
    WidgetsBinding.instance.addObserver(this);
    _resolveTheme(notify: false);
    bioLock = _prefs.getBool('bio') ?? false;
    lockChats = _prefs.getBool('lockChats') ?? false;
    aiCount = _prefs.getInt('aiCount') ?? 0;
    imgCount = _prefs.getInt('imgCount') ?? 0;
    unlocked = (_prefs.getStringList('unlocked') ?? <String>[]).toSet();
    userName = _prefs.getString('userName');
    userEmail = _prefs.getString('userEmail');
    userPhoto = _prefs.getString('userPhoto');
    onboarded = _prefs.getBool('onboarded') ?? false;
    welcomed = onboarded || (_prefs.getBool('welcomed') ?? false);
    profileName = _prefs.getString('profileName') ?? '';
    profileEmail = _prefs.getString('profileEmail') ?? '';
    cardStyle = _prefs.getString('cardStyle') ?? 'list';
    if (!onboarded && !_prefs.containsKey('cardStyle')) {
      // brand-new user: square cards by default (existing users keep what they had)
      cardStyle = 'grid';
      _prefs.setString('cardStyle', 'grid');
    }
    hideFavFilter = _prefs.getBool('hideFavFilter') ?? false;
    speechLang = _prefs.getString('speechLang') ?? '';
    try {
      final raw = _prefs.getString('generalChats');
      if (raw != null) {
        generalChats = [
          for (final m in (jsonDecode(raw) as List))
            if (m is Map) Map<String, dynamic>.from(m)
        ];
      } else {
        // older version kept a single conversation
        final old = _prefs.getString('generalChat');
        if (old != null) {
          final msgs = [
            for (final m in (jsonDecode(old) as List))
              if (m is Map) Map<String, dynamic>.from(m)
          ];
          if (msgs.isNotEmpty) {
            final first = msgs.firstWhere((m) => m['u'] == true,
                orElse: () => {'t': ''})['t'].toString();
            generalChats = [
              {
                'id': 'old',
                'title': first.length > 40 ? '${first.substring(0, 40)}…' : first,
                'ts': DateTime.now().millisecondsSinceEpoch,
                'msgs': msgs,
              }
            ];
            _prefs.setString('generalChats', jsonEncode(generalChats));
          }
        }
      }
    } catch (_) {}
    hidePrivFilter = _prefs.getBool('hidePrivFilter') ?? false;
    micCenter = _prefs.getBool('micCenter') ?? false;
    geminiKey = _prefs.getString('geminiKey') ?? '';
    AiService.geminiKey = geminiKey;
    reminder = _prefs.getBool('reminder') ?? false;
    reminderH = _prefs.getInt('reminderH') ?? 8;
    reminderM = _prefs.getInt('reminderM') ?? 0;
    bedtime = _prefs.getBool('bedtime') ?? false;
    nudge = _prefs.getBool('nudge') ?? false;
    hapticLevel = _prefs.getInt('hapticLevel') ?? 2;
    hapticMotor = _prefs.getBool('hapticNative') ?? true;
    Haptics.level = hapticLevel;
    Haptics.motor = hapticMotor;
    bedH = _prefs.getInt('bedH') ?? 23;
    bedM = _prefs.getInt('bedM') ?? 0;
    lucidMode = _prefs.getBool('lucidMode') ?? false;
    autoBackup = _prefs.getBool('autoBackup') ?? true;
    lastSync = _prefs.getInt('lastSync') ?? 0;
    _deleted = (_prefs.getStringList('deletedIds') ?? <String>[]).toSet();

    final f = File('${_docs.path}/dreams.json');
    if (await f.exists()) {
      try {
        final raw = jsonDecode(await f.readAsString()) as List;
        dreams = raw
            .map((e) => Dream.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      } catch (_) {
        dreams = [];
      }
    }
    _sort();
    _checkAchievements(silent: true);
    locked = bioLock;
    ready = true;
    unawaited(_silentGoogle());
    unawaited(applyReminders());
  }

  void _sort() => dreams.sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> _persist() async {
    try {
      final tmp = File('${_docs.path}/dreams.json.tmp');
      await tmp.writeAsString(jsonEncode(dreams.map((d) => d.toJson()).toList()),
          flush: true);
      await tmp.rename('${_docs.path}/dreams.json');
    } catch (_) {}
  }

  // ---------- files ----------
  String newId() => DateTime.now().microsecondsSinceEpoch.toString();
  String newFileRel(String folder, String ext) => '$folder/${newId()}.$ext';
  String? abs(String? rel) => rel == null ? null : '${_docs.path}/$rel';

  void deleteRel(String? rel) => _deleteFile(rel);

  void _deleteFile(String? rel) {
    try {
      if (rel == null) return;
      final f = File('${_docs.path}/$rel');
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }

  // ---------- dreams ----------
  Dream? byId(String id) {
    for (final d in dreams) {
      if (d.id == id) return d;
    }
    return null;
  }

  Future<void> addDream(Dream d) async {
    dreams.add(d);
    _sort();
    _checkAchievements();
    notifyListeners();
    await _persist();
    _scheduleSync();
    if (nudge) unawaited(applyReminders()); // today's nudge is no longer needed
  }

  /// Sets favourite / private on several dreams at once (one save).
  Future<void> setFlagsMany(Set<String> ids, {bool? fav, bool? priv, bool? pin}) async {
    for (var i = 0; i < dreams.length; i++) {
      if (ids.contains(dreams[i].id)) {
        dreams[i] = dreams[i].copyWith(fav: fav, priv: priv, pin: pin);
      }
    }
    notifyListeners();
    await _persist();
    _scheduleSync();
  }

  Future<void> updateDream(Dream d) async {
    final i = dreams.indexWhere((x) => x.id == d.id);
    if (i < 0) return;
    final old = dreams[i];
    if (old.image != null && old.image != d.image) _deleteFile(old.image);
    if (old.audio != null && old.audio != d.audio) _deleteFile(old.audio);
    dreams[i] = d;
    _sort();
    _checkAchievements();
    notifyListeners();
    await _persist();
    _scheduleSync();
  }

  Future<void> deleteDream(String id) async {
    final d = byId(id);
    if (d == null) return;
    _deleteFile(d.audio);
    _deleteFile(d.image);
    dreams.removeWhere((x) => x.id == id);
    _deleted.add(id);
    _prefs.setStringList('deletedIds', _deleted.toList());
    notifyListeners();
    await _persist();
    _scheduleSync();
  }

  Future<void> deleteAll() async {
    for (final d in dreams) {
      _deleteFile(d.audio);
      _deleteFile(d.image);
    }
    _deleted.addAll(dreams.map((d) => d.id));
    _prefs.setStringList('deletedIds', _deleted.toList());
    dreams = [];
    notifyListeners();
    await _persist();
    _scheduleSync();
  }

  // ---------- stats / achievements ----------
  int _streakCount() {
    final days = dreams
        .map((d) => DateTime(d.createdAt.year, d.createdAt.month, d.createdAt.day))
        .toSet();
    final now = DateTime.now();
    var day = DateTime(now.year, now.month, now.day);
    if (!days.contains(day)) day = DateTime(day.year, day.month, day.day - 1);
    var n = 0;
    while (days.contains(day)) {
      n++;
      day = DateTime(day.year, day.month, day.day - 1);
    }
    return n;
  }

  Stats get stats {
    final now = DateTime.now();
    return Stats(
      total: dreams.length,
      voice: dreams.where((d) => d.audio != null).length,
      streak: _streakCount(),
      moods: dreams.map((d) => d.mood).toSet().length,
      ai: aiCount,
      img: imgCount,
      month: dreams
          .where((d) =>
              d.createdAt.year == now.year && d.createdAt.month == now.month)
          .length,
      lucid: dreams.where((d) => d.lucid).length,
    );
  }

  void _checkAchievements({bool silent = false}) {
    final s = stats;
    var changed = false;
    for (final a in kAchievements) {
      if (a.value(s) >= a.target && !unlocked.contains(a.id)) {
        unlocked.add(a.id);
        changed = true;
        if (!silent) _unlockCtrl.add(a);
      }
    }
    if (changed) _prefs.setStringList('unlocked', unlocked.toList());
  }

  void bumpAi() {
    aiCount++;
    _prefs.setInt('aiCount', aiCount);
    _checkAchievements();
    notifyListeners();
  }

  void bumpImg() {
    imgCount++;
    _prefs.setInt('imgCount', imgCount);
    _checkAchievements();
    notifyListeners();
  }

  // ---------- settings ----------
  void setLang(String v) {
    lang = v;
    _prefs.setString('lang', v);
    notifyListeners();
    unawaited(applyReminders());
  }

  void setTheme(String v) {
    themeId = v;
    _prefs.setString('theme', v);
    notifyListeners();
  }

  void setDark(bool v) => setThemeMode(v ? 'dark' : 'light');

  void setThemeMode(String m) {
    themeMode = m;
    _prefs.setString('themeMode', m);
    _prefs.setBool('dark', m != 'light');
    _resolveTheme();
  }

  void setDarkRange(int fromMin, int toMin) {
    darkFromMin = fromMin;
    darkToMin = toMin;
    _prefs.setInt('darkFrom', fromMin);
    _prefs.setInt('darkTo', toMin);
    _resolveTheme();
  }

  bool _inDarkRange(DateTime n) {
    final m = n.hour * 60 + n.minute;
    if (darkFromMin == darkToMin) return false;
    return darkFromMin < darkToMin
        ? (m >= darkFromMin && m < darkToMin)
        : (m >= darkFromMin || m < darkToMin);
  }

  void _resolveTheme({bool notify = true}) {
    final now = DateTime.now();
    bool d;
    switch (themeMode) {
      case 'light':
        d = false;
        break;
      case 'system':
        d = WidgetsBinding.instance.platformDispatcher.platformBrightness != Brightness.light;
        break;
      case 'auto':
        d = _inDarkRange(now);
        break;
      default:
        d = true;
    }
    _themeTimer?.cancel();
    _themeTimer = null;
    if (themeMode == 'auto' && darkFromMin != darkToMin) {
      // wake up at the next switching moment
      DateTime next(int mins) {
        var t = DateTime(now.year, now.month, now.day, mins ~/ 60, mins % 60);
        if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
        return t;
      }
      final a = next(darkFromMin), b = next(darkToMin);
      final at = a.isBefore(b) ? a : b;
      _themeTimer = Timer(at.difference(now) + const Duration(seconds: 1), _resolveTheme);
    }
    if (d != dark) {
      dark = d;
      if (notify) notifyListeners();
    } else if (notify) {
      notifyListeners();
    }
  }

  @override
  void didChangePlatformBrightness() {
    if (themeMode == 'system') _resolveTheme();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && themeMode == 'auto') _resolveTheme();
  }

  void setBio(bool v) {
    bioLock = v;
    _prefs.setBool('bio', v);
    if (!v) locked = false;
    notifyListeners();
  }

  void setLockChats(bool v) {
    lockChats = v;
    _prefs.setBool('lockChats', v);
    notifyListeners();
  }

  // ---------- external activities (don't lock the app) ----------
  Future<T> external<T>(Future<T> Function() f) async {
    _external = true;
    try {
      return await f();
    } finally {
      Future.delayed(const Duration(milliseconds: 900), () => _external = false);
    }
  }

  // ---------- biometrics ----------
  Future<bool> canAuth() async {
    try {
      return await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  Future<bool> authenticate() async {
    if (authenticating) return false;
    authenticating = true;
    try {
      final supported = await _auth.isDeviceSupported();
      if (!supported) return true; // nothing to authenticate with: don't lock out
      return await _auth.authenticate(
        localizedReason: tr('unlock_reason'),
        options: const AuthenticationOptions(stickyAuth: true),
      );
    } catch (_) {
      return false;
    } finally {
      authenticating = false;
    }
  }

  Future<void> tryUnlock() async {
    if (!locked || authenticating) return;
    final ok = await authenticate();
    if (ok) {
      locked = false;
      notifyListeners();
    }
  }

  void onBackground() {
    if (bioLock && !authenticating && !_external && !locked) {
      locked = true;
      notifyListeners();
    }
  }

  // ---------- Google ----------
  Future<void> _silentGoogle() async {
    try {
      final a = await _google.signInSilently().timeout(const Duration(seconds: 5));
      if (a != null) {
        _setUser(a);
        _scheduleSync(now: true);
      }
    } catch (_) {}
  }

  void _setUser(GoogleSignInAccount a) {
    userName = a.displayName ?? a.email;
    userEmail = a.email;
    userPhoto = a.photoUrl;
    _prefs.setString('userName', userName!);
    _prefs.setString('userEmail', userEmail!);
    if (userPhoto != null) {
      _prefs.setString('userPhoto', userPhoto!);
    } else {
      _prefs.remove('userPhoto');
    }
    notifyListeners();
  }

  /// returns null on success/cancel, otherwise an error marker.
  Future<String?> googleSignIn() async {
    try {
      final a = await external(() => _google.signIn());
      if (a == null) return null;
      _setUser(a);
      unawaited(syncNow());
      return null;
    } catch (e) {
      var msg = e.toString();
      if (e is PlatformException) msg = '${e.code}: ${e.message ?? ''}';
      msg = msg.replaceAll('\n', ' ');
      return msg.length > 140 ? msg.substring(0, 140) : msg;
    }
  }

  Future<void> googleSignOut() async {
    try {
      await _google.signOut();
    } catch (_) {}
    userName = null;
    userEmail = null;
    userPhoto = null;
    _prefs.remove('userName');
    _prefs.remove('userEmail');
    _prefs.remove('userPhoto');
    notifyListeners();
  }

  // ---------- Google Drive backup / sync ----------
  void setAutoBackup(bool v) {
    autoBackup = v;
    _prefs.setBool('autoBackup', v);
    notifyListeners();
    if (v) _scheduleSync(now: true);
  }

  void _scheduleSync({bool now = false}) {
    if (userEmail == null || !autoBackup) return;
    _syncTimer?.cancel();
    _syncTimer = Timer(Duration(seconds: now ? 1 : 4), () => unawaited(syncNow()));
  }

  Future<String?> _driveToken({bool refresh = false}) async {
    var a = _google.currentUser ?? await _google.signInSilently();
    if (a == null) return null;
    if (refresh) {
      try {
        await a.clearAuthCache();
      } catch (_) {}
    }
    return (await a.authentication).accessToken;
  }

  /// Pull from Drive, merge with local data, push everything back.
  /// Returns null on success, otherwise an error marker.
  Future<String?> syncNow() async {
    if (userEmail == null) return 'login';
    if (syncing) {
      _syncAgain = true;
      return null;
    }
    syncing = true;
    syncError = null;
    notifyListeners();
    try {
      try {
        await _syncOnce(await _driveToken());
      } on DriveException catch (e) {
        if (e.status == 401) {
          await _syncOnce(await _driveToken(refresh: true));
        } else if (e.status == 403 && e.scopeProblem) {
          final ok = await external(() => _google.requestScopes([DriveBackup.scope]));
          if (ok != true) rethrow;
          await _syncOnce(await _driveToken(refresh: true));
        } else {
          rethrow;
        }
      }
      lastSync = DateTime.now().millisecondsSinceEpoch;
      _prefs.setInt('lastSync', lastSync);
    } on DriveException catch (e) {
      syncError = e.apiDisabled ? 'api' : e.message;
    } catch (e) {
      var m = e.toString().replaceAll('\n', ' ');
      syncError = m.length > 120 ? m.substring(0, 120) : m;
    } finally {
      syncing = false;
      notifyListeners();
    }
    if (_syncAgain) {
      _syncAgain = false;
      _scheduleSync(now: true);
    }
    return syncError;
  }

  Future<void> _syncOnce(String? token) async {
    if (token == null) throw Exception('no token');
    final drive = DriveBackup(token);
    final remote = await drive.list();

    // 1) read remote index
    var remoteDreams = <Dream>[];
    final remoteDeleted = <String>{};
    final idxId = remote['dreams.json'];
    if (idxId != null) {
      try {
        final j = jsonDecode(utf8.decode(await drive.download(idxId)));
        final list = j is Map ? (j['dreams'] as List? ?? const []) : (j as List);
        remoteDreams = list
            .map((e) => Dream.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        if (j is Map) {
          remoteDeleted.addAll((j['deleted'] as List? ?? const []).map((e) => '$e'));
        }
      } on DriveException {
        rethrow;
      } catch (_) {}
    }

    // 2) merge
    _deleted.addAll(remoteDeleted);
    for (final d in List<Dream>.from(dreams)) {
      if (remoteDeleted.contains(d.id)) {
        _deleteFile(d.audio);
        _deleteFile(d.image);
        dreams.remove(d);
      }
    }
    final have = dreams.map((d) => d.id).toSet();
    for (final r in remoteDreams) {
      if (!have.contains(r.id) && !_deleted.contains(r.id)) dreams.add(r);
    }
    _sort();

    // 3) download media that only exists on Drive
    for (final d in dreams) {
      for (final rel in [d.audio, d.image]) {
        if (rel == null) continue;
        final f = File('${_docs.path}/$rel');
        final id = remote[DriveBackup.flat(rel)];
        if (!await f.exists() && id != null) {
          try {
            await f.parent.create(recursive: true);
            await f.writeAsBytes(await drive.download(id), flush: true);
          } on DriveException {
            rethrow;
          } catch (_) {}
        }
      }
    }
    _checkAchievements(silent: true);
    notifyListeners();
    await _persist();
    _prefs.setStringList('deletedIds', _deleted.toList());

    // 4) upload media that only exists locally
    final keep = <String>{'dreams.json'};
    for (final d in dreams) {
      for (final rel in [d.audio, d.image]) {
        if (rel == null) continue;
        final name = DriveBackup.flat(rel);
        keep.add(name);
        if (remote.containsKey(name)) continue;
        final f = File('${_docs.path}/$rel');
        if (await f.exists()) await drive.upload(name, await f.readAsBytes(), null);
      }
    }

    // 5) upload index
    final idx = utf8.encode(jsonEncode({
      'v': 1,
      'dreams': dreams.map((d) => d.toJson()).toList(),
      'deleted': _deleted.toList(),
    }));
    await drive.upload('dreams.json', idx, idxId);

    // 6) remove orphaned media
    for (final e in remote.entries) {
      if (!keep.contains(e.key)) await drive.delete(e.value);
    }
  }

  Map<String, dynamic>? generalById(String id) {
    for (final c in generalChats) {
      if (c['id'] == id) return c;
    }
    return null;
  }

  /// Creates (id == null) or updates a general conversation; returns its id.
  String saveGeneral(String? id, List<Map<String, dynamic>> msgs) {
    final now = DateTime.now().millisecondsSinceEpoch;
    var useId = id;
    final i = id == null ? -1 : generalChats.indexWhere((c) => c['id'] == id);
    if (i >= 0) {
      final c = generalChats.removeAt(i);
      c['msgs'] = msgs;
      c['ts'] = now;
      generalChats.insert(0, c);
    } else {
      useId = '$now';
      final first = msgs.firstWhere((m) => m['u'] == true, orElse: () => {'t': ''})['t']
          .toString()
          .trim();
      generalChats.insert(0, {
        'id': useId,
        'title': first.length > 40 ? '${first.substring(0, 40)}…' : first,
        'ts': now,
        'msgs': msgs,
      });
    }
    _prefs.setString('generalChats', jsonEncode(generalChats));
    notifyListeners();
    return useId!;
  }

  void deleteGeneral(String id) {
    generalChats.removeWhere((c) => c['id'] == id);
    _prefs.setString('generalChats', jsonEncode(generalChats));
    notifyListeners();
  }

  void setSpeechLang(String v) {
    speechLang = v;
    _prefs.setString('speechLang', v);
    notifyListeners();
  }

  void setHideFavFilter(bool v) {
    hideFavFilter = v;
    _prefs.setBool('hideFavFilter', v);
    notifyListeners();
  }

  void setHidePrivFilter(bool v) {
    hidePrivFilter = v;
    _prefs.setBool('hidePrivFilter', v);
    notifyListeners();
  }

  void setCardStyle(String v) {
    cardStyle = v;
    _prefs.setString('cardStyle', v);
    notifyListeners();
  }

  void setMicCenter(bool v) {
    micCenter = v;
    _prefs.setBool('micCenter', v);
    notifyListeners();
  }

  void setGeminiKey(String v) {
    geminiKey = v.trim();
    AiService.geminiKey = geminiKey;
    _prefs.setString('geminiKey', geminiKey);
    notifyListeners();
  }

  /// Deletes several dreams at once (one save, one sync).
  Future<void> deleteMany(Set<String> ids) async {
    for (final id in ids) {
      final d = byId(id);
      if (d == null) continue;
      _deleteFile(d.audio);
      _deleteFile(d.image);
      dreams.removeWhere((x) => x.id == id);
      _deleted.add(id);
    }
    _prefs.setStringList('deletedIds', _deleted.toList());
    notifyListeners();
    await _persist();
    _scheduleSync();
  }

  /// Written yearly reflection, cached per year together with the dream count it was
  /// written for (so adding dreams later asks for a fresh one).
  String? yearNote(int year, int count) {
    final v = _prefs.getString('yrnote_$year');
    if (v == null) return null;
    final i = v.indexOf('|');
    if (i < 0 || v.substring(0, i) != '$count') return null;
    return v.substring(i + 1);
  }

  void setYearNote(int year, int count, String text) {
    _prefs.setString('yrnote_$year', '$count|$text');
  }

  void setWelcomed() {
    welcomed = true;
    _prefs.setBool('welcomed', true);
    notifyListeners();
  }

  /// Email profile typed by the user: stored only on this device (no account / server).
  void setProfile(String name, String email) {
    profileName = name;
    profileEmail = email;
    _prefs.setString('profileName', name);
    _prefs.setString('profileEmail', email);
    notifyListeners();
  }

  void completeOnboarding() {
    onboarded = true;
    _prefs.setBool('onboarded', true);
    notifyListeners();
  }

  // ---------- reminders ----------
  bool get dreamedToday {
    final n = DateTime.now();
    return dreams.any((d) =>
        d.createdAt.year == n.year && d.createdAt.month == n.month && d.createdAt.day == n.day);
  }

  Future<bool> setNudge(bool v) async {
    if (v && !await Notifier.requestPermission()) return false;
    nudge = v;
    _prefs.setBool('nudge', v);
    notifyListeners();
    await applyReminders();
    return true;
  }

  Future<void> applyReminders() => Notifier.apply(
        nudge: nudge,
        // three hours after the morning reminder (default 11:00), never later than 22:00
        nudgeHour: reminder ? (reminderH + 3 > 22 ? 22 : reminderH + 3) : 11,
        nudgeMinute: reminder ? reminderM : 0,
        dreamedToday: dreamedToday,
        nudgeTitle: tr('notif_nudge_title'),
        nudgeBody: tr('notif_nudge_body'),
        morning: reminder,
        hour: reminderH,
        minute: reminderM,
        lucid: lucidMode,
        bedtime: bedtime,
        bedHour: bedH,
        bedMinute: bedM,
        bedTitle: tr('notif_bed_title'),
        bedBody: tr('notif_bed_body'),
        morningTitle: tr('notif_morning_title'),
        morningBody: tr('notif_morning_body'),
        lucidTitle: tr('notif_lucid_title'),
        lucidBody: tr('notif_lucid_body'),
      );

  /// false if the notification permission was refused.
  Future<bool> setReminder(bool v) async {
    if (v && !await Notifier.requestPermission()) return false;
    reminder = v;
    _prefs.setBool('reminder', v);
    notifyListeners();
    await applyReminders();
    return true;
  }

  Future<void> setReminderTime(int h, int m) async {
    reminderH = h;
    reminderM = m;
    _prefs.setInt('reminderH', h);
    _prefs.setInt('reminderM', m);
    notifyListeners();
    await applyReminders();
  }

  /// Asks GitHub for the latest release; sets the red badge when a newer one exists.
  Future<UpdateInfo> checkForUpdate() async {
    checkingUpdate = true;
    notifyListeners();
    final r = await UpdateCheck.check();
    checkingUpdate = false;
    if (!r.failed) {
      updateAvailable = r.available;
      updateTag = r.tag;
      updateUrl = r.url;
      updateApk = r.apkUrl;
      updateNotes = r.notes;
      updateApkName = r.apkName;
      updateApkSize = r.apkSize;
    }
    notifyListeners();
    return r;
  }

  UpdateInfo get updateInfo => UpdateInfo(
      available: updateAvailable,
      tag: updateTag,
      url: updateUrl,
      apkUrl: updateApk,
      notes: updateNotes,
      apkName: updateApkName,
      apkSize: updateApkSize);

  /// "No thanks, remind me in 24 hours": no automatic update sheet until then.
  bool get updateSnoozed =>
      DateTime.now().millisecondsSinceEpoch < (_prefs.getInt('upd_remind_until') ?? 0);

  void snoozeUpdate() => _prefs.setInt('upd_remind_until',
      DateTime.now().add(const Duration(hours: 24)).millisecondsSinceEpoch);

  void setHapticLevel(int v) {
    hapticLevel = v;
    Haptics.level = v;
    _prefs.setInt('hapticLevel', v);
    notifyListeners();
  }

  void setHapticMotor(bool v) {
    hapticMotor = v;
    Haptics.motor = v;
    _prefs.setBool('hapticNative', v);
    notifyListeners();
  }

  Future<bool> setBedtime(bool v) async {
    if (v && !await Notifier.requestPermission()) return false;
    bedtime = v;
    _prefs.setBool('bedtime', v);
    notifyListeners();
    await applyReminders();
    return true;
  }

  Future<void> setBedtimeTime(int h, int m) async {
    bedH = h;
    bedM = m;
    _prefs.setInt('bedH', h);
    _prefs.setInt('bedM', m);
    notifyListeners();
    await applyReminders();
  }

  Future<bool> setLucidMode(bool v) async {
    if (v && !await Notifier.requestPermission()) return false;
    lucidMode = v;
    _prefs.setBool('lucidMode', v);
    notifyListeners();
    await applyReminders();
    return true;
  }
}
