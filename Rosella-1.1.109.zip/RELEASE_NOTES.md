## Rosella 1.1.109

- Dreams can now have optional details: people, places and tags ("Add details"), shown on the dream page and saved with backups.
- A save (check) button at the top right of the dream editor; the Save button below stays.
- The three header buttons on the home page are replaced by a ⋮ menu that opens as an animated card (view style, general chat, new dream, calendar, dream chats).
