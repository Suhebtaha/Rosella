import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';

final GlobalKey<ScaffoldMessengerState> rootMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

extension TrX on BuildContext {
  String t(String key) =>
      Strings.get(select<AppState, String>((s) => s.lang), key);
}

String fmtDate(DateTime d, String lang) =>
    '${d.day} ${Strings.get(lang, 'm${d.month}')} ${d.year}';

String fmtTime(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

double navPadding(BuildContext c) => 118 + MediaQuery.of(c).padding.bottom;

void toast(BuildContext context, String msg) {
  final c = context.colors;
  rootMessengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
      behavior: SnackBarBehavior.floating,
      backgroundColor: c.surfaceHi,
      elevation: 0,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 112),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: c.border),
      ),
      duration: const Duration(seconds: 3),
    ));
}

const List<String> kMoodEmoji = ['😱', '😢', '😐', '🙂', '🤩'];
const List<Color> kMoodColors = [
  Color(0xFFFF5470),
  Color(0xFF5B8DEF),
  Color(0xFF9AA0B5),
  Color(0xFF34D399),
  Color(0xFFFFC857),
];
String moodEmoji(int m) => kMoodEmoji[(m.clamp(1, 5)) - 1];
Color moodColor(int m) => kMoodColors[(m.clamp(1, 5)) - 1];

// ---------------------------------------------------------------- background
class AppBackground extends StatelessWidget {
  const AppBackground({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return RepaintBoundary(
      child: Stack(
        fit: StackFit.expand,
        children: [
          ColoredBox(color: c.bg),
          Positioned(
              top: -150,
              right: -110,
              child: _Glow(color: c.a, size: 400, alpha: c.isDark ? 0.22 : 0.16)),
          Positioned(
              bottom: 100,
              left: -170,
              child: _Glow(color: c.b, size: 440, alpha: c.isDark ? 0.16 : 0.12)),
          if (c.isDark)
            const CustomPaint(painter: _StarPainter(), size: Size.infinite),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  final Color color;
  final double size;
  final double alpha;
  const _Glow({required this.color, required this.size, required this.alpha});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [al(color, alpha), al(color, 0)]),
        ),
      ),
    );
  }
}

class _StarPainter extends CustomPainter {
  const _StarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(11);
    final p = Paint();
    for (var i = 0; i < 150; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final rad = 0.4 + r.nextDouble() * 1.1;
      p.color = Colors.white.withAlpha((50 + r.nextInt(170)));
      canvas.drawCircle(Offset(x, y), rad, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------- primitives
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  const Pressable({super.key, required this.child, this.onTap, this.scale = 0.97});

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.onTap == null ? null : (_) => setState(() => _down = true),
      onTapUp: widget.onTap == null ? null : (_) => setState(() => _down = false),
      onTapCancel: widget.onTap == null ? null : () => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 22,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: al(c.surface, c.isDark ? 0.72 : 0.92),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: c.border),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return Pressable(onTap: onTap, child: box);
  }
}

class FadeSlide extends StatelessWidget {
  final Widget child;
  final int delay;
  final double dy;
  const FadeSlide({super.key, required this.child, this.delay = 0, this.dy = 18});

  @override
  Widget build(BuildContext context) {
    final total = 450 + delay;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: total),
      curve: Interval(delay / total, 1, curve: Curves.easeOutCubic),
      builder: (_, v, ch) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, (1 - v) * dy), child: ch),
      ),
      child: child,
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool loading;
  final bool expand;
  const GradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.loading = false,
    this.expand = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: loading ? null : onTap,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          gradient: c.gradient,
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(color: al(c.a, 0.35), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (loading)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            else if (icon != null)
              Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SubtleButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final Color? color;
  const SubtleButton(
      {super.key, required this.label, required this.icon, this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final col = color ?? c.text;
    return Pressable(
      onTap: onTap,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        decoration: BoxDecoration(
          color: al(c.surface, c.isDark ? 0.7 : 0.9),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: c.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 19, color: col),
            const SizedBox(width: 8),
            Flexible(
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: col, fontWeight: FontWeight.w600, fontSize: 14.5)),
            ),
          ],
        ),
      ),
    );
  }
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  const RoundIconButton({super.key, required this.icon, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: onTap,
      scale: 0.9,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: al(c.surface, c.isDark ? 0.8 : 0.95),
          border: Border.all(color: c.border),
        ),
        child: Icon(icon, size: 20, color: color ?? c.text),
      ),
    );
  }
}

class TopBar extends StatelessWidget {
  final String? title;
  final List<Widget> actions;
  const TopBar({super.key, this.title, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          RoundIconButton(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.of(context).maybePop(),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                title ?? '',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: c.text, fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          for (final a in actions) ...[const SizedBox(width: 8), a],
        ],
      ),
    );
  }
}

class PageScaffold extends StatelessWidget {
  final Widget child;
  const PageScaffold({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: AppBackground()),
          Positioned.fill(child: SafeArea(child: child)),
        ],
      ),
    );
  }
}

InputDecoration bareInput(BuildContext context, String hint) {
  final c = context.colors;
  return InputDecoration(
    hintText: hint,
    hintStyle: TextStyle(color: al(c.dim, 0.8)),
    border: InputBorder.none,
    enabledBorder: InputBorder.none,
    focusedBorder: InputBorder.none,
    isDense: true,
    contentPadding: const EdgeInsets.symmetric(vertical: 12),
  );
}

class MoodPicker extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const MoodPicker({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Row(
      children: [
        for (var m = 1; m <= 5; m++)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Pressable(
                onTap: () {
                  HapticFeedback.selectionClick();
                  onChanged(m);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: value == m
                        ? al(moodColor(m), 0.22)
                        : al(c.surface, c.isDark ? 0.7 : 0.9),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: value == m ? moodColor(m) : c.border,
                      width: value == m ? 1.5 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedScale(
                        scale: value == m ? 1.2 : 1,
                        duration: const Duration(milliseconds: 250),
                        child: Text(moodEmoji(m), style: const TextStyle(fontSize: 26)),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        context.t('mood_$m'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10.5,
                          color: value == m ? c.text : c.dim,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirm,
  bool danger = true,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      final c = ctx.colors;
      return AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(26),
          side: BorderSide(color: c.border),
        ),
        title: Text(title, style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
        content: Text(message, style: TextStyle(color: c.dim)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(ctx.t('cancel'), style: TextStyle(color: c.dim)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              confirm,
              style: TextStyle(
                color: danger ? const Color(0xFFFF5470) : c.a,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      );
    },
  );
  return r ?? false;
}
