import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import 'widgets.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _toggleBio(BuildContext context, bool v) async {
    final app = context.read<AppState>();
    if (v) {
      final supported = await app.canAuth();
      if (!supported) {
        if (context.mounted) toast(context, app.tr('bio_unsupported'));
        return;
      }
      final ok = await app.authenticate();
      if (!ok) return;
    }
    app.setBio(v);
  }

  Future<void> _signIn(BuildContext context) async {
    final app = context.read<AppState>();
    final err = await app.googleSignIn();
    if (err != null && context.mounted) toast(context, app.tr('signin_failed'));
  }

  Future<void> _deleteAll(BuildContext context) async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_all'),
      message: app.tr('delete_all_confirm'),
      confirm: app.tr('delete'),
    );
    if (ok) await app.deleteAll();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    return SafeArea(
      bottom: false,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 14, 16, navPadding(context)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
            child: Text(context.t('set_title'),
                style: TextStyle(
                    color: c.text,
                    fontSize: 32,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5)),
          ),
          _Label(context.t('account')),
          Panel(
            child: app.userEmail == null
                ? GradientButton(
                    label: context.t('sign_google'),
                    icon: Icons.login_rounded,
                    expand: true,
                    onTap: () => _signIn(context),
                  )
                : Row(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: c.surfaceHi,
                        backgroundImage:
                            app.userPhoto != null ? NetworkImage(app.userPhoto!) : null,
                        onBackgroundImageError:
                            app.userPhoto != null ? (_, __) {} : null,
                        child: app.userPhoto == null
                            ? Text(
                                (app.userName ?? '?').characters.first.toUpperCase(),
                                style: TextStyle(
                                    color: c.text,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 20),
                              )
                            : null,
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(app.userName ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: c.text,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800)),
                            Text(app.userEmail ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(color: c.dim, fontSize: 13)),
                          ],
                        ),
                      ),
                      RoundIconButton(
                        icon: Icons.logout_rounded,
                        onTap: () => app.googleSignOut(),
                      ),
                    ],
                  ),
          ),
          const SizedBox(height: 20),
          _Label(context.t('appearance')),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SwitchRow(
                  icon: app.dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                  title: context.t('dark_mode'),
                  value: app.dark,
                  onChanged: (v) {
                    HapticFeedback.selectionClick();
                    app.setDark(v);
                  },
                ),
                Divider(color: c.border, height: 28),
                Row(
                  children: [
                    Icon(Icons.palette_rounded, color: c.a, size: 22),
                    const SizedBox(width: 12),
                    Text(context.t('theme'),
                        style: TextStyle(
                            color: c.text, fontSize: 15.5, fontWeight: FontWeight.w700)),
                  ],
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 10,
                  runSpacing: 14,
                  children: [
                    for (final p in kPalettes)
                      _Swatch(
                        palette: p,
                        selected: app.themeId == p.id,
                        label: Strings.get(app.lang, p.nameKey),
                        onTap: () {
                          HapticFeedback.selectionClick();
                          app.setTheme(p.id);
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _Label(context.t('language')),
          Panel(
            padding: const EdgeInsets.all(8),
            radius: 24,
            child: _LangSegment(
              current: app.lang,
              onChanged: (v) {
                HapticFeedback.selectionClick();
                app.setLang(v);
              },
            ),
          ),
          const SizedBox(height: 20),
          _Label(context.t('security')),
          Panel(
            child: _SwitchRow(
              icon: Icons.fingerprint_rounded,
              title: context.t('bio_lock'),
              subtitle: context.t('bio_sub'),
              value: app.bioLock,
              onChanged: (v) => _toggleBio(context, v),
            ),
          ),
          const SizedBox(height: 20),
          _Label(context.t('data')),
          Panel(
            onTap: () => _deleteAll(context),
            child: Row(
              children: [
                const Icon(Icons.delete_sweep_rounded, color: Color(0xFFFF5470)),
                const SizedBox(width: 12),
                Text(context.t('delete_all'),
                    style: const TextStyle(
                        color: Color(0xFFFF5470),
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Center(
            child: Column(
              children: [
                Text('${context.t('app_name')} • 1.0.0',
                    style: TextStyle(color: c.dim, fontSize: 12)),
                const SizedBox(height: 4),
                Text(
                  'Developed by suhaib',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(
                      color: al(c.dim, 0.75), fontSize: 10.5, letterSpacing: 0.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
        child: Text(text,
            style: TextStyle(
                color: context.colors.dim, fontSize: 13, fontWeight: FontWeight.w700)),
      );
}

class _SwitchRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Row(
      children: [
        Icon(icon, color: c.a, size: 24),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: TextStyle(
                      color: c.text, fontSize: 15.5, fontWeight: FontWeight.w700)),
              if (subtitle != null)
                Text(subtitle!, style: TextStyle(color: c.dim, fontSize: 12.5)),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeTrackColor: c.a,
          inactiveTrackColor: c.surfaceHi,
          thumbColor: const WidgetStatePropertyAll<Color>(Colors.white),
          trackOutlineColor: const WidgetStatePropertyAll<Color>(Colors.transparent),
        ),
      ],
    );
  }
}

class _Swatch extends StatelessWidget {
  final AppPalette palette;
  final bool selected;
  final String label;
  final VoidCallback onTap;
  const _Swatch(
      {required this.palette,
      required this.selected,
      required this.label,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Pressable(
      onTap: onTap,
      scale: 0.92,
      child: SizedBox(
        width: 64,
        child: Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: selected ? c.text : Colors.transparent, width: 2),
              ),
              child: Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [palette.a, palette.b],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: selected
                    ? const Icon(Icons.check_rounded, color: Colors.white, size: 24)
                    : null,
              ),
            ),
            const SizedBox(height: 6),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: selected ? c.text : c.dim,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _LangSegment extends StatelessWidget {
  final String current;
  final ValueChanged<String> onChanged;
  const _LangSegment({required this.current, required this.onChanged});

  static const List<List<String>> _opts = [
    ['ar', 'العربية'],
    ['ckb', 'کوردی'],
    ['en', 'English'],
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final idx = _opts.indexWhere((o) => o[0] == current).clamp(0, 2);
    return SizedBox(
      height: 46,
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 320),
            curve: Curves.easeOutCubic,
            alignment: AlignmentDirectional(idx - 1.0, 0),
            child: FractionallySizedBox(
              widthFactor: 1 / 3,
              heightFactor: 1,
              child: Container(
                decoration: BoxDecoration(
                  gradient: c.gradient,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                        color: al(c.a, 0.3), blurRadius: 12, offset: const Offset(0, 4)),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              for (final o in _opts)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onChanged(o[0]),
                    child: Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 250),
                        style: TextStyle(
                          color: current == o[0] ? Colors.white : c.text,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                        ),
                        child: Text(o[1]),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
