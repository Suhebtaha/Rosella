import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:http/http.dart' as http;

class AiResult {
  final String text;
  final bool fromAi;
  const AiResult(this.text, this.fromAi);
}

class _Sym {
  final List<String> keys;
  final Map<String, String> text;
  const _Sym(this.keys, this.text);
}

const List<_Sym> _syms = [
  _Sym([
    'water', 'sea', 'ocean', 'river', 'swim', 'drown', 'wave', 'rain',
    'ماء', 'بحر', 'مطر', 'نهر', 'غرق', 'موج', 'سباح',
    'ئاو', 'دەریا', 'باران'
  ], {
    'en':
        'Water usually mirrors your emotions. Calm water suggests inner peace, while rough or deep water points to feelings you are still processing.',
    'ar':
        'الماء يعكس عادةً مشاعرك؛ صفاؤه يدل على سكينة داخلية، واضطرابه أو عمقه يشير إلى مشاعر ما زلت تعالجها.',
    'ckb':
        'ئاو زۆرجار ڕەنگدانەوەی هەستەکانتە؛ ئاوی ئارام ئاشتی ناوەوە دەگەیەنێت و ئاوی شەپۆلدار یان قووڵ هەستی تەواونەکراو.',
  }),
  _Sym([
    'fly', 'flying', 'soar', 'plane', 'طير', 'أطير', 'تحليق', 'طائرة', 'فڕین'
  ], {
    'en':
        'Flying often stands for freedom, ambition, or a wish to rise above a problem.',
    'ar':
        'الطيران يرمز غالباً إلى الحرية والطموح أو الرغبة في التسامي فوق مشكلة ما.',
    'ckb':
        'فڕین زۆرجار هێمای ئازادی و ئامانجە یان ئارەزووی بەرزبوونەوە بەسەر کێشەیەکدا.',
  }),
  _Sym([
    'fall', 'falling', 'drop', 'سقط', 'سقوط', 'وقعت', 'أسقط', 'کەوتن', 'کەوتم'
  ], {
    'en':
        'Falling is commonly linked to feeling a loss of control or worry about something slipping away.',
    'ar':
        'السقوط يرتبط عادةً بالشعور بفقدان السيطرة أو القلق من أن شيئاً ما يفلت منك.',
    'ckb':
        'کەوتن زۆرجار بە هەستکردن بە لەدەستدانی کۆنترۆڵ یان نیگەرانی لە ڕۆیشتنی شتێکەوە دەبەسترێتەوە.',
  }),
  _Sym([
    'chase', 'chased', 'run away', 'escape', 'flee', 'هرب', 'يطارد', 'مطارد',
    'لاحق', 'اهرب', 'هەڵات', 'ڕاو'
  ], {
    'en':
        'Being chased often means you are avoiding a situation or emotion that needs to be faced.',
    'ar':
        'أن يُطاردك أحد يعني غالباً أنك تتجنب موقفاً أو شعوراً يحتاج إلى مواجهة.',
    'ckb':
        'ڕاوەدوونران زۆرجار مانای دووركەوتنەوەیە لە دۆخ یان هەستێک کە پێویستی بە ڕووبەڕووبوونەوە هەیە.',
  }),
  _Sym(['teeth', 'tooth', 'أسنان', 'اسنان', 'ددان'], {
    'en': 'Teeth dreams tend to connect with stress, self-image, or fear of embarrassment.',
    'ar': 'أحلام الأسنان ترتبط عادةً بالتوتر وصورة الذات والخوف من الإحراج.',
    'ckb': 'خەونی ددان زۆرجار پەیوەندی بە فشار و وێنەی خود و ترسی شەرمەزاری هەیە.',
  }),
  _Sym(['snake', 'serpent', 'ثعبان', 'أفعى', 'افعى', 'حية', 'مار'], {
    'en':
        "A snake can symbolize a hidden fear, a change, or something you sense but haven't fully noticed yet.",
    'ar':
        'قد ترمز الأفعى إلى خوف مخفي أو تغيير قادم أو أمر تشعر به دون أن تدركه تماماً.',
    'ckb':
        'مار دەکرێت هێمای ترسێکی شاراوە یان گۆڕانکاری یان شتێک بێت کە هەستی پێدەکەیت بەڵام تەواو تێینەگەیشتووی.',
  }),
  _Sym([
    'death', 'dead', 'die', 'funeral', 'موت', 'ميت', 'جنازة', 'مات', 'مردن'
  ], {
    'en':
        'Death in dreams rarely means literal loss — it more often signals an ending and a new beginning.',
    'ar':
        'الموت في الأحلام نادراً ما يعني فقداناً حرفياً، بل يشير غالباً إلى نهاية مرحلة وبداية جديدة.',
    'ckb':
        'مردن لە خەوندا بە ڕێژەیەکی کەم مردنی ڕاستەقینە دەگەیەنێت؛ زیاتر کۆتایی قۆناغێک و دەستپێکێکی نوێیە.',
  }),
  _Sym([
    'exam', 'test', 'late', 'school', 'امتحان', 'اختبار', 'تأخر', 'تاقیکردنەوە'
  ], {
    'en':
        'Exams or being late reflect pressure to perform and fear of being judged or unprepared.',
    'ar': 'الامتحان أو التأخر يعكس ضغط الأداء والخوف من التقييم أو عدم الاستعداد.',
    'ckb':
        'تاقیکردنەوە یان دواکەوتن فشاری ئەنجامدان و ترسی هەڵسەنگاندن یان ئامادەنەبوون ڕەنگدەداتەوە.',
  }),
];

const Map<String, String> _intro = {
  'en': "Here's a gentle reflection on your dream:",
  'ar': 'هذه قراءة هادئة لحلمك:',
  'ckb': 'ئەمە خوێندنەوەیەکی ئارامە بۆ خەونەکەت:',
};

const Map<String, String> _generic = {
  'en':
      "Dreams often blend the day's thoughts, memories and feelings. Notice which feeling stood out most — it is usually the real message of the dream.",
  'ar':
      'الأحلام غالباً تمزج أفكار اليوم وذكرياته ومشاعره. انتبه إلى الشعور الأبرز فيها، فهو عادةً الرسالة الحقيقية للحلم.',
  'ckb':
      'خەونەکان زۆرجار بیرکردنەوە و بیرەوەری و هەستی ڕۆژ تێکەڵ دەکەن. سەرنج بدە کام هەست زیاتر دیار بوو؛ ئەوە زۆرجار پەیامی ڕاستەقینەی خەونەکەیە.',
};

const Map<String, List<String>> _moodNote = {
  'en': [
    'You woke up with heavy feelings, so be kind to yourself today — talking it through with someone you trust can lighten it.',
    'A calm mood suggests this dream was more about processing the day than sending a strong message.',
    'You woke up feeling good — the dream likely carries encouraging energy you can take into your day.',
  ],
  'ar': [
    'استيقظت بمشاعر ثقيلة، فكن لطيفاً مع نفسك اليوم، والحديث مع شخص تثق به قد يخفف عنك.',
    'المزاج الهادئ يوحي بأن الحلم كان لمعالجة أحداث اليوم أكثر منه رسالة قوية.',
    'استيقظت بشعور جيد، وغالباً يحمل الحلم طاقة مشجعة يمكنك أخذها معك في يومك.',
  ],
  'ckb': [
    'بە هەستی قورس هەستایت، ئەمڕۆ میهرەبان بە لەگەڵ خۆت؛ قسەکردن لەگەڵ کەسێکی متمانەپێکراو دەتوانێت سووکی بکات.',
    'دۆخی ئارام ئاماژەیە بۆ ئەوەی خەونەکە زیاتر بۆ پڕۆسێسکردنی ڕۆژ بووە نەک پەیامێکی بەهێز.',
    'بە هەستێکی باش هەستایت؛ خەونەکە ئەگەر وزەیەکی هاندەر هەڵگرتبێت دەتوانیت لە ڕۆژەکەتدا بەکاری بهێنیت.',
  ],
};

class AiService {
  static const String _textUrl = 'https://text.pollinations.ai/';
  static const String _imgUrl = 'https://image.pollinations.ai/prompt/';

  static const List<String> _moodNames = [
    '', 'nightmare', 'sad', 'neutral', 'good', 'amazing'
  ];

  static String _langName(String lang) => lang == 'ar'
      ? 'Arabic'
      : lang == 'ckb'
          ? 'Central Kurdish (Sorani, written in Arabic script)'
          : 'English';

  static String _clean(String s) {
    var t = s.trim();
    t = t.replaceAll(
        RegExp(r'\n*-{3,}\s*\n.*pollinations.*$',
            dotAll: true, caseSensitive: false),
        '');
    t = t.replaceAll('**', '').replaceAll(RegExp(r'^#+\s*', multiLine: true), '');
    return t.trim();
  }

  static Future<String> _chat(String system, String user,
      {int seconds = 45}) async {
    final res = await http
        .post(
          Uri.parse(_textUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'model': 'openai',
            'private': true,
            'messages': [
              {'role': 'system', 'content': system},
              {'role': 'user', 'content': user},
            ],
          }),
        )
        .timeout(Duration(seconds: seconds));
    if (res.statusCode != 200) throw Exception('http ${res.statusCode}');
    final body = utf8.decode(res.bodyBytes).trim();
    if (body.isEmpty) throw Exception('empty');
    if (body.startsWith('{') && body.contains('"error"')) {
      throw Exception('api error');
    }
    return body;
  }

  static Future<AiResult> interpret({
    required String title,
    required String content,
    required String lang,
    required int mood,
  }) async {
    final system =
        'You are a warm, insightful dream interpreter. Reply ONLY in ${_langName(lang)}. '
        'Structure: 1) the main symbols and what they may mean, 2) the emotional meaning considering the mood after waking, '
        '3) one gentle suggestion. Max 180 words. Plain text only: no markdown, no asterisks, no headings. '
        'Be kind and never alarming. This is for reflection, not professional advice.';
    final user =
        'Dream title: $title\nMood after waking: ${_moodNames[mood.clamp(1, 5)]}\nDream: $content';
    try {
      final t = _clean(await _chat(system, user));
      if (t.isEmpty) throw Exception('empty');
      return AiResult(t, true);
    } catch (_) {
      return AiResult(_local(title, content, lang, mood), false);
    }
  }

  static String _local(String title, String content, String lang, int mood) {
    final l = _intro.containsKey(lang) ? lang : 'en';
    final text = '$title $content'.toLowerCase();
    final matched = <String>[];
    for (final s in _syms) {
      if (s.keys.any((k) => text.contains(k.toLowerCase()))) {
        matched.add(s.text[l]!);
        if (matched.length >= 3) break;
      }
    }
    final notes = _moodNote[l]!;
    final note = mood <= 2 ? notes[0] : (mood == 3 ? notes[1] : notes[2]);
    final body = matched.isEmpty ? _generic[l]! : matched.join('\n\n');
    return '${_intro[l]}\n\n$body\n\n$note';
  }

  static bool _ascii(String s) => RegExp(r'^[\x00-\x7F]+$').hasMatch(s);

  static Future<bool> generateImage({
    required String title,
    required String content,
    required String savePath,
  }) async {
    String prompt;
    final src = '$title. $content'.trim();
    try {
      prompt = _clean(await _chat(
        'You write short English image-generation prompts. Output ONLY the prompt, max 45 words, no quotes. '
        'Style: dreamlike, surreal, cinematic, painterly, soft glowing light.',
        'Dream: $src',
        seconds: 25,
      ));
      if (prompt.isEmpty) throw Exception('empty');
    } catch (_) {
      final short = src.length > 200 ? src.substring(0, 200) : src;
      prompt = _ascii(short) && short.isNotEmpty
          ? short
          : 'a surreal dreamlike scene under a starry night sky';
    }
    prompt = '$prompt, ethereal dreamscape, highly detailed, cinematic lighting';
    if (prompt.length > 450) prompt = prompt.substring(0, 450);
    final seed = math.Random().nextInt(1 << 30);
    final uri = Uri.parse(
        '$_imgUrl${Uri.encodeComponent(prompt)}?width=768&height=768&nologo=true&model=flux&seed=$seed');
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 90));
      final ct = res.headers['content-type'] ?? '';
      if (res.statusCode == 200 &&
          ct.startsWith('image') &&
          res.bodyBytes.length > 2000) {
        await File(savePath).writeAsBytes(res.bodyBytes, flush: true);
        return true;
      }
    } catch (_) {}
    return false;
  }
}
