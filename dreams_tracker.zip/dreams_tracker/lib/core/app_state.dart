import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'achievements.dart';
import 'models.dart';
import 'strings.dart';

class AppState extends ChangeNotifier {
  late SharedPreferences _prefs;
  late Directory _docs;

  List<Dream> dreams = [];
  String lang = 'ar';
  String themeId = 'space';
  bool dark = true;
  bool bioLock = false;
  bool locked = false;
  bool ready = false;
  int aiCount = 0;
  int imgCount = 0;
  String? userName;
  String? userEmail;
  String? userPhoto;
  Set<String> unlocked = {};

  bool authenticating = false;
  bool _external = false;

  final StreamController<AchievementDef> _unlockCtrl =
      StreamController<AchievementDef>.broadcast();
  Stream<AchievementDef> get unlockStream => _unlockCtrl.stream;

  final GoogleSignIn _google = GoogleSignIn(scopes: ['email']);
  final LocalAuthentication _auth = LocalAuthentication();

  String tr(String key) => Strings.get(lang, key);
  String get docsPath => _docs.path;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _docs = await getApplicationDocumentsDirectory();
    for (final sub in ['audio', 'images']) {
      final d = Directory('${_docs.path}/$sub');
      if (!await d.exists()) await d.create(recursive: true);
    }
    lang = _prefs.getString('lang') ?? 'ar';
    themeId = _prefs.getString('theme') ?? 'space';
    dark = _prefs.getBool('dark') ?? true;
    bioLock = _prefs.getBool('bio') ?? false;
    aiCount = _prefs.getInt('aiCount') ?? 0;
    imgCount = _prefs.getInt('imgCount') ?? 0;
    unlocked = (_prefs.getStringList('unlocked') ?? <String>[]).toSet();
    userName = _prefs.getString('userName');
    userEmail = _prefs.getString('userEmail');
    userPhoto = _prefs.getString('userPhoto');

    final f = File('${_docs.path}/dreams.json');
    if (await f.exists()) {
      try {
        final raw = jsonDecode(await f.readAsString()) as List;
        dreams = raw
            .map((e) => Dream.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      } catch (_) {
        dreams = [];
      }
    }
    _sort();
    _checkAchievements(silent: true);
    locked = bioLock;
    ready = true;
    unawaited(_silentGoogle());
  }

  void _sort() => dreams.sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> _persist() async {
    try {
      final tmp = File('${_docs.path}/dreams.json.tmp');
      await tmp.writeAsString(jsonEncode(dreams.map((d) => d.toJson()).toList()),
          flush: true);
      await tmp.rename('${_docs.path}/dreams.json');
    } catch (_) {}
  }

  // ---------- files ----------
  String newId() => DateTime.now().microsecondsSinceEpoch.toString();
  String newFileRel(String folder, String ext) => '$folder/${newId()}.$ext';
  String? abs(String? rel) => rel == null ? null : '${_docs.path}/$rel';

  void _deleteFile(String? rel) {
    try {
      if (rel == null) return;
      final f = File('${_docs.path}/$rel');
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }

  // ---------- dreams ----------
  Dream? byId(String id) {
    for (final d in dreams) {
      if (d.id == id) return d;
    }
    return null;
  }

  Future<void> addDream(Dream d) async {
    dreams.add(d);
    _sort();
    _checkAchievements();
    notifyListeners();
    await _persist();
  }

  Future<void> updateDream(Dream d) async {
    final i = dreams.indexWhere((x) => x.id == d.id);
    if (i < 0) return;
    final old = dreams[i];
    if (old.image != null && old.image != d.image) _deleteFile(old.image);
    dreams[i] = d;
    _sort();
    _checkAchievements();
    notifyListeners();
    await _persist();
  }

  Future<void> deleteDream(String id) async {
    final d = byId(id);
    if (d == null) return;
    _deleteFile(d.audio);
    _deleteFile(d.image);
    dreams.removeWhere((x) => x.id == id);
    notifyListeners();
    await _persist();
  }

  Future<void> deleteAll() async {
    for (final d in dreams) {
      _deleteFile(d.audio);
      _deleteFile(d.image);
    }
    dreams = [];
    notifyListeners();
    await _persist();
  }

  // ---------- stats / achievements ----------
  int _streakCount() {
    final days = dreams
        .map((d) => DateTime(d.createdAt.year, d.createdAt.month, d.createdAt.day))
        .toSet();
    final now = DateTime.now();
    var day = DateTime(now.year, now.month, now.day);
    if (!days.contains(day)) day = DateTime(day.year, day.month, day.day - 1);
    var n = 0;
    while (days.contains(day)) {
      n++;
      day = DateTime(day.year, day.month, day.day - 1);
    }
    return n;
  }

  Stats get stats {
    final now = DateTime.now();
    return Stats(
      total: dreams.length,
      voice: dreams.where((d) => d.audio != null).length,
      streak: _streakCount(),
      moods: dreams.map((d) => d.mood).toSet().length,
      ai: aiCount,
      img: imgCount,
      month: dreams
          .where((d) =>
              d.createdAt.year == now.year && d.createdAt.month == now.month)
          .length,
    );
  }

  void _checkAchievements({bool silent = false}) {
    final s = stats;
    var changed = false;
    for (final a in kAchievements) {
      if (a.value(s) >= a.target && !unlocked.contains(a.id)) {
        unlocked.add(a.id);
        changed = true;
        if (!silent) _unlockCtrl.add(a);
      }
    }
    if (changed) _prefs.setStringList('unlocked', unlocked.toList());
  }

  void bumpAi() {
    aiCount++;
    _prefs.setInt('aiCount', aiCount);
    _checkAchievements();
    notifyListeners();
  }

  void bumpImg() {
    imgCount++;
    _prefs.setInt('imgCount', imgCount);
    _checkAchievements();
    notifyListeners();
  }

  // ---------- settings ----------
  void setLang(String v) {
    lang = v;
    _prefs.setString('lang', v);
    notifyListeners();
  }

  void setTheme(String v) {
    themeId = v;
    _prefs.setString('theme', v);
    notifyListeners();
  }

  void setDark(bool v) {
    dark = v;
    _prefs.setBool('dark', v);
    notifyListeners();
  }

  void setBio(bool v) {
    bioLock = v;
    _prefs.setBool('bio', v);
    if (!v) locked = false;
    notifyListeners();
  }

  // ---------- external activities (don't lock the app) ----------
  Future<T> external<T>(Future<T> Function() f) async {
    _external = true;
    try {
      return await f();
    } finally {
      Future.delayed(const Duration(milliseconds: 900), () => _external = false);
    }
  }

  // ---------- biometrics ----------
  Future<bool> canAuth() async {
    try {
      return await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  Future<bool> authenticate() async {
    if (authenticating) return false;
    authenticating = true;
    try {
      final supported = await _auth.isDeviceSupported();
      if (!supported) return true; // nothing to authenticate with: don't lock out
      return await _auth.authenticate(
        localizedReason: tr('unlock_reason'),
        options: const AuthenticationOptions(stickyAuth: true),
      );
    } catch (_) {
      return false;
    } finally {
      authenticating = false;
    }
  }

  Future<void> tryUnlock() async {
    if (!locked || authenticating) return;
    final ok = await authenticate();
    if (ok) {
      locked = false;
      notifyListeners();
    }
  }

  void onBackground() {
    if (bioLock && !authenticating && !_external && !locked) {
      locked = true;
      notifyListeners();
    }
  }

  // ---------- Google ----------
  Future<void> _silentGoogle() async {
    try {
      final a = await _google.signInSilently().timeout(const Duration(seconds: 5));
      if (a != null) _setUser(a);
    } catch (_) {}
  }

  void _setUser(GoogleSignInAccount a) {
    userName = a.displayName ?? a.email;
    userEmail = a.email;
    userPhoto = a.photoUrl;
    _prefs.setString('userName', userName!);
    _prefs.setString('userEmail', userEmail!);
    if (userPhoto != null) {
      _prefs.setString('userPhoto', userPhoto!);
    } else {
      _prefs.remove('userPhoto');
    }
    notifyListeners();
  }

  /// returns null on success/cancel, otherwise an error marker.
  Future<String?> googleSignIn() async {
    try {
      final a = await external(() => _google.signIn());
      if (a == null) return null;
      _setUser(a);
      return null;
    } catch (e) {
      return 'error';
    }
  }

  Future<void> googleSignOut() async {
    try {
      await _google.signOut();
    } catch (_) {}
    userName = null;
    userEmail = null;
    userPhoto = null;
    _prefs.remove('userName');
    _prefs.remove('userEmail');
    _prefs.remove('userPhoto');
    notifyListeners();
  }
}
