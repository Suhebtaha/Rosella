import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  /// small grey line under the label (e.g. the current view)
  final String? subtitle;
  /// when set, the row opens an inline sub-list (with a small arrow) instead of running onTap
  final List<MenuAction>? children;
  /// shows a check mark (used for the options of a sub-list)
  final bool selected;
  const MenuAction(this.icon, this.label, this.onTap,
      {this.subtitle, this.children, this.selected = false});
}

/// A card that opens from the top corner (below the ⋮ button): two big tiles, a list and a footer.
Future<void> showPopupCard(
  BuildContext context, {
  required List<MenuAction> tiles,
  required List<MenuAction> rows,
  String? footer,
}) {
  final rtl = Directionality.of(context) == TextDirection.rtl;
  final top = MediaQuery.paddingOf(context).top + 66;
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.black.withOpacity(0.28),
    transitionDuration: const Duration(milliseconds: 200),
    pageBuilder: (ctx, _, __) {
      final c = ctx.colors;
      // frosted glass: tiles are slightly lighter / darker veils over the blurred card
      final inner = c.isDark ? const Color(0x14FFFFFF) : const Color(0x66FFFFFF);
      void run(VoidCallback f) {
        Haptics.selection();
        Navigator.of(ctx).pop();
        f();
      }

      int? open;
      Widget row(MenuAction r, {required VoidCallback onTap, bool expanded = false}) => Pressable(
            scale: 0.99,
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Icon(r.icon, color: c.text, size: 22),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(r.label,
                            style: TextStyle(
                                color: c.text, fontSize: 15.5, fontWeight: FontWeight.w700)),
                        if (r.subtitle != null)
                          Text(r.subtitle!,
                              style: TextStyle(color: c.dim, fontSize: 12.5)),
                      ],
                    ),
                  ),
                  if (r.children != null)
                    AnimatedRotation(
                      turns: expanded ? 0.25 : (Directionality.of(ctx) == TextDirection.rtl ? 0.5 : 0),
                      duration: const Duration(milliseconds: 220),
                      child: Icon(Icons.chevron_right_rounded, color: c.dim, size: 22),
                    ),
                ],
              ),
            ),
          );

      return StatefulBuilder(builder: (ctx, setS) => Align(
        alignment: AlignmentDirectional.topEnd,
        child: Padding(
          padding: EdgeInsetsDirectional.only(top: top, end: 16, start: 16),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 330),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(color: Color(0x55000000), blurRadius: 24, offset: Offset(0, 10)),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: const Color(0x38FFFFFF), width: 1),
                      // a dark, slightly coloured veil: the blur shows the page colours through it
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: c.isDark
                            ? [
                                Color.alphaBlend(al(c.a, 0.20), const Color(0xB2101014)),
                                Color.alphaBlend(al(c.b, 0.12), const Color(0xCC08080B)),
                              ]
                            : [
                                Color.alphaBlend(al(c.a, 0.14), const Color(0xCCFFFFFF)),
                                const Color(0xAAFFFFFF),
                              ],
                      ),
                    ),
                    // Material gives the texts the right style (without it they get yellow underlines)
                    child: Material(
                      type: MaterialType.transparency,
                      child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        for (var i = 0; i < tiles.length; i++) ...[
                          if (i > 0) const SizedBox(width: 8),
                          Expanded(
                            child: Pressable(
                              scale: 0.97,
                              onTap: () => run(tiles[i].onTap),
                              child: Container(
                                height: 76,
                                decoration: BoxDecoration(
                                    color: inner, borderRadius: BorderRadius.circular(22)),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(tiles[i].icon, color: c.text, size: 26),
                                    const SizedBox(height: 6),
                                    Text(tiles[i].label,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 12.5,
                                            fontWeight: FontWeight.w700)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 8),
                    AnimatedSize(
                      duration: const Duration(milliseconds: 260),
                      curve: Curves.easeOutCubic,
                      alignment: Alignment.topCenter,
                      child: Container(
                        decoration: BoxDecoration(
                            color: inner, borderRadius: BorderRadius.circular(22)),
                        child: Column(
                            key: ValueKey(open),
                            children: open == null
                                ? [
                                    for (var i = 0; i < rows.length; i++) ...[
                                      if (i > 0)
                                        Divider(
                                            height: 1,
                                            indent: 14,
                                            endIndent: 14,
                                            color: al(c.text, 0.10)),
                                      row(rows[i], onTap: () {
                                        if (rows[i].children != null) {
                                          Haptics.selection();
                                          setS(() => open = i);
                                        } else {
                                          run(rows[i].onTap);
                                        }
                                      }),
                                    ],
                                  ]
                                : [
                                    row(rows[open!], expanded: true, onTap: () {
                                      Haptics.selection();
                                      setS(() => open = null);
                                    }),
                                    Divider(
                                        height: 1,
                                        indent: 14,
                                        endIndent: 14,
                                        color: al(c.text, 0.10)),
                                    for (final o in rows[open!].children!)
                                      Pressable(
                                        scale: 0.99,
                                        onTap: () => run(o.onTap),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 18, vertical: 14),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(o.label,
                                                    style: TextStyle(
                                                        color: c.text,
                                                        fontSize: 15.5,
                                                        fontWeight: FontWeight.w700)),
                                              ),
                                              if (o.selected)
                                                Icon(Icons.check_rounded,
                                                    color: c.text, size: 20),
                                            ],
                                          ),
                                        ),
                                      ),
                                  ],
                        ),
                      ),
                    ),
                    if (footer != null)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 10, 8, 4),
                        child: Text(footer,
                            style: TextStyle(color: c.dim, fontSize: 12.5)),
                      ),
                  ],
                ),
              ),
            ),
                    ),
                ),
              ),
            ),
          ),
        ),
      ));
    },
    transitionBuilder: (ctx, anim, _, child) {
      final curved = CurvedAnimation(
          parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
      // No FadeTransition here: fading a BackdropFilter makes the blur flash and snap.
      // Only scale, so the blur is always the same strength.
      return ScaleTransition(
        scale: Tween<double>(begin: 0.88, end: 1).animate(curved),
        alignment: Alignment(rtl ? -0.9 : 0.9, -1),
        child: child,
      );
    },
  );
}
