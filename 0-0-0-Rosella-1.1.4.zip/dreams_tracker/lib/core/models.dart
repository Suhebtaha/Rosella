class Dream {
  final String id;
  final String title;
  final String content;
  final DateTime createdAt;
  final int mood; // 1..5
  final String? audio; // relative path
  final int audioMs;
  final String? image; // relative path
  final String? interpretation;
  final bool lucid;
  final List<Map<String, dynamic>> chat; // saved AI conversation: {u: bool, t: text}

  const Dream({
    required this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    this.mood = 3,
    this.audio,
    this.audioMs = 0,
    this.image,
    this.interpretation,
    this.lucid = false,
    this.chat = const [],
  });

  static const Object _keep = Object();

  Dream copyWith({
    String? title,
    String? content,
    DateTime? createdAt,
    int? mood,
    Object? audio = _keep,
    int? audioMs,
    Object? image = _keep,
    Object? interpretation = _keep,
    bool? lucid,
    List<Map<String, dynamic>>? chat,
  }) {
    return Dream(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      mood: mood ?? this.mood,
      audio: identical(audio, _keep) ? this.audio : audio as String?,
      audioMs: audioMs ?? this.audioMs,
      image: identical(image, _keep) ? this.image : image as String?,
      interpretation: identical(interpretation, _keep)
          ? this.interpretation
          : interpretation as String?,
      lucid: lucid ?? this.lucid,
      chat: chat ?? this.chat,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
        'mood': mood,
        'audio': audio,
        'audioMs': audioMs,
        'image': image,
        'interpretation': interpretation,
        'lucid': lucid,
        if (chat.isNotEmpty) 'chat': chat,
      };

  factory Dream.fromJson(Map<String, dynamic> j) => Dream(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? '',
        content: (j['content'] as String?) ?? '',
        createdAt: DateTime.tryParse((j['createdAt'] as String?) ?? '') ??
            DateTime.now(),
        mood: (j['mood'] as num?)?.toInt() ?? 3,
        audio: j['audio'] as String?,
        audioMs: (j['audioMs'] as num?)?.toInt() ?? 0,
        image: j['image'] as String?,
        interpretation: j['interpretation'] as String?,
        lucid: j['lucid'] == true,
        chat: [
          for (final m in (j['chat'] as List? ?? const []))
            if (m is Map) Map<String, dynamic>.from(m)
        ],
      );
}
