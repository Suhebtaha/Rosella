import 'package:flutter/material.dart';

/// Lets widgets that live above the Navigator (like the now-playing island)
/// switch the main tab and close any open page.
final GlobalKey<NavigatorState> rootNavKey = GlobalKey<NavigatorState>();

/// Tab index requested from outside the Shell (-1 = none).
final ValueNotifier<int> tabRequest = ValueNotifier<int>(-1);

/// true while the splash screen is showing (overlays hide themselves then).
final ValueNotifier<bool> splashShowing = ValueNotifier<bool>(true);

void openTab(int i) {
  rootNavKey.currentState?.popUntil((r) => r.isFirst);
  tabRequest.value = -1;
  tabRequest.value = i;
}
