import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../services/update_check.dart';
import 'widgets.dart';

/// In-app update: downloads the APK from the GitHub release and opens the system installer.
Future<void> showUpdateDialog(BuildContext context, UpdateInfo info) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _UpdateDialog(info: info),
  );
}

enum _St { idle, downloading, perm, error }

class _UpdateDialog extends StatefulWidget {
  final UpdateInfo info;
  const _UpdateDialog({required this.info});

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  _St _st = _St.idle;
  double _p = 0;
  String _err = '';

  Future<void> _go() async {
    final apk = widget.info.apkUrl;
    if (apk.isEmpty) {
      await _github();
      return;
    }
    setState(() {
      _st = _St.downloading;
      _p = 0;
    });
    try {
      final path = await UpdateCheck.download(apk, (v) {
        if (mounted) setState(() => _p = v);
      });
      if (!mounted) return;
      final r = await UpdateCheck.install(path);
      if (!mounted) return;
      if (r == 'ok') {
        Navigator.of(context).pop();
      } else if (r == 'perm') {
        setState(() => _st = _St.perm);
      } else {
        setState(() {
          _st = _St.error;
          _err = 'install';
        });
      }
    } catch (e) {
      if (!mounted) return;
      final m = e.toString().replaceAll('Exception: ', '');
      setState(() {
        _st = _St.error;
        _err = m.length > 70 ? m.substring(0, 70) : m;
      });
    }
  }

  Future<void> _github() async {
    final url = widget.info.url.isEmpty ? kReleasesPage : widget.info.url;
    final ok = await UpdateCheck.open(url);
    if (!ok) {
      await Clipboard.setData(ClipboardData(text: url));
      if (mounted) toast(context, context.t('copied'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final busy = _st == _St.downloading;
    String msg;
    switch (_st) {
      case _St.idle:
        msg = context.t('update_msg2');
        break;
      case _St.downloading:
        msg = '${context.t('downloading')} ${(100 * _p).round()}%';
        break;
      case _St.perm:
        msg = context.t('update_perm');
        break;
      case _St.error:
        msg = '${context.t('update_error')}\n$_err';
        break;
    }
    return PopScope(
      canPop: !busy,
      child: AlertDialog(
        backgroundColor: c.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(26),
          side: BorderSide(color: c.border),
        ),
        title: Text('${context.t('update_available')} ${widget.info.tag}',
            style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(msg, style: TextStyle(color: c.dim, height: 1.5)),
            if (busy) ...[
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: _p > 0 ? _p : null,
                  minHeight: 8,
                  color: c.a,
                  backgroundColor: c.surfaceHi,
                ),
              ),
            ],
          ],
        ),
        actions: busy
            ? const []
            : [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(context.t('cancel'), style: TextStyle(color: c.dim)),
                ),
                if (_st != _St.idle)
                  TextButton(
                    onPressed: _github,
                    child: Text(context.t('open_github'), style: TextStyle(color: c.dim)),
                  ),
                TextButton(
                  onPressed: _go,
                  child: Text(
                    _st == _St.idle ? context.t('update_now') : context.t('try_again'),
                    style: TextStyle(color: c.a, fontWeight: FontWeight.w800),
                  ),
                ),
              ],
      ),
    );
  }
}
