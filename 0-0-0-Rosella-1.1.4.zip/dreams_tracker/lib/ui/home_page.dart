import 'dart:math' as math;

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'chats_page.dart';
import 'dream_detail.dart';
import 'dream_editor.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _search = TextEditingController();
  String _q = '';
  int? _mood;
  int _range = 0; // 0 all, 1 week, 2 month, 3 year
  final Set<String> _sel = {};

  void _toggle(String id) {
    Haptics.selection();
    setState(() {
      if (!_sel.remove(id)) _sel.add(id);
    });
  }

  void _startSelect(String id) {
    Haptics.medium();
    setState(() => _sel.add(id));
  }

  void _openDream(String id) => Navigator.of(context)
      .push(CupertinoPageRoute<void>(builder: (_) => DreamDetailPage(id: id)));

  Future<void> _deleteSel() async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_selected'),
      message: app.tr('delete_selected_msg'),
      confirm: app.tr('delete'),
    );
    if (!ok) return;
    await app.deleteMany(Set<String>.from(_sel));
    if (mounted) setState(_sel.clear);
  }

  Widget _selBar(AppState app, List<Dream> list) {
    final c = context.colors;
    return Row(
      children: [
        RoundIconButton(icon: Icons.close_rounded, onTap: () => setState(_sel.clear)),
        const SizedBox(width: 12),
        Expanded(
          child: Text('${_sel.length} ${app.tr('selected_n')}',
              style: TextStyle(color: c.text, fontSize: 22, fontWeight: FontWeight.w800)),
        ),
        RoundIconButton(
          icon: Icons.select_all_rounded,
          onTap: () => setState(() {
            _sel
              ..clear()
              ..addAll(list.map((d) => d.id));
          }),
        ),
        const SizedBox(width: 8),
        RoundIconButton(
          icon: Icons.delete_outline_rounded,
          color: const Color(0xFFFF5470),
          onTap: _deleteSel,
        ),
      ],
    );
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _openEditor() {
    Navigator.of(context)
        .push(CupertinoPageRoute<void>(builder: (_) => const DreamEditorPage()));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final q = _q.trim().toLowerCase();
    final list = app.dreams.where((d) {
      if (_mood != null && d.mood != _mood) return false;
      if (_range > 0) {
        final days = const [0, 7, 30, 365][_range];
        if (DateTime.now().difference(d.createdAt).inDays >= days) return false;
      }
      if (q.isEmpty) return true;
      return d.title.toLowerCase().contains(q) || d.content.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 16, 12),
              child: _sel.isNotEmpty ? _selBar(app, list) : Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.t('home_title'),
                            style: TextStyle(
                                color: c.text,
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.5)),
                        const SizedBox(height: 2),
                        Text('${app.dreams.length} ${context.t('dreams_count')}',
                            style: TextStyle(color: c.dim, fontSize: 14)),
                      ],
                    ),
                  ),
                  if (app.dreams.any((d) => d.chat.isNotEmpty)) ...[
                    RoundIconButton(
                      icon: Icons.forum_rounded,
                      onTap: () => Navigator.of(context).push(
                          CupertinoPageRoute<void>(builder: (_) => const ChatsPage())),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Pressable(
                    onTap: _openEditor,
                    scale: 0.9,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: c.gradient,
                        boxShadow: [
                          BoxShadow(color: al(c.a, 0.35), blurRadius: 16, offset: const Offset(0, 6)),
                        ],
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Panel(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                radius: 18,
                child: Row(
                  children: [
                    Icon(Icons.search_rounded, color: c.dim),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _search,
                        onChanged: (v) => setState(() => _q = v),
                        style: TextStyle(color: c.text, fontSize: 16),
                        decoration: bareInput(context, context.t('search_hint')),
                      ),
                    ),
                    if (_q.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          _search.clear();
                          setState(() => _q = '');
                        },
                        child: Icon(Icons.close_rounded, color: c.dim, size: 20),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: SizedBox(
                height: 38,
                child: Row(
                  children: [
                    Expanded(
                      flex: 13,
                      child: _FilterChip(
                        label: context.t('filter_all'),
                        selected: _mood == null,
                        onTap: () => setState(() => _mood = null),
                      ),
                    ),
                    for (var m = 1; m <= 5; m++)
                      Expanded(
                        flex: 10,
                        child: _FilterChip(
                          label: moodEmoji(m),
                          selected: _mood == m,
                          onTap: () => setState(() => _mood = _mood == m ? null : m),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: SizedBox(
                height: 36,
                child: Row(
                  children: [
                    for (var r = 0; r < 4; r++)
                      Expanded(
                        child: _FilterChip(
                          label: context.t(const ['filter_all', 'range_week', 'range_month', 'range_year'][r]),
                          selected: _range == r,
                          onTap: () => setState(() => _range = r),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          if (list.isEmpty)
            SliverToBoxAdapter(child: _Empty(onWrite: _openEditor))
          else if (app.cardStyle == 'grid')
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1,
                ),
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) => FadeSlide(
                    key: ValueKey(list[i].id),
                    delay: math.min(i, 6) * 45,
                    child: _DreamTile(
                      dream: list[i],
                      selecting: _sel.isNotEmpty,
                      selected: _sel.contains(list[i].id),
                      onTap: () =>
                          _sel.isNotEmpty ? _toggle(list[i].id) : _openDream(list[i].id),
                      onLongPress: () => _sel.isNotEmpty
                          ? _toggle(list[i].id)
                          : _startSelect(list[i].id),
                    ),
                  ),
                  childCount: list.length,
                ),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => Padding(
                  key: ValueKey(list[i].id),
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: FadeSlide(
                    delay: math.min(i, 6) * 45,
                    child: _DreamCard(
                      dream: list[i],
                      selecting: _sel.isNotEmpty,
                      selected: _sel.contains(list[i].id),
                      onTap: () =>
                          _sel.isNotEmpty ? _toggle(list[i].id) : _openDream(list[i].id),
                      onLongPress: () => _sel.isNotEmpty
                          ? _toggle(list[i].id)
                          : _startSelect(list[i].id),
                    ),
                  ),
                ),
                childCount: list.length,
              ),
            ),
          SliverToBoxAdapter(child: SizedBox(height: navPadding(context))),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: Pressable(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 4),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: selected
                ? c.gradient
                : flatGradient(al(c.surface, c.isDark ? 0.7 : 0.9)),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: selected ? Colors.transparent : c.border),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : c.text,
              fontWeight: FontWeight.w700,
              fontSize: 14.5,
            ),
          ),
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final VoidCallback onWrite;
  const _Empty({required this.onWrite});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 60, 32, 0),
      child: Column(
        children: [
          Container(
            width: 104,
            height: 104,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(c.a, 0.12),
              border: Border.all(color: al(c.a, 0.3)),
            ),
            child: Icon(Icons.nights_stay_rounded, size: 50, color: c.a),
          ),
          const SizedBox(height: 22),
          Text(context.t('empty_title'),
              style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(context.t('empty_sub'),
              textAlign: TextAlign.center,
              style: TextStyle(color: c.dim, fontSize: 14.5, height: 1.5)),
          const SizedBox(height: 22),
          GradientButton(
              label: context.t('write_dream'), icon: Icons.edit_rounded, onTap: onWrite),
        ],
      ),
    );
  }
}

class _SelCheck extends StatelessWidget {
  final bool selected;
  final double size;
  const _SelCheck({required this.selected, this.size = 26});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: selected ? c.gradient : flatGradient(al(Colors.black, 0.25)),
        border: Border.all(color: selected ? Colors.transparent : al(Colors.white, 0.8), width: 2),
      ),
      child: selected
          ? Icon(Icons.check_rounded, size: size * 0.66, color: onAccent(c.a, c.b))
          : null,
    );
  }
}

class _DreamTile extends StatelessWidget {
  final Dream dream;
  final bool selecting;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _DreamTile({
    required this.dream,
    required this.selecting,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final app = context.read<AppState>();
    final lang = context.select<AppState, String>((s) => s.lang);
    final d = dream;
    final img = app.abs(d.image);
    final hasImg = img != null;
    final fg = hasImg ? Colors.white : c.text;
    final title = d.title.isEmpty
        ? (d.content.trim().isEmpty ? fmtDate(d.createdAt, lang) : d.content.trim())
        : d.title;
    return Pressable(
      onTap: onTap,
      onLongPress: onLongPress,
      scale: 0.96,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [al(moodColor(d.mood), 0.38), al(c.surface, 0.9)],
          ),
          border: Border.all(
              color: selected ? c.a : c.border, width: selected ? 3 : 1),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (hasImg)
              Image.file(File(img),
                  fit: BoxFit.cover,
                  cacheWidth: 520,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            if (hasImg)
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0x33000000), Color(0x00000000), Color(0xCC000000)],
                    stops: [0, 0.4, 1],
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: al(hasImg ? Colors.black : moodColor(d.mood),
                              hasImg ? 0.35 : 0.22),
                        ),
                        child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 20)),
                      ),
                      const Spacer(),
                      if (d.audio != null) _TileBadge(Icons.mic_rounded, fg),
                      if (d.interpretation != null)
                        _TileBadge(Icons.auto_awesome_rounded, fg),
                    ],
                  ),
                  const Spacer(),
                  if (d.lucid) ...[
                    const LucidTag(compact: true, onDark: true),
                    const SizedBox(height: 6),
                  ],
                  Text(title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: fg, fontSize: 15.5, fontWeight: FontWeight.w800, height: 1.25)),
                  const SizedBox(height: 4),
                  Text(fmtDate(d.createdAt, lang),
                      style: TextStyle(color: al(fg, 0.75), fontSize: 11.5)),
                ],
              ),
            ),
            if (selecting)
              PositionedDirectional(
                top: 10,
                end: 10,
                child: _SelCheck(selected: selected),
              ),
          ],
        ),
      ),
    );
  }
}

class _TileBadge extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _TileBadge(this.icon, this.color);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6),
        child: Icon(icon, size: 16, color: al(color, 0.9)),
      );
}

class _DreamCard extends StatelessWidget {
  final Dream dream;
  final bool selecting;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _DreamCard({
    required this.dream,
    required this.selecting,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final lang = context.select<AppState, String>((s) => s.lang);
    final d = dream;
    final preview = d.content.trim().isEmpty && d.audio != null
        ? context.t('voice_recording')
        : d.content.trim();
    final title = d.title.isEmpty ? fmtDate(d.createdAt, lang) : d.title;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
            color: selected ? c.a : Colors.transparent, width: selected ? 2.5 : 0),
      ),
      child: Panel(
      onTap: onTap,
      onLongPress: onLongPress,
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (selecting) ...[
            Padding(
              padding: const EdgeInsets.only(top: 11),
              child: _SelCheck(selected: selected),
            ),
            const SizedBox(width: 12),
          ],
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(moodColor(d.mood), 0.18),
            ),
            child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: c.text, fontSize: 16.5, fontWeight: FontWeight.w700)),
                    ),
                    if (d.audio != null) _Badge(Icons.mic_rounded),
                    if (d.image != null) _Badge(Icons.image_rounded),
                    if (d.interpretation != null) _Badge(Icons.auto_awesome_rounded),
                  ],
                ),
                if (d.lucid) ...[
                  const SizedBox(height: 6),
                  const LucidTag(compact: true),
                ],
                if (preview.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(preview,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: c.dim, fontSize: 14, height: 1.4)),
                ],
                const SizedBox(height: 8),
                Text('${fmtDate(d.createdAt, lang)} • ${fmtTime(d.createdAt)}',
                    style: TextStyle(color: al(c.dim, 0.8), fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  const _Badge(this.icon);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6),
        child: Icon(icon, size: 15, color: context.colors.a),
      );
}
