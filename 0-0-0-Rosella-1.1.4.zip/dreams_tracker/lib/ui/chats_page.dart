import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'dream_chat.dart';
import 'widgets.dart';

/// All saved AI conversations, one per dream.
class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final list = app.dreams.where((d) => d.chat.isNotEmpty).toList();
    return PageScaffold(
      child: Column(
        children: [
          TopBar(title: context.t('chats_title')),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.forum_rounded, size: 48, color: c.a),
                          const SizedBox(height: 14),
                          Text(context.t('chats_empty'),
                              textAlign: TextAlign.center,
                              style: TextStyle(color: c.dim, fontSize: 15, height: 1.5)),
                        ],
                      ),
                    ),
                  )
                : ListView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                    children: [
                      for (final d in list)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Panel(
                            onTap: () => Navigator.of(context).push(CupertinoPageRoute<void>(
                                builder: (_) => DreamChatPage(id: d.id))),
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Icon(Icons.forum_rounded, color: c.a),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        d.title.isEmpty ? fmtDate(d.createdAt, app.lang) : d.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: c.text,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w800),
                                      ),
                                      const SizedBox(height: 4),
                                      Text((d.chat.last['t'] ?? '').toString(),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: c.dim, fontSize: 13.5, height: 1.4)),
                                      const SizedBox(height: 6),
                                      Text('${d.chat.length} ${context.t('chat_msgs')}',
                                          style: TextStyle(
                                              color: al(c.dim, 0.8), fontSize: 12)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
