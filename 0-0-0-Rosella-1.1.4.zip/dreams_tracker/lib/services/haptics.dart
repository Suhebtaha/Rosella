import 'package:flutter/services.dart';

/// App-wide tactile feedback.
///
/// Drives the phone's vibration motor directly (native), so it works on every
/// phone and even when "touch vibration / haptic feedback" is switched off in
/// the system settings. If the native side is unavailable it falls back to the
/// normal system haptics.
class Haptics {
  /// 0 off, 1 light, 2 medium, 3 strong
  static int level = 2;

  /// true = drive the vibration motor directly (ignores the system touch-feedback setting)
  /// false = use the phone's own haptic engine (respects the system setting)
  static bool motor = true;

  static const MethodChannel _ch = MethodChannel('rosella/haptic');
  static int _last = 0;

  // base pulse for each strength level
  static const List<int> _ms = [0, 22, 36, 60];
  static const List<int> _amp = [0, 90, 170, 255];
  // how much each kind of event scales the base pulse
  static const List<double> _kind = [0.6, 0.9, 1.15, 1.5];

  static void selection() => _fire(0);
  static void light() => _fire(1);
  static void medium() => _fire(2);
  static void heavy() => _fire(3);

  /// Plays a pulse for the settings test, ignoring the debounce.
  static void test() {
    _last = 0;
    _fire(2);
  }

  static void _fire(int kind) {
    if (level <= 0) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _last < 45) return; // several widgets can react to one touch
    _last = now;
    final lv = level.clamp(1, 3);
    final k = _kind[kind.clamp(0, 3)];
    final ms = (_ms[lv] * k).round().clamp(16, 140);
    final amp = (_amp[lv] * (k < 1 ? (0.6 + 0.4 * k) : 1.0)).round().clamp(20, 255);
    if (motor) {
      _buzz(ms, amp, kind);
    } else {
      _system(kind);
    }
  }

  static Future<void> _buzz(int ms, int amp, int kind) async {
    try {
      final ok = await _ch.invokeMethod<bool>('buzz', {'ms': ms, 'amp': amp});
      if (ok == true) return;
    } catch (_) {}
    _system(kind);
  }

  static Future<void> _system(int kind) async {
    try {
      switch (kind) {
        case 0:
          await HapticFeedback.selectionClick();
          break;
        case 1:
          await HapticFeedback.lightImpact();
          break;
        case 2:
          await HapticFeedback.mediumImpact();
          break;
        default:
          await HapticFeedback.heavyImpact();
      }
    } catch (_) {}
  }
}
