## Rosella 1.1.107

- New "+" button inside the bottom bar (circle in the theme colour) to add a dream.
- Full calendar page (open it from Insights): monthly view with mood colours, a streak line ("Logged N days in a row") and badges.
- Generating an image or an interpretation can now be cancelled; while an image is generating a black/white (per theme) frame with "Generating…" is shown, and the finished image fades in. The button has a moving "working" animation.
- Search by meaning is much faster: instant word results first, then a shorter AI query.
- "Restoring your dreams…" line on the home screen during the first restore.
- A small date line appears at the bottom while scrolling the dream list.
- Dream titles and text follow their own direction (Arabic dreams read right-to-left even in an English app).
- Close (X) button in the chats window and the chats drawer.
