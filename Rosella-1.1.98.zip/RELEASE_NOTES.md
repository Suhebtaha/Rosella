## Rosella 1.1.98

- Fixed the build error in the update sheet (missing helper functions).
- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.
