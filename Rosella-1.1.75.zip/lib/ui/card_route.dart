import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Opens a page by growing it out of the card that was tapped (and shrinking back into it on
/// return), like a container transform. [from] is the card's rectangle on screen.
class CardOpenRoute extends PageRouteBuilder<void> {
  CardOpenRoute({
    required Rect from,
    required Color color,
    required double radius,
    required WidgetBuilder builder,
  }) : super(
          opaque: false,
          transitionDuration: const Duration(milliseconds: 400),
          reverseTransitionDuration: const Duration(milliseconds: 320),
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, _, child) {
            final curved = CurvedAnimation(
              parent: animation,
              curve: Curves.fastOutSlowIn,
              reverseCurve: Curves.easeInOutCubic,
            );
            final size = MediaQuery.of(context).size;
            final full = Offset.zero & size;
            return AnimatedBuilder(
              animation: curved,
              builder: (_, __) {
                final v = curved.value;
                final rect = Rect.lerp(from, full, v)!;
                final r = lerpDouble(radius, 0, v.clamp(0.0, 1.0))!;
                // page content appears after the card has started to grow
                final fade = const Interval(0.12, 0.6, curve: Curves.easeOut).transform(animation.value);
                return Stack(
                  children: [
                    Positioned.fromRect(
                      rect: rect,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(r),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            ColoredBox(color: color),
                            OverflowBox(
                              alignment: Alignment.topCenter,
                              minWidth: size.width,
                              maxWidth: size.width,
                              minHeight: size.height,
                              maxHeight: size.height,
                              child: RepaintBoundary(child: child),
                            ),
                            // fade the card colour away instead of fading the whole page
                            // (an Opacity over a full page costs an extra layer every frame)
                            if (fade < 1)
                              IgnorePointer(
                                child: ColoredBox(color: color.withOpacity(1 - fade)),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            );
          },
        );
}

/// Global rectangle of the widget behind [context] (null if it is not laid out).
Rect? rectOf(BuildContext context) {
  final ro = context.findRenderObject();
  if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}
