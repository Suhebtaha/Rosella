import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/haptics.dart';
import 'widgets.dart';

class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  /// small grey line under the label
  final String? subtitle;
  /// colour of the icon square (defaults to the theme accent)
  final Color? color;
  /// small number in the corner of a tile
  final String? badge;
  /// marks the current option of a segmented switch
  final bool selected;
  /// when set, the row opens an inline list (slides open, the menu stays open)
  final List<MenuAction>? children;
  const MenuAction(this.icon, this.label, this.onTap,
      {this.subtitle, this.color, this.badge, this.selected = false, this.children});
}

/// A solid card that opens from the top corner (below the ⋮ button):
/// a header line, two big tiles, an optional segmented switch and a list of rows.
/// It is deliberately NOT a live blur: a BackdropFilter flashes while it fades and makes the animation heavy.
Future<void> showPopupCard(
  BuildContext context, {
  required List<MenuAction> tiles,
  required List<MenuAction> rows,
  String? footer,
  String? footerEnd,
  String? viewLabel,
  List<MenuAction>? views,
}) {
  final rtl = Directionality.of(context) == TextDirection.rtl;
  final top = MediaQuery.paddingOf(context).top + 66;
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.black.withOpacity(0.35),
    transitionDuration: const Duration(milliseconds: 340),
    pageBuilder: (ctx, _, __) {
      final c = ctx.colors;
      final card = c.isDark ? const Color(0xFF1C1C20) : c.surface;
      final inner = c.isDark ? const Color(0xFF232328) : c.surfaceHi;
      final line = al(c.text, c.isDark ? 0.08 : 0.10);
      void run(VoidCallback f) {
        Haptics.selection();
        Navigator.of(ctx).pop();
        f();
      }

      Widget square(MenuAction a, double size, double radius) {
        final base = a.color ?? c.a;
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color.lerp(base, Colors.white, 0.18)!, Color.lerp(base, Colors.black, 0.22)!],
            ),
            boxShadow: [BoxShadow(color: al(base, 0.35), blurRadius: 14, offset: const Offset(0, 4))],
          ),
          child: Icon(a.icon, color: Colors.white, size: size * 0.46),
        );
      }

      Widget tile(MenuAction a) => Expanded(
            child: Pressable(
              scale: 0.97,
              onTap: () => run(a.onTap),
              child: Container(
                height: 108,
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
                decoration: BoxDecoration(
                  color: inner,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        square(a, 42, 14),
                        const Spacer(),
                        if (a.badge != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                            decoration: BoxDecoration(
                                color: al(c.text, 0.10), borderRadius: BorderRadius.circular(12)),
                            child: Text(a.badge!,
                                style: TextStyle(
                                    color: c.text, fontSize: 12.5, fontWeight: FontWeight.w800)),
                          ),
                      ],
                    ),
                    const Spacer(),
                    Text(a.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: c.text, fontSize: 15.5, fontWeight: FontWeight.w800)),
                    if (a.subtitle != null)
                      Text(a.subtitle!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: c.dim, fontSize: 12)),
                  ],
                ),
              ),
            ),
          );

      int? viewSel; // current option of the segmented switch (kept inside the open menu)
      int? openRow; // row whose inline list is open
      final childSel = <int, int>{}; // chosen child per row

      return StatefulBuilder(builder: (ctx, setS) {
        if (viewSel == null) {
          final k = views?.indexWhere((v) => v.selected) ?? 0;
          viewSel = k < 0 ? 0 : k;
        }

        Widget rowTile(MenuAction a, int i, {String? sub}) {
          final hasKids = a.children != null;
          final isOpen = openRow == i;
          return Pressable(
            scale: 0.99,
            onTap: () {
              if (hasKids) {
                Haptics.selection();
                setS(() => openRow = isOpen ? null : i);
              } else {
                run(a.onTap);
              }
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(
                children: [
                  square(a, 38, 12),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: c.text, fontSize: 15, fontWeight: FontWeight.w800)),
                        if ((sub ?? a.subtitle) != null)
                          Text(sub ?? a.subtitle!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: c.dim, fontSize: 12)),
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: isOpen ? 0.25 : (rtl ? 0.5 : 0),
                    duration: const Duration(milliseconds: 240),
                    curve: Curves.easeOutCubic,
                    child: Icon(Icons.chevron_right_rounded, color: c.dim, size: 21),
                  ),
                ],
              ),
            ),
          );
        }

        Widget kids(MenuAction a, int i) {
          final cur = childSel[i] ?? a.children!.indexWhere((k) => k.selected);
          return ClipRect(
            child: AnimatedAlign(
              alignment: Alignment.topCenter,
              heightFactor: openRow == i ? 1 : 0,
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              child: AnimatedOpacity(
                opacity: openRow == i ? 1 : 0,
                duration: const Duration(milliseconds: 200),
                child: Column(
                  children: [
                    Divider(height: 1, indent: 12, endIndent: 12, color: line),
                    for (var k = 0; k < a.children!.length; k++)
                      Pressable(
                        scale: 0.99,
                        onTap: () {
                          Haptics.selection();
                          a.children![k].onTap();
                          setS(() => childSel[i] = k);
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                          child: Row(
                            children: [
                              Icon(a.children![k].icon,
                                  size: 18, color: cur == k ? c.text : c.dim),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(a.children![k].label,
                                    style: TextStyle(
                                        color: cur == k ? c.text : c.dim,
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w700)),
                              ),
                              if (cur == k) Icon(Icons.check_rounded, color: c.text, size: 19),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        }

        Widget segmented(List<MenuAction> v) {
          final fg = c.isDark ? const Color(0xFF16161A) : Colors.white;
          return Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: c.isDark ? const Color(0xFF111114) : al(c.text, 0.06),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: line),
            ),
            child: LayoutBuilder(builder: (ctx, cons) {
              final w = cons.maxWidth / v.length;
              return SizedBox(
                height: 38,
                child: Stack(
                  children: [
                    AnimatedPositionedDirectional(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOutCubic,
                      start: w * viewSel!,
                      top: 0,
                      bottom: 0,
                      width: w,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(17),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: c.isDark
                                ? const [Color(0xFFF2F2F5), Color(0xFFC9C9CF)]
                                : [c.a, c.b],
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        for (var i = 0; i < v.length; i++)
                          Expanded(
                            child: Pressable(
                              scale: 0.97,
                              onTap: () {
                                if (viewSel == i) return;
                                Haptics.selection();
                                setS(() => viewSel = i);
                                v[i].onTap(); // the menu stays open
                              },
                              child: Center(
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    AnimatedSwitcher(
                                      duration: const Duration(milliseconds: 200),
                                      child: Icon(v[i].icon,
                                          key: ValueKey(viewSel == i),
                                          size: 17,
                                          color: viewSel == i ? fg : c.dim),
                                    ),
                                    const SizedBox(width: 6),
                                    AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 200),
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                          color: viewSel == i ? fg : c.dim),
                                      child: Text(v[i].label),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              );
            }),
          );
        }

        return Align(
          alignment: AlignmentDirectional.topEnd,
          child: Padding(
            padding: EdgeInsetsDirectional.only(top: top, end: 14, start: 14),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 310),
              child: Material(
                color: card,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                  side: BorderSide(color: line),
                ),
                clipBehavior: Clip.antiAlias,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (footer != null || footerEnd != null)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(footer ?? '',
                                    style: TextStyle(
                                        color: c.dim, fontSize: 12.5, fontWeight: FontWeight.w700)),
                              ),
                              if (footerEnd != null)
                                Text(footerEnd,
                                    style: TextStyle(
                                        color: c.dim, fontSize: 12.5, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      Row(
                        children: [
                          for (var i = 0; i < tiles.length; i++) ...[
                            if (i > 0) const SizedBox(width: 8),
                            tile(tiles[i]),
                          ],
                        ],
                      ),
                      if (views != null) ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(8, 12, 8, 6),
                          child: Text((viewLabel ?? '').toUpperCase(),
                              style: TextStyle(
                                  color: c.dim,
                                  fontSize: 11.5,
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w800)),
                        ),
                        segmented(views),
                      ],
                      const SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: inner,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: line),
                        ),
                        child: Column(
                          children: [
                            for (var i = 0; i < rows.length; i++) ...[
                              if (i > 0) Divider(height: 1, color: line),
                              rowTile(rows[i], i,
                                  sub: rows[i].children != null && childSel[i] != null
                                      ? rows[i].children![childSel[i]!].label
                                      : null),
                              if (rows[i].children != null) kids(rows[i], i),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      });
    },
    transitionBuilder: (ctx, anim, _, child) {
      // grows out of the ⋮ button with a soft spring and shrinks back into it
      final curved = CurvedAnimation(
          parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeInCubic);
      final fade = CurvedAnimation(
          parent: anim,
          curve: const Interval(0.0, 0.55, curve: Curves.easeOut),
          reverseCurve: const Interval(0.35, 1.0, curve: Curves.easeIn));
      return FadeTransition(
        opacity: fade,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.2, end: 1).animate(curved),
          alignment: Alignment(rtl ? -0.93 : 0.93, -1),
          child: child,
        ),
      );
    },
  );
}
