## Rosella 1.1.123

- The ⋮ menu is now frosted glass: a blurred, translucent card with a thin light border.
- New calendar design: a big month title, a frosted card, mood-coloured rounded day tiles with a small bar under each, and a monthly mood legend.
- Profile feels alive: a slowly drifting glow, a turning gradient ring around your photo, and numbers that count up.
- Profile has more: this month / this year / average words, and your pinned dreams next to your favorites.
