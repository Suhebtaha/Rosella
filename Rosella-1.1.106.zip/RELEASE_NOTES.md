## Rosella 1.1.106

- Fixed the welcome title animation playing twice, and the title is now plain white.
- The flashes in the welcome animation are now black instead of violet.
- The "new chat" button in the general chat only shows when there is a conversation on screen.
