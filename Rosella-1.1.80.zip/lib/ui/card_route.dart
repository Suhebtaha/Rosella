import 'package:flutter/material.dart';

/// Opens a page by sliding it in from the right edge (and back out to the right), whatever the
/// text direction is. The old card-grow animation is gone. [from], [color] and [radius] are
/// kept only so existing callers keep compiling.
class CardOpenRoute extends PageRouteBuilder<void> {
  CardOpenRoute({
    Rect? from,
    Color? color,
    double radius = 0,
    required WidgetBuilder builder,
  }) : super(
          opaque: true,
          transitionDuration: const Duration(milliseconds: 340),
          reverseTransitionDuration: const Duration(milliseconds: 300),
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, secondary, child) {
            final slide = Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(
                CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                    reverseCurve: Curves.easeInCubic));
            // the page under it moves a little to the left, so the two feel connected
            final under = Tween<Offset>(begin: Offset.zero, end: const Offset(-0.18, 0)).animate(
                CurvedAnimation(parent: secondary, curve: Curves.easeOutCubic));
            return SlideTransition(
              position: under,
              child: SlideTransition(
                position: slide,
                child: ColoredBox(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: RepaintBoundary(child: child),
                ),
              ),
            );
          },
        );
}

/// Global rectangle of the widget behind [context] (null if it is not laid out).
Rect? rectOf(BuildContext context) {
  final ro = context.findRenderObject();
  if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}
