import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import 'widgets.dart';

/// First-run flow for new users:
/// 1. night sky + mountain + "Discover the secrets of your dreams" + arrow
/// 2. the sky tilts up, an eclipse appears, sign-in buttons (email / Google)
/// 3. a short quotes carousel, then the normal onboarding
class WelcomeFlow extends StatefulWidget {
  const WelcomeFlow({super.key});

  @override
  State<WelcomeFlow> createState() => _WelcomeFlowState();
}

class _WelcomeFlowState extends State<WelcomeFlow> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200));
  int _stage = 0; // 0 intro, 1 sign-in, 2 quotes
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _go() {
    if (_stage != 0) return;
    HapticFeedback.selectionClick();
    setState(() => _stage = 1);
    _c.forward();
  }

  void _toQuotes() {
    if (!mounted) return;
    setState(() => _stage = 2);
  }

  Future<void> _google({bool login = false}) async {
    if (_busy) return;
    final app = context.read<AppState>();
    setState(() => _busy = true);
    final err = await app.googleSignIn();
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      toast(context, err);
      return;
    }
    if (app.userEmail != null) {
      if (login) {
        // an existing user: his backup is syncing, go straight in
        app.setWelcomed();
        app.completeOnboarding();
      } else {
        _toQuotes();
      }
    }
  }

  Future<void> _email() async {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0C0F16),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => const _EmailSheet(),
    );
    if (ok == true && mounted) _toQuotes();
  }

  void _langSheet() {
    final app = context.read<AppState>();
    const opts = [
      ['ar', 'العربية'],
      ['ckb', 'کوردی'],
      ['es', 'Español'],
      ['ko', '한국어'],
      ['en', 'English'],
    ];
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF0C0F16),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final o in opts)
                Pressable(
                  onTap: () {
                    app.setLang(o[0]);
                    Navigator.of(ctx).pop();
                  },
                  child: Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: al(Colors.white, app.lang == o[0] ? 0.16 : 0.06),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(o[1],
                        style: const TextStyle(
                            color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: buildTheme('onyx', true),
      child: Builder(builder: (context) {
        return Scaffold(
          backgroundColor: const Color(0xFF040813),
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: _stage == 2
                ? _Quotes(key: const ValueKey('q'), onDone: () => context.read<AppState>().setWelcomed())
                : _sky(context),
          ),
        );
      }),
    );
  }

  Widget _sky(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return AnimatedBuilder(
      key: const ValueKey('sky'),
      animation: _c,
      builder: (_, __) {
        final t = Curves.easeInOutCubic.transform(_c.value);
        final intro = (1 - (t / 0.35)).clamp(0.0, 1.0);
        final eclipse = ((t - 0.55) / 0.45).clamp(0.0, 1.0);
        final ui = ((t - 0.8) / 0.2).clamp(0.0, 1.0);
        return Stack(
          children: [
            Positioned.fill(
              child: RepaintBoundary(
                child: CustomPaint(painter: _SkyPainter(t, eclipse)),
              ),
            ),
            // intro: title + arrow
            if (intro > 0)
              Positioned.fill(
                child: Opacity(
                  opacity: intro,
                  child: SafeArea(
                    child: Column(
                      children: [
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: IconButton(
                              onPressed: _langSheet,
                              icon: const Icon(Icons.language_rounded, color: Colors.white70),
                            ),
                          ),
                        ),
                        SizedBox(height: size.height * 0.1),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 36),
                          child: Text(context.t('w_title'),
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 31,
                                  fontWeight: FontWeight.w800,
                                  height: 1.35)),
                        ),
                        const Spacer(),
                        Pressable(
                          onTap: _go,
                          scale: 0.9,
                          child: Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFF05070D),
                              border: Border.all(color: al(Colors.white, 0.18)),
                              boxShadow: [
                                BoxShadow(color: al(Colors.white, 0.12), blurRadius: 22),
                              ],
                            ),
                            child: const Icon(Icons.arrow_forward_rounded,
                                color: Colors.white, size: 26),
                          ),
                        ),
                        SizedBox(height: size.height * 0.07),
                      ],
                    ),
                  ),
                ),
              ),
            // sign-in
            if (ui > 0)
              Positioned.fill(
                child: SafeArea(
                  child: Opacity(
                    opacity: ui,
                    child: Column(
                      children: [
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton(
                            onPressed: _busy ? null : () => _google(login: true),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              child: Text(context.t('w_login'),
                                  style: const TextStyle(
                                      color: Color(0xFF5AA2FF),
                                      fontSize: 15.5,
                                      fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(24, 0, 24, 30),
                          child: Column(
                            children: [
                              _AuthButton(
                                onTap: _email,
                                label: context.t('w_email'),
                                leading: const Icon(Icons.mail_outline_rounded,
                                    color: Colors.white, size: 22),
                              ),
                              const SizedBox(height: 14),
                              _AuthButton(
                                onTap: _busy ? () {} : _google,
                                label: context.t('w_google'),
                                busy: _busy,
                                leading: const Text('G',
                                    style: TextStyle(
                                        color: Color(0xFF4285F4),
                                        fontSize: 21,
                                        fontWeight: FontWeight.w900)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _AuthButton extends StatelessWidget {
  final VoidCallback onTap;
  final String label;
  final Widget leading;
  final bool busy;
  const _AuthButton(
      {required this.onTap, required this.label, required this.leading, this.busy = false});

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      scale: 0.97,
      child: Container(
        height: 56,
        width: double.infinity,
        decoration: BoxDecoration(
          color: al(const Color(0xFF3B82F6), 0.08),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: al(const Color(0xFF4C8DFF), 0.75), width: 1.4),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (busy)
              const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white))
            else
              leading,
            const SizedBox(width: 12),
            Text(label,
                style: const TextStyle(
                    color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

/// Night sky: three star layers (parallax), mountain, eclipse with a glowing corona.
class _SkyPainter extends CustomPainter {
  final double t; // 0..1 camera tilt
  final double eclipse; // 0..1
  _SkyPainter(this.t, this.eclipse);

  static final List<List<double>> _stars = () {
    final r = math.Random(21);
    return [
      for (var i = 0; i < 420; i++)
        [r.nextDouble(), r.nextDouble() * 2 - 1, 0.3 + r.nextDouble() * 1.0, 30 + r.nextDouble() * 200, (r.nextInt(3)).toDouble()]
    ];
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF030611), Color(0xFF07122A), Color(0xFF0B1B3A)],
        ).createShader(Offset.zero & size),
    );
    final p = Paint();
    for (final s in _stars) {
      final depth = 0.45 + 0.25 * s[4]; // 3 layers
      final y = s[1] * h + t * h * depth * 0.9;
      if (y < -4 || y > h + 4) continue;
      p.color = Color.fromARGB(s[3].toInt(), 200, 215, 255);
      canvas.drawCircle(Offset(s[0] * w, y), s[2], p);
    }
    // eclipse
    if (eclipse > 0) {
      final c = Offset(w / 2, h * 0.34);
      final rad = w * 0.15 * (0.88 + 0.12 * eclipse);
      final corona = Paint()
        ..shader = RadialGradient(
          colors: [
            al(Colors.white, 0.95 * eclipse),
            al(const Color(0xFFBFD4FF), 0.45 * eclipse),
            al(const Color(0xFF4C7DFF), 0.0),
          ],
          stops: const [0.5, 0.72, 1.0],
        ).createShader(Rect.fromCircle(center: c, radius: rad * 2.1));
      canvas.drawCircle(c, rad * 2.1, corona);
      canvas.drawCircle(
        c,
        rad * 1.04,
        Paint()
          ..color = al(Colors.white, 0.9 * eclipse)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(c, rad, Paint()..color = Colors.black);
    }
    // mountain silhouette sliding down as the camera tilts up
    final dy = t * h * 0.6;
    if (dy < h * 0.45) {
      final top = h * 0.70 + dy;
      final path = Path()
        ..moveTo(0, h)
        ..lineTo(0, top + h * 0.02)
        ..lineTo(w * 0.10, top - h * 0.015)
        ..lineTo(w * 0.22, top + h * 0.012)
        ..lineTo(w * 0.36, top - h * 0.045)
        ..lineTo(w * 0.47, top - h * 0.02)
        ..lineTo(w * 0.60, top - h * 0.06)
        ..lineTo(w * 0.74, top - h * 0.015)
        ..lineTo(w * 0.86, top + h * 0.01)
        ..lineTo(w, top - h * 0.02)
        ..lineTo(w, h + dy)
        ..lineTo(0, h + dy)
        ..close();
      canvas.drawPath(path, Paint()..color = const Color(0xFF05080F));
    }
  }

  @override
  bool shouldRepaint(covariant _SkyPainter o) => o.t != t || o.eclipse != eclipse;
}

class _EmailSheet extends StatefulWidget {
  const _EmailSheet();

  @override
  State<_EmailSheet> createState() => _EmailSheetState();
}

class _EmailSheetState extends State<_EmailSheet> {
  final _name = TextEditingController();
  final _mail = TextEditingController();
  String? _err;

  @override
  void dispose() {
    _name.dispose();
    _mail.dispose();
    super.dispose();
  }

  void _save() {
    final m = _mail.text.trim();
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]{2,}$').hasMatch(m)) {
      setState(() => _err = context.t('w_email_bad'));
      return;
    }
    context.read<AppState>().setProfile(_name.text.trim(), m);
    Navigator.of(context).pop(true);
  }

  InputDecoration _dec(String hint, IconData icon) => InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38),
        prefixIcon: Icon(icon, color: Colors.white54),
        filled: true,
        fillColor: al(Colors.white, 0.07),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          22, 20, 22, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(context.t('w_email_title'),
              style: const TextStyle(
                  color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          TextField(
            controller: _name,
            textInputAction: TextInputAction.next,
            style: const TextStyle(color: Colors.white),
            decoration: _dec(context.t('w_name_hint'), Icons.person_outline_rounded),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _mail,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _save(),
            style: const TextStyle(color: Colors.white),
            decoration: _dec(context.t('w_email_hint'), Icons.mail_outline_rounded),
          ),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_err!,
                  style: const TextStyle(color: Color(0xFFFF6B81), fontSize: 13.5)),
            ),
          const SizedBox(height: 10),
          Text(context.t('w_email_note'),
              style: const TextStyle(color: Colors.white38, fontSize: 12.5)),
          const SizedBox(height: 16),
          GradientButton(
              label: context.t('next'),
              icon: Icons.arrow_forward_rounded,
              expand: true,
              onTap: _save),
        ],
      ),
    );
  }
}

class _Quotes extends StatefulWidget {
  final VoidCallback onDone;
  const _Quotes({super.key, required this.onDone});

  @override
  State<_Quotes> createState() => _QuotesState();
}

class _QuotesState extends State<_Quotes> {
  final PageController _pc = PageController();
  int _i = 0;

  // name, quote key, role key, initials
  static const _q = [
    ['Sigmund Freud', 'w_q1', 'w_r1', 'SF'],
    ['Carl G. Jung', 'w_q2', 'w_r2', 'CJ'],
    ['Rosella', 'w_q3', 'w_r3', 'R'],
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Column(
          children: [
            const Spacer(flex: 2),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(context.t('w_join'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      height: 1.3)),
            ),
            const SizedBox(height: 26),
            SizedBox(
              height: 330,
              child: PageView.builder(
                controller: _pc,
                itemCount: _q.length,
                onPageChanged: (v) => setState(() => _i = v),
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _card(context, _q[i]),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < _q.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: _i == i ? 26 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: _i == i ? Colors.white : al(Colors.white, 0.22),
                    ),
                  ),
              ],
            ),
            const Spacer(flex: 3),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
              child: GradientButton(
                label: context.t('start'),
                icon: Icons.arrow_forward_rounded,
                expand: true,
                onTap: widget.onDone,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, List<String> q) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0C0E12),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: al(Colors.white, 0.09)),
      ),
      child: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.format_quote_rounded, color: al(Colors.white, 0.35), size: 38),
                  const SizedBox(height: 8),
                  Text(context.t(q[1]),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          height: 1.5)),
                ],
              ),
            ),
          ),
          Container(height: 1, color: al(Colors.white, 0.08)),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(q[0],
                          style: const TextStyle(
                              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 5),
                      Text(context.t(q[2]),
                          style: TextStyle(
                              color: al(Colors.white, 0.6), fontSize: 13.5, height: 1.4)),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 58,
                  height: 58,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                        colors: [Color(0xFF3B82F6), Color(0xFF9CC4FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight),
                  ),
                  child: Text(q[3],
                      style: const TextStyle(
                          color: Colors.black, fontSize: 19, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
