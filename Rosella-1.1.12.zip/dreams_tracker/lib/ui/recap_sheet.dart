import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import '../services/haptics.dart';
import 'widgets.dart';

/// Card on the Insights page that opens the AI recap.
class RecapCard extends StatelessWidget {
  const RecapCard({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Panel(
        padding: const EdgeInsets.all(16),
        radius: 20,
        onTap: () {
          Haptics.selection();
          showModalBottomSheet<void>(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (_) => const _RecapSheet(),
          );
        },
        child: Row(children: [
          Icon(Icons.auto_awesome_rounded, color: c.a, size: 26),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('recap_title'),
                    style: TextStyle(
                        color: c.text, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(context.t('recap_sub'),
                    style: TextStyle(color: c.dim, fontSize: 12.5)),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: c.dim),
        ]),
      ),
    );
  }
}

class _RecapSheet extends StatefulWidget {
  const _RecapSheet();

  @override
  State<_RecapSheet> createState() => _RecapSheetState();
}

class _RecapSheetState extends State<_RecapSheet> {
  int _days = 7;
  bool _busy = false;
  String? _out;

  Future<void> _go() async {
    final app = context.read<AppState>();
    final from = DateTime.now().subtract(Duration(days: _days));
    final ds = app.dreams
        .where((d) => !d.priv && d.createdAt.isAfter(from))
        .toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
    if (ds.length < 2) {
      setState(() => _out = app.tr('recap_none'));
      return;
    }
    setState(() {
      _busy = true;
      _out = null;
    });
    String text;
    try {
      text = await AiService.recap(ds, _days, app.lang);
      if (text.isEmpty) text = app.tr('recap_fail');
    } catch (_) {
      text = app.tr('recap_fail');
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _out = text;
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final h = MediaQuery.of(context).size.height;
    return Container(
      constraints: BoxConstraints(maxHeight: h * 0.85),
      decoration: BoxDecoration(
        color: c.bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.fromLTRB(
          20, 18, 20, 20 + MediaQuery.of(context).padding.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(context.t('recap_title'),
                style: TextStyle(
                    color: c.text, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            Row(children: [
              for (final d in const [7, 30])
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: _busy ? null : () => setState(() => _days = d),
                      child: Container(
                        height: 42,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: _days == d ? al(c.a, 0.18) : al(c.text, 0.06),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: _days == d ? c.a : Colors.transparent),
                        ),
                        child: Text(context.t(d == 7 ? 'recap_week' : 'recap_month'),
                            style: TextStyle(
                                color: c.text, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),
            ]),
            const SizedBox(height: 14),
            GradientButton(
              label: context.t('recap_go'),
              icon: Icons.auto_awesome_rounded,
              onTap: _busy ? () {} : _go,
            ),
            const SizedBox(height: 16),
            if (_busy)
              Center(
                  child: Padding(
                padding: const EdgeInsets.all(20),
                child: CircularProgressIndicator(strokeWidth: 2.6, color: c.a),
              ))
            else if (_out != null)
              SelectableText(_out!,
                  style: TextStyle(color: c.text, fontSize: 15.5, height: 1.55)),
          ],
        ),
      ),
    );
  }
}
