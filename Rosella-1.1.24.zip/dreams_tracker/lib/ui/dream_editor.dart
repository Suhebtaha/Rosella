import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../services/ai_service.dart';
import 'audio_clip.dart';
import 'dream_chat.dart';
import 'dream_detail.dart';
import 'widgets.dart';

class DreamEditorPage extends StatefulWidget {
  final Dream? dream;
  const DreamEditorPage({super.key, this.dream});

  @override
  State<DreamEditorPage> createState() => _DreamEditorPageState();
}

class _DreamEditorPageState extends State<DreamEditorPage> {
  late final AppState _app;
  late final TextEditingController _title;
  late final TextEditingController _content;
  late int _mood;
  bool _lucid = false;
  late DateTime _date;
  String? _image;

  final AudioRecorder _rec = AudioRecorder();
  bool _listening = false; // recording
  bool _transcribing = false;
  int _txGen = 0; // bumped to cancel a running transcription
  String? _audio;
  int _audioMs = 0;
  final Stopwatch _sw = Stopwatch();
  Timer? _tick;
  int _recMs = 0;
  bool _generating = false;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _app = context.read<AppState>();
    final d = widget.dream;
    _title = TextEditingController(text: d?.title ?? '');
    _content = TextEditingController(text: d?.content ?? '');
    _mood = d?.mood ?? 3;
    _lucid = d?.lucid ?? false;
    _date = d?.createdAt ?? DateTime.now();
    _image = d?.image;
    _audio = d?.audio;
    _audioMs = d?.audioMs ?? 0;
  }

  @override
  void dispose() {
    _tick?.cancel();
    () async {
      try {
        if (await _rec.isRecording()) await _rec.stop();
      } catch (_) {}
      try {
        await _rec.dispose();
      } catch (_) {}
    }();
    if (!_saved && _audio != null && _audio != widget.dream?.audio) {
      _app.deleteRel(_audio);
    }
    if (!_saved && _image != null && _image != widget.dream?.image) {
      try {
        final f = File(_app.abs(_image)!);
        if (f.existsSync()) f.deleteSync();
      } catch (_) {}
    }
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  /// Records with no time limit; when stopped the audio is kept and turned into text.
  Future<void> _toggleListen() async {
    if (_listening) {
      await _stopRecording();
      return;
    }
    var ok = false;
    try {
      ok = await _app.external(() => _rec.hasPermission());
    } catch (_) {}
    if (!mounted) return;
    if (!ok) {
      toast(context, _app.tr('mic_unavailable'));
      return;
    }
    _txGen++; // forget any transcription still running for the old audio
    if (_transcribing && mounted) setState(() => _transcribing = false);
    // a new recording replaces a not-yet-saved one
    if (_audio != null && _audio != widget.dream?.audio) _app.deleteRel(_audio);
    final rel = _app.newFileRel('audio', 'm4a');
    try {
      await _rec.start(
        const RecordConfig(
            encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 16000, numChannels: 1),
        path: _app.abs(rel)!,
      );
    } catch (_) {
      if (mounted) toast(context, _app.tr('mic_unavailable'));
      return;
    }
    if (!mounted) return;
    _audio = rel;
    _sw
      ..reset()
      ..start();
    _recMs = 0;
    _tick = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (mounted) setState(() => _recMs = _sw.elapsedMilliseconds);
    });
    setState(() => _listening = true);
  }

  Future<void> _stopRecording() async {
    _tick?.cancel();
    _sw.stop();
    try {
      await _rec.stop();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _listening = false;
      _audioMs = _sw.elapsedMilliseconds;
    });
    await _transcribe();
  }

  Future<void> _transcribe() async {
    final rel = _audio;
    if (rel == null) return;
    final gen = ++_txGen;
    setState(() => _transcribing = true);
    String? text;
    try {
      text = await AiService.transcribe(_app.abs(rel)!, _app.sttLang);
    } catch (_) {}
    if (!mounted || gen != _txGen) return; // cancelled (audio deleted / re-recorded)
    setState(() => _transcribing = false);
    if (_audio != rel) return;
    if (text == null) {
      toast(context, '${_app.tr('transcribe_failed')}\n${AiService.lastError}');
    } else if (text.isEmpty) {
      toast(context, _app.tr('no_speech'));
    } else {
      final cur = _content.text.trimRight();
      final full = cur.isEmpty ? text : '$cur\n$text';
      setState(() {
        _content.text = full;
        _content.selection = TextSelection.collapsed(offset: full.length);
      });
    }
  }

  Future<void> _deleteAudio() async {
    final ok = await confirmDialog(
      context,
      title: _app.tr('del_audio'),
      message: _app.tr('del_audio_msg'),
      confirm: _app.tr('delete'),
    );
    if (!ok || !mounted) return;
    if (_audio != widget.dream?.audio) _app.deleteRel(_audio); // saved audio goes on Save
    _txGen++; // stop waiting for the AI
    setState(() {
      _audio = null;
      _audioMs = 0;
      _transcribing = false;
    });
  }

  String _clock(int ms) {
    final s = ms ~/ 1000;
    return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
  }

  Future<void> _pickImage() async {
    try {
      final x = await _app.external(() => ImagePicker().pickImage(
            source: ImageSource.gallery,
            maxWidth: 1600,
            imageQuality: 85,
          ));
      if (x == null) return;
      final rel = _app.newFileRel('images', 'jpg');
      await File(x.path).copy(_app.abs(rel)!);
      if (!mounted) return;
      _dropPendingImage();
      setState(() => _image = rel);
    } catch (_) {}
  }

  void _dropPendingImage() {
    if (_image != null && _image != widget.dream?.image) {
      try {
        final f = File(_app.abs(_image)!);
        if (f.existsSync()) f.deleteSync();
      } catch (_) {}
    }
  }

  Future<void> _generate() async {
    if (_generating) return;
    if (_content.text.trim().isEmpty && _title.text.trim().isEmpty) {
      toast(context, _app.tr('write_first'));
      return;
    }
    setState(() => _generating = true);
    final rel = _app.newFileRel('images', 'jpg');
    final ok = await AiService.generateImage(
      title: _title.text.trim(),
      content: _content.text.trim(),
      savePath: _app.abs(rel)!,
    );
    if (!mounted) return;
    if (ok) {
      _dropPendingImage();
      _app.bumpImg();
      setState(() {
        _image = rel;
        _generating = false;
      });
    } else {
      setState(() => _generating = false);
      toast(context, _app.tr('image_failed'));
    }
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (p != null && mounted) {
      setState(() => _date = DateTime(p.year, p.month, p.day, _date.hour, _date.minute));
    }
  }

  /// [then]: null = just save and close; 'interpret' / 'chat' = save, then open that screen.
  Future<void> _save({String? then}) async {
    final old = widget.dream;
    if (_content.text.trim().isEmpty &&
        _title.text.trim().isEmpty &&
        _audio == null) {
      toast(context, _app.tr('write_first'));
      return;
    }
    if (_listening) await _stopRecording();
    final d = Dream(
      id: old?.id ?? _app.newId(),
      title: _title.text.trim(),
      content: _content.text.trim(),
      createdAt: _date,
      mood: _mood,
      audio: _audio,
      audioMs: _audioMs,
      image: _image,
      interpretation: old?.interpretation,
      lucid: _lucid,
    );
    _saved = true;
    if (old == null) {
      await _app.addDream(d);
    } else {
      await _app.updateDream(d);
    }
    if (!mounted) return;
    if (then == 'interpret') {
      Navigator.of(context).pushReplacement(CupertinoPageRoute<void>(
          builder: (_) => DreamDetailPage(id: d.id, autoInterpret: true)));
    } else if (then == 'chat') {
      Navigator.of(context).pushReplacement(
          CupertinoPageRoute<void>(builder: (_) => DreamChatPage(id: d.id)));
    } else {
      Navigator.of(context).pop();
    }
  }

  bool get _dirty {
    if (_saved) return false;
    final d = widget.dream;
    return _title.text.trim() != (d?.title ?? '').trim() ||
        _content.text.trim() != (d?.content ?? '').trim() ||
        _image != d?.image ||
        _audio != d?.audio ||
        _listening ||
        _mood != (d?.mood ?? 3) ||
        _lucid != (d?.lucid ?? false);
  }

  Future<void> _confirmLeave() async {
    final ok = await confirmDialog(
      context,
      title: _app.tr('leave_title'),
      message: _app.tr('leave_msg'),
      confirm: _app.tr('discard'),
    );
    if (ok && mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final lang = context.select<AppState, String>((s) => s.lang);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (_dirty) {
          _confirmLeave();
        } else {
          Navigator.of(context).pop();
        }
      },
      child: PageScaffold(
      child: Column(
        children: [
          TopBar(
            title: widget.dream == null ? context.t('new_dream') : context.t('edit_dream'),
          ),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
              children: [
                Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  radius: 20,
                  child: TextField(
                    controller: _title,
                    textInputAction: TextInputAction.next,
                    style: TextStyle(color: c.text, fontSize: 18, fontWeight: FontWeight.w700),
                    decoration: bareInput(context, context.t('title_hint')),
                  ),
                ),
                const SizedBox(height: 12),
                Panel(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  radius: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: _content,
                        minLines: 8,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        style: TextStyle(color: c.text, fontSize: 16, height: 1.55),
                        decoration: bareInput(context, context.t('content_hint')),
                      ),
                      const SizedBox(height: 4),
                      if (_audio != null && !_listening) ...[
                        Row(
                          children: [
                            Expanded(
                              child: AudioClip(
                                key: ValueKey(_audio),
                                path: _app.abs(_audio)!,
                                durationMs: _audioMs,
                              ),
                            ),
                            const SizedBox(width: 8),
                            RoundIconButton(
                                icon: Icons.delete_outline_rounded, onTap: _deleteAudio),
                          ],
                        ),
                        const SizedBox(height: 8),
                      ],
                      Pressable(
                        onTap: _toggleListen,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          height: 40,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          decoration: BoxDecoration(
                            gradient: _listening ? c.gradient : flatGradient(c.surfaceHi),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _transcribing
                                    ? Icons.hourglass_top_rounded
                                    : (_listening ? Icons.stop_rounded : Icons.mic_none_rounded),
                                size: 19,
                                color: _listening ? Colors.white : c.text,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _transcribing
                                    ? context.t('transcribing')
                                    : (_listening
                                        ? '${context.t('stop_rec')}  ${_clock(_recMs)}'
                                        : context.t('dictate')),
                                style: TextStyle(
                                  color: _listening ? Colors.white : c.text,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 4, right: 4),
                  child: Text(context.t('how_felt'),
                      style: TextStyle(
                          color: c.dim, fontSize: 13, fontWeight: FontWeight.w600)),
                ),
                MoodPicker(value: _mood, onChanged: (m) => setState(() => _mood = m)),
                const SizedBox(height: 14),
                Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  radius: 18,
                  child: Row(
                    children: [
                      Icon(Icons.visibility_rounded, color: c.a),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(context.t('lucid_dream'),
                            style: TextStyle(
                                color: c.text,
                                fontSize: 15,
                                fontWeight: FontWeight.w600)),
                      ),
                      Switch(
                        value: _lucid,
                        onChanged: (v) => setState(() => _lucid = v),
                        activeTrackColor: c.a,
                        inactiveTrackColor: c.surfaceHi,
                        thumbColor: const WidgetStatePropertyAll<Color>(Colors.white),
                        trackOutlineColor:
                            const WidgetStatePropertyAll<Color>(Colors.transparent),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Panel(
                  onTap: _pickDate,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  radius: 18,
                  child: Row(
                    children: [
                      Icon(Icons.calendar_month_rounded, color: c.a),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          '${context.t('date')}: ${fmtDate(_date, lang)}',
                          style: TextStyle(
                              color: c.text, fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ),
                      Icon(Icons.edit_calendar_rounded, color: c.dim, size: 20),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _imageSection(c),
                const SizedBox(height: 24),
                SubtleButton(
                  label: context.t('interpret'),
                  icon: Icons.psychology_rounded,
                  onTap: () => _save(then: 'interpret'),
                ),
                const SizedBox(height: 10),
                SubtleButton(
                  label: context.t('chat_ask'),
                  icon: Icons.forum_rounded,
                  onTap: () => _save(then: 'chat'),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    label: context.t('save'),
                    icon: Icons.check_rounded,
                    expand: true,
                    onTap: _save,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ));
  }

  Widget _imageSection(AppColors c) {
    if (_generating) {
      return Panel(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Column(
          children: [
            SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 3, color: c.a),
            ),
            const SizedBox(height: 12),
            Text(context.t('generating'), style: TextStyle(color: c.dim)),
          ],
        ),
      );
    }
    if (_image != null) {
      return Column(children: [
        ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            Image.file(
              File(_app.abs(_image)!),
              height: 220,
              width: double.infinity,
              fit: BoxFit.cover,
              cacheWidth: 1000,
              errorBuilder: (_, __, ___) => Container(
                height: 220,
                color: c.surfaceHi,
                child: Icon(Icons.broken_image_rounded, color: c.dim),
              ),
            ),
            PositionedDirectional(
              top: 10,
              end: 10,
              child: RoundIconButton(
                icon: Icons.close_rounded,
                onTap: () async {
                  final ok = await confirmDialog(
                    context,
                    title: _app.tr('del_image_title'),
                    message: _app.tr('del_image_confirm'),
                    confirm: _app.tr('delete'),
                  );
                  if (!ok || !mounted) return;
                  _dropPendingImage();
                  setState(() => _image = null);
                },
              ),
            ),
          ],
        ),
      ),
        const SizedBox(height: 10),
        SubtleButton(
          label: context.t('regen_image'),
          icon: Icons.refresh_rounded,
          onTap: _generate,
        ),
      ]);
    }
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: GradientButton(
            label: context.t('gen_image'),
            icon: Icons.auto_awesome_rounded,
            expand: true,
            onTap: _generate,
          ),
        ),
        const SizedBox(height: 10),
        SubtleButton(
          label: context.t('gallery'),
          icon: Icons.photo_library_rounded,
          onTap: _pickImage,
        ),
      ],
    );
  }
}
