## Rosella 1.1.113

- The round "+" new-dream button moved from above the mic to the end corner, just above the bottom bar.
