## Rosella 1.1.120

- Feed cards: the lock button now asks for confirmation before making a dream private/public.
- New pin button with confirmation, and a pencil button to edit the dream.
