import 'dart:math' as math;

import 'package:flutter/cupertino.dart' show CupertinoPageRoute;
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/nav_bus.dart';
import '../core/symbols.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'card_route.dart';
import 'chats_page.dart';
import 'dream_detail.dart';
import 'dream_editor.dart';
import '../services/haptics.dart';
import 'fast_scroll.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _search = TextEditingController();
  String _q = '';
  int? _mood;
  int _range = 0; // 0 all, 1 week, 2 month, 3 year
  final Set<String> _sel = {};
  bool _hideUninterp = false;
  bool _favOnly = false;
  final ScrollController _scroll = ScrollController();
  final Map<String, GlobalKey> _tileKeys = {};
  List<String> _dragPath = [];
  final Set<String> _dragAdded = {};

  /// A long press just happened on [id]: it starts a new drag path.
  void _onLong(String id) {
    if (_sel.isNotEmpty) {
      _toggle(id);
    } else {
      _startSelect(id);
    }
    _dragPath = [id];
    _dragAdded
      ..clear()
      ..addAll(_sel.contains(id) ? [id] : const <String>[]);
  }

  GlobalKey _tileKey(String id) => _tileKeys.putIfAbsent(id, () => GlobalKey());

  /// Long press then drag: every dream under the finger joins the selection.
  void _dragSelect(Offset p) {
    if (_scroll.hasClients) {
      final h = MediaQuery.of(context).size.height;
      final pos = _scroll.position;
      if (p.dy < 150 && pos.pixels > 0) {
        _scroll.jumpTo((pos.pixels - 16).clamp(0.0, pos.maxScrollExtent));
      } else if (p.dy > h - 170 && pos.pixels < pos.maxScrollExtent) {
        _scroll.jumpTo((pos.pixels + 16).clamp(0.0, pos.maxScrollExtent));
      }
    }
    for (final e in _tileKeys.entries) {
      final ctx = e.value.currentContext;
      if (ctx == null) continue;
      final rb = ctx.findRenderObject();
      if (rb is! RenderBox || !rb.attached) continue;
      final r = rb.localToGlobal(Offset.zero) & rb.size;
      if (r.contains(p)) {
        final id = e.key;
        final at = _dragPath.indexOf(id);
        if (at < 0) {
          // new dream under the finger: select it
          _dragPath.add(id);
          if (_sel.add(id)) _dragAdded.add(id);
          Haptics.selection();
          setState(() {});
        } else if (at < _dragPath.length - 1) {
          // finger went back over dreams it already crossed: un-select them
          for (final x in _dragPath.sublist(at + 1)) {
            if (_dragAdded.remove(x)) _sel.remove(x);
          }
          _dragPath = _dragPath.sublist(0, at + 1);
          Haptics.selection();
          setState(() {});
        }
        break;
      }
    }
  }

  void _flagSel(AppState app, {required bool priv}) {
    final chosen = app.dreams.where((d) => _sel.contains(d.id)).toList();
    if (chosen.isEmpty) return;
    final all = chosen.every((d) => priv ? d.priv : d.fav);
    final ids = _sel.toSet();
    if (priv) {
      app.setFlagsMany(ids, priv: !all);
      toast(context, app.tr(all ? 'priv_off' : 'priv_on'));
    } else {
      app.setFlagsMany(ids, fav: !all);
    }
    setState(_sel.clear);
  }
  bool _showPriv = false;

  @override
  void initState() {
    super.initState();
    searchRequest.addListener(_onSearchRequest);
  }

  void _onSearchRequest() {
    final w = searchRequest.value;
    if (w.isEmpty || !mounted) return;
    setState(() {
      _search.text = w;
      _q = w;
      _mood = null;
      _range = 0;
    });
  }

  void _toggle(String id) {
    Haptics.selection();
    setState(() {
      if (!_sel.remove(id)) _sel.add(id);
    });
  }

  void _startSelect(String id) {
    Haptics.medium();
    setState(() => _sel.add(id));
  }

  /// Opens the dream by growing the page out of the tapped card ([cardCtx] = the card).
  void _openDream(String id, [BuildContext? cardCtx, double radius = 24]) {
    final rect = cardCtx == null ? null : rectOf(cardCtx);
    if (rect == null) {
      Navigator.of(context)
          .push(CupertinoPageRoute<void>(builder: (_) => DreamDetailPage(id: id)));
      return;
    }
    final c = context.colors;
    Navigator.of(context).push(CardOpenRoute(
      from: rect,
      color: Color.alphaBlend(c.surface, c.bg),
      radius: radius,
      builder: (_) => DreamDetailPage(id: id),
    ));
  }

  Future<void> _deleteSel() async {
    final app = context.read<AppState>();
    final ok = await confirmDialog(
      context,
      title: app.tr('delete_selected'),
      message: app.tr('delete_selected_msg'),
      confirm: app.tr('delete'),
    );
    if (!ok) return;
    await app.deleteMany(Set<String>.from(_sel));
    if (mounted) setState(_sel.clear);
  }

  Widget _selBar(AppState app, List<Dream> list) {
    final c = context.colors;
    return Row(
      children: [
        RoundIconButton(icon: Icons.close_rounded, onTap: () => setState(_sel.clear)),
        const SizedBox(width: 12),
        Expanded(
          child: Text('${_sel.length} ${app.tr('selected_n')}',
              style: TextStyle(color: c.text, fontSize: 22, fontWeight: FontWeight.w800)),
        ),
        RoundIconButton(
          icon: Icons.select_all_rounded,
          onTap: () => setState(() {
            _sel
              ..clear()
              ..addAll(list.map((d) => d.id));
          }),
        ),
        const SizedBox(width: 8),
        const SizedBox(width: 8),
        RoundIconButton(
          icon: Icons.star_rounded,
          color: const Color(0xFFFFB020),
          onTap: () => _flagSel(app, priv: false),
        ),
        const SizedBox(width: 8),
        RoundIconButton(
          icon: Icons.lock_rounded,
          onTap: () => _flagSel(app, priv: true),
        ),
        const SizedBox(width: 8),
        RoundIconButton(
          icon: Icons.delete_outline_rounded,
          color: const Color(0xFFFF5470),
          onTap: _deleteSel,
        ),
      ],
    );
  }

  @override
  void dispose() {
    searchRequest.removeListener(_onSearchRequest);
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  void _openEditor() {
    Navigator.of(context)
        .push(CupertinoPageRoute<void>(builder: (_) => const DreamEditorPage()));
  }

  Widget _uninterpBanner(AppState app, dynamic c) {
    final open = app.dreams
        .where((d) => !d.priv && d.interpretation == null && d.content.trim().length > 20)
        .toList();
    if (open.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: GestureDetector(
        onTap: () {
          Haptics.selection();
          _openDream(open.first.id);
        },
        child: Panel(
          padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
          radius: 18,
          child: Row(children: [
            Icon(Icons.auto_awesome_rounded, color: c.a, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${open.length} ${context.t('uninterp_n')}',
                      style: TextStyle(
                          color: c.text, fontSize: 14.5, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(context.t('uninterp_tap'),
                      style: TextStyle(color: c.dim, fontSize: 12.5)),
                ],
              ),
            ),
            IconButton(
              onPressed: () => setState(() => _hideUninterp = true),
              icon: Icon(Icons.close_rounded, color: c.dim, size: 20),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = context.colors;
    final q = _q.trim().toLowerCase();
    final list = app.dreams.where((d) {
      if (d.priv != (_showPriv && !app.hidePrivFilter)) return false;
      if (_favOnly && !app.hideFavFilter && !d.fav) return false;
      if (_mood != null && d.mood != _mood) return false;
      if (_range > 0) {
        final days = const [0, 7, 30, 365][_range];
        if (DateTime.now().difference(d.createdAt).inDays >= days) return false;
      }
      if (q.isEmpty) return true;
      if (d.title.toLowerCase().contains(q) || d.content.toLowerCase().contains(q)) {
        return true;
      }
      final nq = normText(q);
      return normText(d.title).contains(nq) || normText(d.content).contains(nq);
    }).toList();

    return SafeArea(
      bottom: false,
      child: Stack(children: [
      CustomScrollView(
        controller: _scroll,
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 16, 12),
              child: _sel.isNotEmpty ? _selBar(app, list) : Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.t('home_title'),
                            style: TextStyle(
                                color: c.text,
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.5)),
                        const SizedBox(height: 2),
                        Text('${app.dreams.length} ${context.t('dreams_count')}',
                            style: TextStyle(color: c.dim, fontSize: 14)),
                      ],
                    ),
                  ),
                  RoundIconButton(
                    icon: app.cardStyle == 'grid'
                        ? Icons.view_agenda_rounded
                        : Icons.grid_view_rounded,
                    onTap: () =>
                        app.setCardStyle(app.cardStyle == 'grid' ? 'list' : 'grid'),
                  ),
                  const SizedBox(width: 10),
                  if (app.dreams.any((d) => d.chat.isNotEmpty)) ...[
                    RoundIconButton(
                      icon: Icons.forum_rounded,
                      onTap: () => Navigator.of(context).push(
                          CupertinoPageRoute<void>(builder: (_) => const ChatsPage())),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Pressable(
                    onTap: _openEditor,
                    scale: 0.9,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: c.gradient,
                        boxShadow: [
                          BoxShadow(color: al(c.a, 0.35), blurRadius: 16, offset: const Offset(0, 6)),
                        ],
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Panel(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                radius: 18,
                child: Row(
                  children: [
                    Icon(Icons.search_rounded, color: c.dim),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _search,
                        onChanged: (v) => setState(() => _q = v),
                        style: TextStyle(color: c.text, fontSize: 16),
                        decoration: bareInput(context, context.t('search_hint')),
                      ),
                    ),
                    if (_q.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          _search.clear();
                          setState(() => _q = '');
                        },
                        child: Icon(Icons.close_rounded, color: c.dim, size: 20),
                      ),
                  ],
                ),
              ),
            ),
          ),
          if (!_hideUninterp && _q.isEmpty && _mood == null && _range == 0)
            SliverToBoxAdapter(child: _uninterpBanner(app, c)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: SizedBox(
                height: 38,
                child: Row(
                  children: [
                    Expanded(
                      flex: 13,
                      child: _FilterChip(
                        label: context.t('filter_all'),
                        selected: _mood == null,
                        onTap: () => setState(() => _mood = null),
                      ),
                    ),
                    for (var m = 1; m <= 5; m++)
                      Expanded(
                        flex: 10,
                        child: _FilterChip(
                          label: moodEmoji(m),
                          selected: _mood == m,
                          onTap: () => setState(() => _mood = _mood == m ? null : m),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          if (!app.hideFavFilter || !app.hidePrivFilter)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: SizedBox(
                height: 36,
                child: Row(
                  children: [
                    if (!app.hideFavFilter)
                    Expanded(
                      child: _FilterChip(
                        label: '\u2605 ${context.t('fav_filter')}',
                        selected: _favOnly,
                        onTap: () => setState(() => _favOnly = !_favOnly),
                      ),
                    ),
                    if (!app.hidePrivFilter)
                    Expanded(
                      child: _FilterChip(
                        label: '\u{1F512} ${context.t('priv_filter')}',
                        selected: _showPriv,
                        onTap: () async {
                          if (_showPriv) {
                            setState(() => _showPriv = false);
                            return;
                          }
                          final ok = await app.external(() => app.authenticate());
                          if (ok && mounted) setState(() => _showPriv = true);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: SizedBox(
                height: 36,
                child: Row(
                  children: [
                    for (var r = 0; r < 4; r++)
                      Expanded(
                        child: _FilterChip(
                          label: context.t(const ['filter_all', 'range_week', 'range_month', 'range_year'][r]),
                          selected: _range == r,
                          onTap: () => setState(() => _range = r),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          if (list.isEmpty)
            SliverToBoxAdapter(child: _Empty(onWrite: _openEditor))
          else if (app.cardStyle == 'grid')
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1,
                ),
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) => FadeSlide(
                    key: ValueKey(list[i].id),
                    delay: math.min(i, 8) * 55,
                    once: list[i].id,
                    enabled: i < 10,
                    child: Builder(
                      builder: (cardCtx) => _DreamTile(
                        key: _tileKey(list[i].id),
                        onDrag: _dragSelect,
                        dream: list[i],
                        selecting: _sel.isNotEmpty,
                        selected: _sel.contains(list[i].id),
                        onTap: () => _sel.isNotEmpty
                            ? _toggle(list[i].id)
                            : _openDream(list[i].id, cardCtx, 26),
                        onLongPress: () => _onLong(list[i].id),
                      ),
                    ),
                  ),
                  childCount: list.length,
                ),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => Padding(
                  key: ValueKey(list[i].id),
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: FadeSlide(
                    delay: math.min(i, 8) * 55,
                    once: list[i].id,
                    enabled: i < 10,
                    child: Builder(
                      builder: (cardCtx) => _DreamCard(
                        key: _tileKey(list[i].id),
                        onDrag: _dragSelect,
                        dream: list[i],
                        selecting: _sel.isNotEmpty,
                        selected: _sel.contains(list[i].id),
                        onTap: () => _sel.isNotEmpty
                            ? _toggle(list[i].id)
                            : _openDream(list[i].id, cardCtx, 24),
                        onLongPress: () => _onLong(list[i].id),
                      ),
                    ),
                  ),
                ),
                childCount: list.length,
              ),
            ),
          SliverToBoxAdapter(child: SizedBox(height: navPadding(context))),
        ],
      ),
      Positioned.fill(
        child: FastScroller(
          controller: _scroll,
          dreams: list,
          lang: app.lang,
          bottom: navPadding(context) + 8,
        ),
      ),
      ]),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: Pressable(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 4),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: selected
                ? c.gradient
                : flatGradient(al(c.surface, c.isDark ? 0.7 : 0.9)),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: selected ? Colors.transparent : c.border),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : c.text,
              fontWeight: FontWeight.w700,
              fontSize: 14.5,
            ),
          ),
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final VoidCallback onWrite;
  const _Empty({required this.onWrite});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 60, 32, 0),
      child: Column(
        children: [
          Container(
            width: 104,
            height: 104,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(c.a, 0.12),
              border: Border.all(color: al(c.a, 0.3)),
            ),
            child: Icon(Icons.nights_stay_rounded, size: 50, color: c.a),
          ),
          const SizedBox(height: 22),
          Text(context.t('empty_title'),
              style: TextStyle(color: c.text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(context.t('empty_sub'),
              textAlign: TextAlign.center,
              style: TextStyle(color: c.dim, fontSize: 14.5, height: 1.5)),
          const SizedBox(height: 22),
          GradientButton(
              label: context.t('write_dream'), icon: Icons.edit_rounded, onTap: onWrite),
        ],
      ),
    );
  }
}

class _SelCheck extends StatelessWidget {
  final bool selected;
  final double size;
  const _SelCheck({required this.selected, this.size = 26});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: selected ? c.gradient : flatGradient(al(Colors.black, 0.25)),
        border: Border.all(color: selected ? Colors.transparent : al(Colors.white, 0.8), width: 2),
      ),
      child: selected
          ? Icon(Icons.check_rounded, size: size * 0.66, color: onAccent(c.a, c.b))
          : null,
    );
  }
}

class _DreamTile extends StatelessWidget {
  final Dream dream;
  final bool selecting;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final void Function(Offset)? onDrag;
  const _DreamTile({
    super.key,
    this.onDrag,
    required this.dream,
    required this.selecting,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final app = context.read<AppState>();
    final lang = context.select<AppState, String>((s) => s.lang);
    final d = dream;
    final img = app.abs(d.image);
    final hasImg = img != null;
    final fg = hasImg ? Colors.white : c.text;
    final title = d.title.isEmpty
        ? (d.content.trim().isEmpty ? fmtDate(d.createdAt, lang) : d.content.trim())
        : d.title;
    return Pressable(
      onTap: onTap,
      onLongPress: onLongPress,
      onLongPressMove: onDrag,
      scale: 0.96,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [al(moodColor(d.mood), 0.38), al(c.surface, 0.9)],
          ),
          border: Border.all(
              color: selected ? c.a : c.border, width: selected ? 3 : 1),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (hasImg)
              Image.file(File(img),
                  fit: BoxFit.cover,
                  cacheWidth: 520,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            if (hasImg)
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0x33000000), Color(0x00000000), Color(0xCC000000)],
                    stops: [0, 0.4, 1],
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: al(hasImg ? Colors.black : moodColor(d.mood),
                              hasImg ? 0.35 : 0.22),
                        ),
                        child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 20)),
                      ),
                      const Spacer(),
                      if (d.audio != null) _TileBadge(Icons.mic_rounded, fg),
                      if (d.interpretation != null)
                        _TileBadge(Icons.auto_awesome_rounded, fg),
                      if (d.fav) _TileBadge(Icons.star_rounded, const Color(0xFFFFC94D)),
                      if (d.priv) _TileBadge(Icons.lock_rounded, fg),
                    ],
                  ),
                  const Spacer(),
                  if (d.lucid) ...[
                    const LucidTag(compact: true, onDark: true),
                    const SizedBox(height: 6),
                  ],
                  Text(title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: fg, fontSize: 15.5, fontWeight: FontWeight.w800, height: 1.25)),
                  const SizedBox(height: 4),
                  Text(fmtDate(d.createdAt, lang),
                      style: TextStyle(color: al(fg, 0.75), fontSize: 11.5)),
                ],
              ),
            ),
            if (selecting)
              PositionedDirectional(
                top: 10,
                end: 10,
                child: _SelCheck(selected: selected),
              ),
          ],
        ),
      ),
    );
  }
}

class _TileBadge extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _TileBadge(this.icon, this.color);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6),
        child: Icon(icon, size: 16, color: al(color, 0.9)),
      );
}

class _DreamCard extends StatelessWidget {
  final Dream dream;
  final bool selecting;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final void Function(Offset)? onDrag;
  const _DreamCard({
    super.key,
    this.onDrag,
    required this.dream,
    required this.selecting,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final lang = context.select<AppState, String>((s) => s.lang);
    final d = dream;
    final preview = d.content.trim().isEmpty && d.audio != null
        ? context.t('voice_recording')
        : d.content.trim();
    final title = d.title.isEmpty ? fmtDate(d.createdAt, lang) : d.title;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
            color: selected ? c.a : Colors.transparent, width: selected ? 2.5 : 0),
      ),
      child: Panel(
      onTap: onTap,
      onLongPress: onLongPress,
      onLongPressMove: onDrag,
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (selecting) ...[
            Padding(
              padding: const EdgeInsets.only(top: 11),
              child: _SelCheck(selected: selected),
            ),
            const SizedBox(width: 12),
          ],
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: al(moodColor(d.mood), 0.18),
            ),
            child: Text(moodEmoji(d.mood), style: const TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: c.text, fontSize: 16.5, fontWeight: FontWeight.w700)),
                    ),
                    if (d.audio != null) _Badge(Icons.mic_rounded),
                    if (d.image != null) _Badge(Icons.image_rounded),
                    if (d.interpretation != null) _Badge(Icons.auto_awesome_rounded),
                    if (d.fav) _Badge(Icons.star_rounded),
                    if (d.priv) _Badge(Icons.lock_rounded),
                  ],
                ),
                if (d.lucid) ...[
                  const SizedBox(height: 6),
                  const LucidTag(compact: true),
                ],
                if (preview.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(preview,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: c.dim, fontSize: 14, height: 1.4)),
                ],
                const SizedBox(height: 8),
                Text('${fmtDate(d.createdAt, lang)} • ${fmtTime(d.createdAt)}',
                    style: TextStyle(color: al(c.dim, 0.8), fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  const _Badge(this.icon);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6),
        child: Icon(icon, size: 15, color: context.colors.a),
      );
}
