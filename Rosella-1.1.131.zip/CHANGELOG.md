## 1.1.131
- Settings redesigned in a compact iOS style: small colored icons, slim rows, solid rounded groups with thin dividers, small uppercase section labels.
- Rows that open a page now show a chevron automatically (flipped for RTL); value rows keep their value next to the chevron.
- Smaller choice cards and tighter spacing so the page is shorter overall.

## 1.1.130
- Menus now support press-and-slide: hold, slide over the items (they light up) and release to choose.
- Fixed: after opening Favorites, the Private tile now works (the two views no longer mix).
- Removed the overshoot at the end of the menu opening animation.
- Dream ⋮ menu: colored icons with a short description on every item (no more white icons), arrows only where they make sense.

## 1.1.129
- Home ⋮ menu: smaller card; header shows only the favorites count (private count removed).
- Cards / List switch no longer closes the menu: a pill slides between the two options.
- Sort is now an inline row that slides open (Newest / Oldest first) and keeps the menu open.
- New menu open/close animation: the card springs out of the ⋮ button and shrinks back into it.
- Favorites filter with no results shows a yellow star and "No dreams".

## 1.1.128
- Redesigned the home ⋮ menu: header with counts, big Private / Favorites tiles with colored icons and badges, a Cards / List switch, and Calendar / Chats / Sort rows.
- Added Sort (newest / oldest first) to the home list.
- Menu card is now solid (no live blur), so closing animates smoothly with no pop or flash.

## 1.1.127
- Fixed the ⋮ menu blur flashing/snapping on open and close (the fade was breaking the backdrop blur).
- Smoother, lighter menu animation: scale-only open, lower blur cost, lighter shadow, faster expand.

## 1.1.126
- Fixed: a private dream no longer stays a favorite; making a dream private removes its favorite mark.
- Private dreams no longer appear in the Favorites filter or on the profile.

## 1.1.125
- Fixed the home ⋮ menu: removed the yellow underlines under the labels.
- Cleaner frosted-glass look tinted with the theme colour instead of muddy gray.
- "Switch views" now expands smoothly with no overlapping text.

## Rosella 1.1.124

- Collections: group your dreams (Strange Dreams, Nightmares, Beautiful Dreams, Lucid Dreams, or your own). Add a dream from its ⋮ menu; Nightmares, Beautiful and Lucid also fill in automatically from the mood and lucid flag.
- Dream personality: a calm label for how you record dreams (based only on your journal, not a psychological analysis).
- A calmer profile: your name, bio, a short archive line, personality, collections, achievements, favorites and pinned dreams. The big statistic tiles were removed.

## Rosella 1.1.123

- The ⋮ menu is now frosted glass: a blurred, translucent card with a thin light border.
- New calendar design: a big month title, a frosted card, mood-coloured rounded day tiles with a small bar under each, and a monthly mood legend.
- Profile feels alive: a slowly drifting glow, a turning gradient ring around your photo, and numbers that count up.
- Profile has more: this month / this year / average words, and your pinned dreams next to your favorites.

## Rosella 1.1.122

- Profile: fixed the oversized start date; the three info tiles are now the same size.
- Profile no longer repeats the Insights page (mood chart, recurring symbols, achievements). New: your favorite dreams, most active day, longest dream, and the people, places and tags that appear most in your dreams.

## Rosella 1.1.121

- Fixed: pressing the system Back button while dreams are selected now clears the selection instead of leaving the app.
- The Instagram-style feed cards were removed; the original square and long cards are back (square is the default).
- Profile no longer lists your dreams or a Private tab. It now shows your journey (start date, words, voice notes, images), a mood overview, recurring symbols and all achievements (locked ones dimmed).

## Rosella 1.1.120

- Feed cards: the lock button now asks for confirmation before making a dream private/public.
- New pin button with confirmation, and a pencil button to edit the dream.

## Rosella 1.1.119

- Feed cards: larger white title, aligned to the right for Arabic (RTL) text.
- Dreams without an image now use a compact card with a gradient based on the mood.
- New action row on every card: favorite, interpretation, private/public, share.

## Rosella 1.1.118

- New Feed view on the home page: big post-style cards with your photo, name, date and a large dream image. Feed is now the default (switch to Grid anytime from ⋮ > Switch views or in Settings).
- A soft ambient glow from the top of every page, in the theme colour (golden on the black theme).

## Rosella 1.1.117

- Social features removed: no followers/following, friends, notifications or public/friends visibility. Rosella stays a private dream journal.
- Profile keeps your photo, name, bio, dream stats (dreams, day streak, lucid, recurring), unlocked achievements, and your dreams as a feed. The email is no longer shown.

## Rosella 1.1.116

- Profile now shows your dreams as a feed of posts (no square grid) and no longer pins a single featured dream at the top.
- Two tabs: Posts and Private (fingerprint/PIN to open). Private posts show a lock.

## Rosella 1.1.115

- Profile redesigned like a social profile: photo, Posts / Followers / Following, bio, Edit profile and Add friends buttons, and tabs for a dreams grid, a posts feed and your private dreams (fingerprint/PIN to open).
- Tap your profile photo to view it full screen (pinch to zoom).
- New notifications button on the home page and on the profile, plus Friends and Notifications screens (they fill up once an online service is connected).
- When you write a dream you can now choose who can see it: Public, Friends or Private.

## Rosella 1.1.114

- The 4th tab is now Profile (photo, name, bio, stats, a featured dream). App settings moved behind the gear icon on the profile page.
- Edit profile: change photo and name, write a bio, hide the email, and choose which stats are shown (dream count, streak, lucid, recurring), plus pick a featured dream.
- Home ⋮ menu: Private replaces the view tile; "Switch views" is a row with a small arrow that expands into List / Cards with a smooth animation.
- The "+" button now has a dark glass look on dark themes.

## Rosella 1.1.113

- The round "+" new-dream button moved from above the mic to the end corner, just above the bottom bar.

## Rosella 1.1.112

- Share card: swipe sideways to browse different looks (your theme, aurora, sunset, violet, paper, mono, forest, blush) and layouts (classic, centered, quote). The card you see is the one that gets shared or saved.

## Rosella 1.1.111

- Long-press the app icon to get a "New dream" shortcut that opens the quick-write popup.
- A round "+" button in the theme colour now sits above the centered mic to add a new dream.
- Favorites and Private filters moved into the ⋮ menu on the home page.

## Rosella 1.1.110

- On the dream page, the pin / favorite / lock / share / delete buttons moved into a ⋮ menu that opens as an animated card.
- New users now start with the microphone in the middle of the bar.
- New short opening animation: the moon appears, the letters of "rosella" appear one by one, and a soft blue glow rises from the bottom.

## Rosella 1.1.109

- Dreams can now have optional details: people, places and tags ("Add details"), shown on the dream page and saved with backups.
- A save (check) button at the top right of the dream editor; the Save button below stays.
- The three header buttons on the home page are replaced by a ⋮ menu that opens as an animated card (view style, general chat, new dream, calendar, dream chats).

## Rosella 1.1.108

- The first-run language page is gone: the app opens in the phone's language, or English when that language is not available.
- Fixed the "Generating · Cancel" button shrinking while it animates.
- When the bottom bar collapses on scroll, the icons are bigger and the lens is a little larger; the bar shrinks less.
- The date shown while scrolling no longer overlaps the scroll-up arrow.
- Added a close (X) button to the language list in Settings.

## Rosella 1.1.107

- New "+" button inside the bottom bar (circle in the theme colour) to add a dream.
- Full calendar page (open it from Insights): monthly view with mood colours, a streak line ("Logged N days in a row") and badges.
- Generating an image or an interpretation can now be cancelled; while an image is generating a black/white (per theme) frame with "Generating…" is shown, and the finished image fades in. The button has a moving "working" animation.
- Search by meaning is much faster: instant word results first, then a shorter AI query.
- "Restoring your dreams…" line on the home screen during the first restore.
- A small date line appears at the bottom while scrolling the dream list.
- Dream titles and text follow their own direction (Arabic dreams read right-to-left even in an English app).
- Close (X) button in the chats window and the chats drawer.

## Rosella 1.1.106

- Fixed the welcome title animation playing twice, and the title is now plain white.
- The flashes in the welcome animation are now black instead of violet.
- The "new chat" button in the general chat only shows when there is a conversation on screen.

## Rosella 1.1.105

- The small "Rosella" word at the top of every page is now plain white (follows light/dark) instead of coloured.
- Every welcome/feature page now has its own animation: theme, voice, interpretation, chat, AI image, sounds, lock, haptics, reminders and colours each move differently.

## Rosella 1.1.104

- Privacy Policy and Terms of Use are now shown in the language you chose in the app (24 languages), with English as the fallback.

## Rosella 1.1.103

- The welcome and feature pages now switch instantly between light and dark when you choose a mode.
- Selecting dreams: the pin and favorite icons are now empty until they apply to the selection, then turn blue / yellow.
- Added an edit (pencil) icon inside the dream text card.
- Privacy Policy and Terms of Use are now always shown in English, whatever the app language.

## Rosella 1.1.102

- The bottom bar now recedes with a much lighter, simpler animation.
- The welcome title ("Discover the secrets of your dreams") no longer plays its animation twice.
- New users now start with the black theme by default.
- The dream-count card (moon and book) now has a pure black background.

## Rosella 1.1.101

- The bottom bar now recedes slightly while you press or drag the glass lens.
- Home-screen widget picker now shows a real preview of each widget size.
- Simpler, fully static first-run language page with a white Rosella wordmark.
- The default Dynamic theme is now saved on first launch, so the app keeps it after the welcome pages.

## Rosella 1.1.100

- New Privacy Policy and Terms of Use pages, in Settings (Arabic and English).
- Friendlier, more natural wording for welcome messages, errors and buttons in Arabic.

## Rosella 1.1.99

- New app icon: a glowing white crescent beside "rosella" on black.
- The same mark (white on black) now appears in the opening screen and the welcome screens.
- New look for delete and confirmation dialogs: a card rising from the bottom with a separate Cancel button.

## Rosella 1.1.98

- Fixed the build error in the update sheet (missing helper functions).
- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.

## Rosella 1.1.97

- New app icon: "rosella" in rounded lettering with sparkles, on a soft green background.
- The same wordmark appears in the opening screen and the welcome screens.

## Rosella 1.1.96

- New app icon: the name written in bold lettering with sparkles, over a soft violet background.
- The same wordmark with sparkles now appears in the opening screen and the welcome screens.
- Welcome and feature screens are plain black now, without colour gradients.

## Rosella 1.1.95

- Fixed Settings jumping back to the top while scrolling quickly right after opening the app.
- Dream search by meaning is more reliable: it retries another route and falls back to a word search instead of failing.
- "Check again" moved from the update sheet to a small refresh icon next to "Check for update" in Settings.
- Removed the Gold, Sunset and Space themes.
- New users start with the phone's own haptics only; the motor vibration is off by default.

## Rosella 1.1.94

- Fixed the language page: rows no longer disappear and come back while scrolling.
- The Dynamic theme now uses the same violet, magenta and indigo colours as the welcome screens.
- Dynamic is now the default theme for new users.

## Rosella 1.1.93

- New full-screen language page on first launch: moving violet light, drifting stars, the app mark and rows that rise in one by one.
- "Discover the secrets of your dreams" now flies in letter by letter with a soft blur, in a more elegant font.
- Background stars never stop moving and twinkling.
- Welcome pages (sky, quotes, onboarding and "Welcome") have a black background with slowly moving violet and magenta gradients.
- The app mark in the welcome page has a colour gradient that keeps turning.
- Automatic cleanup of unneeded cache files, and a smaller picture cache.

## Rosella 1.1.92

- New settings icon: a detailed gear with fine teeth, matching the reference design.
- In-app update: you can now pause and resume the download, and it continues from where it stopped.
- You can cancel a download at any time from the update sheet.
- "Check again" button in the update sheet, so you can look for a newer release even when an update is already available.

- Settings tab: new gear icon (12 teeth, three spokes and a hub) drawn in the same single colour as the other tab icons
- Round buttons and filter chips (moods, favourites, private, week/month/year) now use the dark glass look of the "Ask AI" reference: soft top-lit fill and a thin bright rim
- Bottom bar: smaller, flatter and faster glass pill (soft light fill, hairline rim, no shadow), like the reference designs
- Smoothness: the app asks the phone for its highest refresh rate again whenever it opens or returns, and the round buttons no longer blur the background (up to 8 blur layers per screen removed)
- Dream page opens with a plain slide from the left (no zoom/scale)
- Fewer effects: the moving sheen on buttons is removed to save battery and keep scrolling smooth
- Bottom bar: the glass lens now follows slow drags smoothly
- Dream page: the edit (pencil) button moved down next to the title
- Dream cards: Material 3 container transform (the card grows into the dream page and shrinks back to its place)
- Fixed: opening a picture no longer pushes the dream page to the left behind it
- You can now delete a dream's interpretation (trash icon in the interpretation card)
- Bottom bar: the glass lens follows your finger again while dragging, and still glides smoothly to the tab on a long press
- Opening a dream is smoother: the heavy parts (picture, selectable text, audio, similar dreams) now load right after the page finishes sliding in
- Bottom bar: bigger glass lens
- Bottom bar: long-pressing a tab now slides the glass lens to it smoothly instead of jumping
- Performance: pages no longer rebuild while the keyboard opens, lighter image filtering on dream cards
- Static interface: no more entrance animations; counters, progress bars and charts show their final value at once and never replay when scrolling or reopening a page
- Opening a dream: the card-grow animation is removed; the page now slides in from the right
- Cards: smoother entrance of the dream cards (one short ease-out, no bounce) and a cleaner open animation
- Themes: the deep black theme now sits right next to the Dynamic theme at the top
- Performance: faster and lighter bottom-bar glass slider, quicker tab switching (all pages are prepared quietly in the background), lighter blur and cached layers
- Voice to text: other languages (Russian, French, German, Turkish, Japanese, Chinese and more) are recognised in automatic mode instead of being sent to the Kurdish engine
- Voice to text: Arabic now uses the most accurate engine (better with Iraqi dialect), language detection no longer misroutes Arabic to Kurdish, invented phrases and repeated loops are removed, and recording uses noise suppression and auto gain
- Smoother dream-card opening animation
- Update window: full-width download button, icons always grey in every theme
- Bottom bar: icons between the old and new tab no longer flicker when jumping tabs
- Onboarding: animated floating icons with orbiting rings, slow staggered text and drifting light behind every page
- AMOLED is on by default for new users, and its switch is hidden in light mode
- Search: the keyboard no longer closes after typing the first letter
- Bottom bar is now clearly blurred (frosted glass); settings cards are deep black
- Home: removed the large grey top card (mood colour bar and dream counter) that overlapped the header
- Bottom bar: switching tabs no longer animates the bar or its icons
- AMOLED black mode (Settings → Appearance): everything pure black in dark mode
- Moving dark-grey metal surface on the search field, the update button and the sign-in buttons; main buttons get a gliding light sheen
- Bottom bar: dark transparent black, icons no longer react while the glass slider passes
- The + buttons are dark glass like the rest; Mono theme removed
- Welcome screen is pure black with its animations
- New Inter font (free open-source, very close to the iPhone look)
- Round icon buttons and the + button are frosted glass; bottom bar uses filled icon for the selected tab and outlined icons for the others
- Setting: show or hide the tab names under the bottom-bar icons
- Bottom bar: removed the orange rim and the icon pulsing; slower, smoother liquid-glass slider that stretches while it moves and may bulge past the ends
- Bottom bar redesigned: light-orange rim, transparent glass slider that magnifies the active tab, and it shrinks to icons only (and drops lower) while you scroll down
- Removed the Glass theme
- New home header: big gradient card in the colour of your overall mood, with your latest dream, a large dream counter and a mood scale
- New languages: Romanian, Greek, Armenian, Azerbaijani, Chinese (Hindi removed)
- Times now use the 12-hour clock (AM/PM)
- Nightmare SOS: added the birds sound
- Appearance: choose Dark, Light, Auto (pick the hours dark mode switches on and off) or System (follows your device)
- Fixed the build failure caused by a crash inside the Android lint check
- Late-recording reminder: an optional gentle notification if you haven't logged a dream today (Settings)
- Nightmare SOS: a calm page in Sounds with a slow breathing circle, soothing sounds and a quick way to sleep or write the dream
- The sleep timer now fades the sound out gradually at the end instead of cutting it
- A round arrow button jumps back to the top of your dreams list, and to the latest message in chats
- Updates now download inside Rosella (no system download app) and the file is checked to be complete before installing
- Tap the progress button again to cancel a download
- The update sheet now has a proper landscape layout
- AI chat: a rewrite button next to the last answer writes it again in a different way
- Fixed the flicker in the filter rows when switching week / month / year
- Lighter, smoother page transitions; the Insights page is prepared in the background
- A softer, more refined look: glassy card edges, glossy buttons, gentle vignette
- New suggestion prompts in the AI chat, with a calm moving glow
- Haptic feedback when an AI answer finishes and when a voice recording stops
- New: your year in dreams, an animated yearly summary you can share
- New: search your dreams by meaning, not only by exact words
- New: similar dreams are suggested under every dream
- Fixed uneven white edges around dream cards that have an image
- Welcome: a small language card appears first, then the night-sky intro
- New first-run experience: night sky, eclipse and Google sign-in
- Language picker is now a grid of tiles
- A warp-speed "Welcome to Rosella" entrance after setup
- New update sheet with release notes, file size and download progress
- Pin dreams to the top of your list
- Update downloads keep running in the background
- Kurdish typed with Arabic letters is now understood by the AI
- Smoother and clearer app opening animation
